(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../assetlist.schema.json',
    chainName: 'neutron',
    assets: [
        {
            description: 'Neutron is a smart contract blockchain within the Cosmos ecosystem, leveraging the Cosmos Hub\'s security to provide cross-chain DeFi applications.',
            extendedDescription: 'Neutron is a blockchain network designed to bring smart contracts to the Cosmos ecosystem using CosmWasm. It leverages Interchain Security to rely on the Cosmos Hub\'s validator set, enhancing its security without needing its own validators. This allows Neutron to provide robust, cross-chain smart contract applications across more than 50 interconnected blockchains. Neutron\'s focus on interchain queries and transactions enables secure data retrieval and transaction execution across multiple chains, fostering the development of complex and decentralized applications within the Cosmos network.',
            denomUnits: [
                {
                    denom: 'untrn',
                    exponent: 0
                },
                {
                    denom: 'ntrn',
                    exponent: 6
                }
            ],
            base: 'untrn',
            name: 'Neutron',
            display: 'ntrn',
            symbol: 'NTRN',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.svg'
            },
            coingeckoId: 'neutron-3',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.svg',
                    theme: {
                        primaryColorHex: '#040404',
                        backgroundColorHex: '#000000',
                        circle: true
                    }
                }
            ],
            socials: {
                website: 'https://neutron.org/',
                twitter: 'https://twitter.com/Neutron_org'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'IBC uatom through cosmoshub-4 transfer/channel-1',
            denomUnits: [
                {
                    denom: 'ibc/C4CFF46FD6DE35CA4CF4CE031E643C8FDC9BA4B99AE598E9B0ED98FE3A2319F9',
                    exponent: 0,
                    aliases: [
                        'uatom'
                    ]
                },
                {
                    denom: 'atom',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/C4CFF46FD6DE35CA4CF4CE031E643C8FDC9BA4B99AE598E9B0ED98FE3A2319F9',
            name: 'IBC atom',
            display: 'atom',
            symbol: 'ATOM',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'cosmoshub',
                        baseDenom: 'uatom',
                        channelId: 'channel-569'
                    },
                    chain: {
                        channelId: 'channel-1',
                        path: 'transfer/channel-1/uatom'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'cosmoshub',
                        baseDenom: 'uatom'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg',
                    theme: {
                        primaryColorHex: '#272d45'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg'
            },
            coingeckoId: 'cosmos'
        },
        {
            description: 'IBC Axelar uusdc through axelar-dojo-1 transfer/channel-2',
            denomUnits: [
                {
                    denom: 'ibc/F082B65C88E4B6D5EF1DB243CDA1D331D002759E938A0F5CD3FFDC5D53B3E349',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/F082B65C88E4B6D5EF1DB243CDA1D331D002759E938A0F5CD3FFDC5D53B3E349',
            name: 'USD Coin (Axelar)',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdc',
                        channelId: 'channel-78'
                    },
                    chain: {
                        channelId: 'channel-2',
                        path: 'transfer/channel-2/uusdc'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'uusdc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/usdc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/usdc.svg',
                    theme: {
                        primaryColorHex: '#2474cc'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/usdc.svg'
            },
            coingeckoId: 'axlusdc'
        },
        {
            description: 'Tia on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/773B4D0A3CD667B2275D5A4A7A2F0909C0BA0F4059C0B9181E680DDF4965DCC7',
                    exponent: 0,
                    aliases: [
                        'utia'
                    ]
                },
                {
                    denom: 'tia',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/773B4D0A3CD667B2275D5A4A7A2F0909C0BA0F4059C0B9181E680DDF4965DCC7',
            name: 'Celestia TIA',
            display: 'tia',
            symbol: 'TIA',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'celestia',
                        baseDenom: 'utia',
                        channelId: 'channel-8'
                    },
                    chain: {
                        channelId: 'channel-35',
                        path: 'transfer/channel-35/utia'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'celestia',
                        baseDenom: 'utia'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.svg',
                    theme: {
                        primaryColorHex: '#7c2cfb'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/celestia/images/celestia.svg'
            },
            coingeckoId: 'celestia'
        },
        {
            description: 'ELYS on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/28FC965E05DB1A4C0A6DE6B720F67AFF8CAB571FE262824976DDDFF49A4BAAF7',
                    exponent: 0,
                    aliases: [
                        'uelys'
                    ]
                },
                {
                    denom: 'elys',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/28FC965E05DB1A4C0A6DE6B720F67AFF8CAB571FE262824976DDDFF49A4BAAF7',
            name: 'ELYS',
            display: 'elys',
            symbol: 'ELYS',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'elys',
                        baseDenom: 'uelys',
                        channelId: 'channel-16'
                    },
                    chain: {
                        channelId: 'channel-6476',
                        path: 'transfer/channel-6476/uelys'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'elys',
                        baseDenom: 'uelys'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/elys/images/elys.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/elys/images/elys.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/elys/images/elys.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/elys/images/elys.svg'
            },
            coingeckoId: 'elys-network'
        },
        {
            description: 'Astropepe meme coin',
            denomUnits: [
                {
                    denom: 'factory/neutron14henrqx9y328fjrdvz6l6d92r0t7g5hk86q5nd/uastropepe',
                    exponent: 0
                },
                {
                    denom: 'ASTROPEPE',
                    exponent: 6
                }
            ],
            base: 'factory/neutron14henrqx9y328fjrdvz6l6d92r0t7g5hk86q5nd/uastropepe',
            name: 'AstroPepe',
            display: 'ASTROPEPE',
            symbol: 'ASTROPEPE',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astropepe.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astropepe.png',
                    theme: {
                        primaryColorHex: '#47391d'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'wstETH on Neutron',
            denomUnits: [
                {
                    denom: 'factory/neutron1ug740qrkquxzrk2hh29qrlx3sktkfml3je7juusc2te7xmvsscns0n2wry/wstETH',
                    exponent: 0
                },
                {
                    denom: 'wstETH',
                    exponent: 18
                }
            ],
            base: 'factory/neutron1ug740qrkquxzrk2hh29qrlx3sktkfml3je7juusc2te7xmvsscns0n2wry/wstETH',
            name: 'wstETH',
            display: 'wstETH',
            symbol: 'wstETH',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0'
                    },
                    provider: 'Lido wstETH Cosmos Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wsteth.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wsteth.svg'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'DYDX on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/2CB87BCE0937B1D1DFCEE79BE4501AAF3C265E923509AEAC410AD85D27F35130',
                    exponent: 0,
                    aliases: [
                        'adydx'
                    ]
                },
                {
                    denom: 'dydx',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/2CB87BCE0937B1D1DFCEE79BE4501AAF3C265E923509AEAC410AD85D27F35130',
            name: 'DYDX',
            display: 'dydx',
            symbol: 'DYDX',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'dydx',
                        baseDenom: 'adydx',
                        channelId: 'channel-11'
                    },
                    chain: {
                        channelId: 'channel-48',
                        path: 'transfer/channel-48/adydx'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'dydx',
                        baseDenom: 'adydx'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/dydx/images/dydx.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/dydx/images/dydx.svg',
                    theme: {
                        primaryColorHex: '#21212f'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/dydx/images/dydx.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/dydx/images/dydx.svg'
            },
            coingeckoId: 'dydx-chain'
        },
        {
            description: 'The cutest NEWT token on Neutron chain.',
            denomUnits: [
                {
                    denom: 'factory/neutron1p8d89wvxyjcnawmgw72klknr3lg9gwwl6ypxda/newt',
                    exponent: 0,
                    aliases: [
                        'unewt'
                    ]
                },
                {
                    denom: 'newt',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1p8d89wvxyjcnawmgw72klknr3lg9gwwl6ypxda/newt',
            name: 'Newt',
            display: 'newt',
            symbol: 'NEWT',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/newt.png'
            },
            coingeckoId: 'newt',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/newt.png',
                    theme: {
                        primaryColorHex: '#16233d'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Astroport is a neutral marketplace where anyone, from anywhere in the galaxy, can dock to trade their wares.',
            denomUnits: [
                {
                    denom: 'factory/neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07/astro',
                    exponent: 0,
                    aliases: [
                        'uastro'
                    ]
                },
                {
                    denom: 'astro',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07/astro',
            name: 'Astroport token',
            display: 'astro',
            symbol: 'ASTRO',
            coingeckoId: 'astroport-fi',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astro.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astro.svg',
                    theme: {
                        primaryColorHex: '#4056e9'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astro.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/astro.svg'
            },
            socials: {
                website: 'https://astroport.fi/',
                twitter: 'https://twitter.com/astroport_fi'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Astroport is a neutral marketplace where anyone, from anywhere in the galaxy, can dock to trade their wares.',
            denomUnits: [
                {
                    denom: 'factory/neutron1zlf3hutsa4qnmue53lz2tfxrutp8y2e3rj4nkghg3rupgl4mqy8s5jgxsn/xASTRO',
                    exponent: 0,
                    aliases: [
                        'uxastro'
                    ]
                },
                {
                    denom: 'xASTRO',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1zlf3hutsa4qnmue53lz2tfxrutp8y2e3rj4nkghg3rupgl4mqy8s5jgxsn/xASTRO',
            name: 'Staked Astroport Token',
            display: 'xASTRO',
            symbol: 'xASTRO',
            traces: [
                {
                    type: 'liquid-stake',
                    counterparty: {
                        chainName: 'neutron',
                        baseDenom: 'factory/neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07/astro'
                    },
                    provider: 'Astroport'
                }
            ],
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xAstro.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xAstro.svg'
            },
            socials: {
                website: 'https://astroport.fi/',
                twitter: 'https://twitter.com/astroport_fi'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'ASTRO.cw20 on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/5751B8BCDA688FD0A8EC0B292EEF1CDEAB4B766B63EC632778B196D317C40C3A',
                    exponent: 0,
                    aliases: [
                        'uastro'
                    ]
                },
                {
                    denom: 'astro.cw20',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/5751B8BCDA688FD0A8EC0B292EEF1CDEAB4B766B63EC632778B196D317C40C3A',
            name: 'Astroport CW20 token',
            display: 'astro.cw20',
            symbol: 'ASTRO.cw20',
            traces: [
                {
                    type: 'ibc-cw20',
                    counterparty: {
                        chainName: 'terra2',
                        baseDenom: 'cw20:terra1nsuqsk6kh58ulczatwev87ttq2z6r3pusulg9r24mfj2fvtzd4uq3exn26',
                        channelId: 'channel-167',
                        port: 'wasm.terra1jhfjnm39y3nn9l4520mdn4k5mw23nz0674c4gsvyrcr90z9tqcvst22fce'
                    },
                    chain: {
                        channelId: 'channel-5',
                        path: 'transfer/channel-5/cw20:terra1nsuqsk6kh58ulczatwev87ttq2z6r3pusulg9r24mfj2fvtzd4uq3exn26',
                        port: 'transfer'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'terra2',
                        baseDenom: 'cw20:terra1nsuqsk6kh58ulczatwev87ttq2z6r3pusulg9r24mfj2fvtzd4uq3exn26'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/terra2/images/astro-cw20.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/terra2/images/astro-cw20.svg'
            },
            coingeckoId: 'astroport-fi'
        },
        {
            description: 'Baby Corgi is the real doggo of Neutron!',
            denomUnits: [
                {
                    denom: 'factory/neutron1tklm6cvr2wxg8k65t8gh5ewslnzdfd5fsk0w3f/corgi',
                    exponent: 0,
                    aliases: [
                        'ucorgi'
                    ]
                },
                {
                    denom: 'corgi',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1tklm6cvr2wxg8k65t8gh5ewslnzdfd5fsk0w3f/corgi',
            name: 'Baby Corgi',
            display: 'corgi',
            symbol: 'CORGI',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/babycorgi.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/babycorgi.png',
                    theme: {
                        primaryColorHex: '#fab442'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'clownmaxxed store of value',
            denomUnits: [
                {
                    denom: 'factory/neutron170v88vrtnedesyfytuku257cggxc79rd7lwt7q/ucircus',
                    exponent: 0,
                    aliases: [
                        'ucircus'
                    ]
                },
                {
                    denom: 'circus',
                    exponent: 6
                }
            ],
            base: 'factory/neutron170v88vrtnedesyfytuku257cggxc79rd7lwt7q/ucircus',
            name: 'AtomEconomicZone69JaeKwonInu',
            display: 'circus',
            symbol: 'CIRCUS',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/circus.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/circus.png',
                    theme: {
                        primaryColorHex: '#242033'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Jimmy Neutron Finance',
            denomUnits: [
                {
                    denom: 'factory/neutron108x7vp9zv22d6wxrs9as8dshd3pd5vsga463yd/JIMMY',
                    exponent: 0,
                    aliases: [
                        'ujimmy'
                    ]
                },
                {
                    denom: 'jimmy',
                    exponent: 6
                }
            ],
            base: 'factory/neutron108x7vp9zv22d6wxrs9as8dshd3pd5vsga463yd/JIMMY',
            name: 'jimmy',
            display: 'jimmy',
            symbol: 'JIMMY',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jimmy.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jimmy.png',
                    theme: {
                        primaryColorHex: '#7d3c20'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Baddest coin on Cosmos',
            denomUnits: [
                {
                    denom: 'factory/neutron143wp6g8paqasnuuey6zyapucknwy9rhnld8hkr/bad',
                    exponent: 0,
                    aliases: [
                        'ubad'
                    ]
                },
                {
                    denom: 'bad',
                    exponent: 6
                }
            ],
            base: 'factory/neutron143wp6g8paqasnuuey6zyapucknwy9rhnld8hkr/bad',
            name: 'Badcoin',
            display: 'bad',
            symbol: 'BAD',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bad.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bad.png',
                    theme: {
                        primaryColorHex: '#211a0d'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'BITCOSMOS',
            denomUnits: [
                {
                    denom: 'neutron1fjzg7fmv770hsvahqm0nwnu6grs3rjnd2wa6fvm9unv6vedkzekqpw44qj',
                    exponent: 0,
                    aliases: [
                        'ubitcosmos'
                    ]
                },
                {
                    denom: 'bitcosmos',
                    exponent: 6
                }
            ],
            base: 'neutron1fjzg7fmv770hsvahqm0nwnu6grs3rjnd2wa6fvm9unv6vedkzekqpw44qj',
            name: 'Bitcosmos',
            display: 'bitcosmos',
            symbol: 'BTC',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bitcosmos.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bitcosmos.png',
                    theme: {
                        primaryColorHex: '#1b0847'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'What the Fuck',
            denomUnits: [
                {
                    denom: 'neutron12h09p8hq5y4xpsmcuxxzsn9juef4f6jvekp8yefc6xnlwm6uumnsdk29wf',
                    exponent: 0,
                    aliases: [
                        'uwtf'
                    ]
                },
                {
                    denom: 'wtf',
                    exponent: 6
                }
            ],
            base: 'neutron12h09p8hq5y4xpsmcuxxzsn9juef4f6jvekp8yefc6xnlwm6uumnsdk29wf',
            name: 'wtf',
            display: 'wtf',
            symbol: 'WTF',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/WTF.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/WTF.png',
                    theme: {
                        primaryColorHex: '#dcd5ab'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'NLS on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/6C9E6701AC217C0FC7D74B0F7A6265B9B4E3C3CDA6E80AADE5F950A8F52F9972',
                    exponent: 0,
                    aliases: [
                        'unls'
                    ]
                },
                {
                    denom: 'nls',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/6C9E6701AC217C0FC7D74B0F7A6265B9B4E3C3CDA6E80AADE5F950A8F52F9972',
            name: 'Nolus NLS',
            display: 'nls',
            symbol: 'NLS',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'nolus',
                        baseDenom: 'unls',
                        channelId: 'channel-3839'
                    },
                    chain: {
                        channelId: 'channel-44',
                        path: 'transfer/channel-44/unls'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'nolus',
                        baseDenom: 'unls'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nolus/images/nolus.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nolus/images/nolus.svg',
                    theme: {
                        primaryColorHex: '#fc542c'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nolus/images/nolus.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nolus/images/nolus.svg'
            },
            coingeckoId: 'nolus'
        },
        {
            description: 'A Mechanical Canine',
            denomUnits: [
                {
                    denom: 'factory/neutron1t5qrjtyryh8gzt800qr5vylhh2f8cmx4wmz9mc/ugoddard',
                    exponent: 0,
                    aliases: [
                        'ugoddard'
                    ]
                },
                {
                    denom: 'goddard',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1t5qrjtyryh8gzt800qr5vylhh2f8cmx4wmz9mc/ugoddard',
            name: 'Goddard',
            display: 'goddard',
            symbol: 'GODRD',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/goddardntrn.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/goddardntrn.png',
                    theme: {
                        primaryColorHex: '#516b80'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'The deflationary utility token of the Apollo DAO project',
            denomUnits: [
                {
                    denom: 'factory/neutron154gg0wtm2v4h9ur8xg32ep64e8ef0g5twlsgvfeajqwghdryvyqsqhgk8e/APOLLO',
                    exponent: 0,
                    aliases: [
                        'uapollo'
                    ]
                },
                {
                    denom: 'apollo',
                    exponent: 6
                }
            ],
            base: 'factory/neutron154gg0wtm2v4h9ur8xg32ep64e8ef0g5twlsgvfeajqwghdryvyqsqhgk8e/APOLLO',
            name: 'Apollo DAO',
            display: 'apollo',
            symbol: 'APOLLO',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/apollo.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/apollo.svg'
                }
            ],
            socials: {
                website: 'https://apollo.farm/',
                twitter: 'https://twitter.com/ApolloDAO'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'NEWTROLL',
            denomUnits: [
                {
                    denom: 'factory/neutron1ume2n42r5j0660gegrr28fzdze7aqf7r5cd9y6/newtroll',
                    exponent: 0,
                    aliases: [
                        'unewtroll'
                    ]
                },
                {
                    denom: 'newtroll',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1ume2n42r5j0660gegrr28fzdze7aqf7r5cd9y6/newtroll',
            name: 'Newtroll',
            display: 'newtroll',
            symbol: 'NTRL',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/newtroll.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/newtroll.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Retro Game',
            denomUnits: [
                {
                    denom: 'factory/neutron1t24nc7whl77relnu3taxyg3p66pjyuk82png2y/uretro',
                    exponent: 0,
                    aliases: [
                        'uretro'
                    ]
                },
                {
                    denom: 'retro',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1t24nc7whl77relnu3taxyg3p66pjyuk82png2y/uretro',
            name: 'Retro',
            display: 'retro',
            symbol: 'RETRO',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/retro.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/retro.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'THE FIRST NATIVE GODDARD MEMECOIN ON NEUTRON',
            denomUnits: [
                {
                    denom: 'factory/neutron1yqj9vcc0y73xfxjzegaj4v8q0zefevnlpuh4rj/GODDARD',
                    exponent: 0,
                    aliases: [
                        'ugoddard'
                    ]
                },
                {
                    denom: 'goddard',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1yqj9vcc0y73xfxjzegaj4v8q0zefevnlpuh4rj/GODDARD',
            name: 'Goddard',
            display: 'goddard',
            symbol: 'GODDARD',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/goddard.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/goddard.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'The first memecoin on osmosis.',
            denomUnits: [
                {
                    denom: 'ibc/7DA39F5140741177846FCF3CFAB14450EE7F57B7794E5A94BEF73825D3741958',
                    exponent: 0
                },
                {
                    denom: 'WOSMO',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/7DA39F5140741177846FCF3CFAB14450EE7F57B7794E5A94BEF73825D3741958',
            name: 'Wosmo',
            display: 'WOSMO',
            symbol: 'WOSMO',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'osmosis',
                        baseDenom: 'factory/osmo1pfyxruwvtwk00y8z06dh2lqjdj82ldvy74wzm3/WOSMO',
                        channelId: 'channel-874'
                    },
                    chain: {
                        channelId: 'channel-10',
                        path: 'transfer/channel-10/factory/osmo1pfyxruwvtwk00y8z06dh2lqjdj82ldvy74wzm3/WOSMO'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'osmosis',
                        baseDenom: 'factory/osmo1pfyxruwvtwk00y8z06dh2lqjdj82ldvy74wzm3/WOSMO'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/wosmo.png',
                    theme: {
                        primaryColorHex: '#edd5ee'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/wosmo.png'
            }
        },
        {
            description: 'Astro BOY',
            denomUnits: [
                {
                    denom: 'neutron1uqvse8fdrd9tam47f2jhy9m6al6xxtqpc83f9pdnz5gdle4swc0spfnctv',
                    exponent: 0,
                    aliases: [
                        'uboy'
                    ]
                },
                {
                    denom: 'boy',
                    exponent: 6
                }
            ],
            base: 'neutron1uqvse8fdrd9tam47f2jhy9m6al6xxtqpc83f9pdnz5gdle4swc0spfnctv',
            name: 'boy',
            display: 'boy',
            symbol: 'BOY',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/boy.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/boy.png',
                    theme: {
                        primaryColorHex: '#333333'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'A clan of 11y bad kids crafting chaos on the Cosmos eco. One bad memecoin to rule them all  $BADKID. Airdropped to Badkids NFT holders and $STARS stakers. It\'s so bad, your wallet\'s throwing a tantrum for it.',
            denomUnits: [
                {
                    denom: 'ibc/9F8417FBA11E5E01F7F85DDD48C400EB746E95084C11706041663845B4A700A8',
                    exponent: 0
                },
                {
                    denom: 'BADKID',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9F8417FBA11E5E01F7F85DDD48C400EB746E95084C11706041663845B4A700A8',
            name: 'Badkid',
            display: 'BADKID',
            symbol: 'BADKID',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'osmosis',
                        baseDenom: 'factory/osmo10n8rv8npx870l69248hnp6djy6pll2yuzzn9x8/BADKID',
                        channelId: 'channel-874'
                    },
                    chain: {
                        channelId: 'channel-10',
                        path: 'transfer/channel-10/factory/osmo10n8rv8npx870l69248hnp6djy6pll2yuzzn9x8/BADKID'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'osmosis',
                        baseDenom: 'factory/osmo10n8rv8npx870l69248hnp6djy6pll2yuzzn9x8/BADKID'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/badkid.png',
                    theme: {
                        primaryColorHex: '#57443f'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/badkid.png'
            }
        },
        {
            description: 'Reflections of cartel activity on Cosmos.',
            denomUnits: [
                {
                    denom: 'factory/neutron1w0pz4mjw7n96kkragj8etgfgakg5vw9lzg77wq/cartel',
                    exponent: 0,
                    aliases: [
                        'ucartel'
                    ]
                },
                {
                    denom: 'cartel',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1w0pz4mjw7n96kkragj8etgfgakg5vw9lzg77wq/cartel',
            name: 'cartel',
            display: 'cartel',
            symbol: 'CARTEL',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/cartel.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/cartel.png',
                    theme: {
                        primaryColorHex: '#8c9098'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: '$ATOM to $1,000 LFG!!',
            denomUnits: [
                {
                    denom: 'factory/neutron13lkh47msw28yynspc5rnmty3yktk43wc3dsv0l/ATOM1KLFG',
                    exponent: 0,
                    aliases: [
                        'uatom1klfg'
                    ]
                },
                {
                    denom: 'ATOM1KLFG',
                    exponent: 6
                }
            ],
            base: 'factory/neutron13lkh47msw28yynspc5rnmty3yktk43wc3dsv0l/ATOM1KLFG',
            name: 'ATOM1KLFG',
            display: 'ATOM1KLFG',
            symbol: 'ATOM1KLFG',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ATOM1KLFGc.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ATOM1KLFGc.png',
                    theme: {
                        primaryColorHex: '#040404'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            typeAsset: 'ics20',
            description: 'USD Coin on Neutron',
            denomUnits: [
                {
                    denom: 'ibc/B559A80D62249C8AA07A380E2A2BEA6E5CA9A6F079C912C3A9E9B494105E4F81',
                    exponent: 0,
                    aliases: [
                        'uusdc',
                        'microusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: 'ibc/B559A80D62249C8AA07A380E2A2BEA6E5CA9A6F079C912C3A9E9B494105E4F81',
            name: 'USD Coin',
            display: 'usdc',
            symbol: 'USDC',
            coingeckoId: 'usd-coin',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'noble',
                        baseDenom: 'uusdc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    }
                }
            ],
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        channelId: 'channel-18',
                        baseDenom: 'uusdc',
                        chainName: 'noble'
                    },
                    chain: {
                        channelId: 'channel-30',
                        path: 'transfer/channel-30/uusdc'
                    }
                }
            ]
        },
        {
            description: 'WEIRD FRIENDS token',
            denomUnits: [
                {
                    denom: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/WEIRD',
                    exponent: 0,
                    aliases: [
                        'uWEIRD'
                    ]
                },
                {
                    denom: 'WEIRD',
                    exponent: 6
                }
            ],
            base: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/WEIRD',
            name: 'WEIRD',
            display: 'WEIRD',
            symbol: 'WEIRD',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/WEIRD.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/WEIRD.png',
                    theme: {
                        primaryColorHex: '#ebf0f4'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            denomUnits: [
                {
                    denom: 'factory/neutron19tynwawkm2rgefqxy7weupu4hdamyhg890zep2/TAKUMI',
                    exponent: 0,
                    aliases: [
                        'utakumi'
                    ]
                },
                {
                    denom: 'takumi',
                    exponent: 6
                }
            ],
            base: 'factory/neutron19tynwawkm2rgefqxy7weupu4hdamyhg890zep2/TAKUMI',
            name: 'Takumi Asano',
            display: 'takumi',
            symbol: 'TAKUMI',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/TAKUMI.png',
                    theme: {
                        primaryColorHex: '#556867'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Ninja Blaze is a decentralized multi-chain gaming platform powered by Injective Blockchain.',
            extendedDescription: 'The only truly decentralized gaming platform. Shape the future of gaming by owning Ninja Blaze tokens.',
            denomUnits: [
                {
                    denom: 'ibc/A79E35F2418EB26FA8D72B9AA5EDF28C0C2CF475E8CF4CAEBB25FA5C858D4D22',
                    exponent: 0,
                    aliases: [
                        'uNBZ'
                    ]
                },
                {
                    denom: 'NBZ',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/A79E35F2418EB26FA8D72B9AA5EDF28C0C2CF475E8CF4CAEBB25FA5C858D4D22',
            name: 'Ninja Blaze',
            display: 'NBZ',
            symbol: 'NBZ',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'injective',
                        baseDenom: 'factory/inj1llr45x92t7jrqtxvc02gpkcqhqr82dvyzkr4mz/NBZ',
                        channelId: 'channel-177'
                    },
                    chain: {
                        channelId: 'channel-60',
                        path: 'transfer/channel-60/factory/inj1llr45x92t7jrqtxvc02gpkcqhqr82dvyzkr4mz/NBZ'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'injective',
                        baseDenom: 'factory/inj1llr45x92t7jrqtxvc02gpkcqhqr82dvyzkr4mz/NBZ'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/injective/images/NBZ.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/injective/images/NBZ.svg',
                    theme: {
                        primaryColorHex: '#9890f9'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/injective/images/NBZ.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/injective/images/NBZ.svg'
            },
            socials: {
                website: 'https://blaze.ninja',
                twitter: 'https://x.com/NinjaBlazeApp'
            }
        },
        {
            description: 'Mars Protocol is a cross-collateralized Money Market Protocol on Neutron and Osmosis.',
            extendedDescription: 'Lend, borrow and earn with an autonomous credit protocol in the Cosmos universe. Open to all, closed to none.',
            denomUnits: [
                {
                    denom: 'factory/neutron1ndu2wvkrxtane8se2tr48gv7nsm46y5gcqjhux/MARS',
                    exponent: 0,
                    aliases: [
                        'umars'
                    ]
                },
                {
                    denom: 'MARS',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1ndu2wvkrxtane8se2tr48gv7nsm46y5gcqjhux/MARS',
            name: 'Mars Protocol token',
            display: 'MARS',
            symbol: 'MARS',
            coingeckoId: 'mars-protocol-a7fcbcfb-fd61-4017-92f0-7ee9f9cc6da3',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.svg',
                    theme: {
                        primaryColorHex: '#ef4136'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.svg'
            },
            socials: {
                website: 'https://marsprotocol.io/',
                twitter: 'https://x.com/mars_protocol'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Drop staked NTRN',
            extendedDescription: 'Drop protocol token for the interchain liquidity',
            denomUnits: [
                {
                    denom: 'factory/neutron1frc0p5czd9uaaymdkug2njz7dc7j65jxukp9apmt9260a8egujkspms2t2/udntrn',
                    exponent: 0
                },
                {
                    denom: 'dNTRN',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1frc0p5czd9uaaymdkug2njz7dc7j65jxukp9apmt9260a8egujkspms2t2/udntrn',
            name: 'dNTRN',
            display: 'dNTRN',
            symbol: 'dNTRN',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dNTRN.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dNTRN.svg'
            },
            socials: {
                website: 'https://www.drop.money/',
                twitter: 'https://x.com/Dropdotmoney'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Drop staked ATOM',
            extendedDescription: 'Drop protocol token for the interchain liquidity',
            denomUnits: [
                {
                    denom: 'factory/neutron1k6hr0f83e7un2wjf29cspk7j69jrnskk65k3ek2nj9dztrlzpj6q00rtsa/udatom',
                    exponent: 0
                },
                {
                    denom: 'dATOM',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1k6hr0f83e7un2wjf29cspk7j69jrnskk65k3ek2nj9dztrlzpj6q00rtsa/udatom',
            name: 'dATOM',
            display: 'dATOM',
            symbol: 'dATOM',
            coingeckoId: 'drop-staked-atom',
            traces: [
                {
                    type: 'liquid-stake',
                    counterparty: {
                        chainName: 'cosmoshub',
                        baseDenom: 'uatom'
                    },
                    provider: 'Drop Protocol'
                }
            ],
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dATOM.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dATOM.svg'
            },
            socials: {
                website: 'https://www.drop.money/',
                twitter: 'https://x.com/Dropdotmoney'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'SinGarden token',
            denomUnits: [
                {
                    denom: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/sin',
                    exponent: 0,
                    aliases: [
                        'uSIN'
                    ]
                },
                {
                    denom: 'SIN',
                    exponent: 6
                }
            ],
            base: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/sin',
            name: 'SIN',
            display: 'SIN',
            symbol: 'SIN',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/sin.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/sin.png',
                    theme: {
                        primaryColorHex: '#ebf0f4'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'CryptoGopniks token',
            denomUnits: [
                {
                    denom: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/GOP',
                    exponent: 0,
                    aliases: [
                        'uGOP'
                    ]
                },
                {
                    denom: 'GOP',
                    exponent: 6
                }
            ],
            base: 'factory/neutron133xakkrfksq39wxy575unve2nyehg5npx75nph/GOP',
            name: 'GOP',
            display: 'GOP',
            symbol: 'GOP',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/gop.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/gop.png',
                    theme: {
                        primaryColorHex: '#000000'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            typeAsset: 'sdk.coin',
            denomUnits: [
                {
                    denom: 'factory/neutron129ukd5cwahcjkccujz87rjemjukff7jf6sau72qrhva677xgz9gs4m4jeq/uarena',
                    exponent: 0,
                    aliases: [
                        'uarena'
                    ]
                },
                {
                    denom: 'arena',
                    exponent: 6
                }
            ],
            base: 'factory/neutron129ukd5cwahcjkccujz87rjemjukff7jf6sau72qrhva677xgz9gs4m4jeq/uarena',
            name: 'Arena Token',
            display: 'arena',
            symbol: 'ARENA',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/arena_dao.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/arena_dao.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/arena_dao.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/arena_dao.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#FF8000'
                    }
                }
            ],
            description: 'The governance token of the Arena DAO',
            socials: {
                twitter: 'https://x.com/ArenaDAO',
                website: 'https://arenadao.org/'
            }
        },
        {
            description: 'Astrovault AXV',
            denomUnits: [
                {
                    denom: 'cw20:neutron10dxyft3nv4vpxh5vrpn0xw8geej8dw3g39g7nqp8mrm307ypssksau29af',
                    exponent: 0
                },
                {
                    denom: 'AXV',
                    exponent: 6
                }
            ],
            typeAsset: 'cw20',
            address: 'neutron10dxyft3nv4vpxh5vrpn0xw8geej8dw3g39g7nqp8mrm307ypssksau29af',
            base: 'cw20:neutron10dxyft3nv4vpxh5vrpn0xw8geej8dw3g39g7nqp8mrm307ypssksau29af',
            name: 'Astrovault AXV (Neutron)',
            display: 'AXV',
            symbol: 'AXV',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/axv.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/axv.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/axv.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/axv.svg'
                }
            ],
            socials: {
                website: 'https://astrovault.io/',
                twitter: 'https://x.com/axvdex'
            },
            coingeckoId: 'astrovault'
        },
        {
            description: 'IBC Axelar wbtc-satoshi through axelar-dojo-1 transfer/channel-2',
            denomUnits: [
                {
                    denom: 'ibc/DF8722298D192AAB85D86D0462E8166234A6A9A572DD4A2EA7996029DF4DB363',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'axlwbtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/DF8722298D192AAB85D86D0462E8166234A6A9A572DD4A2EA7996029DF4DB363',
            name: 'Wrapped Bitcoin (Axelar)',
            display: 'axlwbtc',
            symbol: 'axlWBTC',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'wbtc-satoshi',
                        channelId: 'channel-78'
                    },
                    chain: {
                        channelId: 'channel-2',
                        path: 'transfer/channel-2/wbtc-satoshi'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/wbtc.png'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'wbtc-satoshi'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/axelar/images/wbtc.png',
                    theme: {
                        primaryColorHex: '#41394d'
                    }
                }
            ],
            coingeckoId: 'axlwbtc'
        },
        {
            description: 'Astrovault xATOM on Neutron Chain',
            denomUnits: [
                {
                    denom: 'cw20:neutron1vjl4ze7gr32lar5s4fj776v70j4ml7mlt4aqln2hwgfhqjck8xwqfhx8vj',
                    exponent: 0
                },
                {
                    denom: 'xATOM',
                    exponent: 6
                }
            ],
            typeAsset: 'cw20',
            address: 'neutron1vjl4ze7gr32lar5s4fj776v70j4ml7mlt4aqln2hwgfhqjck8xwqfhx8vj',
            base: 'cw20:neutron1vjl4ze7gr32lar5s4fj776v70j4ml7mlt4aqln2hwgfhqjck8xwqfhx8vj',
            name: 'Astrovault xATOM (Neutron)',
            display: 'xATOM',
            symbol: 'xATOM',
            traces: [
                {
                    type: 'liquid-stake',
                    counterparty: {
                        chainName: 'neutron',
                        baseDenom: 'ibc/C4CFF46FD6DE35CA4CF4CE031E643C8FDC9BA4B99AE598E9B0ED98FE3A2319F9'
                    },
                    provider: 'Astrovault'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xatom.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xatom.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xatom.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/xatom.svg'
                }
            ],
            coingeckoId: 'astrovault-xatom'
        },
        {
            description: 'The advance token for ATOM denominated vaults on Amulet Protocol',
            denomUnits: [
                {
                    denom: 'factory/neutron1shwxlkpdjd8h5wdtrykypwd2v62z5glr95yp0etdcspkkjwm5meq82ndxs/amatom',
                    exponent: 0
                },
                {
                    denom: 'amATOM',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1shwxlkpdjd8h5wdtrykypwd2v62z5glr95yp0etdcspkkjwm5meq82ndxs/amatom',
            name: 'amATOM',
            display: 'amATOM',
            symbol: 'amATOM',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'neutron',
                        baseDenom: 'ibc/C4CFF46FD6DE35CA4CF4CE031E643C8FDC9BA4B99AE598E9B0ED98FE3A2319F9',
                        contract: 'neutron16d4a7q3wfkkawj4jwyzz6g97xtmj0crkyn06ev74fu4xsgkwnreswzfpcy'
                    },
                    provider: 'Amulet'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/amATOM.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/amATOM.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/amATOM.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/amATOM.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Liquid Staked USDC',
            denomUnits: [
                {
                    denom: 'factory/neutron1mdy5fhtwdjagp5eallsdhlx6gxylm8rxqk72wjzg6y5d5kt44ysqprkduw/JSD',
                    exponent: 0
                },
                {
                    denom: 'JSD',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1mdy5fhtwdjagp5eallsdhlx6gxylm8rxqk72wjzg6y5d5kt44ysqprkduw/JSD',
            name: 'Jade',
            display: 'JSD',
            symbol: 'JSD',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jsd.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jsd.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jsd.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/jsd.svg'
                }
            ],
            socials: {
                website: 'https://Jade.Money',
                twitter: 'https://x.com/jadedotmoney'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Boost DAO FUEL',
            denomUnits: [
                {
                    denom: 'factory/neutron1zl2htquajn50vxu5ltz0y5hf2qzvkgnjaaza2rssef268xplq6vsjuruxm/fuel',
                    exponent: 0
                },
                {
                    denom: 'FUEL',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1zl2htquajn50vxu5ltz0y5hf2qzvkgnjaaza2rssef268xplq6vsjuruxm/fuel',
            name: 'FUEL',
            display: 'FUEL',
            symbol: 'FUEL',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/fuel.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/fuel.png'
                }
            ],
            socials: {
                website: 'https://www.boostdao.io',
                twitter: 'https://x.com/boost_dao'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Bonded GopLend USDC',
            extendedDescription: 'bglUSDC (Bonded GopLend USDC) is issued in exchange for USDC for the deposit period. These tokens are liquid and generate income in the amount of the set APR on the platform',
            denomUnits: [
                {
                    denom: 'factory/neutron16ue9kysgneyqktmjxdfshajgvlrcx9rehxz8x9th7g8fgtnlxwuqvg9mgp/bglUSDC',
                    exponent: 0
                },
                {
                    denom: 'bglUSDC',
                    exponent: 6
                }
            ],
            base: 'factory/neutron16ue9kysgneyqktmjxdfshajgvlrcx9rehxz8x9th7g8fgtnlxwuqvg9mgp/bglUSDC',
            name: 'bglUSDC',
            display: 'bglUSDC',
            symbol: 'bglUSDC',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bglUSDC.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/bglUSDC.png'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Drop staked TIA',
            extendedDescription: 'Drop protocol token for the interchain liquidity',
            denomUnits: [
                {
                    denom: 'factory/neutron1ut4c6pv4u6vyu97yw48y8g7mle0cat54848v6m97k977022lzxtsaqsgmq/udtia',
                    exponent: 0
                },
                {
                    denom: 'dTIA',
                    exponent: 6
                }
            ],
            base: 'factory/neutron1ut4c6pv4u6vyu97yw48y8g7mle0cat54848v6m97k977022lzxtsaqsgmq/udtia',
            name: 'dTIA',
            display: 'dTIA',
            symbol: 'dTIA',
            traces: [
                {
                    type: 'liquid-stake',
                    counterparty: {
                        chainName: 'celestia',
                        baseDenom: 'utia'
                    },
                    provider: 'Drop Protocol'
                }
            ],
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dTIA.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/dTIA.svg'
            },
            socials: {
                website: 'https://www.drop.money/',
                twitter: 'https://x.com/Dropdotmoney'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'IBC NEPT, Neptune Protocol token, on Neutron chain',
            denomUnits: [
                {
                    denom: 'ibc/C084B31AB4906CD6CC65CB779B1527A66B6C98629259E3548B2F20D2753D5837',
                    exponent: 0
                },
                {
                    denom: 'NEPT',
                    exponent: 6
                }
            ],
            base: 'ibc/C084B31AB4906CD6CC65CB779B1527A66B6C98629259E3548B2F20D2753D5837',
            name: 'Neptune Finance',
            display: 'NEPT',
            symbol: 'NEPT',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'injective',
                        baseDenom: 'factory/inj1v3a4zznudwpukpr8y987pu5gnh4xuf7v36jhva/nept',
                        channelId: 'channel-177'
                    },
                    chain: {
                        channelId: 'channel-60',
                        path: 'transfer/channel-60/factory/inj1v3a4zznudwpukpr8y987pu5gnh4xuf7v36jhva/nept'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'injective',
                        baseDenom: 'factory/inj1v3a4zznudwpukpr8y987pu5gnh4xuf7v36jhva/nept'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/injective/images/nept.png',
                    theme: {
                        primaryColorHex: '#21549f'
                    }
                }
            ],
            socials: {
                website: 'https://nept.finance/',
                twitter: 'https://x.com/neptune_finance'
            },
            typeAsset: 'ics20'
        },
        {
            description: 'Dogecoin on Int3face',
            denomUnits: [
                {
                    denom: 'ibc/F16C7C5B6F7E96ACDA73E35BCA3A3DE49DDF7164066A359C843E9709041CE6B9',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    ]
                },
                {
                    denom: 'doge',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/F16C7C5B6F7E96ACDA73E35BCA3A3DE49DDF7164066A359C843E9709041CE6B9',
            name: 'Dogecoin (Int3)',
            display: 'doge',
            symbol: 'DOGE.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'dogecoin',
                        baseDenom: 'shibe'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-6455',
                        path: 'transfer/channel-6455/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.png',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Bitcoin on Int3face',
            denomUnits: [
                {
                    denom: 'ibc/D9E2128761E0A60C6C7C166BF30A23E9C2029576817F16CD4BD4F598A2077C04',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    ]
                },
                {
                    denom: 'btc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/D9E2128761E0A60C6C7C166BF30A23E9C2029576817F16CD4BD4F598A2077C04',
            name: 'Bitcoin (Int3)',
            display: 'btc',
            symbol: 'BTC.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-6455',
                        path: 'transfer/channel-6455/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.png',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Bitcoin-Cash on Int3face',
            denomUnits: [
                {
                    denom: 'ibc/1D45F4770FA033E69A3A3B751263FD774952C2452F65944A1CB914E58C74A35B',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    ]
                },
                {
                    denom: 'bch',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/1D45F4770FA033E69A3A3B751263FD774952C2452F65944A1CB914E58C74A35B',
            name: 'Bitcoin Cash (Int3)',
            display: 'bch',
            symbol: 'BCH.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'bitcoincash',
                        baseDenom: 'sat'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-6455',
                        path: 'transfer/channel-6455/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.png',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Litecoin on Int3face',
            denomUnits: [
                {
                    denom: 'ibc/C4C791209A16419A4BB3C3177E5E8AE4477C9D7457842E7F531F91C513FA79A0',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    ]
                },
                {
                    denom: 'ltc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/C4C791209A16419A4BB3C3177E5E8AE4477C9D7457842E7F531F91C513FA79A0',
            name: 'Litecoin (Int3)',
            display: 'ltc',
            symbol: 'LTC.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'litecoin',
                        baseDenom: 'litoshi'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-6455',
                        path: 'transfer/channel-6455/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3face',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.png',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../chain.schema.json',
    chainName: 'neutron',
    status: 'live',
    networkType: 'mainnet',
    prettyName: 'Neutron',
    chainType: 'cosmos',
    chainId: 'neutron-1',
    bech32Prefix: 'neutron',
    website: 'https://neutron.org/',
    daemonName: 'neutrond',
    nodeHome: '$HOME/.neutrond',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'untrn',
                lowGasPrice: 0.0053,
                averageGasPrice: 0.0053,
                highGasPrice: 0.0053
            },
            {
                denom: 'ibc/C4CFF46FD6DE35CA4CF4CE031E643C8FDC9BA4B99AE598E9B0ED98FE3A2319F9',
                lowGasPrice: 0.0008,
                averageGasPrice: 0.0008,
                highGasPrice: 0.0008
            },
            {
                denom: 'ibc/F082B65C88E4B6D5EF1DB243CDA1D331D002759E938A0F5CD3FFDC5D53B3E349',
                lowGasPrice: 0.008,
                averageGasPrice: 0.008,
                highGasPrice: 0.008
            },
            {
                denom: 'factory/neutron1ug740qrkquxzrk2hh29qrlx3sktkfml3je7juusc2te7xmvsscns0n2wry/wstETH',
                lowGasPrice: 2903231.6597,
                averageGasPrice: 2903231.6597,
                highGasPrice: 2903231.6597
            },
            {
                denom: 'ibc/2CB87BCE0937B1D1DFCEE79BE4501AAF3C265E923509AEAC410AD85D27F35130',
                lowGasPrice: 2564102564.1026,
                averageGasPrice: 2564102564.1026,
                highGasPrice: 2564102564.1026
            },
            {
                denom: 'ibc/773B4D0A3CD667B2275D5A4A7A2F0909C0BA0F4059C0B9181E680DDF4965DCC7',
                lowGasPrice: 0.0004,
                averageGasPrice: 0.0004,
                highGasPrice: 0.0004
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'untrn'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/neutron-org/neutron',
        recommendedVersion: 'v5.0.2',
        compatibleVersions: [
            'v5.0.2'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/neutron-org/neutron/releases/download/v5.0.2/neutrond-linux-amd64'
        },
        consensus: {
            type: 'cometbft',
            version: 'v0.38.15'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/neutron-org/mainnet-assets/main/neutron-1-genesis.json'
        },
        sdk: {
            type: 'cosmos',
            repo: 'https://github.com/neutron-org/cosmos-sdk',
            version: 'v0.50.10',
            tag: 'v0.50.10-neutron'
        },
        ibc: {
            type: 'go',
            version: 'v8.5.2'
        },
        cosmwasm: {
            version: 'v0.53.0',
            repo: 'https://github.com/neutron-org/wasmd',
            enabled: true
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-raw.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-raw.svg'
    },
    description: 'The most secure CosmWasm platform in Cosmos, Neutron lets smart-contracts leverage bleeding-edge Interchain technology with minimal overhead.',
    apis: {
        rpc: [
            {
                address: 'https://rpc-lb.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rpc-solara.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rpc-vertexa.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rpc-voidara.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rpc-pulsarix.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rpc.novel.remedy.tm.p2p.org',
                provider: 'P2P'
            },
            {
                address: 'https://rpc.lavenderfive.com:443/neutron',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'https://rpc-neutron.whispernode.com',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'https://rpc-neutron.cosmos-spaces.cloud',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'https://neutron-rpc.publicnode.com:443',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'https://community.nuxian-node.ch:6797/neutron/trpc',
                provider: 'PRO Delegators'
            },
            {
                address: 'https://rpc.neutron.bronbro.io:443',
                provider: 'Bro_n_Bro'
            },
            {
                address: 'https://rpc.neutron.quokkastake.io',
                provider: '🐹 Quokka Stake'
            },
            {
                address: 'https://neutron.drpc.org',
                provider: 'dRPC'
            },
            {
                address: 'https://neutron-rpc.ibs.team',
                provider: 'Inter Blockchain Services'
            }
        ],
        rest: [
            {
                address: 'https://rest-lb.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rest-solara.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rest-vertexa.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rest-voidara.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://rest-pulsarix.neutron-1.neutron.org',
                provider: 'Neutron'
            },
            {
                address: 'https://api.novel.remedy.tm.p2p.org',
                provider: 'P2P'
            },
            {
                address: 'https://rest.lavenderfive.com:443/neutron',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'https://lcd-neutron.whispernode.com',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'https://api-neutron.cosmos-spaces.cloud',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'https://neutron-rest.publicnode.com',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'https://community.nuxian-node.ch:6797/neutron/crpc',
                provider: 'PRO Delegators'
            },
            {
                address: 'https://lcd.neutron.bronbro.io:443',
                provider: 'Bro_n_Bro'
            },
            {
                address: 'https://api.neutron.quokkastake.io',
                provider: '🐹 Quokka Stake'
            },
            {
                address: 'https://neutron-api.ibs.team',
                provider: 'Inter Blockchain Services'
            }
        ],
        grpc: [
            {
                address: 'grpc-lb.neutron.org:80',
                provider: 'Neutron'
            },
            {
                address: 'grpc-kralum.neutron-1.neutron.org:80',
                provider: 'Neutron'
            },
            {
                address: 'neutron-grpc-pub.rpc.p2p.world:3001',
                provider: 'P2P'
            },
            {
                address: 'neutron.lavenderfive.com:443',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'grpc-neutron.whispernode.com:443',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'grpc-neutron.cosmos-spaces.cloud:3090',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'neutron-grpc.publicnode.com:443',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'https://grpc.neutron.bronbro.io:443',
                provider: 'Bro_n_Bro'
            },
            {
                address: 'rpc.neutron.quokkastake.io:9090',
                provider: '🐹 Quokka Stake'
            }
        ]
    },
    explorers: [
        {
            kind: 'Mintscan',
            url: 'https://www.mintscan.io/neutron',
            txPage: 'https://www.mintscan.io/neutron/transactions/${txHash}',
            accountPage: 'https://www.mintscan.io/neutron/accounts/${accountAddress}'
        },
        {
            kind: 'ezstaking',
            url: 'https://ezstaking.app/neutron',
            txPage: 'https://ezstaking.app/neutron/txs/${txHash}',
            accountPage: 'https://ezstaking.app/neutron/account/${accountAddress}'
        },
        {
            kind: 'WhisperNode 🤐',
            url: 'https://mainnet.whispernode.com/neutron',
            txPage: 'https://mainnet.whispernode.com/neutron/tx/${txHash}',
            accountPage: 'https://mainnet.whispernode.com/neutron/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-raw.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-raw.svg',
            theme: {
                primaryColorHex: '#000000',
                backgroundColorHex: '#00000000',
                circle: false
            }
        },
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/ntrn.svg',
            theme: {
                primaryColorHex: '#040404',
                backgroundColorHex: '#000000',
                circle: true
            }
        },
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-black-logo.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/neutron-black-logo.svg'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'agoric',
            clientId: '07-tendermint-101',
            connectionId: 'connection-99'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-148',
            connectionId: 'connection-108'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-146',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5789',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'archway',
            clientId: '07-tendermint-51',
            connectionId: 'connection-58'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-62',
            connectionId: 'connection-43'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-61',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-41',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'axelar',
            clientId: '07-tendermint-123',
            connectionId: 'connection-110'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-1',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-78',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'babylon',
            clientId: '07-tendermint-5',
            connectionId: 'connection-5'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-164',
            connectionId: 'connection-123'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6980',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'celestia',
            clientId: '07-tendermint-29',
            connectionId: 'connection-7'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-48',
            connectionId: 'connection-36'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-35',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'chihuahua',
            clientId: '07-tendermint-191',
            connectionId: 'connection-127'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-74',
            connectionId: 'connection-53'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-76',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-51',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-77',
                    portId: 'wasm.chihuahua1jwkag4yvhyj9fuddtkygvavya8hmdjuzmgxwg9vp3lw9twv6lrcq9mgl52'
                },
                chain2: {
                    channelId: 'channel-52',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'composable',
            clientId: '07-tendermint-66',
            connectionId: 'connection-28'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-29',
            connectionId: 'connection-22'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-18',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-17',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1119',
            connectionId: 'connection-809'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-569',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'dungeon1',
            clientId: '07-tendermint-8',
            connectionId: 'connection-10'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-146',
            connectionId: 'connection-106'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5481',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'dydx',
            clientId: '07-tendermint-11',
            connectionId: 'connection-17'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-72',
            connectionId: 'connection-51'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-11',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-48',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'dymension',
            clientId: '07-tendermint-16',
            connectionId: 'connection-9'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-82',
            connectionId: 'connection-61'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-675',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'elys',
            clientId: '07-tendermint-36',
            connectionId: 'connection-19'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-152',
            connectionId: 'connection-112'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-16',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6476',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'initia',
            clientId: '07-tendermint-20',
            connectionId: 'connection-20'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-161',
            connectionId: 'connection-118'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-37',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6885',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'injective',
            clientId: '07-tendermint-233',
            connectionId: 'connection-220'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-78',
            connectionId: 'connection-58'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-177',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-60',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'int3face',
            clientId: '07-tendermint-3',
            connectionId: 'connection-1'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-151',
            connectionId: 'connection-111'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6455',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'juno',
            clientId: '07-tendermint-557',
            connectionId: 'connection-524'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-97',
            connectionId: 'connection-71'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-548',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4328',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'kava',
            clientId: '07-tendermint-151',
            connectionId: 'connection-194'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-54',
            connectionId: 'connection-37'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-136',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-36',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'kujira',
            clientId: '07-tendermint-112',
            connectionId: 'connection-82'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-75',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'mantrachain',
            clientId: '07-tendermint-7',
            connectionId: 'connection-7'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-162',
            connectionId: 'connection-119'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-7',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6964',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'mars',
            clientId: '07-tendermint-64',
            connectionId: 'connection-50'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-21',
            connectionId: 'connection-21'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-37',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-16',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'killed',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-40',
            connectionId: 'connection-31'
        },
        chain2: {
            chainName: 'noble',
            clientId: '07-tendermint-25',
            connectionId: 'connection-34'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-30',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-18',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-83',
            connectionId: 'connection-62'
        },
        chain2: {
            chainName: 'nois',
            clientId: '07-tendermint-20',
            connectionId: 'connection-13'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-722',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-47',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-1559',
                    portId: 'wasm.neutron14cwv7d4lwc69zrjrzywwh8c9327m8dpngpq52f5kgqephhgrjc2s9ry3eu'
                },
                chain2: {
                    channelId: 'channel-48',
                    portId: 'wasm.nois1acyc05v6fgcdgj88nmz2t40aex9nlnptqpwp5hf8hwg7rhce9uuqgqz5wp'
                },
                ordering: 'unordered',
                version: 'nois-v7',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-71',
            connectionId: 'connection-50'
        },
        chain2: {
            chainName: 'nolus',
            clientId: '07-tendermint-13',
            connectionId: 'connection-11'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-44',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3839',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-154',
            connectionId: 'connection-114'
        },
        chain2: {
            chainName: 'nomic',
            clientId: '07-tendermint-11',
            connectionId: 'connection-10'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-6478',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-19',
            connectionId: 'connection-18'
        },
        chain2: {
            chainName: 'osmosis',
            clientId: '07-tendermint-2823',
            connectionId: 'connection-2338'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-874',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-2107',
                    portId: 'wasm.neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07'
                },
                chain2: {
                    channelId: 'channel-39589',
                    portId: 'wasm.osmo1pfeve3esg5rhhkfhlujxtthc25akcf3zpa3t9whghvvp2v5v92ps0z30r6'
                },
                ordering: 'unordered',
                version: 'astroport-ibc-v1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-137',
            connectionId: 'connection-98'
        },
        chain2: {
            chainName: 'penumbra',
            clientId: '07-tendermint-9',
            connectionId: 'connection-7'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4886',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-73',
            connectionId: 'connection-52'
        },
        chain2: {
            chainName: 'persistence',
            clientId: '07-tendermint-161',
            connectionId: 'connection-199'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-49',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-136',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-98',
            connectionId: 'connection-72'
        },
        chain2: {
            chainName: 'pryzm',
            clientId: '07-tendermint-6',
            connectionId: 'connection-6'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4329',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-90',
            connectionId: 'connection-66'
        },
        chain2: {
            chainName: 'saga',
            clientId: '07-tendermint-6',
            connectionId: 'connection-6'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2060',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-85',
            connectionId: 'connection-63'
        },
        chain2: {
            chainName: 'secretnetwork',
            clientId: '07-tendermint-199',
            connectionId: 'connection-192'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1551',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-144',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-1950',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-151',
                    portId: 'wasm.secret1tqmms5awftpuhalcv5h5mg76fa0tkdz4jv9ex4'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-89',
            connectionId: 'connection-65'
        },
        chain2: {
            chainName: 'sei',
            clientId: '07-tendermint-123',
            connectionId: 'connection-157'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2016',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-66',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-2110',
                    portId: 'wasm.neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07'
                },
                chain2: {
                    channelId: 'channel-71',
                    portId: 'wasm.sei12fykm2xhg5ces2vmf4q2aem8c958exv3v0wmvrspa8zucrdwjeds2e2ntx'
                },
                ordering: 'unordered',
                version: 'astroport-ibc-v1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-160',
            connectionId: 'connection-117'
        },
        chain2: {
            chainName: 'sidechain',
            clientId: '07-tendermint-23',
            connectionId: 'connection-9'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-6852',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-31',
            connectionId: 'connection-23'
        },
        chain2: {
            chainName: 'stargaze',
            clientId: '07-tendermint-283',
            connectionId: 'connection-211'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-18',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-191',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-18',
            connectionId: 'connection-15'
        },
        chain2: {
            chainName: 'stride',
            clientId: '07-tendermint-125',
            connectionId: 'connection-113'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-123',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-12',
            connectionId: 'connection-9'
        },
        chain2: {
            chainName: 'terra2',
            clientId: '07-tendermint-274',
            connectionId: 'connection-192'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-25',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-229',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-167',
                    portId: 'wasm.terra1jhfjnm39y3nn9l4520mdn4k5mw23nz0674c4gsvyrcr90z9tqcvst22fce'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-2112',
                    portId: 'wasm.neutron1ffus553eet978k024lmssw0czsxwr97mggyv85lpcsdkft8v9ufsz3sa07'
                },
                chain2: {
                    channelId: 'channel-396',
                    portId: 'wasm.terra1k9j8rcyk87v5jvfla2m9wp200azegjz0eshl7n2pwv852a7ssceqsnn7pq'
                },
                ordering: 'unordered',
                version: 'astroport-ibc-v1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-5389',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-554',
                    portId: 'wasm.terra1e0mrzy8077druuu42vs0hu7ugguade0cj65dgtauyaw4gsl4kv0qtdf2au'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/chain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/neutron/ibc-data.js [app-client] (ecmascript)");
;
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$neutron$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
}]);

//# sourceMappingURL=node_modules_%40chain-registry_v2_esm_mainnet_neutron_9e1f1c0e._.js.map