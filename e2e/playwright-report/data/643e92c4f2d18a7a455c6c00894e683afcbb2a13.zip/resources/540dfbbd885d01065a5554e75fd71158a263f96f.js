(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@vanilla-extract/css/injectStyles/dist/vanilla-extract-css-injectStyles.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "injectStyles": (()=>injectStyles)
});
var stylesheets = {};
var injectStyles = (_ref)=>{
    var { fileScope, css } = _ref;
    var fileScopeId = fileScope.packageName ? [
        fileScope.packageName,
        fileScope.filePath
    ].join('/') : fileScope.filePath;
    var stylesheet = stylesheets[fileScopeId];
    if (!stylesheet) {
        var styleEl = document.createElement('style');
        if (fileScope.packageName) {
            styleEl.setAttribute('data-package', fileScope.packageName);
        }
        styleEl.setAttribute('data-file', fileScope.filePath);
        styleEl.setAttribute('type', 'text/css');
        stylesheet = stylesheets[fileScopeId] = styleEl;
        document.head.appendChild(styleEl);
    }
    stylesheet.innerHTML = css;
};
;
}}),
"[project]/node_modules/@vanilla-extract/css/adapter/dist/vanilla-extract-css-adapter.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "appendCss": (()=>appendCss),
    "getIdentOption": (()=>getIdentOption),
    "markCompositionUsed": (()=>markCompositionUsed),
    "mockAdapter": (()=>mockAdapter),
    "onBeginFileScope": (()=>onBeginFileScope),
    "onEndFileScope": (()=>onEndFileScope),
    "registerClassName": (()=>registerClassName),
    "registerComposition": (()=>registerComposition),
    "removeAdapter": (()=>removeAdapter),
    "setAdapter": (()=>setAdapter),
    "setAdapterIfNotSet": (()=>setAdapterIfNotSet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var mockAdapter = {
    appendCss: ()=>{},
    registerClassName: ()=>{},
    onEndFileScope: ()=>{},
    registerComposition: ()=>{},
    markCompositionUsed: ()=>{},
    getIdentOption: ()=>("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : 'debug'
};
var adapterStack = [
    mockAdapter
];
var currentAdapter = ()=>{
    if (adapterStack.length < 1) {
        throw new Error('No adapter configured');
    }
    return adapterStack[adapterStack.length - 1];
};
var hasConfiguredAdapter = false;
var setAdapterIfNotSet = (newAdapter)=>{
    if (!hasConfiguredAdapter) {
        setAdapter(newAdapter);
    }
};
var setAdapter = (newAdapter)=>{
    if (!newAdapter) {
        throw new Error('No adapter provided when calling "setAdapter"');
    }
    hasConfiguredAdapter = true;
    adapterStack.push(newAdapter);
};
var removeAdapter = ()=>{
    adapterStack.pop();
};
var appendCss = function appendCss() {
    return currentAdapter().appendCss(...arguments);
};
var registerClassName = function registerClassName() {
    return currentAdapter().registerClassName(...arguments);
};
var registerComposition = function registerComposition() {
    return currentAdapter().registerComposition(...arguments);
};
var markCompositionUsed = function markCompositionUsed() {
    return currentAdapter().markCompositionUsed(...arguments);
};
var onBeginFileScope = function onBeginFileScope() {
    var _currentAdapter$onBeg, _currentAdapter;
    for(var _len = arguments.length, props = new Array(_len), _key = 0; _key < _len; _key++){
        props[_key] = arguments[_key];
    }
    return (_currentAdapter$onBeg = (_currentAdapter = currentAdapter()).onBeginFileScope) === null || _currentAdapter$onBeg === void 0 ? void 0 : _currentAdapter$onBeg.call(_currentAdapter, ...props);
};
var onEndFileScope = function onEndFileScope() {
    return currentAdapter().onEndFileScope(...arguments);
};
var getIdentOption = function getIdentOption() {
    var adapter = currentAdapter();
    // Backwards compatibility with old versions of the integration package
    if (!('getIdentOption' in adapter)) {
        return ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : 'debug';
    }
    return adapter.getIdentOption(...arguments);
};
;
}}),
"[project]/node_modules/@vanilla-extract/css/dist/taggedTemplateLiteral-8e47dbd7.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "_": (()=>_taggedTemplateLiteral)
});
function _taggedTemplateLiteral(strings, raw) {
    if (!raw) {
        raw = strings.slice(0);
    }
    return Object.freeze(Object.defineProperties(strings, {
        raw: {
            value: Object.freeze(raw)
        }
    }));
}
;
}}),
"[project]/node_modules/@vanilla-extract/css/dist/transformCss-830a230d.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "_": (()=>_objectSpread2),
    "a": (()=>_objectWithoutProperties),
    "d": (()=>dudupeAndJoinClassList),
    "t": (()=>transformCss)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/private/dist/vanilla-extract-private.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/cssesc/cssesc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$modern$2d$ahocorasick$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/modern-ahocorasick/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/adapter/dist/vanilla-extract-css-adapter.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/dist/taggedTemplateLiteral-8e47dbd7.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$css$2d$what$2f$lib$2f$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/css-what/lib/es/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/node_modules/dedent/dist/dedent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$media$2d$query$2d$parser$2f$dist$2f$media$2d$query$2d$parser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/media-query-parser/dist/media-query-parser.esm.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
function toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
    var i = toPrimitive(t, "string");
    return "symbol" == typeof i ? i : String(i);
}
function _defineProperty(obj, key, value) {
    key = toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread2(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function forEach(obj, fn) {
    for(var _key in obj){
        fn(obj[_key], _key);
    }
}
function omit(obj, omitKeys) {
    var result = {};
    for(var _key2 in obj){
        if (omitKeys.indexOf(_key2) === -1) {
            result[_key2] = obj[_key2];
        }
    }
    return result;
}
function mapKeys(obj, fn) {
    var result = {};
    for(var _key3 in obj){
        result[fn(obj[_key3], _key3)] = obj[_key3];
    }
    return result;
}
function composeStylesIntoSet(set) {
    for(var _len = arguments.length, classNames = new Array(_len > 1 ? _len - 1 : 0), _key5 = 1; _key5 < _len; _key5++){
        classNames[_key5 - 1] = arguments[_key5];
    }
    for (var className of classNames){
        if (className.length === 0) {
            continue;
        }
        if (typeof className === 'string') {
            if (className.includes(' ')) {
                composeStylesIntoSet(set, ...className.trim().split(' '));
            } else {
                set.add(className);
            }
        } else if (Array.isArray(className)) {
            composeStylesIntoSet(set, ...className);
        }
    }
}
function dudupeAndJoinClassList(classNames) {
    var set = new Set();
    composeStylesIntoSet(set, ...classNames);
    return Array.from(set).join(' ');
}
var _templateObject$1;
// https://stackoverflow.com/questions/3561493/is-there-a-regexp-escape-function-in-javascript
function escapeRegex(string) {
    return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
}
var validateSelector = (selector, targetClassName)=>{
    var replaceTarget = ()=>{
        var targetRegex = new RegExp(".".concat(escapeRegex((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(targetClassName, {
            isIdentifier: true
        }))), 'g');
        return selector.replace(targetRegex, '&');
    };
    var selectorParts;
    try {
        selectorParts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$css$2d$what$2f$lib$2f$es$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(selector);
    } catch (err) {
        throw new Error("Invalid selector: ".concat(replaceTarget()));
    }
    selectorParts.forEach((tokens)=>{
        try {
            for(var i = tokens.length - 1; i >= -1; i--){
                if (!tokens[i]) {
                    throw new Error();
                }
                var token = tokens[i];
                if (token.type === 'child' || token.type === 'parent' || token.type === 'sibling' || token.type === 'adjacent' || token.type === 'descendant') {
                    throw new Error();
                }
                if (token.type === 'attribute' && token.name === 'class' && token.value === targetClassName) {
                    return; // Found it
                }
            }
        } catch (err) {
            throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_templateObject$1 || (_templateObject$1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])([
                "\n        Invalid selector: ",
                "\n    \n        Style selectors must target the '&' character (along with any modifiers), e.g. ",
                " or ",
                ".\n        \n        This is to ensure that each style block only affects the styling of a single class.\n        \n        If your selector is targeting another class, you should move it to the style definition for that class, e.g. given we have styles for 'parent' and 'child' elements, instead of adding a selector of ",
                ") to 'parent', you should add ",
                " to 'child').\n        \n        If your selector is targeting something global, use the 'globalStyle' function instead, e.g. if you wanted to write ",
                ", you should instead write 'globalStyle(",
                ", { ... })'\n      "
            ])), replaceTarget(), '`${parent} &`', '`${parent} &:hover`', '`& ${child}`', '`${parent} &`', '`& h1`', '`${parent} h1`'));
        }
    });
};
/** e.g. @media screen and (min-width: 500px) */ class ConditionalRuleset {
    /**
   * Stores information about where conditions must be in relation to other conditions
   *
   * e.g. mobile -> tablet, desktop
   */ constructor(){
        this.ruleset = new Map();
        this.precedenceLookup = new Map();
    }
    findOrCreateCondition(conditionQuery) {
        var targetCondition = this.ruleset.get(conditionQuery);
        if (!targetCondition) {
            // No target condition so create one
            targetCondition = {
                query: conditionQuery,
                rules: [],
                children: new ConditionalRuleset()
            };
            this.ruleset.set(conditionQuery, targetCondition);
        }
        return targetCondition;
    }
    getConditionalRulesetByPath(conditionPath) {
        var currRuleset = this;
        for (var query of conditionPath){
            var condition = currRuleset.findOrCreateCondition(query);
            currRuleset = condition.children;
        }
        return currRuleset;
    }
    addRule(rule, conditionQuery, conditionPath) {
        var ruleset = this.getConditionalRulesetByPath(conditionPath);
        var targetCondition = ruleset.findOrCreateCondition(conditionQuery);
        if (!targetCondition) {
            throw new Error('Failed to add conditional rule');
        }
        targetCondition.rules.push(rule);
    }
    addConditionPrecedence(conditionPath, conditionOrder) {
        var ruleset = this.getConditionalRulesetByPath(conditionPath);
        for(var i = 0; i < conditionOrder.length; i++){
            var _ruleset$precedenceLo;
            var query = conditionOrder[i];
            var conditionPrecedence = (_ruleset$precedenceLo = ruleset.precedenceLookup.get(query)) !== null && _ruleset$precedenceLo !== void 0 ? _ruleset$precedenceLo : new Set();
            for (var lowerPrecedenceCondition of conditionOrder.slice(i + 1)){
                conditionPrecedence.add(lowerPrecedenceCondition);
            }
            ruleset.precedenceLookup.set(query, conditionPrecedence);
        }
    }
    isCompatible(incomingRuleset) {
        for (var [condition, orderPrecedence] of this.precedenceLookup.entries()){
            for (var lowerPrecedenceCondition of orderPrecedence){
                var _incomingRuleset$prec;
                if ((_incomingRuleset$prec = incomingRuleset.precedenceLookup.get(lowerPrecedenceCondition)) !== null && _incomingRuleset$prec !== void 0 && _incomingRuleset$prec.has(condition)) {
                    return false;
                }
            }
        }
        // Check that children are compatible
        for (var { query, children } of incomingRuleset.ruleset.values()){
            var matchingCondition = this.ruleset.get(query);
            if (matchingCondition && !matchingCondition.children.isCompatible(children)) {
                return false;
            }
        }
        return true;
    }
    merge(incomingRuleset) {
        // Merge rulesets into one array
        for (var { query, rules, children } of incomingRuleset.ruleset.values()){
            var matchingCondition = this.ruleset.get(query);
            if (matchingCondition) {
                matchingCondition.rules.push(...rules);
                matchingCondition.children.merge(children);
            } else {
                this.ruleset.set(query, {
                    query,
                    rules,
                    children
                });
            }
        }
        // Merge order precedences
        for (var [condition, incomingOrderPrecedence] of incomingRuleset.precedenceLookup.entries()){
            var _this$precedenceLooku;
            var orderPrecedence = (_this$precedenceLooku = this.precedenceLookup.get(condition)) !== null && _this$precedenceLooku !== void 0 ? _this$precedenceLooku : new Set();
            this.precedenceLookup.set(condition, new Set([
                ...orderPrecedence,
                ...incomingOrderPrecedence
            ]));
        }
    }
    /**
   * Merge another ConditionalRuleset into this one if they are compatible
   *
   * @returns true if successful, false if the ruleset is incompatible
   */ mergeIfCompatible(incomingRuleset) {
        if (!this.isCompatible(incomingRuleset)) {
            return false;
        }
        this.merge(incomingRuleset);
        return true;
    }
    getSortedRuleset() {
        var _this = this;
        var sortedRuleset = [];
        // Loop through all queries and add them to the sorted ruleset
        var _loop = function _loop(dependents) {
            var conditionForQuery = _this.ruleset.get(query);
            if (!conditionForQuery) {
                throw new Error("Can't find condition for ".concat(query));
            }
            // Find the location of the first dependent condition in the sortedRuleset
            // A dependent condition is a condition that must be placed *after* the current one
            var firstMatchingDependent = sortedRuleset.findIndex((condition)=>dependents.has(condition.query));
            if (firstMatchingDependent > -1) {
                // Insert the condition before the dependent one
                sortedRuleset.splice(firstMatchingDependent, 0, conditionForQuery);
            } else {
                // No match, just insert at the end
                sortedRuleset.push(conditionForQuery);
            }
        };
        for (var [query, dependents] of this.precedenceLookup.entries()){
            _loop(dependents);
        }
        return sortedRuleset;
    }
    renderToArray() {
        var arr = [];
        for (var { query, rules, children } of this.getSortedRuleset()){
            var selectors = {};
            for (var rule of rules){
                selectors[rule.selector] = _objectSpread2(_objectSpread2({}, selectors[rule.selector]), rule.rule);
            }
            Object.assign(selectors, ...children.renderToArray());
            arr.push({
                [query]: selectors
            });
        }
        return arr;
    }
}
var simplePseudoMap = {
    ':-moz-any-link': true,
    ':-moz-full-screen': true,
    ':-moz-placeholder': true,
    ':-moz-read-only': true,
    ':-moz-read-write': true,
    ':-ms-fullscreen': true,
    ':-ms-input-placeholder': true,
    ':-webkit-any-link': true,
    ':-webkit-full-screen': true,
    '::-moz-color-swatch': true,
    '::-moz-list-bullet': true,
    '::-moz-list-number': true,
    '::-moz-page-sequence': true,
    '::-moz-page': true,
    '::-moz-placeholder': true,
    '::-moz-progress-bar': true,
    '::-moz-range-progress': true,
    '::-moz-range-thumb': true,
    '::-moz-range-track': true,
    '::-moz-scrolled-page-sequence': true,
    '::-moz-selection': true,
    '::-ms-backdrop': true,
    '::-ms-browse': true,
    '::-ms-check': true,
    '::-ms-clear': true,
    '::-ms-fill-lower': true,
    '::-ms-fill-upper': true,
    '::-ms-fill': true,
    '::-ms-reveal': true,
    '::-ms-thumb': true,
    '::-ms-ticks-after': true,
    '::-ms-ticks-before': true,
    '::-ms-tooltip': true,
    '::-ms-track': true,
    '::-ms-value': true,
    '::-webkit-backdrop': true,
    '::-webkit-calendar-picker-indicator': true,
    '::-webkit-inner-spin-button': true,
    '::-webkit-input-placeholder': true,
    '::-webkit-meter-bar': true,
    '::-webkit-meter-even-less-good-value': true,
    '::-webkit-meter-inner-element': true,
    '::-webkit-meter-optimum-value': true,
    '::-webkit-meter-suboptimum-value': true,
    '::-webkit-outer-spin-button': true,
    '::-webkit-progress-bar': true,
    '::-webkit-progress-inner-element': true,
    '::-webkit-progress-inner-value': true,
    '::-webkit-progress-value': true,
    '::-webkit-resizer': true,
    '::-webkit-scrollbar-button': true,
    '::-webkit-scrollbar-corner': true,
    '::-webkit-scrollbar-thumb': true,
    '::-webkit-scrollbar-track-piece': true,
    '::-webkit-scrollbar-track': true,
    '::-webkit-scrollbar': true,
    '::-webkit-search-cancel-button': true,
    '::-webkit-search-results-button': true,
    '::-webkit-slider-runnable-track': true,
    '::-webkit-slider-thumb': true,
    '::after': true,
    '::backdrop': true,
    '::before': true,
    '::cue': true,
    '::file-selector-button': true,
    '::first-letter': true,
    '::first-line': true,
    '::grammar-error': true,
    '::marker': true,
    '::placeholder': true,
    '::selection': true,
    '::spelling-error': true,
    '::target-text': true,
    '::view-transition-group': true,
    '::view-transition-image-pair': true,
    '::view-transition-new': true,
    '::view-transition-old': true,
    '::view-transition': true,
    ':active': true,
    ':after': true,
    ':any-link': true,
    ':before': true,
    ':blank': true,
    ':checked': true,
    ':default': true,
    ':defined': true,
    ':disabled': true,
    ':empty': true,
    ':enabled': true,
    ':first-child': true,
    ':first-letter': true,
    ':first-line': true,
    ':first-of-type': true,
    ':first': true,
    ':focus-visible': true,
    ':focus-within': true,
    ':focus': true,
    ':fullscreen': true,
    ':hover': true,
    ':in-range': true,
    ':indeterminate': true,
    ':invalid': true,
    ':last-child': true,
    ':last-of-type': true,
    ':left': true,
    ':link': true,
    ':only-child': true,
    ':only-of-type': true,
    ':optional': true,
    ':out-of-range': true,
    ':placeholder-shown': true,
    ':read-only': true,
    ':read-write': true,
    ':required': true,
    ':right': true,
    ':root': true,
    ':scope': true,
    ':target': true,
    ':valid': true,
    ':visited': true
};
var simplePseudos = Object.keys(simplePseudoMap);
var simplePseudoLookup = simplePseudoMap;
var _templateObject;
var createMediaQueryError = (mediaQuery, msg)=>new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_templateObject || (_templateObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])([
        "\n    Invalid media query: \"",
        "\"\n\n    ",
        "\n\n    Read more on MDN: https://developer.mozilla.org/en-US/docs/Web/CSS/Media_Queries/Using_media_queries\n  "
    ])), mediaQuery, msg));
var validateMediaQuery = (mediaQuery)=>{
    // Empty queries will start with '@media '
    if (mediaQuery === '@media ') {
        throw createMediaQueryError(mediaQuery, 'Query is empty');
    }
    try {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$media$2d$query$2d$parser$2f$dist$2f$media$2d$query$2d$parser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAST"])(mediaQuery);
    } catch (e) {
        throw createMediaQueryError(mediaQuery, e.message);
    }
};
var _excluded = [
    "vars"
], _excluded2 = [
    "content"
];
var DECLARATION = '__DECLARATION';
var UNITLESS = {
    animationIterationCount: true,
    borderImage: true,
    borderImageOutset: true,
    borderImageSlice: true,
    borderImageWidth: true,
    boxFlex: true,
    boxFlexGroup: true,
    columnCount: true,
    columns: true,
    flex: true,
    flexGrow: true,
    flexShrink: true,
    fontWeight: true,
    gridArea: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnStart: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowStart: true,
    initialLetter: true,
    lineClamp: true,
    lineHeight: true,
    maxLines: true,
    opacity: true,
    order: true,
    orphans: true,
    scale: true,
    tabSize: true,
    WebkitLineClamp: true,
    widows: true,
    zIndex: true,
    zoom: true,
    // svg properties
    fillOpacity: true,
    floodOpacity: true,
    maskBorder: true,
    maskBorderOutset: true,
    maskBorderSlice: true,
    maskBorderWidth: true,
    shapeImageThreshold: true,
    stopOpacity: true,
    strokeDashoffset: true,
    strokeMiterlimit: true,
    strokeOpacity: true,
    strokeWidth: true
};
function dashify(str) {
    return str.replace(/([A-Z])/g, '-$1').replace(/^ms-/, '-ms-').toLowerCase();
}
function replaceBetweenIndexes(target, startIndex, endIndex, replacement) {
    var start = target.slice(0, startIndex);
    var end = target.slice(endIndex);
    return "".concat(start).concat(replacement).concat(end);
}
var DOUBLE_SPACE = '  ';
var specialKeys = [
    ...simplePseudos,
    '@layer',
    '@media',
    '@supports',
    '@container',
    'selectors'
];
class Stylesheet {
    constructor(localClassNames, composedClassLists){
        this.rules = [];
        this.conditionalRulesets = [
            new ConditionalRuleset()
        ];
        this.fontFaceRules = [];
        this.keyframesRules = [];
        this.propertyRules = [];
        this.localClassNamesMap = new Map(localClassNames.map((localClassName)=>[
                localClassName,
                localClassName
            ]));
        this.localClassNamesSearch = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$modern$2d$ahocorasick$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](localClassNames);
        this.layers = new Map();
        // Class list compositions should be priortized by Newer > Older
        // Therefore we reverse the array as they are added in sequence
        this.composedClassLists = composedClassLists.map((_ref)=>{
            var { identifier, classList } = _ref;
            return {
                identifier,
                regex: RegExp("(".concat(classList, ")"), 'g')
            };
        }).reverse();
    }
    processCssObj(root) {
        if (root.type === 'fontFace') {
            this.fontFaceRules.push(root.rule);
            return;
        }
        if (root.type === 'property') {
            this.propertyRules.push(root);
            return;
        }
        if (root.type === 'keyframes') {
            root.rule = Object.fromEntries(Object.entries(root.rule).map((_ref2)=>{
                var [keyframe, rule] = _ref2;
                return [
                    keyframe,
                    this.transformVars(this.transformProperties(rule))
                ];
            }));
            this.keyframesRules.push(root);
            return;
        }
        this.currConditionalRuleset = new ConditionalRuleset();
        if (root.type === 'layer') {
            var layerDefinition = "@layer ".concat(root.name);
            this.addLayer([
                layerDefinition
            ]);
        } else {
            // Add main styles
            var mainRule = omit(root.rule, specialKeys);
            this.addRule({
                selector: root.selector,
                rule: mainRule
            });
            this.transformLayer(root, root.rule['@layer']);
            this.transformMedia(root, root.rule['@media']);
            this.transformSupports(root, root.rule['@supports']);
            this.transformContainer(root, root.rule['@container']);
            this.transformSimplePseudos(root, root.rule);
            this.transformSelectors(root, root.rule);
        }
        var activeConditionalRuleset = this.conditionalRulesets[this.conditionalRulesets.length - 1];
        if (!activeConditionalRuleset.mergeIfCompatible(this.currConditionalRuleset)) {
            // Ruleset merge failed due to incompatibility. We now deopt by starting a fresh ConditionalRuleset
            this.conditionalRulesets.push(this.currConditionalRuleset);
        }
    }
    addConditionalRule(cssRule, conditions) {
        // Run `transformProperties` before `transformVars` as we don't want to pixelify CSS Vars
        var rule = this.transformVars(this.transformProperties(cssRule.rule));
        var selector = this.transformSelector(cssRule.selector);
        if (!this.currConditionalRuleset) {
            throw new Error("Couldn't add conditional rule");
        }
        var conditionQuery = conditions[conditions.length - 1];
        var parentConditions = conditions.slice(0, conditions.length - 1);
        this.currConditionalRuleset.addRule({
            selector,
            rule
        }, conditionQuery, parentConditions);
    }
    addRule(cssRule) {
        // Run `transformProperties` before `transformVars` as we don't want to pixelify CSS Vars
        var rule = this.transformVars(this.transformProperties(cssRule.rule));
        var selector = this.transformSelector(cssRule.selector);
        this.rules.push({
            selector,
            rule
        });
    }
    addLayer(layer) {
        var uniqueLayerKey = layer.join(' - ');
        this.layers.set(uniqueLayerKey, layer);
    }
    transformProperties(cssRule) {
        return this.transformContent(this.pixelifyProperties(cssRule));
    }
    pixelifyProperties(cssRule) {
        forEach(cssRule, (value, key)=>{
            if (typeof value === 'number' && value !== 0 && !UNITLESS[key]) {
                // @ts-expect-error Any ideas?
                cssRule[key] = "".concat(value, "px");
            }
        });
        return cssRule;
    }
    transformVars(_ref3) {
        var { vars } = _ref3, rest = _objectWithoutProperties(_ref3, _excluded);
        if (!vars) {
            return rest;
        }
        return _objectSpread2(_objectSpread2({}, mapKeys(vars, (_value, key)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVarName"])(key))), rest);
    }
    transformContent(_ref4) {
        var { content } = _ref4, rest = _objectWithoutProperties(_ref4, _excluded2);
        if (typeof content === 'undefined') {
            return rest;
        }
        // Handle fallback arrays:
        var contentArray = Array.isArray(content) ? content : [
            content
        ];
        return _objectSpread2({
            content: contentArray.map((value)=>// This logic was adapted from Stitches :)
                value && (value.includes('"') || value.includes("'") || /^([A-Za-z\-]+\([^]*|[^]*-quote|inherit|initial|none|normal|revert|unset)(\s|$)/.test(value)) ? value : "\"".concat(value, "\""))
        }, rest);
    }
    transformClassname(identifier) {
        return ".".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(identifier, {
            isIdentifier: true
        }));
    }
    transformSelector(selector) {
        // Map class list compositions to single identifiers
        var transformedSelector = selector;
        var _loop = function _loop(identifier) {
            transformedSelector = transformedSelector.replace(regex, ()=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markCompositionUsed"])(identifier);
                return identifier;
            });
        };
        for (var { identifier, regex } of this.composedClassLists){
            _loop(identifier);
        }
        if (this.localClassNamesMap.has(transformedSelector)) {
            return this.transformClassname(transformedSelector);
        }
        var results = this.localClassNamesSearch.search(transformedSelector);
        var lastReplaceIndex = transformedSelector.length;
        // Perform replacements backwards to simplify index handling
        for(var i = results.length - 1; i >= 0; i--){
            var [endIndex, [firstMatch]] = results[i];
            var startIndex = endIndex - firstMatch.length + 1;
            // Class names can be substrings of other class names
            // e.g. '_1g1ptzo1' and '_1g1ptzo10'
            //
            // Additionally, concatenated classnames can contain substrings equal to other classnames
            // e.g. '&&' where '&' is 'debugName_hash1' and 'debugName_hash1d' is also a local classname
            // Before transforming the selector, this would look like `debugName_hash1debugName_hash1`
            // which contains the substring `debugName_hash1d`’.
            //
            // In either of these cases, the last replace index will occur either before or within the
            // current replacement range (from `startIndex` to `endIndex`).
            // If this occurs, we skip the replacement to avoid transforming the selector incorrectly.
            var skipReplacement = lastReplaceIndex <= endIndex;
            if (skipReplacement) {
                continue;
            }
            lastReplaceIndex = startIndex;
            // If class names already starts with a '.' then skip
            if (transformedSelector[startIndex - 1] !== '.') {
                transformedSelector = replaceBetweenIndexes(transformedSelector, startIndex, endIndex + 1, this.transformClassname(firstMatch));
            }
        }
        return transformedSelector;
    }
    transformSelectors(root, rule, conditions) {
        forEach(rule.selectors, (selectorRule, selector)=>{
            if (root.type !== 'local') {
                throw new Error("Selectors are not allowed within ".concat(root.type === 'global' ? '"globalStyle"' : '"selectors"'));
            }
            var transformedSelector = this.transformSelector(selector.replace(RegExp('&', 'g'), root.selector));
            validateSelector(transformedSelector, root.selector);
            var rule = {
                selector: transformedSelector,
                rule: omit(selectorRule, specialKeys)
            };
            if (conditions) {
                this.addConditionalRule(rule, conditions);
            } else {
                this.addRule(rule);
            }
            var selectorRoot = {
                type: 'selector',
                selector: transformedSelector,
                rule: selectorRule
            };
            this.transformLayer(selectorRoot, selectorRule['@layer'], conditions);
            this.transformSupports(selectorRoot, selectorRule['@supports'], conditions);
            this.transformMedia(selectorRoot, selectorRule['@media'], conditions);
            this.transformContainer(selectorRoot, selectorRule['@container'], conditions);
        });
    }
    transformMedia(root, rules) {
        var parentConditions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
        if (rules) {
            var _this$currConditional;
            (_this$currConditional = this.currConditionalRuleset) === null || _this$currConditional === void 0 || _this$currConditional.addConditionPrecedence(parentConditions, Object.keys(rules).map((query)=>"@media ".concat(query)));
            for (var [query, mediaRule] of Object.entries(rules)){
                var mediaQuery = "@media ".concat(query);
                validateMediaQuery(mediaQuery);
                var conditions = [
                    ...parentConditions,
                    mediaQuery
                ];
                this.addConditionalRule({
                    selector: root.selector,
                    rule: omit(mediaRule, specialKeys)
                }, conditions);
                if (root.type === 'local') {
                    this.transformSimplePseudos(root, mediaRule, conditions);
                    this.transformSelectors(root, mediaRule, conditions);
                }
                this.transformLayer(root, mediaRule['@layer'], conditions);
                this.transformSupports(root, mediaRule['@supports'], conditions);
                this.transformContainer(root, mediaRule['@container'], conditions);
            }
        }
    }
    transformContainer(root, rules) {
        var parentConditions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
        if (rules) {
            var _this$currConditional2;
            (_this$currConditional2 = this.currConditionalRuleset) === null || _this$currConditional2 === void 0 || _this$currConditional2.addConditionPrecedence(parentConditions, Object.keys(rules).map((query)=>"@container ".concat(query)));
            forEach(rules, (containerRule, query)=>{
                var containerQuery = "@container ".concat(query);
                var conditions = [
                    ...parentConditions,
                    containerQuery
                ];
                this.addConditionalRule({
                    selector: root.selector,
                    rule: omit(containerRule, specialKeys)
                }, conditions);
                if (root.type === 'local') {
                    this.transformSimplePseudos(root, containerRule, conditions);
                    this.transformSelectors(root, containerRule, conditions);
                }
                this.transformLayer(root, containerRule['@layer'], conditions);
                this.transformSupports(root, containerRule['@supports'], conditions);
                this.transformMedia(root, containerRule['@media'], conditions);
            });
        }
    }
    transformLayer(root, rules) {
        var parentConditions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
        if (rules) {
            var _this$currConditional3;
            (_this$currConditional3 = this.currConditionalRuleset) === null || _this$currConditional3 === void 0 || _this$currConditional3.addConditionPrecedence(parentConditions, Object.keys(rules).map((name)=>"@layer ".concat(name)));
            forEach(rules, (layerRule, name)=>{
                var conditions = [
                    ...parentConditions,
                    "@layer ".concat(name)
                ];
                this.addLayer(conditions);
                this.addConditionalRule({
                    selector: root.selector,
                    rule: omit(layerRule, specialKeys)
                }, conditions);
                if (root.type === 'local') {
                    this.transformSimplePseudos(root, layerRule, conditions);
                    this.transformSelectors(root, layerRule, conditions);
                }
                this.transformMedia(root, layerRule['@media'], conditions);
                this.transformSupports(root, layerRule['@supports'], conditions);
                this.transformContainer(root, layerRule['@container'], conditions);
            });
        }
    }
    transformSupports(root, rules) {
        var parentConditions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
        if (rules) {
            var _this$currConditional4;
            (_this$currConditional4 = this.currConditionalRuleset) === null || _this$currConditional4 === void 0 || _this$currConditional4.addConditionPrecedence(parentConditions, Object.keys(rules).map((query)=>"@supports ".concat(query)));
            forEach(rules, (supportsRule, query)=>{
                var conditions = [
                    ...parentConditions,
                    "@supports ".concat(query)
                ];
                this.addConditionalRule({
                    selector: root.selector,
                    rule: omit(supportsRule, specialKeys)
                }, conditions);
                if (root.type === 'local') {
                    this.transformSimplePseudos(root, supportsRule, conditions);
                    this.transformSelectors(root, supportsRule, conditions);
                }
                this.transformLayer(root, supportsRule['@layer'], conditions);
                this.transformMedia(root, supportsRule['@media'], conditions);
                this.transformContainer(root, supportsRule['@container'], conditions);
            });
        }
    }
    transformSimplePseudos(root, rule, conditions) {
        for (var key of Object.keys(rule)){
            // Process simple pseudos
            if (simplePseudoLookup[key]) {
                if (root.type !== 'local') {
                    throw new Error("Simple pseudos are not valid in ".concat(root.type === 'global' ? '"globalStyle"' : '"selectors"'));
                }
                if (conditions) {
                    this.addConditionalRule({
                        selector: "".concat(root.selector).concat(key),
                        rule: rule[key]
                    }, conditions);
                } else {
                    this.addRule({
                        conditions,
                        selector: "".concat(root.selector).concat(key),
                        rule: rule[key]
                    });
                }
            }
        }
    }
    toCss() {
        var css = [];
        // Render font-face rules
        for (var fontFaceRule of this.fontFaceRules){
            css.push(renderCss({
                '@font-face': fontFaceRule
            }));
        }
        // Render property rules
        for (var property of this.propertyRules){
            css.push(renderCss({
                ["@property ".concat(property.name)]: property.rule
            }));
        }
        // Render keyframes
        for (var keyframe of this.keyframesRules){
            css.push(renderCss({
                ["@keyframes ".concat(keyframe.name)]: keyframe.rule
            }));
        }
        // Render layer definitions
        for (var layer of this.layers.values()){
            var [definition, ...nesting] = layer.reverse();
            var cssObj = {
                [definition]: DECLARATION
            };
            for (var part of nesting){
                cssObj = {
                    [part]: cssObj
                };
            }
            css.push(renderCss(cssObj));
        }
        // Render unconditional rules
        for (var rule of this.rules){
            css.push(renderCss({
                [rule.selector]: rule.rule
            }));
        }
        // Render conditional rules
        for (var conditionalRuleset of this.conditionalRulesets){
            for (var conditionalRule of conditionalRuleset.renderToArray()){
                css.push(renderCss(conditionalRule));
            }
        }
        return css.filter(Boolean);
    }
}
function renderCss(v) {
    var indent = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var rules = [];
    var _loop2 = function _loop2(key) {
        var value = v[key];
        if (value && Array.isArray(value)) {
            rules.push(...value.map((v)=>renderCss({
                    [key]: v
                }, indent)));
        } else if (value && typeof value === 'object') {
            var isEmpty = Object.keys(value).length === 0;
            if (!isEmpty) {
                rules.push("".concat(indent).concat(key, " {\n").concat(renderCss(value, indent + DOUBLE_SPACE), "\n").concat(indent, "}"));
            }
        } else if (value === DECLARATION) {
            rules.push("".concat(indent).concat(key, ";"));
        } else {
            rules.push("".concat(indent).concat(key.startsWith('--') ? key : dashify(key), ": ").concat(value, ";"));
        }
    };
    for (var key of Object.keys(v)){
        _loop2(key);
    }
    return rules.join('\n');
}
function transformCss(_ref5) {
    var { localClassNames, cssObjs, composedClassLists } = _ref5;
    var stylesheet = new Stylesheet(localClassNames, composedClassLists);
    for (var root of cssObjs){
        stylesheet.processCssObj(root);
    }
    return stylesheet.toCss();
}
;
}}),
"[project]/node_modules/@vanilla-extract/css/fileScope/dist/vanilla-extract-css-fileScope.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "endFileScope": (()=>endFileScope),
    "getAndIncrementRefCounter": (()=>getAndIncrementRefCounter),
    "getFileScope": (()=>getFileScope),
    "hasFileScope": (()=>hasFileScope),
    "setFileScope": (()=>setFileScope)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/dist/taggedTemplateLiteral-8e47dbd7.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/node_modules/dedent/dist/dedent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/adapter/dist/vanilla-extract-css-adapter.browser.esm.js [app-client] (ecmascript)");
;
;
;
var _templateObject;
var refCounter = 0;
var fileScopes = [];
function setFileScope(filePath, packageName) {
    refCounter = 0;
    var fileScope = {
        filePath,
        packageName
    };
    fileScopes.unshift(fileScope);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onBeginFileScope"])(fileScope);
}
function endFileScope() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onEndFileScope"])(getFileScope());
    refCounter = 0;
    fileScopes.splice(0, 1);
}
function hasFileScope() {
    return fileScopes.length > 0;
}
function getFileScope() {
    if (fileScopes.length === 0) {
        throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_templateObject || (_templateObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])([
            "\n        Styles were unable to be assigned to a file. This is generally caused by one of the following:\n\n        - You may have created styles outside of a '.css.ts' context\n        - You may have incorrect configuration. See https://vanilla-extract.style/documentation/getting-started\n      "
        ]))));
    }
    return fileScopes[0];
}
function getAndIncrementRefCounter() {
    return refCounter++;
}
;
}}),
"[project]/node_modules/@vanilla-extract/css/dist/vanilla-extract-css.browser.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assertVarName": (()=>assertVarName),
    "assignVars": (()=>assignVars),
    "composeStyles": (()=>composeStyles),
    "createContainer": (()=>createContainer),
    "createGlobalTheme": (()=>createGlobalTheme),
    "createGlobalThemeContract": (()=>createGlobalThemeContract),
    "createGlobalVar": (()=>createGlobalVar),
    "createTheme": (()=>createTheme),
    "createThemeContract": (()=>createThemeContract),
    "createVar": (()=>createVar),
    "createViewTransition": (()=>createViewTransition),
    "fallbackVar": (()=>fallbackVar),
    "fontFace": (()=>fontFace),
    "generateIdentifier": (()=>generateIdentifier),
    "globalFontFace": (()=>globalFontFace),
    "globalKeyframes": (()=>globalKeyframes),
    "globalLayer": (()=>globalLayer),
    "globalStyle": (()=>globalStyle),
    "keyframes": (()=>keyframes),
    "layer": (()=>layer),
    "style": (()=>style),
    "styleVariants": (()=>styleVariants)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$injectStyles$2f$dist$2f$vanilla$2d$extract$2d$css$2d$injectStyles$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/injectStyles/dist/vanilla-extract-css-injectStyles.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/dist/transformCss-830a230d.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/adapter/dist/vanilla-extract-css-adapter.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$hash$2f$dist$2f$emotion$2d$hash$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@emotion/hash/dist/emotion-hash.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/fileScope/dist/vanilla-extract-css-fileScope.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$lru$2d$cache$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/node_modules/lru-cache/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/private/dist/vanilla-extract-private.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/cssesc/cssesc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deep$2d$object$2d$diff$2f$mjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/deep-object-diff/mjs/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deep$2d$object$2d$diff$2f$mjs$2f$diff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__ = __turbopack_context__.i("[project]/node_modules/deep-object-diff/mjs/diff.js [app-client] (ecmascript) <export default as diff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$picocolors$2f$picocolors$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/picocolors/picocolors.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/dist/taggedTemplateLiteral-8e47dbd7.browser.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/css/node_modules/dedent/dist/dedent.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/deepmerge/dist/cjs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$modern$2d$ahocorasick$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/modern-ahocorasick/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$media$2d$query$2d$parser$2f$dist$2f$media$2d$query$2d$parser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/media-query-parser/dist/media-query-parser.esm.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
var localClassNames = new Set();
var composedClassLists = [];
var bufferedCSSObjs = [];
var browserRuntimeAdapter = {
    appendCss: (cssObj)=>{
        bufferedCSSObjs.push(cssObj);
    },
    registerClassName: (className)=>{
        localClassNames.add(className);
    },
    registerComposition: (composition)=>{
        composedClassLists.push(composition);
    },
    markCompositionUsed: ()=>{},
    onEndFileScope: (fileScope)=>{
        var css = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["t"])({
            localClassNames: Array.from(localClassNames),
            composedClassLists,
            cssObjs: bufferedCSSObjs
        }).join('\n');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$injectStyles$2f$dist$2f$vanilla$2d$extract$2d$css$2d$injectStyles$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["injectStyles"])({
            fileScope,
            css
        });
        bufferedCSSObjs = [];
    },
    getIdentOption: ()=>("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : 'debug'
};
{
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setAdapterIfNotSet"])(browserRuntimeAdapter);
}var getLastSlashBeforeIndex = (path, index)=>{
    var pathIndex = index - 1;
    while(pathIndex >= 0){
        if (path[pathIndex] === '/') {
            return pathIndex;
        }
        pathIndex--;
    }
    return -1;
};
/**
 * Assumptions:
 * - The path is always normalized to use posix file separators (/) (see `addFileScope`)
 * - The path is always relative to the project root, i.e. there will never be a leading slash (see `addFileScope`)
 * - As long as `.css` is there, we have a valid `.css.*` file path, because otherwise there wouldn't
 *   be a file scope to begin with
 *
 * The LRU cache we use can't cache undefined/null values, so we opt to return an empty string,
 * rather than using a custom Symbol or something similar.
 */ var _getDebugFileName = (path)=>{
    var file;
    var lastIndexOfDotCss = path.lastIndexOf('.css');
    if (lastIndexOfDotCss === -1) {
        return '';
    }
    var lastSlashIndex = getLastSlashBeforeIndex(path, lastIndexOfDotCss);
    file = path.slice(lastSlashIndex + 1, lastIndexOfDotCss);
    // There are no slashes, therefore theres no directory to extract
    if (lastSlashIndex === -1) {
        return file;
    }
    var secondLastSlashIndex = getLastSlashBeforeIndex(path, lastSlashIndex - 1);
    // If secondLastSlashIndex is -1, it means that the path looks like `directory/file.css.ts`,
    // in which case dir will still be sliced starting at 0, which is what we want
    var dir = path.slice(secondLastSlashIndex + 1, lastSlashIndex);
    var debugFileName = file !== 'index' ? file : dir;
    return debugFileName;
};
var memoizedGetDebugFileName = ()=>{
    var cache = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$lru$2d$cache$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LRUCache"]({
        max: 500
    });
    return (path)=>{
        var cachedResult = cache.get(path);
        if (cachedResult) {
            return cachedResult;
        }
        var result = _getDebugFileName(path);
        cache.set(path, result);
        return result;
    };
};
var getDebugFileName = memoizedGetDebugFileName();
function getDevPrefix(_ref) {
    var { debugId, debugFileName } = _ref;
    var parts = debugId ? [
        debugId.replace(/\s/g, '_')
    ] : [];
    if (debugFileName) {
        var { filePath } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])();
        var _debugFileName = getDebugFileName(filePath);
        // debugFileName could be an empty string
        if (_debugFileName) {
            parts.unshift(_debugFileName);
        }
    }
    return parts.join('_');
}
function normalizeIdentifier(identifier) {
    return identifier.match(/^[0-9]/) ? "_".concat(identifier) : identifier;
}
function generateIdentifier(arg) {
    var identOption = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIdentOption"])();
    var { debugId, debugFileName = true } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])({}, typeof arg === 'string' ? {
        debugId: arg
    } : null), typeof arg === 'object' ? arg : null);
    // Convert ref count to base 36 for optimal hash lengths
    var refCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAndIncrementRefCounter"])().toString(36);
    var { filePath, packageName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])();
    var fileScopeHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$emotion$2f$hash$2f$dist$2f$emotion$2d$hash$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(packageName ? "".concat(packageName).concat(filePath) : filePath);
    var identifier = "".concat(fileScopeHash).concat(refCount);
    if (identOption === 'debug') {
        var devPrefix = getDevPrefix({
            debugId,
            debugFileName
        });
        if (devPrefix) {
            identifier = "".concat(devPrefix, "__").concat(identifier);
        }
        return normalizeIdentifier(identifier);
    }
    if (typeof identOption === 'function') {
        identifier = identOption({
            hash: identifier,
            debugId,
            filePath,
            packageName
        });
        if (!identifier.match(/^[A-Z_][0-9A-Z_-]+$/i)) {
            throw new Error("Identifier function returned invalid indentifier: \"".concat(identifier, "\""));
        }
        return identifier;
    }
    return normalizeIdentifier(identifier);
}
var normaliseObject = (obj)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(obj, ()=>'');
function validateContract(contract, tokens) {
    var theDiff = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deep$2d$object$2d$diff$2f$mjs$2f$diff$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__["diff"])(normaliseObject(contract), normaliseObject(tokens));
    var valid = Object.keys(theDiff).length === 0;
    return {
        valid,
        diffString: valid ? '' : renderDiff(contract, theDiff)
    };
}
function diffLine(value, nesting, type) {
    var whitespace = [
        ...Array(nesting).keys()
    ].map(()=>'  ').join('');
    var line = "".concat(type ? type : ' ').concat(whitespace).concat(value);
    if ("TURBOPACK compile-time truthy", 1) {
        if (type === '-') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$picocolors$2f$picocolors$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].red(line);
        }
        if (type === '+') {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$picocolors$2f$picocolors$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].green(line);
        }
    }
    return line;
}
function renderDiff(orig, diff) {
    var nesting = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
    var lines = [];
    if (nesting === 0) {
        lines.push(diffLine('{', 0));
    }
    var innerNesting = nesting + 1;
    var keys = Object.keys(diff).sort();
    for (var key of keys){
        var value = diff[key];
        if (!(key in orig)) {
            lines.push(diffLine("".concat(key, ": ...,"), innerNesting, '+'));
        } else if (typeof value === 'object') {
            lines.push(diffLine("".concat(key, ": {"), innerNesting));
            lines.push(renderDiff(orig[key], diff[key], innerNesting));
            lines.push(diffLine('}', innerNesting));
        } else {
            lines.push(diffLine("".concat(key, ": ...,"), innerNesting, '-'));
        }
    }
    if (nesting === 0) {
        lines.push(diffLine('}', 0));
    }
    return lines.join('\n');
}
var buildPropertyRule = (_ref)=>{
    var { syntax, inherits, initialValue } = _ref;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])({
        syntax: "\"".concat(Array.isArray(syntax) ? syntax.join(' | ') : syntax, "\""),
        inherits: inherits ? 'true' : 'false'
    }, initialValue != null ? {
        initialValue
    } : {});
};
function createVar(debugIdOrDeclaration, debugId) {
    var cssVarName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(generateIdentifier({
        debugId: typeof debugIdOrDeclaration === 'string' ? debugIdOrDeclaration : debugId,
        debugFileName: false
    }), {
        isIdentifier: true
    });
    if (debugIdOrDeclaration && typeof debugIdOrDeclaration === 'object') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
            type: 'property',
            name: "--".concat(cssVarName),
            rule: buildPropertyRule(debugIdOrDeclaration)
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    }
    return "var(--".concat(cssVarName, ")");
}
function createGlobalVar(name, declaration) {
    if (declaration && typeof declaration === 'object') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
            type: 'property',
            name: "--".concat(name),
            rule: buildPropertyRule(declaration)
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    }
    return "var(--".concat(name, ")");
}
function assertVarName(value) {
    if (typeof value !== 'string' || !/^var\(--.*\)$/.test(value)) {
        throw new Error("Invalid variable name: ".concat(value));
    }
}
function fallbackVar() {
    var finalValue = '';
    for(var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++){
        values[_key] = arguments[_key];
    }
    values.reverse().forEach((value)=>{
        if (finalValue === '') {
            finalValue = String(value);
        } else {
            assertVarName(value);
            finalValue = value.replace(/\)$/, ", ".concat(finalValue, ")"));
        }
    });
    return finalValue;
}
function assignVars(varContract, tokens) {
    var varSetters = {};
    var { valid, diffString } = validateContract(varContract, tokens);
    if (!valid) {
        throw new Error("Tokens don't match contract.\n".concat(diffString));
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(tokens, (value, path)=>{
        varSetters[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["get"])(varContract, path)] = String(value);
    });
    return varSetters;
}
function createThemeContract(tokens) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(tokens, (_value, path)=>{
        return createVar(path.join('-'));
    });
}
function createGlobalThemeContract(tokens, mapFn) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(tokens, (value, path)=>{
        var rawVarName = typeof mapFn === 'function' ? mapFn(value, path) : value;
        var varName = typeof rawVarName === 'string' ? rawVarName.replace(/^\-\-/, '') : null;
        if (typeof varName !== 'string' || varName !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(varName, {
            isIdentifier: true
        })) {
            throw new Error("Invalid variable name for \"".concat(path.join('.'), "\": ").concat(varName));
        }
        return "var(--".concat(varName, ")");
    });
}
var _excluded = [
    "@layer"
];
function createGlobalTheme(selector, arg2, arg3) {
    var themeContractProvided = Boolean(arg3);
    var tokenArg = themeContractProvided ? arg3 : arg2;
    var { layerName, tokens } = extractLayerFromTokens(tokenArg);
    var themeContract = themeContractProvided ? arg2 : createThemeContract(tokens);
    var rule = {
        vars: assignVars(themeContract, tokens)
    };
    if (layerName) {
        rule = {
            '@layer': {
                [layerName]: rule
            }
        };
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'global',
        selector: selector,
        rule
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    if (!themeContractProvided) {
        return themeContract;
    }
}
function createTheme(arg1, arg2, arg3) {
    var themeClassName = generateIdentifier(typeof arg2 === 'object' ? arg3 : arg2);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerClassName"])(themeClassName, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    var vars = typeof arg2 === 'object' ? createGlobalTheme(themeClassName, arg1, arg2) : createGlobalTheme(themeClassName, arg1);
    return vars ? [
        themeClassName,
        vars
    ] : themeClassName;
}
function extractLayerFromTokens(tokens) {
    if ('@layer' in tokens) {
        var { '@layer': layerName } = tokens, rest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["a"])(tokens, _excluded);
        return {
            layerName,
            tokens: rest
        };
    }
    return {
        tokens
    };
}
var _templateObject;
function composedStyle(rules, debugId) {
    var className = generateIdentifier(debugId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerClassName"])(className, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    var classList = [];
    var styleRules = [];
    for (var rule of rules){
        if (typeof rule === 'string') {
            classList.push(rule);
        } else {
            styleRules.push(rule);
        }
    }
    var result = className;
    if (classList.length > 0) {
        result = "".concat(className, " ").concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"])(classList));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerComposition"])({
            identifier: className,
            classList: result
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
        if (styleRules.length > 0) {
            // If there are styles attached to this composition then it is
            // always used and should never be removed
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["markCompositionUsed"])(className);
        }
    }
    if (styleRules.length > 0) {
        var _rule = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$deepmerge$2f$dist$2f$cjs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].all(styleRules, {
            // Replace arrays rather than merging
            arrayMerge: (_, sourceArray)=>sourceArray
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
            type: 'local',
            selector: className,
            rule: _rule
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    }
    return result;
}
function style(rule, debugId) {
    if (Array.isArray(rule)) {
        return composedStyle(rule, debugId);
    }
    var className = generateIdentifier(debugId);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerClassName"])(className, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'local',
        selector: className,
        rule
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    return className;
}
/**
 * @deprecated The same functionality is now provided by the 'style' function when you pass it an array
 */ function composeStyles() {
    var compose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hasFileScope"])() ? composedStyle : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["d"];
    for(var _len = arguments.length, classNames = new Array(_len), _key = 0; _key < _len; _key++){
        classNames[_key] = arguments[_key];
    }
    return compose(classNames);
}
function globalStyle(selector, rule) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'global',
        selector,
        rule
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
}
function fontFace(rule, debugId) {
    var fontFamily = "\"".concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(generateIdentifier(debugId), {
        quotes: 'double'
    }), "\"");
    var rules = Array.isArray(rule) ? rule : [
        rule
    ];
    for (var singleRule of rules){
        if ('fontFamily' in singleRule) {
            throw new Error((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$node_modules$2f$dedent$2f$dist$2f$dedent$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(_templateObject || (_templateObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$taggedTemplateLiteral$2d$8e47dbd7$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])([
                "\n      This function creates and returns a hashed font-family name, so the \"fontFamily\" property should not be provided.\n    \n      If you'd like to define a globally scoped custom font, you can use the \"globalFontFace\" function instead.\n    "
            ]))));
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
            type: 'fontFace',
            rule: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])({}, singleRule), {}, {
                fontFamily
            })
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    }
    return fontFamily;
}
function globalFontFace(fontFamily, rule) {
    var rules = Array.isArray(rule) ? rule : [
        rule
    ];
    for (var singleRule of rules){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
            type: 'fontFace',
            rule: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])({}, singleRule), {}, {
                fontFamily
            })
        }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    }
}
function keyframes(rule, debugId) {
    var name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cssesc$2f$cssesc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(generateIdentifier(debugId), {
        isIdentifier: true
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'keyframes',
        name,
        rule
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    return name;
}
function globalKeyframes(name, rule) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'keyframes',
        name,
        rule
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
}
function styleVariants() {
    if (typeof (arguments.length <= 1 ? undefined : arguments[1]) === 'function') {
        var _data = arguments.length <= 0 ? undefined : arguments[0];
        var _mapData = arguments.length <= 1 ? undefined : arguments[1];
        var _debugId = arguments.length <= 2 ? undefined : arguments[2];
        var _classMap = {};
        for(var _key2 in _data){
            _classMap[_key2] = style(_mapData(_data[_key2], _key2), _debugId ? "".concat(_debugId, "_").concat(_key2) : _key2);
        }
        return _classMap;
    }
    var styleMap = arguments.length <= 0 ? undefined : arguments[0];
    var debugId = arguments.length <= 1 ? undefined : arguments[1];
    var classMap = {};
    for(var _key3 in styleMap){
        classMap[_key3] = style(styleMap[_key3], debugId ? "".concat(debugId, "_").concat(_key3) : _key3);
    }
    return classMap;
}
// createContainer is used for local scoping of CSS containers
// For now it is mostly just an alias of generateIdentifier
var createContainer = (debugId)=>generateIdentifier(debugId);
// createViewTransition is used for locally scoping CSS view transitions
// For now it is mostly just an alias of generateIdentifier
var createViewTransition = (debugId)=>generateIdentifier(debugId);
var defaultLayerOptions = {};
var merge = (obj1, obj2)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$dist$2f$transformCss$2d$830a230d$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_"])({}, obj1), obj2);
var getLayerArgs = function getLayerArgs() {
    var options = defaultLayerOptions;
    var debugId = arguments.length <= 0 ? undefined : arguments[0];
    if (typeof (arguments.length <= 0 ? undefined : arguments[0]) === 'object') {
        options = merge(defaultLayerOptions, arguments.length <= 0 ? undefined : arguments[0]);
        debugId = arguments.length <= 1 ? undefined : arguments[1];
    }
    return [
        options,
        debugId
    ];
};
function layer() {
    var [options, debugId] = getLayerArgs(...arguments);
    var name = generateIdentifier(debugId);
    if (options.parent) {
        name = "".concat(options.parent, ".").concat(name);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'layer',
        name
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    return name;
}
function globalLayer() {
    var [options, name] = getLayerArgs(...arguments);
    if (options.parent) {
        name = "".concat(options.parent, ".").concat(name);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$adapter$2f$dist$2f$vanilla$2d$extract$2d$css$2d$adapter$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["appendCss"])({
        type: 'layer',
        name
    }, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$css$2f$fileScope$2f$dist$2f$vanilla$2d$extract$2d$css$2d$fileScope$2e$browser$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFileScope"])());
    return name;
}
;
}}),
"[project]/node_modules/@vanilla-extract/private/dist/vanilla-extract-private.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "get": (()=>get),
    "getVarName": (()=>getVarName),
    "walkObject": (()=>walkObject)
});
function getVarName(variable) {
    var matches = variable.match(/^var\((.*)\)$/);
    if (matches) {
        return matches[1];
    }
    return variable;
}
function get(obj, path) {
    var result = obj;
    for (var key of path){
        if (!(key in result)) {
            throw new Error("Path ".concat(path.join(' -> '), " does not exist in object"));
        }
        result = result[key];
    }
    return result;
}
function walkObject(obj, fn) {
    var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
    var clone = {};
    for(var key in obj){
        var _value = obj[key];
        var currentPath = [
            ...path,
            key
        ];
        if (typeof _value === 'string' || typeof _value === 'number' || _value == null) {
            clone[key] = fn(_value, currentPath);
        } else if (typeof _value === 'object' && !Array.isArray(_value)) {
            clone[key] = walkObject(_value, fn, currentPath);
        } else {
            console.warn("Skipping invalid key \"".concat(currentPath.join('.'), "\". Should be a string, number, null or object. Received: \"").concat(Array.isArray(_value) ? 'Array' : typeof _value, "\""));
        }
    }
    return clone;
}
;
}}),
"[project]/node_modules/@vanilla-extract/css/node_modules/dedent/dist/dedent.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return typeof key === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (typeof res !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
const dedent = createDedent({});
const __TURBOPACK__default__export__ = dedent;
function createDedent(options) {
    dedent.withOptions = (newOptions)=>createDedent(_objectSpread(_objectSpread({}, options), newOptions));
    return dedent;
    "TURBOPACK unreachable";
    function dedent(strings, ...values) {
        const raw = typeof strings === "string" ? [
            strings
        ] : strings.raw;
        const { escapeSpecialCharacters = Array.isArray(strings), trimWhitespace = true } = options;
        // first, perform interpolation
        let result = "";
        for(let i = 0; i < raw.length; i++){
            let next = raw[i];
            if (escapeSpecialCharacters) {
                // handle escaped newlines, backticks, and interpolation characters
                next = next.replace(/\\\n[ \t]*/g, "").replace(/\\`/g, "`").replace(/\\\$/g, "$").replace(/\\\{/g, "{");
            }
            result += next;
            if (i < values.length) {
                // eslint-disable-next-line @typescript-eslint/restrict-plus-operands
                result += values[i];
            }
        }
        // now strip indentation
        const lines = result.split("\n");
        let mindent = null;
        for (const l of lines){
            const m = l.match(/^(\s+)\S+/);
            if (m) {
                const indent = m[1].length;
                if (!mindent) {
                    // this is the first indented line
                    mindent = indent;
                } else {
                    mindent = Math.min(mindent, indent);
                }
            }
        }
        if (mindent !== null) {
            const m = mindent; // appease TypeScript
            result = lines// https://github.com/typescript-eslint/typescript-eslint/issues/7140
            // eslint-disable-next-line @typescript-eslint/prefer-string-starts-ends-with
            .map((l)=>l[0] === " " || l[0] === "\t" ? l.slice(m) : l).join("\n");
        }
        // dedent eats leading and trailing whitespace too
        if (trimWhitespace) {
            result = result.trim();
        }
        // handle escaped newlines at the end to ensure they don't get stripped too
        if (escapeSpecialCharacters) {
            result = result.replace(/\\n/g, "\n");
        }
        return result;
    }
}
}}),
"[project]/node_modules/@vanilla-extract/css/node_modules/lru-cache/dist/esm/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * @module LRUCache
 */ __turbopack_context__.s({
    "LRUCache": (()=>LRUCache)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const perf = typeof performance === 'object' && performance && typeof performance.now === 'function' ? performance : Date;
const warned = new Set();
/* c8 ignore start */ const PROCESS = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] === 'object' && !!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] : {};
/* c8 ignore start */ const emitWarning = (msg, type, code, fn)=>{
    typeof PROCESS.emitWarning === 'function' ? PROCESS.emitWarning(msg, type, code, fn) : console.error(`[${code}] ${type}: ${msg}`);
};
let AC = globalThis.AbortController;
let AS = globalThis.AbortSignal;
/* c8 ignore start */ if (typeof AC === 'undefined') {
    //@ts-ignore
    AS = class AbortSignal {
        onabort;
        _onabort = [];
        reason;
        aborted = false;
        addEventListener(_, fn) {
            this._onabort.push(fn);
        }
    };
    //@ts-ignore
    AC = class AbortController {
        constructor(){
            warnACPolyfill();
        }
        signal = new AS();
        abort(reason) {
            if (this.signal.aborted) return;
            //@ts-ignore
            this.signal.reason = reason;
            //@ts-ignore
            this.signal.aborted = true;
            //@ts-ignore
            for (const fn of this.signal._onabort){
                fn(reason);
            }
            this.signal.onabort?.(reason);
        }
    };
    let printACPolyfillWarning = PROCESS.env?.LRU_CACHE_IGNORE_AC_WARNING !== '1';
    const warnACPolyfill = ()=>{
        if (!printACPolyfillWarning) return;
        printACPolyfillWarning = false;
        emitWarning('AbortController is not defined. If using lru-cache in ' + 'node 14, load an AbortController polyfill from the ' + '`node-abort-controller` package. A minimal polyfill is ' + 'provided for use by LRUCache.fetch(), but it should not be ' + 'relied upon in other contexts (eg, passing it to other APIs that ' + 'use AbortController/AbortSignal might have undesirable effects). ' + 'You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.', 'NO_ABORT_CONTROLLER', 'ENOTSUP', warnACPolyfill);
    };
}
/* c8 ignore stop */ const shouldWarn = (code)=>!warned.has(code);
const TYPE = Symbol('type');
const isPosInt = (n)=>n && n === Math.floor(n) && n > 0 && isFinite(n);
/* c8 ignore start */ // This is a little bit ridiculous, tbh.
// The maximum array length is 2^32-1 or thereabouts on most JS impls.
// And well before that point, you're caching the entire world, I mean,
// that's ~32GB of just integers for the next/prev links, plus whatever
// else to hold that many keys and values.  Just filling the memory with
// zeroes at init time is brutal when you get that big.
// But why not be complete?
// Maybe in the future, these limits will have expanded.
const getUintArray = (max)=>!isPosInt(max) ? null : max <= Math.pow(2, 8) ? Uint8Array : max <= Math.pow(2, 16) ? Uint16Array : max <= Math.pow(2, 32) ? Uint32Array : max <= Number.MAX_SAFE_INTEGER ? ZeroArray : null;
/* c8 ignore stop */ class ZeroArray extends Array {
    constructor(size){
        super(size);
        this.fill(0);
    }
}
class Stack {
    heap;
    length;
    // private constructor
    static #constructing = false;
    static create(max) {
        const HeapCls = getUintArray(max);
        if (!HeapCls) return [];
        Stack.#constructing = true;
        const s = new Stack(max, HeapCls);
        Stack.#constructing = false;
        return s;
    }
    constructor(max, HeapCls){
        /* c8 ignore start */ if (!Stack.#constructing) {
            throw new TypeError('instantiate Stack using Stack.create(n)');
        }
        /* c8 ignore stop */ this.heap = new HeapCls(max);
        this.length = 0;
    }
    push(n) {
        this.heap[this.length++] = n;
    }
    pop() {
        return this.heap[--this.length];
    }
}
class LRUCache {
    // options that cannot be changed without disaster
    #max;
    #maxSize;
    #dispose;
    #disposeAfter;
    #fetchMethod;
    #memoMethod;
    /**
     * {@link LRUCache.OptionsBase.ttl}
     */ ttl;
    /**
     * {@link LRUCache.OptionsBase.ttlResolution}
     */ ttlResolution;
    /**
     * {@link LRUCache.OptionsBase.ttlAutopurge}
     */ ttlAutopurge;
    /**
     * {@link LRUCache.OptionsBase.updateAgeOnGet}
     */ updateAgeOnGet;
    /**
     * {@link LRUCache.OptionsBase.updateAgeOnHas}
     */ updateAgeOnHas;
    /**
     * {@link LRUCache.OptionsBase.allowStale}
     */ allowStale;
    /**
     * {@link LRUCache.OptionsBase.noDisposeOnSet}
     */ noDisposeOnSet;
    /**
     * {@link LRUCache.OptionsBase.noUpdateTTL}
     */ noUpdateTTL;
    /**
     * {@link LRUCache.OptionsBase.maxEntrySize}
     */ maxEntrySize;
    /**
     * {@link LRUCache.OptionsBase.sizeCalculation}
     */ sizeCalculation;
    /**
     * {@link LRUCache.OptionsBase.noDeleteOnFetchRejection}
     */ noDeleteOnFetchRejection;
    /**
     * {@link LRUCache.OptionsBase.noDeleteOnStaleGet}
     */ noDeleteOnStaleGet;
    /**
     * {@link LRUCache.OptionsBase.allowStaleOnFetchAbort}
     */ allowStaleOnFetchAbort;
    /**
     * {@link LRUCache.OptionsBase.allowStaleOnFetchRejection}
     */ allowStaleOnFetchRejection;
    /**
     * {@link LRUCache.OptionsBase.ignoreFetchAbort}
     */ ignoreFetchAbort;
    // computed properties
    #size;
    #calculatedSize;
    #keyMap;
    #keyList;
    #valList;
    #next;
    #prev;
    #head;
    #tail;
    #free;
    #disposed;
    #sizes;
    #starts;
    #ttls;
    #hasDispose;
    #hasFetchMethod;
    #hasDisposeAfter;
    /**
     * Do not call this method unless you need to inspect the
     * inner workings of the cache.  If anything returned by this
     * object is modified in any way, strange breakage may occur.
     *
     * These fields are private for a reason!
     *
     * @internal
     */ static unsafeExposeInternals(c) {
        return {
            // properties
            starts: c.#starts,
            ttls: c.#ttls,
            sizes: c.#sizes,
            keyMap: c.#keyMap,
            keyList: c.#keyList,
            valList: c.#valList,
            next: c.#next,
            prev: c.#prev,
            get head () {
                return c.#head;
            },
            get tail () {
                return c.#tail;
            },
            free: c.#free,
            // methods
            isBackgroundFetch: (p)=>c.#isBackgroundFetch(p),
            backgroundFetch: (k, index, options, context)=>c.#backgroundFetch(k, index, options, context),
            moveToTail: (index)=>c.#moveToTail(index),
            indexes: (options)=>c.#indexes(options),
            rindexes: (options)=>c.#rindexes(options),
            isStale: (index)=>c.#isStale(index)
        };
    }
    // Protected read-only members
    /**
     * {@link LRUCache.OptionsBase.max} (read-only)
     */ get max() {
        return this.#max;
    }
    /**
     * {@link LRUCache.OptionsBase.maxSize} (read-only)
     */ get maxSize() {
        return this.#maxSize;
    }
    /**
     * The total computed size of items in the cache (read-only)
     */ get calculatedSize() {
        return this.#calculatedSize;
    }
    /**
     * The number of items stored in the cache (read-only)
     */ get size() {
        return this.#size;
    }
    /**
     * {@link LRUCache.OptionsBase.fetchMethod} (read-only)
     */ get fetchMethod() {
        return this.#fetchMethod;
    }
    get memoMethod() {
        return this.#memoMethod;
    }
    /**
     * {@link LRUCache.OptionsBase.dispose} (read-only)
     */ get dispose() {
        return this.#dispose;
    }
    /**
     * {@link LRUCache.OptionsBase.disposeAfter} (read-only)
     */ get disposeAfter() {
        return this.#disposeAfter;
    }
    constructor(options){
        const { max = 0, ttl, ttlResolution = 1, ttlAutopurge, updateAgeOnGet, updateAgeOnHas, allowStale, dispose, disposeAfter, noDisposeOnSet, noUpdateTTL, maxSize = 0, maxEntrySize = 0, sizeCalculation, fetchMethod, memoMethod, noDeleteOnFetchRejection, noDeleteOnStaleGet, allowStaleOnFetchRejection, allowStaleOnFetchAbort, ignoreFetchAbort } = options;
        if (max !== 0 && !isPosInt(max)) {
            throw new TypeError('max option must be a nonnegative integer');
        }
        const UintArray = max ? getUintArray(max) : Array;
        if (!UintArray) {
            throw new Error('invalid max value: ' + max);
        }
        this.#max = max;
        this.#maxSize = maxSize;
        this.maxEntrySize = maxEntrySize || this.#maxSize;
        this.sizeCalculation = sizeCalculation;
        if (this.sizeCalculation) {
            if (!this.#maxSize && !this.maxEntrySize) {
                throw new TypeError('cannot set sizeCalculation without setting maxSize or maxEntrySize');
            }
            if (typeof this.sizeCalculation !== 'function') {
                throw new TypeError('sizeCalculation set to non-function');
            }
        }
        if (memoMethod !== undefined && typeof memoMethod !== 'function') {
            throw new TypeError('memoMethod must be a function if defined');
        }
        this.#memoMethod = memoMethod;
        if (fetchMethod !== undefined && typeof fetchMethod !== 'function') {
            throw new TypeError('fetchMethod must be a function if specified');
        }
        this.#fetchMethod = fetchMethod;
        this.#hasFetchMethod = !!fetchMethod;
        this.#keyMap = new Map();
        this.#keyList = new Array(max).fill(undefined);
        this.#valList = new Array(max).fill(undefined);
        this.#next = new UintArray(max);
        this.#prev = new UintArray(max);
        this.#head = 0;
        this.#tail = 0;
        this.#free = Stack.create(max);
        this.#size = 0;
        this.#calculatedSize = 0;
        if (typeof dispose === 'function') {
            this.#dispose = dispose;
        }
        if (typeof disposeAfter === 'function') {
            this.#disposeAfter = disposeAfter;
            this.#disposed = [];
        } else {
            this.#disposeAfter = undefined;
            this.#disposed = undefined;
        }
        this.#hasDispose = !!this.#dispose;
        this.#hasDisposeAfter = !!this.#disposeAfter;
        this.noDisposeOnSet = !!noDisposeOnSet;
        this.noUpdateTTL = !!noUpdateTTL;
        this.noDeleteOnFetchRejection = !!noDeleteOnFetchRejection;
        this.allowStaleOnFetchRejection = !!allowStaleOnFetchRejection;
        this.allowStaleOnFetchAbort = !!allowStaleOnFetchAbort;
        this.ignoreFetchAbort = !!ignoreFetchAbort;
        // NB: maxEntrySize is set to maxSize if it's set
        if (this.maxEntrySize !== 0) {
            if (this.#maxSize !== 0) {
                if (!isPosInt(this.#maxSize)) {
                    throw new TypeError('maxSize must be a positive integer if specified');
                }
            }
            if (!isPosInt(this.maxEntrySize)) {
                throw new TypeError('maxEntrySize must be a positive integer if specified');
            }
            this.#initializeSizeTracking();
        }
        this.allowStale = !!allowStale;
        this.noDeleteOnStaleGet = !!noDeleteOnStaleGet;
        this.updateAgeOnGet = !!updateAgeOnGet;
        this.updateAgeOnHas = !!updateAgeOnHas;
        this.ttlResolution = isPosInt(ttlResolution) || ttlResolution === 0 ? ttlResolution : 1;
        this.ttlAutopurge = !!ttlAutopurge;
        this.ttl = ttl || 0;
        if (this.ttl) {
            if (!isPosInt(this.ttl)) {
                throw new TypeError('ttl must be a positive integer if specified');
            }
            this.#initializeTTLTracking();
        }
        // do not allow completely unbounded caches
        if (this.#max === 0 && this.ttl === 0 && this.#maxSize === 0) {
            throw new TypeError('At least one of max, maxSize, or ttl is required');
        }
        if (!this.ttlAutopurge && !this.#max && !this.#maxSize) {
            const code = 'LRU_CACHE_UNBOUNDED';
            if (shouldWarn(code)) {
                warned.add(code);
                const msg = 'TTL caching without ttlAutopurge, max, or maxSize can ' + 'result in unbounded memory consumption.';
                emitWarning(msg, 'UnboundedCacheWarning', code, LRUCache);
            }
        }
    }
    /**
     * Return the number of ms left in the item's TTL. If item is not in cache,
     * returns `0`. Returns `Infinity` if item is in cache without a defined TTL.
     */ getRemainingTTL(key) {
        return this.#keyMap.has(key) ? Infinity : 0;
    }
    #initializeTTLTracking() {
        const ttls = new ZeroArray(this.#max);
        const starts = new ZeroArray(this.#max);
        this.#ttls = ttls;
        this.#starts = starts;
        this.#setItemTTL = (index, ttl, start = perf.now())=>{
            starts[index] = ttl !== 0 ? start : 0;
            ttls[index] = ttl;
            if (ttl !== 0 && this.ttlAutopurge) {
                const t = setTimeout(()=>{
                    if (this.#isStale(index)) {
                        this.#delete(this.#keyList[index], 'expire');
                    }
                }, ttl + 1);
                // unref() not supported on all platforms
                /* c8 ignore start */ if (t.unref) {
                    t.unref();
                }
            /* c8 ignore stop */ }
        };
        this.#updateItemAge = (index)=>{
            starts[index] = ttls[index] !== 0 ? perf.now() : 0;
        };
        this.#statusTTL = (status, index)=>{
            if (ttls[index]) {
                const ttl = ttls[index];
                const start = starts[index];
                /* c8 ignore next */ if (!ttl || !start) return;
                status.ttl = ttl;
                status.start = start;
                status.now = cachedNow || getNow();
                const age = status.now - start;
                status.remainingTTL = ttl - age;
            }
        };
        // debounce calls to perf.now() to 1s so we're not hitting
        // that costly call repeatedly.
        let cachedNow = 0;
        const getNow = ()=>{
            const n = perf.now();
            if (this.ttlResolution > 0) {
                cachedNow = n;
                const t = setTimeout(()=>cachedNow = 0, this.ttlResolution);
                // not available on all platforms
                /* c8 ignore start */ if (t.unref) {
                    t.unref();
                }
            /* c8 ignore stop */ }
            return n;
        };
        this.getRemainingTTL = (key)=>{
            const index = this.#keyMap.get(key);
            if (index === undefined) {
                return 0;
            }
            const ttl = ttls[index];
            const start = starts[index];
            if (!ttl || !start) {
                return Infinity;
            }
            const age = (cachedNow || getNow()) - start;
            return ttl - age;
        };
        this.#isStale = (index)=>{
            const s = starts[index];
            const t = ttls[index];
            return !!t && !!s && (cachedNow || getNow()) - s > t;
        };
    }
    // conditionally set private methods related to TTL
    #updateItemAge = ()=>{};
    #statusTTL = ()=>{};
    #setItemTTL = ()=>{};
    /* c8 ignore stop */ #isStale = ()=>false;
    #initializeSizeTracking() {
        const sizes = new ZeroArray(this.#max);
        this.#calculatedSize = 0;
        this.#sizes = sizes;
        this.#removeItemSize = (index)=>{
            this.#calculatedSize -= sizes[index];
            sizes[index] = 0;
        };
        this.#requireSize = (k, v, size, sizeCalculation)=>{
            // provisionally accept background fetches.
            // actual value size will be checked when they return.
            if (this.#isBackgroundFetch(v)) {
                return 0;
            }
            if (!isPosInt(size)) {
                if (sizeCalculation) {
                    if (typeof sizeCalculation !== 'function') {
                        throw new TypeError('sizeCalculation must be a function');
                    }
                    size = sizeCalculation(v, k);
                    if (!isPosInt(size)) {
                        throw new TypeError('sizeCalculation return invalid (expect positive integer)');
                    }
                } else {
                    throw new TypeError('invalid size value (must be positive integer). ' + 'When maxSize or maxEntrySize is used, sizeCalculation ' + 'or size must be set.');
                }
            }
            return size;
        };
        this.#addItemSize = (index, size, status)=>{
            sizes[index] = size;
            if (this.#maxSize) {
                const maxSize = this.#maxSize - sizes[index];
                while(this.#calculatedSize > maxSize){
                    this.#evict(true);
                }
            }
            this.#calculatedSize += sizes[index];
            if (status) {
                status.entrySize = size;
                status.totalCalculatedSize = this.#calculatedSize;
            }
        };
    }
    #removeItemSize = (_i)=>{};
    #addItemSize = (_i, _s, _st)=>{};
    #requireSize = (_k, _v, size, sizeCalculation)=>{
        if (size || sizeCalculation) {
            throw new TypeError('cannot set size without setting maxSize or maxEntrySize on cache');
        }
        return 0;
    };
    *#indexes({ allowStale = this.allowStale } = {}) {
        if (this.#size) {
            for(let i = this.#tail; true;){
                if (!this.#isValidIndex(i)) {
                    break;
                }
                if (allowStale || !this.#isStale(i)) {
                    yield i;
                }
                if (i === this.#head) {
                    break;
                } else {
                    i = this.#prev[i];
                }
            }
        }
    }
    *#rindexes({ allowStale = this.allowStale } = {}) {
        if (this.#size) {
            for(let i = this.#head; true;){
                if (!this.#isValidIndex(i)) {
                    break;
                }
                if (allowStale || !this.#isStale(i)) {
                    yield i;
                }
                if (i === this.#tail) {
                    break;
                } else {
                    i = this.#next[i];
                }
            }
        }
    }
    #isValidIndex(index) {
        return index !== undefined && this.#keyMap.get(this.#keyList[index]) === index;
    }
    /**
     * Return a generator yielding `[key, value]` pairs,
     * in order from most recently used to least recently used.
     */ *entries() {
        for (const i of this.#indexes()){
            if (this.#valList[i] !== undefined && this.#keyList[i] !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield [
                    this.#keyList[i],
                    this.#valList[i]
                ];
            }
        }
    }
    /**
     * Inverse order version of {@link LRUCache.entries}
     *
     * Return a generator yielding `[key, value]` pairs,
     * in order from least recently used to most recently used.
     */ *rentries() {
        for (const i of this.#rindexes()){
            if (this.#valList[i] !== undefined && this.#keyList[i] !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield [
                    this.#keyList[i],
                    this.#valList[i]
                ];
            }
        }
    }
    /**
     * Return a generator yielding the keys in the cache,
     * in order from most recently used to least recently used.
     */ *keys() {
        for (const i of this.#indexes()){
            const k = this.#keyList[i];
            if (k !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield k;
            }
        }
    }
    /**
     * Inverse order version of {@link LRUCache.keys}
     *
     * Return a generator yielding the keys in the cache,
     * in order from least recently used to most recently used.
     */ *rkeys() {
        for (const i of this.#rindexes()){
            const k = this.#keyList[i];
            if (k !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield k;
            }
        }
    }
    /**
     * Return a generator yielding the values in the cache,
     * in order from most recently used to least recently used.
     */ *values() {
        for (const i of this.#indexes()){
            const v = this.#valList[i];
            if (v !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield this.#valList[i];
            }
        }
    }
    /**
     * Inverse order version of {@link LRUCache.values}
     *
     * Return a generator yielding the values in the cache,
     * in order from least recently used to most recently used.
     */ *rvalues() {
        for (const i of this.#rindexes()){
            const v = this.#valList[i];
            if (v !== undefined && !this.#isBackgroundFetch(this.#valList[i])) {
                yield this.#valList[i];
            }
        }
    }
    /**
     * Iterating over the cache itself yields the same results as
     * {@link LRUCache.entries}
     */ [Symbol.iterator]() {
        return this.entries();
    }
    /**
     * A String value that is used in the creation of the default string
     * description of an object. Called by the built-in method
     * `Object.prototype.toString`.
     */ [Symbol.toStringTag] = 'LRUCache';
    /**
     * Find a value for which the supplied fn method returns a truthy value,
     * similar to `Array.find()`. fn is called as `fn(value, key, cache)`.
     */ find(fn, getOptions = {}) {
        for (const i of this.#indexes()){
            const v = this.#valList[i];
            const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
            if (value === undefined) continue;
            if (fn(value, this.#keyList[i], this)) {
                return this.get(this.#keyList[i], getOptions);
            }
        }
    }
    /**
     * Call the supplied function on each item in the cache, in order from most
     * recently used to least recently used.
     *
     * `fn` is called as `fn(value, key, cache)`.
     *
     * If `thisp` is provided, function will be called in the `this`-context of
     * the provided object, or the cache if no `thisp` object is provided.
     *
     * Does not update age or recenty of use, or iterate over stale values.
     */ forEach(fn, thisp = this) {
        for (const i of this.#indexes()){
            const v = this.#valList[i];
            const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
            if (value === undefined) continue;
            fn.call(thisp, value, this.#keyList[i], this);
        }
    }
    /**
     * The same as {@link LRUCache.forEach} but items are iterated over in
     * reverse order.  (ie, less recently used items are iterated over first.)
     */ rforEach(fn, thisp = this) {
        for (const i of this.#rindexes()){
            const v = this.#valList[i];
            const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
            if (value === undefined) continue;
            fn.call(thisp, value, this.#keyList[i], this);
        }
    }
    /**
     * Delete any stale entries. Returns true if anything was removed,
     * false otherwise.
     */ purgeStale() {
        let deleted = false;
        for (const i of this.#rindexes({
            allowStale: true
        })){
            if (this.#isStale(i)) {
                this.#delete(this.#keyList[i], 'expire');
                deleted = true;
            }
        }
        return deleted;
    }
    /**
     * Get the extended info about a given entry, to get its value, size, and
     * TTL info simultaneously. Returns `undefined` if the key is not present.
     *
     * Unlike {@link LRUCache#dump}, which is designed to be portable and survive
     * serialization, the `start` value is always the current timestamp, and the
     * `ttl` is a calculated remaining time to live (negative if expired).
     *
     * Always returns stale values, if their info is found in the cache, so be
     * sure to check for expirations (ie, a negative {@link LRUCache.Entry#ttl})
     * if relevant.
     */ info(key) {
        const i = this.#keyMap.get(key);
        if (i === undefined) return undefined;
        const v = this.#valList[i];
        const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
        if (value === undefined) return undefined;
        const entry = {
            value
        };
        if (this.#ttls && this.#starts) {
            const ttl = this.#ttls[i];
            const start = this.#starts[i];
            if (ttl && start) {
                const remain = ttl - (perf.now() - start);
                entry.ttl = remain;
                entry.start = Date.now();
            }
        }
        if (this.#sizes) {
            entry.size = this.#sizes[i];
        }
        return entry;
    }
    /**
     * Return an array of [key, {@link LRUCache.Entry}] tuples which can be
     * passed to {@link LRLUCache#load}.
     *
     * The `start` fields are calculated relative to a portable `Date.now()`
     * timestamp, even if `performance.now()` is available.
     *
     * Stale entries are always included in the `dump`, even if
     * {@link LRUCache.OptionsBase.allowStale} is false.
     *
     * Note: this returns an actual array, not a generator, so it can be more
     * easily passed around.
     */ dump() {
        const arr = [];
        for (const i of this.#indexes({
            allowStale: true
        })){
            const key = this.#keyList[i];
            const v = this.#valList[i];
            const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
            if (value === undefined || key === undefined) continue;
            const entry = {
                value
            };
            if (this.#ttls && this.#starts) {
                entry.ttl = this.#ttls[i];
                // always dump the start relative to a portable timestamp
                // it's ok for this to be a bit slow, it's a rare operation.
                const age = perf.now() - this.#starts[i];
                entry.start = Math.floor(Date.now() - age);
            }
            if (this.#sizes) {
                entry.size = this.#sizes[i];
            }
            arr.unshift([
                key,
                entry
            ]);
        }
        return arr;
    }
    /**
     * Reset the cache and load in the items in entries in the order listed.
     *
     * The shape of the resulting cache may be different if the same options are
     * not used in both caches.
     *
     * The `start` fields are assumed to be calculated relative to a portable
     * `Date.now()` timestamp, even if `performance.now()` is available.
     */ load(arr) {
        this.clear();
        for (const [key, entry] of arr){
            if (entry.start) {
                // entry.start is a portable timestamp, but we may be using
                // node's performance.now(), so calculate the offset, so that
                // we get the intended remaining TTL, no matter how long it's
                // been on ice.
                //
                // it's ok for this to be a bit slow, it's a rare operation.
                const age = Date.now() - entry.start;
                entry.start = perf.now() - age;
            }
            this.set(key, entry.value, entry);
        }
    }
    /**
     * Add a value to the cache.
     *
     * Note: if `undefined` is specified as a value, this is an alias for
     * {@link LRUCache#delete}
     *
     * Fields on the {@link LRUCache.SetOptions} options param will override
     * their corresponding values in the constructor options for the scope
     * of this single `set()` operation.
     *
     * If `start` is provided, then that will set the effective start
     * time for the TTL calculation. Note that this must be a previous
     * value of `performance.now()` if supported, or a previous value of
     * `Date.now()` if not.
     *
     * Options object may also include `size`, which will prevent
     * calling the `sizeCalculation` function and just use the specified
     * number if it is a positive integer, and `noDisposeOnSet` which
     * will prevent calling a `dispose` function in the case of
     * overwrites.
     *
     * If the `size` (or return value of `sizeCalculation`) for a given
     * entry is greater than `maxEntrySize`, then the item will not be
     * added to the cache.
     *
     * Will update the recency of the entry.
     *
     * If the value is `undefined`, then this is an alias for
     * `cache.delete(key)`. `undefined` is never stored in the cache.
     */ set(k, v, setOptions = {}) {
        if (v === undefined) {
            this.delete(k);
            return this;
        }
        const { ttl = this.ttl, start, noDisposeOnSet = this.noDisposeOnSet, sizeCalculation = this.sizeCalculation, status } = setOptions;
        let { noUpdateTTL = this.noUpdateTTL } = setOptions;
        const size = this.#requireSize(k, v, setOptions.size || 0, sizeCalculation);
        // if the item doesn't fit, don't do anything
        // NB: maxEntrySize set to maxSize by default
        if (this.maxEntrySize && size > this.maxEntrySize) {
            if (status) {
                status.set = 'miss';
                status.maxEntrySizeExceeded = true;
            }
            // have to delete, in case something is there already.
            this.#delete(k, 'set');
            return this;
        }
        let index = this.#size === 0 ? undefined : this.#keyMap.get(k);
        if (index === undefined) {
            // addition
            index = this.#size === 0 ? this.#tail : this.#free.length !== 0 ? this.#free.pop() : this.#size === this.#max ? this.#evict(false) : this.#size;
            this.#keyList[index] = k;
            this.#valList[index] = v;
            this.#keyMap.set(k, index);
            this.#next[this.#tail] = index;
            this.#prev[index] = this.#tail;
            this.#tail = index;
            this.#size++;
            this.#addItemSize(index, size, status);
            if (status) status.set = 'add';
            noUpdateTTL = false;
        } else {
            // update
            this.#moveToTail(index);
            const oldVal = this.#valList[index];
            if (v !== oldVal) {
                if (this.#hasFetchMethod && this.#isBackgroundFetch(oldVal)) {
                    oldVal.__abortController.abort(new Error('replaced'));
                    const { __staleWhileFetching: s } = oldVal;
                    if (s !== undefined && !noDisposeOnSet) {
                        if (this.#hasDispose) {
                            this.#dispose?.(s, k, 'set');
                        }
                        if (this.#hasDisposeAfter) {
                            this.#disposed?.push([
                                s,
                                k,
                                'set'
                            ]);
                        }
                    }
                } else if (!noDisposeOnSet) {
                    if (this.#hasDispose) {
                        this.#dispose?.(oldVal, k, 'set');
                    }
                    if (this.#hasDisposeAfter) {
                        this.#disposed?.push([
                            oldVal,
                            k,
                            'set'
                        ]);
                    }
                }
                this.#removeItemSize(index);
                this.#addItemSize(index, size, status);
                this.#valList[index] = v;
                if (status) {
                    status.set = 'replace';
                    const oldValue = oldVal && this.#isBackgroundFetch(oldVal) ? oldVal.__staleWhileFetching : oldVal;
                    if (oldValue !== undefined) status.oldValue = oldValue;
                }
            } else if (status) {
                status.set = 'update';
            }
        }
        if (ttl !== 0 && !this.#ttls) {
            this.#initializeTTLTracking();
        }
        if (this.#ttls) {
            if (!noUpdateTTL) {
                this.#setItemTTL(index, ttl, start);
            }
            if (status) this.#statusTTL(status, index);
        }
        if (!noDisposeOnSet && this.#hasDisposeAfter && this.#disposed) {
            const dt = this.#disposed;
            let task;
            while(task = dt?.shift()){
                this.#disposeAfter?.(...task);
            }
        }
        return this;
    }
    /**
     * Evict the least recently used item, returning its value or
     * `undefined` if cache is empty.
     */ pop() {
        try {
            while(this.#size){
                const val = this.#valList[this.#head];
                this.#evict(true);
                if (this.#isBackgroundFetch(val)) {
                    if (val.__staleWhileFetching) {
                        return val.__staleWhileFetching;
                    }
                } else if (val !== undefined) {
                    return val;
                }
            }
        } finally{
            if (this.#hasDisposeAfter && this.#disposed) {
                const dt = this.#disposed;
                let task;
                while(task = dt?.shift()){
                    this.#disposeAfter?.(...task);
                }
            }
        }
    }
    #evict(free) {
        const head = this.#head;
        const k = this.#keyList[head];
        const v = this.#valList[head];
        if (this.#hasFetchMethod && this.#isBackgroundFetch(v)) {
            v.__abortController.abort(new Error('evicted'));
        } else if (this.#hasDispose || this.#hasDisposeAfter) {
            if (this.#hasDispose) {
                this.#dispose?.(v, k, 'evict');
            }
            if (this.#hasDisposeAfter) {
                this.#disposed?.push([
                    v,
                    k,
                    'evict'
                ]);
            }
        }
        this.#removeItemSize(head);
        // if we aren't about to use the index, then null these out
        if (free) {
            this.#keyList[head] = undefined;
            this.#valList[head] = undefined;
            this.#free.push(head);
        }
        if (this.#size === 1) {
            this.#head = this.#tail = 0;
            this.#free.length = 0;
        } else {
            this.#head = this.#next[head];
        }
        this.#keyMap.delete(k);
        this.#size--;
        return head;
    }
    /**
     * Check if a key is in the cache, without updating the recency of use.
     * Will return false if the item is stale, even though it is technically
     * in the cache.
     *
     * Check if a key is in the cache, without updating the recency of
     * use. Age is updated if {@link LRUCache.OptionsBase.updateAgeOnHas} is set
     * to `true` in either the options or the constructor.
     *
     * Will return `false` if the item is stale, even though it is technically in
     * the cache. The difference can be determined (if it matters) by using a
     * `status` argument, and inspecting the `has` field.
     *
     * Will not update item age unless
     * {@link LRUCache.OptionsBase.updateAgeOnHas} is set.
     */ has(k, hasOptions = {}) {
        const { updateAgeOnHas = this.updateAgeOnHas, status } = hasOptions;
        const index = this.#keyMap.get(k);
        if (index !== undefined) {
            const v = this.#valList[index];
            if (this.#isBackgroundFetch(v) && v.__staleWhileFetching === undefined) {
                return false;
            }
            if (!this.#isStale(index)) {
                if (updateAgeOnHas) {
                    this.#updateItemAge(index);
                }
                if (status) {
                    status.has = 'hit';
                    this.#statusTTL(status, index);
                }
                return true;
            } else if (status) {
                status.has = 'stale';
                this.#statusTTL(status, index);
            }
        } else if (status) {
            status.has = 'miss';
        }
        return false;
    }
    /**
     * Like {@link LRUCache#get} but doesn't update recency or delete stale
     * items.
     *
     * Returns `undefined` if the item is stale, unless
     * {@link LRUCache.OptionsBase.allowStale} is set.
     */ peek(k, peekOptions = {}) {
        const { allowStale = this.allowStale } = peekOptions;
        const index = this.#keyMap.get(k);
        if (index === undefined || !allowStale && this.#isStale(index)) {
            return;
        }
        const v = this.#valList[index];
        // either stale and allowed, or forcing a refresh of non-stale value
        return this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
    }
    #backgroundFetch(k, index, options, context) {
        const v = index === undefined ? undefined : this.#valList[index];
        if (this.#isBackgroundFetch(v)) {
            return v;
        }
        const ac = new AC();
        const { signal } = options;
        // when/if our AC signals, then stop listening to theirs.
        signal?.addEventListener('abort', ()=>ac.abort(signal.reason), {
            signal: ac.signal
        });
        const fetchOpts = {
            signal: ac.signal,
            options,
            context
        };
        const cb = (v, updateCache = false)=>{
            const { aborted } = ac.signal;
            const ignoreAbort = options.ignoreFetchAbort && v !== undefined;
            if (options.status) {
                if (aborted && !updateCache) {
                    options.status.fetchAborted = true;
                    options.status.fetchError = ac.signal.reason;
                    if (ignoreAbort) options.status.fetchAbortIgnored = true;
                } else {
                    options.status.fetchResolved = true;
                }
            }
            if (aborted && !ignoreAbort && !updateCache) {
                return fetchFail(ac.signal.reason);
            }
            // either we didn't abort, and are still here, or we did, and ignored
            const bf = p;
            if (this.#valList[index] === p) {
                if (v === undefined) {
                    if (bf.__staleWhileFetching) {
                        this.#valList[index] = bf.__staleWhileFetching;
                    } else {
                        this.#delete(k, 'fetch');
                    }
                } else {
                    if (options.status) options.status.fetchUpdated = true;
                    this.set(k, v, fetchOpts.options);
                }
            }
            return v;
        };
        const eb = (er)=>{
            if (options.status) {
                options.status.fetchRejected = true;
                options.status.fetchError = er;
            }
            return fetchFail(er);
        };
        const fetchFail = (er)=>{
            const { aborted } = ac.signal;
            const allowStaleAborted = aborted && options.allowStaleOnFetchAbort;
            const allowStale = allowStaleAborted || options.allowStaleOnFetchRejection;
            const noDelete = allowStale || options.noDeleteOnFetchRejection;
            const bf = p;
            if (this.#valList[index] === p) {
                // if we allow stale on fetch rejections, then we need to ensure that
                // the stale value is not removed from the cache when the fetch fails.
                const del = !noDelete || bf.__staleWhileFetching === undefined;
                if (del) {
                    this.#delete(k, 'fetch');
                } else if (!allowStaleAborted) {
                    // still replace the *promise* with the stale value,
                    // since we are done with the promise at this point.
                    // leave it untouched if we're still waiting for an
                    // aborted background fetch that hasn't yet returned.
                    this.#valList[index] = bf.__staleWhileFetching;
                }
            }
            if (allowStale) {
                if (options.status && bf.__staleWhileFetching !== undefined) {
                    options.status.returnedStale = true;
                }
                return bf.__staleWhileFetching;
            } else if (bf.__returned === bf) {
                throw er;
            }
        };
        const pcall = (res, rej)=>{
            const fmp = this.#fetchMethod?.(k, v, fetchOpts);
            if (fmp && fmp instanceof Promise) {
                fmp.then((v)=>res(v === undefined ? undefined : v), rej);
            }
            // ignored, we go until we finish, regardless.
            // defer check until we are actually aborting,
            // so fetchMethod can override.
            ac.signal.addEventListener('abort', ()=>{
                if (!options.ignoreFetchAbort || options.allowStaleOnFetchAbort) {
                    res(undefined);
                    // when it eventually resolves, update the cache.
                    if (options.allowStaleOnFetchAbort) {
                        res = (v)=>cb(v, true);
                    }
                }
            });
        };
        if (options.status) options.status.fetchDispatched = true;
        const p = new Promise(pcall).then(cb, eb);
        const bf = Object.assign(p, {
            __abortController: ac,
            __staleWhileFetching: v,
            __returned: undefined
        });
        if (index === undefined) {
            // internal, don't expose status.
            this.set(k, bf, {
                ...fetchOpts.options,
                status: undefined
            });
            index = this.#keyMap.get(k);
        } else {
            this.#valList[index] = bf;
        }
        return bf;
    }
    #isBackgroundFetch(p) {
        if (!this.#hasFetchMethod) return false;
        const b = p;
        return !!b && b instanceof Promise && b.hasOwnProperty('__staleWhileFetching') && b.__abortController instanceof AC;
    }
    async fetch(k, fetchOptions = {}) {
        const { // get options
        allowStale = this.allowStale, updateAgeOnGet = this.updateAgeOnGet, noDeleteOnStaleGet = this.noDeleteOnStaleGet, // set options
        ttl = this.ttl, noDisposeOnSet = this.noDisposeOnSet, size = 0, sizeCalculation = this.sizeCalculation, noUpdateTTL = this.noUpdateTTL, // fetch exclusive options
        noDeleteOnFetchRejection = this.noDeleteOnFetchRejection, allowStaleOnFetchRejection = this.allowStaleOnFetchRejection, ignoreFetchAbort = this.ignoreFetchAbort, allowStaleOnFetchAbort = this.allowStaleOnFetchAbort, context, forceRefresh = false, status, signal } = fetchOptions;
        if (!this.#hasFetchMethod) {
            if (status) status.fetch = 'get';
            return this.get(k, {
                allowStale,
                updateAgeOnGet,
                noDeleteOnStaleGet,
                status
            });
        }
        const options = {
            allowStale,
            updateAgeOnGet,
            noDeleteOnStaleGet,
            ttl,
            noDisposeOnSet,
            size,
            sizeCalculation,
            noUpdateTTL,
            noDeleteOnFetchRejection,
            allowStaleOnFetchRejection,
            allowStaleOnFetchAbort,
            ignoreFetchAbort,
            status,
            signal
        };
        let index = this.#keyMap.get(k);
        if (index === undefined) {
            if (status) status.fetch = 'miss';
            const p = this.#backgroundFetch(k, index, options, context);
            return p.__returned = p;
        } else {
            // in cache, maybe already fetching
            const v = this.#valList[index];
            if (this.#isBackgroundFetch(v)) {
                const stale = allowStale && v.__staleWhileFetching !== undefined;
                if (status) {
                    status.fetch = 'inflight';
                    if (stale) status.returnedStale = true;
                }
                return stale ? v.__staleWhileFetching : v.__returned = v;
            }
            // if we force a refresh, that means do NOT serve the cached value,
            // unless we are already in the process of refreshing the cache.
            const isStale = this.#isStale(index);
            if (!forceRefresh && !isStale) {
                if (status) status.fetch = 'hit';
                this.#moveToTail(index);
                if (updateAgeOnGet) {
                    this.#updateItemAge(index);
                }
                if (status) this.#statusTTL(status, index);
                return v;
            }
            // ok, it is stale or a forced refresh, and not already fetching.
            // refresh the cache.
            const p = this.#backgroundFetch(k, index, options, context);
            const hasStale = p.__staleWhileFetching !== undefined;
            const staleVal = hasStale && allowStale;
            if (status) {
                status.fetch = isStale ? 'stale' : 'refresh';
                if (staleVal && isStale) status.returnedStale = true;
            }
            return staleVal ? p.__staleWhileFetching : p.__returned = p;
        }
    }
    async forceFetch(k, fetchOptions = {}) {
        const v = await this.fetch(k, fetchOptions);
        if (v === undefined) throw new Error('fetch() returned undefined');
        return v;
    }
    memo(k, memoOptions = {}) {
        const memoMethod = this.#memoMethod;
        if (!memoMethod) {
            throw new Error('no memoMethod provided to constructor');
        }
        const { context, forceRefresh, ...options } = memoOptions;
        const v = this.get(k, options);
        if (!forceRefresh && v !== undefined) return v;
        const vv = memoMethod(k, v, {
            options,
            context
        });
        this.set(k, vv, options);
        return vv;
    }
    /**
     * Return a value from the cache. Will update the recency of the cache
     * entry found.
     *
     * If the key is not found, get() will return `undefined`.
     */ get(k, getOptions = {}) {
        const { allowStale = this.allowStale, updateAgeOnGet = this.updateAgeOnGet, noDeleteOnStaleGet = this.noDeleteOnStaleGet, status } = getOptions;
        const index = this.#keyMap.get(k);
        if (index !== undefined) {
            const value = this.#valList[index];
            const fetching = this.#isBackgroundFetch(value);
            if (status) this.#statusTTL(status, index);
            if (this.#isStale(index)) {
                if (status) status.get = 'stale';
                // delete only if not an in-flight background fetch
                if (!fetching) {
                    if (!noDeleteOnStaleGet) {
                        this.#delete(k, 'expire');
                    }
                    if (status && allowStale) status.returnedStale = true;
                    return allowStale ? value : undefined;
                } else {
                    if (status && allowStale && value.__staleWhileFetching !== undefined) {
                        status.returnedStale = true;
                    }
                    return allowStale ? value.__staleWhileFetching : undefined;
                }
            } else {
                if (status) status.get = 'hit';
                // if we're currently fetching it, we don't actually have it yet
                // it's not stale, which means this isn't a staleWhileRefetching.
                // If it's not stale, and fetching, AND has a __staleWhileFetching
                // value, then that means the user fetched with {forceRefresh:true},
                // so it's safe to return that value.
                if (fetching) {
                    return value.__staleWhileFetching;
                }
                this.#moveToTail(index);
                if (updateAgeOnGet) {
                    this.#updateItemAge(index);
                }
                return value;
            }
        } else if (status) {
            status.get = 'miss';
        }
    }
    #connect(p, n) {
        this.#prev[n] = p;
        this.#next[p] = n;
    }
    #moveToTail(index) {
        // if tail already, nothing to do
        // if head, move head to next[index]
        // else
        //   move next[prev[index]] to next[index] (head has no prev)
        //   move prev[next[index]] to prev[index]
        // prev[index] = tail
        // next[tail] = index
        // tail = index
        if (index !== this.#tail) {
            if (index === this.#head) {
                this.#head = this.#next[index];
            } else {
                this.#connect(this.#prev[index], this.#next[index]);
            }
            this.#connect(this.#tail, index);
            this.#tail = index;
        }
    }
    /**
     * Deletes a key out of the cache.
     *
     * Returns true if the key was deleted, false otherwise.
     */ delete(k) {
        return this.#delete(k, 'delete');
    }
    #delete(k, reason) {
        let deleted = false;
        if (this.#size !== 0) {
            const index = this.#keyMap.get(k);
            if (index !== undefined) {
                deleted = true;
                if (this.#size === 1) {
                    this.#clear(reason);
                } else {
                    this.#removeItemSize(index);
                    const v = this.#valList[index];
                    if (this.#isBackgroundFetch(v)) {
                        v.__abortController.abort(new Error('deleted'));
                    } else if (this.#hasDispose || this.#hasDisposeAfter) {
                        if (this.#hasDispose) {
                            this.#dispose?.(v, k, reason);
                        }
                        if (this.#hasDisposeAfter) {
                            this.#disposed?.push([
                                v,
                                k,
                                reason
                            ]);
                        }
                    }
                    this.#keyMap.delete(k);
                    this.#keyList[index] = undefined;
                    this.#valList[index] = undefined;
                    if (index === this.#tail) {
                        this.#tail = this.#prev[index];
                    } else if (index === this.#head) {
                        this.#head = this.#next[index];
                    } else {
                        const pi = this.#prev[index];
                        this.#next[pi] = this.#next[index];
                        const ni = this.#next[index];
                        this.#prev[ni] = this.#prev[index];
                    }
                    this.#size--;
                    this.#free.push(index);
                }
            }
        }
        if (this.#hasDisposeAfter && this.#disposed?.length) {
            const dt = this.#disposed;
            let task;
            while(task = dt?.shift()){
                this.#disposeAfter?.(...task);
            }
        }
        return deleted;
    }
    /**
     * Clear the cache entirely, throwing away all values.
     */ clear() {
        return this.#clear('delete');
    }
    #clear(reason) {
        for (const index of this.#rindexes({
            allowStale: true
        })){
            const v = this.#valList[index];
            if (this.#isBackgroundFetch(v)) {
                v.__abortController.abort(new Error('deleted'));
            } else {
                const k = this.#keyList[index];
                if (this.#hasDispose) {
                    this.#dispose?.(v, k, reason);
                }
                if (this.#hasDisposeAfter) {
                    this.#disposed?.push([
                        v,
                        k,
                        reason
                    ]);
                }
            }
        }
        this.#keyMap.clear();
        this.#valList.fill(undefined);
        this.#keyList.fill(undefined);
        if (this.#ttls && this.#starts) {
            this.#ttls.fill(0);
            this.#starts.fill(0);
        }
        if (this.#sizes) {
            this.#sizes.fill(0);
        }
        this.#head = 0;
        this.#tail = 0;
        this.#free.length = 0;
        this.#calculatedSize = 0;
        this.#size = 0;
        if (this.#hasDisposeAfter && this.#disposed) {
            const dt = this.#disposed;
            let task;
            while(task = dt?.shift()){
                this.#disposeAfter?.(...task);
            }
        }
    }
} //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@vanilla-extract/dynamic/dist/vanilla-extract-dynamic.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assignInlineVars": (()=>assignInlineVars),
    "setElementVars": (()=>setElementVars)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/private/dist/vanilla-extract-private.esm.js [app-client] (ecmascript)");
;
function assignInlineVars(varsOrContract, tokens) {
    var styles = {};
    if (typeof tokens === 'object') {
        var _contract = varsOrContract;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(tokens, (value, path)=>{
            if (value == null) {
                return;
            }
            var varName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["get"])(_contract, path);
            styles[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVarName"])(varName)] = String(value);
        });
    } else {
        var _vars = varsOrContract;
        for(var varName in _vars){
            var value = _vars[varName];
            if (value == null) {
                continue;
            }
            styles[(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVarName"])(varName)] = value;
        }
    }
    Object.defineProperty(styles, 'toString', {
        value: function value() {
            return Object.keys(this).map((key)=>"".concat(key, ":").concat(this[key])).join(';');
        },
        writable: false
    });
    return styles;
}
function setVar(element, variable, value) {
    element.style.setProperty((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVarName"])(variable), value);
}
function setElementVars(element, varsOrContract, tokens) {
    if (typeof tokens === 'object') {
        var _contract = varsOrContract;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walkObject"])(tokens, (value, path)=>{
            if (value == null) {
                return;
            }
            setVar(element, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$private$2f$dist$2f$vanilla$2d$extract$2d$private$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["get"])(_contract, path), String(value));
        });
    } else {
        var _vars = varsOrContract;
        for(var varName in _vars){
            var value = _vars[varName];
            if (value == null) {
                continue;
            }
            setVar(element, varName, _vars[varName]);
        }
    }
}
;
}}),
"[project]/node_modules/@vanilla-extract/recipes/createRuntimeFn/dist/vanilla-extract-recipes-createRuntimeFn.esm.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
;
}}),
"[project]/node_modules/@vanilla-extract/recipes/createRuntimeFn/dist/vanilla-extract-recipes-createRuntimeFn.esm.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$recipes$2f$createRuntimeFn$2f$dist$2f$vanilla$2d$extract$2d$recipes$2d$createRuntimeFn$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/recipes/createRuntimeFn/dist/vanilla-extract-recipes-createRuntimeFn.esm.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/@vanilla-extract/recipes/dist/createRuntimeFn-62c9670f.esm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "c": (()=>createRuntimeFn),
    "m": (()=>mapValues)
});
function toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
        var i = e.call(t, r || "default");
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
}
function toPropertyKey(t) {
    var i = toPrimitive(t, "string");
    return "symbol" == typeof i ? i : String(i);
}
function _defineProperty(obj, key, value) {
    key = toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        r && (o = o.filter(function(r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}
function _objectSpread2(e) {
    for(var r = 1; r < arguments.length; r++){
        var t = null != arguments[r] ? arguments[r] : {};
        r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
            _defineProperty(e, r, t[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
        });
    }
    return e;
}
function mapValues(input, fn) {
    var result = {};
    for(var _key in input){
        result[_key] = fn(input[_key], _key);
    }
    return result;
}
var shouldApplyCompound = (compoundCheck, selections, defaultVariants)=>{
    for (var key of Object.keys(compoundCheck)){
        var _selections$key;
        if (compoundCheck[key] !== ((_selections$key = selections[key]) !== null && _selections$key !== void 0 ? _selections$key : defaultVariants[key])) {
            return false;
        }
    }
    return true;
};
var createRuntimeFn = (config)=>{
    var runtimeFn = (options)=>{
        var className = config.defaultClassName;
        var selections = _objectSpread2(_objectSpread2({}, config.defaultVariants), options);
        for(var variantName in selections){
            var _selections$variantNa;
            var variantSelection = (_selections$variantNa = selections[variantName]) !== null && _selections$variantNa !== void 0 ? _selections$variantNa : config.defaultVariants[variantName];
            if (variantSelection != null) {
                var selection = variantSelection;
                if (typeof selection === 'boolean') {
                    // @ts-expect-error
                    selection = selection === true ? 'true' : 'false';
                }
                var selectionClassName = // @ts-expect-error
                config.variantClassNames[variantName][selection];
                if (selectionClassName) {
                    className += ' ' + selectionClassName;
                }
            }
        }
        for (var [compoundCheck, compoundClassName] of config.compoundVariants){
            if (shouldApplyCompound(compoundCheck, selections, config.defaultVariants)) {
                className += ' ' + compoundClassName;
            }
        }
        return className;
    };
    runtimeFn.variants = ()=>Object.keys(config.variantClassNames);
    runtimeFn.classNames = {
        get base () {
            return config.defaultClassName.split(' ')[0];
        },
        get variants () {
            return mapValues(config.variantClassNames, (classNames)=>mapValues(classNames, (className)=>className.split(' ')[0]));
        }
    };
    return runtimeFn;
};
;
}}),
"[project]/node_modules/@vanilla-extract/recipes/dist/createRuntimeFn-62c9670f.esm.js [app-client] (ecmascript) <export c as createRuntimeFn>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createRuntimeFn": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$recipes$2f$dist$2f$createRuntimeFn$2d$62c9670f$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vanilla$2d$extract$2f$recipes$2f$dist$2f$createRuntimeFn$2d$62c9670f$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vanilla-extract/recipes/dist/createRuntimeFn-62c9670f.esm.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=node_modules_%40vanilla-extract_615d3a74._.js.map