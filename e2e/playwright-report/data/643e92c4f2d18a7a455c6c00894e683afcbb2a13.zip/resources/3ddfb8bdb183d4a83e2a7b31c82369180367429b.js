(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * Check if the authentication object is a ByteAuth.
 * @param auth The object to check
 * @returns Whether the object is a ByteAuth.
 */ __turbopack_context__.s({
    "BaseDocAuth": (()=>BaseDocAuth),
    "isByteAuth": (()=>isByteAuth),
    "isDocAuth": (()=>isDocAuth)
});
function isByteAuth(auth) {
    return 'sign' in auth;
}
function isDocAuth(auth) {
    return 'signDoc' in auth;
}
class BaseDocAuth {
    offlineSigner;
    address;
    algo;
    pubkey;
    constructor(offlineSigner, address, algo, pubkey){
        this.offlineSigner = offlineSigner;
        this.address = address;
        this.algo = algo;
        this.pubkey = pubkey;
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/account.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AccountBase": (()=>AccountBase)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)");
;
class AccountBase {
    prefix;
    auth;
    isPublicKeyCompressed;
    address;
    constructor(prefix, auth, isPublicKeyCompressed = true){
        this.prefix = prefix;
        this.auth = auth;
        this.isPublicKeyCompressed = isPublicKeyCompressed;
        this.address = this.getAddress();
    }
    get publicKey() {
        return this.auth.getPublicKey(this.isPublicKeyCompressed);
    }
    getAddress() {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDocAuth"])(this.auth)) {
            return this.auth.address;
        } else {
            return this.getAddressByPubKey();
        }
    }
    toAccountData() {
        return {
            address: this.address,
            algo: this.auth.algo,
            pubkey: this.publicKey.value
        };
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/doc.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/hdpath.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * HDPath represents a Hierarchical Deterministic (HD) path.
 */ __turbopack_context__.s({
    "HDPath": (()=>HDPath)
});
class HDPath {
    constructor(coinType, accountIndex = 0, change = 0, addressIndex = 0, masterPath = HDPath.MASTER_PATH, purpose = HDPath.PURPOSE){
        this.masterPath = masterPath;
        this.purpose = purpose;
        this.coinType = coinType;
        this.accountIndex = accountIndex;
        this.change = change;
        this.addressIndex = addressIndex;
    }
    static MASTER_PATH = 'm';
    static PURPOSE = '44';
    // coin types constants
    static COSMOS_COIN_TYPE = '118';
    static ETH_COIN_TYPE = '60';
    // static derivation methods
    /**
     * Derives a HD path for Cosmos.
     */ static cosmos(accountIndex = 0, change = 0, addressIndex = 0) {
        return new HDPath(HDPath.COSMOS_COIN_TYPE, accountIndex, change, addressIndex);
    }
    /**
     * Derives a HD path for Ethereum.
     */ static eth(accountIndex = 0, change = 0, addressIndex = 0) {
        return new HDPath(HDPath.ETH_COIN_TYPE, accountIndex, change, addressIndex);
    }
    /**
     * The master path of the HD path (e.g., "m").
     */ masterPath;
    /**
     * The purpose of the HD path (e.g., 44).
     */ purpose;
    /**
     * The coin type of the HD path (e.g., 118).
     */ coinType;
    /**
     * The account index of the HD path (e.g., 0).
     */ accountIndex;
    /**
     * The change index of the HD path (e.g., 0).
     */ change;
    /**
     * the address index of the HD path (e.g., 0).
     */ addressIndex;
    /**
     * The string representation of the HD path (e.g., "m/44'/118'/0'/0/0").
     */ toString() {
        return `${this.masterPath}/${this.purpose}'/${this.coinType}'/${this.accountIndex}'/${this.change}/${this.addressIndex}`;
    }
    /**
     * Derives from a HD path string.
     */ static fromString(path) {
        const parts = path.split('/');
        if (parts.length !== 6) {
            throw new Error('Invalid HD path');
        }
        return new HDPath(parts[2].replace("'", ''), parseInt(parts[3].replace("'", ''), 10), parseInt(parts[4], 10), parseInt(parts[5], 10), parts[0], parts[1].replace("'", ''));
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/signer.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "BaseSigner": (()=>BaseSigner),
    "SIGN_MODE": (()=>SIGN_MODE),
    "isHttpEndpoint": (()=>isHttpEndpoint)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)");
;
function isHttpEndpoint(endpoint) {
    return typeof endpoint.url === 'string' && typeof endpoint.headers === 'object';
}
class BaseSigner {
    _auth;
    _config;
    constructor(auth, config){
        this._auth = auth;
        this._config = config;
    }
    get auth() {
        return this._auth;
    }
    get config() {
        return this._config;
    }
    get publicKey() {
        return this.auth.getPublicKey(this.config.publicKey.isCompressed);
    }
    setAuth(auth) {
        this._auth = auth;
    }
    /**
     * default common implementation for sign arbitrary data in bytes.
     */ signArbitrary(data) {
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isByteAuth"])(this.auth)) {
            throw new Error('signArbitrary needs ByteAuth implementation');
        }
        const hashedData = this.config.message.hash(data);
        const signature = this.auth.sign(hashedData);
        return signature.toCompact();
    }
}
const SIGN_MODE = {
    /**
     * SIGN_MODE for (cosmos_)direct
     */ DIRECT: 'direct',
    /**
     * SIGN_MODE for (cosmos_)amino
     */ AMINO: 'amino',
    /**
     * SIGN_MODE for ethereum_tx
     */ ETHEREUM_TX: 'ethereum_tx'
};
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/telescope.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * This file and any referenced files were automatically generated by @cosmology/telescope@1.4.11
 * DO NOT MODIFY BY HAND. Instead, download the latest proto files for your chain
 * and run the transpile command or yarn proto command to regenerate this bundle.
 */ __turbopack_context__.s({
    "WireType": (()=>WireType)
});
var WireType;
(function(WireType) {
    WireType[WireType["Varint"] = 0] = "Varint";
    WireType[WireType["Fixed64"] = 1] = "Fixed64";
    WireType[WireType["Bytes"] = 2] = "Bytes";
    WireType[WireType["Fixed32"] = 5] = "Fixed32";
})(WireType || (WireType = {}));
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/tx-builder.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * BaseTxBuilderContext is a base class for ITxBuilderContext.
 */ __turbopack_context__.s({
    "BaseTxBuilderContext": (()=>BaseTxBuilderContext)
});
class BaseTxBuilderContext {
    signer;
    stagingData = {};
    constructor(signer){
        this.signer = signer;
    }
    setStagingData(key, data) {
        this.stagingData[key] = data;
    }
    getStagingData(key) {
        return this.stagingData[key];
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/rpc.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$account$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/account.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$hdpath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/hdpath.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/signer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/telescope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$tx$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/tx-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$rpc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/rpc.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$account$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/account.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$hdpath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/hdpath.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/signer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/telescope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$tx$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/tx-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$rpc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/rpc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AccountBase": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$account$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccountBase"]),
    "BaseDocAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseDocAuth"]),
    "BaseSigner": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseSigner"]),
    "BaseTxBuilderContext": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$tx$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseTxBuilderContext"]),
    "HDPath": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$hdpath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HDPath"]),
    "SIGN_MODE": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SIGN_MODE"]),
    "WireType": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WireType"]),
    "isByteAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isByteAuth"]),
    "isDocAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isDocAuth"]),
    "isHttpEndpoint": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHttpEndpoint"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$account$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/account.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/auth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$hdpath$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/hdpath.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$signer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/signer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$telescope$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/telescope.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$tx$2d$builder$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/tx-builder.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$rpc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/rpc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AccountBase": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["AccountBase"]),
    "BaseDocAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["BaseDocAuth"]),
    "BaseSigner": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["BaseSigner"]),
    "BaseTxBuilderContext": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["BaseTxBuilderContext"]),
    "HDPath": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["HDPath"]),
    "SIGN_MODE": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["SIGN_MODE"]),
    "WireType": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["WireType"]),
    "isByteAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["isByteAuth"]),
    "isDocAuth": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["isDocAuth"]),
    "isHttpEndpoint": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__["isHttpEndpoint"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$types$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript) <exports>");
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/auth.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseDocAuth = void 0;
exports.isByteAuth = isByteAuth;
exports.isDocAuth = isDocAuth;
/**
 * Check if the authentication object is a ByteAuth.
 * @param auth The object to check
 * @returns Whether the object is a ByteAuth.
 */ function isByteAuth(auth) {
    return 'sign' in auth;
}
/**
 * Check if the authentication object is a DocAuth.
 * @param auth The object to check
 * @returns Whether the object is a DocAuth.
 */ function isDocAuth(auth) {
    return 'signDoc' in auth;
}
/**
 * Base class for Doc Auth.
 */ class BaseDocAuth {
    offlineSigner;
    address;
    algo;
    pubkey;
    constructor(offlineSigner, address, algo, pubkey){
        this.offlineSigner = offlineSigner;
        this.address = address;
        this.algo = algo;
        this.pubkey = pubkey;
    }
}
exports.BaseDocAuth = BaseDocAuth;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/types/account.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AccountBase = void 0;
const auth_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/auth.js [app-client] (ecmascript)");
/**
 * AccountBase implements common parts of the IAccount interface.
 */ class AccountBase {
    prefix;
    auth;
    isPublicKeyCompressed;
    address;
    constructor(prefix, auth, isPublicKeyCompressed = true){
        this.prefix = prefix;
        this.auth = auth;
        this.isPublicKeyCompressed = isPublicKeyCompressed;
        this.address = this.getAddress();
    }
    get publicKey() {
        return this.auth.getPublicKey(this.isPublicKeyCompressed);
    }
    getAddress() {
        if ((0, auth_1.isDocAuth)(this.auth)) {
            return this.auth.address;
        } else {
            return this.getAddressByPubKey();
        }
    }
    toAccountData() {
        return {
            address: this.address,
            algo: this.auth.algo,
            pubkey: this.publicKey.value
        };
    }
}
exports.AccountBase = AccountBase;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/utils/node_modules/bech32/dist/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
'use strict';
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.bech32m = exports.bech32 = void 0;
const ALPHABET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const ALPHABET_MAP = {};
for(let z = 0; z < ALPHABET.length; z++){
    const x = ALPHABET.charAt(z);
    ALPHABET_MAP[x] = z;
}
function polymodStep(pre) {
    const b = pre >> 25;
    return (pre & 0x1ffffff) << 5 ^ -(b >> 0 & 1) & 0x3b6a57b2 ^ -(b >> 1 & 1) & 0x26508e6d ^ -(b >> 2 & 1) & 0x1ea119fa ^ -(b >> 3 & 1) & 0x3d4233dd ^ -(b >> 4 & 1) & 0x2a1462b3;
}
function prefixChk(prefix) {
    let chk = 1;
    for(let i = 0; i < prefix.length; ++i){
        const c = prefix.charCodeAt(i);
        if (c < 33 || c > 126) return 'Invalid prefix (' + prefix + ')';
        chk = polymodStep(chk) ^ c >> 5;
    }
    chk = polymodStep(chk);
    for(let i = 0; i < prefix.length; ++i){
        const v = prefix.charCodeAt(i);
        chk = polymodStep(chk) ^ v & 0x1f;
    }
    return chk;
}
function convert(data, inBits, outBits, pad) {
    let value = 0;
    let bits = 0;
    const maxV = (1 << outBits) - 1;
    const result = [];
    for(let i = 0; i < data.length; ++i){
        value = value << inBits | data[i];
        bits += inBits;
        while(bits >= outBits){
            bits -= outBits;
            result.push(value >> bits & maxV);
        }
    }
    if (pad) {
        if (bits > 0) {
            result.push(value << outBits - bits & maxV);
        }
    } else {
        if (bits >= inBits) return 'Excess padding';
        if (value << outBits - bits & maxV) return 'Non-zero padding';
    }
    return result;
}
function toWords(bytes) {
    return convert(bytes, 8, 5, true);
}
function fromWordsUnsafe(words) {
    const res = convert(words, 5, 8, false);
    if (Array.isArray(res)) return res;
}
function fromWords(words) {
    const res = convert(words, 5, 8, false);
    if (Array.isArray(res)) return res;
    throw new Error(res);
}
function getLibraryFromEncoding(encoding) {
    let ENCODING_CONST;
    if (encoding === 'bech32') {
        ENCODING_CONST = 1;
    } else {
        ENCODING_CONST = 0x2bc830a3;
    }
    function encode(prefix, words, LIMIT) {
        LIMIT = LIMIT || 90;
        if (prefix.length + 7 + words.length > LIMIT) throw new TypeError('Exceeds length limit');
        prefix = prefix.toLowerCase();
        // determine chk mod
        let chk = prefixChk(prefix);
        if (typeof chk === 'string') throw new Error(chk);
        let result = prefix + '1';
        for(let i = 0; i < words.length; ++i){
            const x = words[i];
            if (x >> 5 !== 0) throw new Error('Non 5-bit word');
            chk = polymodStep(chk) ^ x;
            result += ALPHABET.charAt(x);
        }
        for(let i = 0; i < 6; ++i){
            chk = polymodStep(chk);
        }
        chk ^= ENCODING_CONST;
        for(let i = 0; i < 6; ++i){
            const v = chk >> (5 - i) * 5 & 0x1f;
            result += ALPHABET.charAt(v);
        }
        return result;
    }
    function __decode(str, LIMIT) {
        LIMIT = LIMIT || 90;
        if (str.length < 8) return str + ' too short';
        if (str.length > LIMIT) return 'Exceeds length limit';
        // don't allow mixed case
        const lowered = str.toLowerCase();
        const uppered = str.toUpperCase();
        if (str !== lowered && str !== uppered) return 'Mixed-case string ' + str;
        str = lowered;
        const split = str.lastIndexOf('1');
        if (split === -1) return 'No separator character for ' + str;
        if (split === 0) return 'Missing prefix for ' + str;
        const prefix = str.slice(0, split);
        const wordChars = str.slice(split + 1);
        if (wordChars.length < 6) return 'Data too short';
        let chk = prefixChk(prefix);
        if (typeof chk === 'string') return chk;
        const words = [];
        for(let i = 0; i < wordChars.length; ++i){
            const c = wordChars.charAt(i);
            const v = ALPHABET_MAP[c];
            if (v === undefined) return 'Unknown character ' + c;
            chk = polymodStep(chk) ^ v;
            // not in the checksum?
            if (i + 6 >= wordChars.length) continue;
            words.push(v);
        }
        if (chk !== ENCODING_CONST) return 'Invalid checksum for ' + str;
        return {
            prefix,
            words
        };
    }
    function decodeUnsafe(str, LIMIT) {
        const res = __decode(str, LIMIT);
        if (typeof res === 'object') return res;
    }
    function decode(str, LIMIT) {
        const res = __decode(str, LIMIT);
        if (typeof res === 'object') return res;
        throw new Error(res);
    }
    return {
        decodeUnsafe,
        decode,
        encode,
        toWords,
        fromWordsUnsafe,
        fromWords
    };
}
exports.bech32 = getLibraryFromEncoding('bech32');
exports.bech32m = getLibraryFromEncoding('bech32m');
}}),
"[project]/examples/e2e/node_modules/@interchainjs/auth/utils.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getSeedFromMnemonic = getSeedFromMnemonic;
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const pbkdf2_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/pbkdf2.js [app-client] (ecmascript)");
const sha512_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/sha512.js [app-client] (ecmascript)");
function getSeedFromMnemonic(mnemonic, password) {
    const mnemonicBytes = (0, utils_1.fromUtf8)(mnemonic.normalize('NFKD'));
    const salt = 'mnemonic' + (password ? password.normalize('NFKD') : '');
    const seed = (0, pbkdf2_1.pbkdf2)(sha512_1.sha512, mnemonicBytes, salt, {
        c: 2048,
        dkLen: 64
    });
    return seed;
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/auth/secp256k1.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Secp256k1Signature = exports.Secp256k1Auth = void 0;
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const secp256k1_1 = __turbopack_context__.r("[project]/node_modules/@noble/curves/secp256k1.js [app-client] (ecmascript)");
const bip32_1 = __turbopack_context__.r("[project]/node_modules/@scure/bip32/lib/index.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/auth/utils.js [app-client] (ecmascript)");
/**
 * secp256k1 Auth
 */ class Secp256k1Auth {
    hdPath;
    privateKey = null;
    algo = 'secp256k1';
    constructor(privateKey, hdPath){
        this.hdPath = hdPath;
        if (privateKey instanceof bip32_1.HDKey) {
            this.privateKey = utils_1.Key.from(privateKey.privateKey);
        } else if (privateKey instanceof utils_1.Key) {
            this.privateKey = privateKey;
        } else if (privateKey) {
            this.privateKey = utils_1.Key.from(privateKey);
        }
    }
    /**
     * Create new Auths from mnemonic
     */ static fromMnemonic(mnemonic, hdPaths, options) {
        const masterSeed = bip32_1.HDKey.fromMasterSeed((0, utils_2.getSeedFromMnemonic)(mnemonic, options?.bip39Password));
        return hdPaths.map((hdPath)=>{
            return new Secp256k1Auth(masterSeed.derive(hdPath), hdPath);
        });
    }
    /**
     * Get public key generated from private key
     */ getPublicKey = (isCompressed)=>{
        return utils_1.Key.from(secp256k1_1.secp256k1.getPublicKey(this.privateKey.value, isCompressed));
    };
    /**
     * Sign data in bytes
     */ sign(data) {
        if (!this.privateKey) {
            throw new Error('No privateKey set!');
        }
        const signature = secp256k1_1.secp256k1.sign(data, this.privateKey.toBigInt());
        return new Secp256k1Signature(signature);
    }
}
exports.Secp256k1Auth = Secp256k1Auth;
/**
 * secp256k1 Signature wrapper
 */ class Secp256k1Signature {
    signature;
    constructor(signature){
        this.signature = signature;
    }
    /**
     * Convert signature to compact form
     */ toCompact() {
        return utils_1.Key.from(this.signature.toCompactRawBytes());
    }
}
exports.Secp256k1Signature = Secp256k1Signature;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromAscii": (()=>fromAscii),
    "toAscii": (()=>toAscii)
});
function toAscii(input) {
    const toNums = (str)=>str.split("").map((x)=>{
            const charCode = x.charCodeAt(0);
            // 0x00–0x1F control characters
            // 0x20–0x7E printable characters
            // 0x7F delete character
            // 0x80–0xFF out of 7 bit ascii range
            if (charCode < 0x20 || charCode > 0x7e) {
                throw new Error("Cannot encode character that is out of printable ASCII range: " + charCode);
            }
            return charCode;
        });
    return Uint8Array.from(toNums(input));
}
function fromAscii(data) {
    const fromNums = (listOfNumbers)=>listOfNumbers.map((x)=>{
            // 0x00–0x1F control characters
            // 0x20–0x7E printable characters
            // 0x7F delete character
            // 0x80–0xFF out of 7 bit ascii range
            if (x < 0x20 || x > 0x7e) {
                throw new Error("Cannot decode character that is out of printable ASCII range: " + x);
            }
            return String.fromCharCode(x);
        });
    return fromNums(Array.from(data)).join("");
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromBase64": (()=>fromBase64),
    "toBase64": (()=>toBase64)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/base64-js/index.js [app-client] (ecmascript)");
;
function toBase64(data) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromByteArray"])(data);
}
function fromBase64(base64String) {
    if (!base64String.match(/^[a-zA-Z0-9+/]*={0,2}$/)) {
        throw new Error("Invalid base64 string format");
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toByteArray"])(base64String);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromBech32": (()=>fromBech32),
    "normalizeBech32": (()=>normalizeBech32),
    "toBech32": (()=>toBech32)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bech32/index.js [app-client] (ecmascript)");
;
function toBech32(prefix, data, limit) {
    const address = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encode"])(prefix, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toWords"])(data), limit);
    return address;
}
function fromBech32(address, limit = Infinity) {
    const decodedAddress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decode"])(address, limit);
    return {
        prefix: decodedAddress.prefix,
        data: new Uint8Array((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromWords"])(decodedAddress.words))
    };
}
function normalizeBech32(address) {
    const { prefix, data } = fromBech32(address);
    return toBech32(prefix, data);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromHex": (()=>fromHex),
    "toHex": (()=>toHex)
});
function toHex(data) {
    let out = "";
    for (const byte of data){
        out += ("0" + byte.toString(16)).slice(-2);
    }
    return out;
}
function fromHex(hexstring) {
    if (hexstring.length % 2 !== 0) {
        throw new Error("hex string length must be a multiple of 2");
    }
    const out = new Uint8Array(hexstring.length / 2);
    for(let i = 0; i < out.length; i++){
        const j = 2 * i;
        const hexByteAsString = hexstring.slice(j, j + 2);
        if (!hexByteAsString.match(/[0-9a-f]{2}/i)) {
            throw new Error("hex string contains invalid characters");
        }
        out[i] = parseInt(hexByteAsString, 16);
    }
    return out;
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/rfc3339.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromRfc3339": (()=>fromRfc3339),
    "toRfc3339": (()=>toRfc3339)
});
const rfc3339Matcher = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(\.\d{1,9})?((?:[+-]\d{2}:\d{2})|Z)$/;
function padded(integer, length = 2) {
    return integer.toString().padStart(length, "0");
}
function fromRfc3339(str) {
    const matches = rfc3339Matcher.exec(str);
    if (!matches) {
        throw new Error("Date string is not in RFC3339 format");
    }
    const year = +matches[1];
    const month = +matches[2];
    const day = +matches[3];
    const hour = +matches[4];
    const minute = +matches[5];
    const second = +matches[6];
    // fractional seconds match either undefined or a string like ".1", ".123456789"
    const milliSeconds = matches[7] ? Math.floor(+matches[7] * 1000) : 0;
    let tzOffsetSign;
    let tzOffsetHours;
    let tzOffsetMinutes;
    // if timezone is undefined, it must be Z or nothing (otherwise the group would have captured).
    if (matches[8] === "Z") {
        tzOffsetSign = 1;
        tzOffsetHours = 0;
        tzOffsetMinutes = 0;
    } else {
        tzOffsetSign = matches[8].substring(0, 1) === "-" ? -1 : 1;
        tzOffsetHours = +matches[8].substring(1, 3);
        tzOffsetMinutes = +matches[8].substring(4, 6);
    }
    const tzOffset = tzOffsetSign * (tzOffsetHours * 60 + tzOffsetMinutes) * 60; // seconds
    const date = new Date();
    date.setUTCFullYear(year, month - 1, day);
    date.setUTCHours(hour, minute, second, milliSeconds);
    return new Date(date.getTime() - tzOffset * 1000);
}
function toRfc3339(date) {
    const year = date.getUTCFullYear();
    const month = padded(date.getUTCMonth() + 1);
    const day = padded(date.getUTCDate());
    const hour = padded(date.getUTCHours());
    const minute = padded(date.getUTCMinutes());
    const second = padded(date.getUTCSeconds());
    const ms = padded(date.getUTCMilliseconds(), 3);
    return `${year}-${month}-${day}T${hour}:${minute}:${second}.${ms}Z`;
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utf8.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "fromUtf8": (()=>fromUtf8),
    "toUtf8": (()=>toUtf8)
});
function toUtf8(str) {
    return new TextEncoder().encode(str);
}
function fromUtf8(data, lossy = false) {
    const fatal = !lossy;
    return new TextDecoder("utf-8", {
        fatal
    }).decode(data);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "decodeCosmosSdkDecFromProto": (()=>decodeCosmosSdkDecFromProto),
    "longify": (()=>longify),
    "toAccAddress": (()=>toAccAddress)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/decimal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
;
;
;
function toAccAddress(address) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBech32"])(address).data;
}
function longify(value) {
    const checkedValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint64"].fromString(value.toString());
    return BigInt(checkedValue.toString());
}
function decodeCosmosSdkDecFromProto(input) {
    const asString = typeof input === "string" ? input : (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromAscii"])(input);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(asString, 18);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$rfc3339$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/rfc3339.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utf8.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utils.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$rfc3339$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/rfc3339.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utf8.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/pbkdf2.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getNodeCrypto": (()=>getNodeCrypto),
    "getSubtle": (()=>getSubtle),
    "pbkdf2Sha512": (()=>pbkdf2Sha512),
    "pbkdf2Sha512Noble": (()=>pbkdf2Sha512Noble),
    "pbkdf2Sha512NodeCrypto": (()=>pbkdf2Sha512NodeCrypto),
    "pbkdf2Sha512Subtle": (()=>pbkdf2Sha512Subtle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/asserts.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$pbkdf2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/pbkdf2.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha512$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/sha512.js [app-client] (ecmascript)");
;
;
;
async function getNodeCrypto() {
    try {
        const nodeCrypto = await __turbopack_context__.r("[project]/node_modules/crypto/lib/index.js [app-client] (ecmascript, async loader)")(__turbopack_context__.i);
        // We get `Object{default: Object{}}` as a fallback when using
        // `crypto: false` in Webpack 5, which we interprete as unavailable.
        if (typeof nodeCrypto === "object" && Object.keys(nodeCrypto).length <= 1) {
            return undefined;
        }
        return nodeCrypto;
    } catch  {
        return undefined;
    }
}
async function getSubtle() {
    // From Node.js 15 onwards, webcrypto is available in globalThis.
    // In version 15 and 16 this was stored under the webcrypto key.
    // With Node.js 17 it was moved to the same locations where browsers
    // make it available.
    // Loading `require("crypto")` here seems unnecessary since it only
    // causes issues with bundlers and does not increase compatibility.
    // Browsers and Node.js 17+
    let subtle = globalThis?.crypto?.subtle;
    // Node.js 15+
    if (!subtle) subtle = globalThis?.crypto?.webcrypto?.subtle;
    return subtle;
}
async function pbkdf2Sha512Subtle(// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
subtle, secret, salt, iterations, keylen) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(subtle, "Argument subtle is falsy");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(typeof subtle === "object", "Argument subtle is not of type object");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(typeof subtle.importKey === "function", "subtle.importKey is not a function");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(typeof subtle.deriveBits === "function", "subtle.deriveBits is not a function");
    return subtle.importKey("raw", secret, {
        name: "PBKDF2"
    }, false, [
        "deriveBits"
    ]).then((key)=>subtle.deriveBits({
            name: "PBKDF2",
            salt: salt,
            iterations: iterations,
            hash: {
                name: "SHA-512"
            }
        }, key, keylen * 8).then((buffer)=>new Uint8Array(buffer)));
}
async function pbkdf2Sha512NodeCrypto(// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
nodeCrypto, secret, salt, iterations, keylen) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(nodeCrypto, "Argument nodeCrypto is falsy");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(typeof nodeCrypto === "object", "Argument nodeCrypto is not of type object");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$asserts$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assert"])(typeof nodeCrypto.pbkdf2 === "function", "nodeCrypto.pbkdf2 is not a function");
    return new Promise((resolve, reject)=>{
        nodeCrypto.pbkdf2(secret, salt, iterations, keylen, "sha512", (error, result)=>{
            if (error) {
                reject(error);
            } else {
                resolve(Uint8Array.from(result));
            }
        });
    });
}
async function pbkdf2Sha512Noble(secret, salt, iterations, keylen) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$pbkdf2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pbkdf2Async"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha512$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha512"], secret, salt, {
        c: iterations,
        dkLen: keylen
    });
}
async function pbkdf2Sha512(secret, salt, iterations, keylen) {
    const subtle = await getSubtle();
    if (subtle) {
        return pbkdf2Sha512Subtle(subtle, secret, salt, iterations, keylen);
    } else {
        const nodeCrypto = await getNodeCrypto();
        if (nodeCrypto) {
            return pbkdf2Sha512NodeCrypto(nodeCrypto, secret, salt, iterations, keylen);
        } else {
            return pbkdf2Sha512Noble(secret, salt, iterations, keylen);
        }
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/utils.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// See https://github.com/paulmillr/noble-hashes/issues/25 for why this is needed
__turbopack_context__.s({
    "toRealUint8Array": (()=>toRealUint8Array)
});
function toRealUint8Array(data) {
    if (data instanceof Uint8Array) return data;
    else return Uint8Array.from(data);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Sha256": (()=>Sha256),
    "Sha512": (()=>Sha512),
    "sha256": (()=>sha256),
    "sha512": (()=>sha512)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/sha256.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha512$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/sha512.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/utils.js [app-client] (ecmascript)");
;
;
;
class Sha256 {
    blockSize = 512 / 8;
    impl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha256$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"].create();
    constructor(firstData){
        if (firstData) {
            this.update(firstData);
        }
    }
    update(data) {
        this.impl.update((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRealUint8Array"])(data));
        return this;
    }
    digest() {
        return this.impl.digest();
    }
}
function sha256(data) {
    return new Sha256(data).digest();
}
class Sha512 {
    blockSize = 1024 / 8;
    impl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha512$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha512"].create();
    constructor(firstData){
        if (firstData) {
            this.update(firstData);
        }
    }
    update(data) {
        this.impl.update((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRealUint8Array"])(data));
        return this;
    }
    digest() {
        return this.impl.digest();
    }
}
function sha512(data) {
    return new Sha512(data).digest();
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/bip39.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Bip39": (()=>Bip39),
    "EnglishMnemonic": (()=>EnglishMnemonic),
    "entropyToMnemonic": (()=>entropyToMnemonic),
    "mnemonicToEntropy": (()=>mnemonicToEntropy)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utf8.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$pbkdf2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/pbkdf2.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)");
;
;
;
const wordlist = [
    "abandon",
    "ability",
    "able",
    "about",
    "above",
    "absent",
    "absorb",
    "abstract",
    "absurd",
    "abuse",
    "access",
    "accident",
    "account",
    "accuse",
    "achieve",
    "acid",
    "acoustic",
    "acquire",
    "across",
    "act",
    "action",
    "actor",
    "actress",
    "actual",
    "adapt",
    "add",
    "addict",
    "address",
    "adjust",
    "admit",
    "adult",
    "advance",
    "advice",
    "aerobic",
    "affair",
    "afford",
    "afraid",
    "again",
    "age",
    "agent",
    "agree",
    "ahead",
    "aim",
    "air",
    "airport",
    "aisle",
    "alarm",
    "album",
    "alcohol",
    "alert",
    "alien",
    "all",
    "alley",
    "allow",
    "almost",
    "alone",
    "alpha",
    "already",
    "also",
    "alter",
    "always",
    "amateur",
    "amazing",
    "among",
    "amount",
    "amused",
    "analyst",
    "anchor",
    "ancient",
    "anger",
    "angle",
    "angry",
    "animal",
    "ankle",
    "announce",
    "annual",
    "another",
    "answer",
    "antenna",
    "antique",
    "anxiety",
    "any",
    "apart",
    "apology",
    "appear",
    "apple",
    "approve",
    "april",
    "arch",
    "arctic",
    "area",
    "arena",
    "argue",
    "arm",
    "armed",
    "armor",
    "army",
    "around",
    "arrange",
    "arrest",
    "arrive",
    "arrow",
    "art",
    "artefact",
    "artist",
    "artwork",
    "ask",
    "aspect",
    "assault",
    "asset",
    "assist",
    "assume",
    "asthma",
    "athlete",
    "atom",
    "attack",
    "attend",
    "attitude",
    "attract",
    "auction",
    "audit",
    "august",
    "aunt",
    "author",
    "auto",
    "autumn",
    "average",
    "avocado",
    "avoid",
    "awake",
    "aware",
    "away",
    "awesome",
    "awful",
    "awkward",
    "axis",
    "baby",
    "bachelor",
    "bacon",
    "badge",
    "bag",
    "balance",
    "balcony",
    "ball",
    "bamboo",
    "banana",
    "banner",
    "bar",
    "barely",
    "bargain",
    "barrel",
    "base",
    "basic",
    "basket",
    "battle",
    "beach",
    "bean",
    "beauty",
    "because",
    "become",
    "beef",
    "before",
    "begin",
    "behave",
    "behind",
    "believe",
    "below",
    "belt",
    "bench",
    "benefit",
    "best",
    "betray",
    "better",
    "between",
    "beyond",
    "bicycle",
    "bid",
    "bike",
    "bind",
    "biology",
    "bird",
    "birth",
    "bitter",
    "black",
    "blade",
    "blame",
    "blanket",
    "blast",
    "bleak",
    "bless",
    "blind",
    "blood",
    "blossom",
    "blouse",
    "blue",
    "blur",
    "blush",
    "board",
    "boat",
    "body",
    "boil",
    "bomb",
    "bone",
    "bonus",
    "book",
    "boost",
    "border",
    "boring",
    "borrow",
    "boss",
    "bottom",
    "bounce",
    "box",
    "boy",
    "bracket",
    "brain",
    "brand",
    "brass",
    "brave",
    "bread",
    "breeze",
    "brick",
    "bridge",
    "brief",
    "bright",
    "bring",
    "brisk",
    "broccoli",
    "broken",
    "bronze",
    "broom",
    "brother",
    "brown",
    "brush",
    "bubble",
    "buddy",
    "budget",
    "buffalo",
    "build",
    "bulb",
    "bulk",
    "bullet",
    "bundle",
    "bunker",
    "burden",
    "burger",
    "burst",
    "bus",
    "business",
    "busy",
    "butter",
    "buyer",
    "buzz",
    "cabbage",
    "cabin",
    "cable",
    "cactus",
    "cage",
    "cake",
    "call",
    "calm",
    "camera",
    "camp",
    "can",
    "canal",
    "cancel",
    "candy",
    "cannon",
    "canoe",
    "canvas",
    "canyon",
    "capable",
    "capital",
    "captain",
    "car",
    "carbon",
    "card",
    "cargo",
    "carpet",
    "carry",
    "cart",
    "case",
    "cash",
    "casino",
    "castle",
    "casual",
    "cat",
    "catalog",
    "catch",
    "category",
    "cattle",
    "caught",
    "cause",
    "caution",
    "cave",
    "ceiling",
    "celery",
    "cement",
    "census",
    "century",
    "cereal",
    "certain",
    "chair",
    "chalk",
    "champion",
    "change",
    "chaos",
    "chapter",
    "charge",
    "chase",
    "chat",
    "cheap",
    "check",
    "cheese",
    "chef",
    "cherry",
    "chest",
    "chicken",
    "chief",
    "child",
    "chimney",
    "choice",
    "choose",
    "chronic",
    "chuckle",
    "chunk",
    "churn",
    "cigar",
    "cinnamon",
    "circle",
    "citizen",
    "city",
    "civil",
    "claim",
    "clap",
    "clarify",
    "claw",
    "clay",
    "clean",
    "clerk",
    "clever",
    "click",
    "client",
    "cliff",
    "climb",
    "clinic",
    "clip",
    "clock",
    "clog",
    "close",
    "cloth",
    "cloud",
    "clown",
    "club",
    "clump",
    "cluster",
    "clutch",
    "coach",
    "coast",
    "coconut",
    "code",
    "coffee",
    "coil",
    "coin",
    "collect",
    "color",
    "column",
    "combine",
    "come",
    "comfort",
    "comic",
    "common",
    "company",
    "concert",
    "conduct",
    "confirm",
    "congress",
    "connect",
    "consider",
    "control",
    "convince",
    "cook",
    "cool",
    "copper",
    "copy",
    "coral",
    "core",
    "corn",
    "correct",
    "cost",
    "cotton",
    "couch",
    "country",
    "couple",
    "course",
    "cousin",
    "cover",
    "coyote",
    "crack",
    "cradle",
    "craft",
    "cram",
    "crane",
    "crash",
    "crater",
    "crawl",
    "crazy",
    "cream",
    "credit",
    "creek",
    "crew",
    "cricket",
    "crime",
    "crisp",
    "critic",
    "crop",
    "cross",
    "crouch",
    "crowd",
    "crucial",
    "cruel",
    "cruise",
    "crumble",
    "crunch",
    "crush",
    "cry",
    "crystal",
    "cube",
    "culture",
    "cup",
    "cupboard",
    "curious",
    "current",
    "curtain",
    "curve",
    "cushion",
    "custom",
    "cute",
    "cycle",
    "dad",
    "damage",
    "damp",
    "dance",
    "danger",
    "daring",
    "dash",
    "daughter",
    "dawn",
    "day",
    "deal",
    "debate",
    "debris",
    "decade",
    "december",
    "decide",
    "decline",
    "decorate",
    "decrease",
    "deer",
    "defense",
    "define",
    "defy",
    "degree",
    "delay",
    "deliver",
    "demand",
    "demise",
    "denial",
    "dentist",
    "deny",
    "depart",
    "depend",
    "deposit",
    "depth",
    "deputy",
    "derive",
    "describe",
    "desert",
    "design",
    "desk",
    "despair",
    "destroy",
    "detail",
    "detect",
    "develop",
    "device",
    "devote",
    "diagram",
    "dial",
    "diamond",
    "diary",
    "dice",
    "diesel",
    "diet",
    "differ",
    "digital",
    "dignity",
    "dilemma",
    "dinner",
    "dinosaur",
    "direct",
    "dirt",
    "disagree",
    "discover",
    "disease",
    "dish",
    "dismiss",
    "disorder",
    "display",
    "distance",
    "divert",
    "divide",
    "divorce",
    "dizzy",
    "doctor",
    "document",
    "dog",
    "doll",
    "dolphin",
    "domain",
    "donate",
    "donkey",
    "donor",
    "door",
    "dose",
    "double",
    "dove",
    "draft",
    "dragon",
    "drama",
    "drastic",
    "draw",
    "dream",
    "dress",
    "drift",
    "drill",
    "drink",
    "drip",
    "drive",
    "drop",
    "drum",
    "dry",
    "duck",
    "dumb",
    "dune",
    "during",
    "dust",
    "dutch",
    "duty",
    "dwarf",
    "dynamic",
    "eager",
    "eagle",
    "early",
    "earn",
    "earth",
    "easily",
    "east",
    "easy",
    "echo",
    "ecology",
    "economy",
    "edge",
    "edit",
    "educate",
    "effort",
    "egg",
    "eight",
    "either",
    "elbow",
    "elder",
    "electric",
    "elegant",
    "element",
    "elephant",
    "elevator",
    "elite",
    "else",
    "embark",
    "embody",
    "embrace",
    "emerge",
    "emotion",
    "employ",
    "empower",
    "empty",
    "enable",
    "enact",
    "end",
    "endless",
    "endorse",
    "enemy",
    "energy",
    "enforce",
    "engage",
    "engine",
    "enhance",
    "enjoy",
    "enlist",
    "enough",
    "enrich",
    "enroll",
    "ensure",
    "enter",
    "entire",
    "entry",
    "envelope",
    "episode",
    "equal",
    "equip",
    "era",
    "erase",
    "erode",
    "erosion",
    "error",
    "erupt",
    "escape",
    "essay",
    "essence",
    "estate",
    "eternal",
    "ethics",
    "evidence",
    "evil",
    "evoke",
    "evolve",
    "exact",
    "example",
    "excess",
    "exchange",
    "excite",
    "exclude",
    "excuse",
    "execute",
    "exercise",
    "exhaust",
    "exhibit",
    "exile",
    "exist",
    "exit",
    "exotic",
    "expand",
    "expect",
    "expire",
    "explain",
    "expose",
    "express",
    "extend",
    "extra",
    "eye",
    "eyebrow",
    "fabric",
    "face",
    "faculty",
    "fade",
    "faint",
    "faith",
    "fall",
    "false",
    "fame",
    "family",
    "famous",
    "fan",
    "fancy",
    "fantasy",
    "farm",
    "fashion",
    "fat",
    "fatal",
    "father",
    "fatigue",
    "fault",
    "favorite",
    "feature",
    "february",
    "federal",
    "fee",
    "feed",
    "feel",
    "female",
    "fence",
    "festival",
    "fetch",
    "fever",
    "few",
    "fiber",
    "fiction",
    "field",
    "figure",
    "file",
    "film",
    "filter",
    "final",
    "find",
    "fine",
    "finger",
    "finish",
    "fire",
    "firm",
    "first",
    "fiscal",
    "fish",
    "fit",
    "fitness",
    "fix",
    "flag",
    "flame",
    "flash",
    "flat",
    "flavor",
    "flee",
    "flight",
    "flip",
    "float",
    "flock",
    "floor",
    "flower",
    "fluid",
    "flush",
    "fly",
    "foam",
    "focus",
    "fog",
    "foil",
    "fold",
    "follow",
    "food",
    "foot",
    "force",
    "forest",
    "forget",
    "fork",
    "fortune",
    "forum",
    "forward",
    "fossil",
    "foster",
    "found",
    "fox",
    "fragile",
    "frame",
    "frequent",
    "fresh",
    "friend",
    "fringe",
    "frog",
    "front",
    "frost",
    "frown",
    "frozen",
    "fruit",
    "fuel",
    "fun",
    "funny",
    "furnace",
    "fury",
    "future",
    "gadget",
    "gain",
    "galaxy",
    "gallery",
    "game",
    "gap",
    "garage",
    "garbage",
    "garden",
    "garlic",
    "garment",
    "gas",
    "gasp",
    "gate",
    "gather",
    "gauge",
    "gaze",
    "general",
    "genius",
    "genre",
    "gentle",
    "genuine",
    "gesture",
    "ghost",
    "giant",
    "gift",
    "giggle",
    "ginger",
    "giraffe",
    "girl",
    "give",
    "glad",
    "glance",
    "glare",
    "glass",
    "glide",
    "glimpse",
    "globe",
    "gloom",
    "glory",
    "glove",
    "glow",
    "glue",
    "goat",
    "goddess",
    "gold",
    "good",
    "goose",
    "gorilla",
    "gospel",
    "gossip",
    "govern",
    "gown",
    "grab",
    "grace",
    "grain",
    "grant",
    "grape",
    "grass",
    "gravity",
    "great",
    "green",
    "grid",
    "grief",
    "grit",
    "grocery",
    "group",
    "grow",
    "grunt",
    "guard",
    "guess",
    "guide",
    "guilt",
    "guitar",
    "gun",
    "gym",
    "habit",
    "hair",
    "half",
    "hammer",
    "hamster",
    "hand",
    "happy",
    "harbor",
    "hard",
    "harsh",
    "harvest",
    "hat",
    "have",
    "hawk",
    "hazard",
    "head",
    "health",
    "heart",
    "heavy",
    "hedgehog",
    "height",
    "hello",
    "helmet",
    "help",
    "hen",
    "hero",
    "hidden",
    "high",
    "hill",
    "hint",
    "hip",
    "hire",
    "history",
    "hobby",
    "hockey",
    "hold",
    "hole",
    "holiday",
    "hollow",
    "home",
    "honey",
    "hood",
    "hope",
    "horn",
    "horror",
    "horse",
    "hospital",
    "host",
    "hotel",
    "hour",
    "hover",
    "hub",
    "huge",
    "human",
    "humble",
    "humor",
    "hundred",
    "hungry",
    "hunt",
    "hurdle",
    "hurry",
    "hurt",
    "husband",
    "hybrid",
    "ice",
    "icon",
    "idea",
    "identify",
    "idle",
    "ignore",
    "ill",
    "illegal",
    "illness",
    "image",
    "imitate",
    "immense",
    "immune",
    "impact",
    "impose",
    "improve",
    "impulse",
    "inch",
    "include",
    "income",
    "increase",
    "index",
    "indicate",
    "indoor",
    "industry",
    "infant",
    "inflict",
    "inform",
    "inhale",
    "inherit",
    "initial",
    "inject",
    "injury",
    "inmate",
    "inner",
    "innocent",
    "input",
    "inquiry",
    "insane",
    "insect",
    "inside",
    "inspire",
    "install",
    "intact",
    "interest",
    "into",
    "invest",
    "invite",
    "involve",
    "iron",
    "island",
    "isolate",
    "issue",
    "item",
    "ivory",
    "jacket",
    "jaguar",
    "jar",
    "jazz",
    "jealous",
    "jeans",
    "jelly",
    "jewel",
    "job",
    "join",
    "joke",
    "journey",
    "joy",
    "judge",
    "juice",
    "jump",
    "jungle",
    "junior",
    "junk",
    "just",
    "kangaroo",
    "keen",
    "keep",
    "ketchup",
    "key",
    "kick",
    "kid",
    "kidney",
    "kind",
    "kingdom",
    "kiss",
    "kit",
    "kitchen",
    "kite",
    "kitten",
    "kiwi",
    "knee",
    "knife",
    "knock",
    "know",
    "lab",
    "label",
    "labor",
    "ladder",
    "lady",
    "lake",
    "lamp",
    "language",
    "laptop",
    "large",
    "later",
    "latin",
    "laugh",
    "laundry",
    "lava",
    "law",
    "lawn",
    "lawsuit",
    "layer",
    "lazy",
    "leader",
    "leaf",
    "learn",
    "leave",
    "lecture",
    "left",
    "leg",
    "legal",
    "legend",
    "leisure",
    "lemon",
    "lend",
    "length",
    "lens",
    "leopard",
    "lesson",
    "letter",
    "level",
    "liar",
    "liberty",
    "library",
    "license",
    "life",
    "lift",
    "light",
    "like",
    "limb",
    "limit",
    "link",
    "lion",
    "liquid",
    "list",
    "little",
    "live",
    "lizard",
    "load",
    "loan",
    "lobster",
    "local",
    "lock",
    "logic",
    "lonely",
    "long",
    "loop",
    "lottery",
    "loud",
    "lounge",
    "love",
    "loyal",
    "lucky",
    "luggage",
    "lumber",
    "lunar",
    "lunch",
    "luxury",
    "lyrics",
    "machine",
    "mad",
    "magic",
    "magnet",
    "maid",
    "mail",
    "main",
    "major",
    "make",
    "mammal",
    "man",
    "manage",
    "mandate",
    "mango",
    "mansion",
    "manual",
    "maple",
    "marble",
    "march",
    "margin",
    "marine",
    "market",
    "marriage",
    "mask",
    "mass",
    "master",
    "match",
    "material",
    "math",
    "matrix",
    "matter",
    "maximum",
    "maze",
    "meadow",
    "mean",
    "measure",
    "meat",
    "mechanic",
    "medal",
    "media",
    "melody",
    "melt",
    "member",
    "memory",
    "mention",
    "menu",
    "mercy",
    "merge",
    "merit",
    "merry",
    "mesh",
    "message",
    "metal",
    "method",
    "middle",
    "midnight",
    "milk",
    "million",
    "mimic",
    "mind",
    "minimum",
    "minor",
    "minute",
    "miracle",
    "mirror",
    "misery",
    "miss",
    "mistake",
    "mix",
    "mixed",
    "mixture",
    "mobile",
    "model",
    "modify",
    "mom",
    "moment",
    "monitor",
    "monkey",
    "monster",
    "month",
    "moon",
    "moral",
    "more",
    "morning",
    "mosquito",
    "mother",
    "motion",
    "motor",
    "mountain",
    "mouse",
    "move",
    "movie",
    "much",
    "muffin",
    "mule",
    "multiply",
    "muscle",
    "museum",
    "mushroom",
    "music",
    "must",
    "mutual",
    "myself",
    "mystery",
    "myth",
    "naive",
    "name",
    "napkin",
    "narrow",
    "nasty",
    "nation",
    "nature",
    "near",
    "neck",
    "need",
    "negative",
    "neglect",
    "neither",
    "nephew",
    "nerve",
    "nest",
    "net",
    "network",
    "neutral",
    "never",
    "news",
    "next",
    "nice",
    "night",
    "noble",
    "noise",
    "nominee",
    "noodle",
    "normal",
    "north",
    "nose",
    "notable",
    "note",
    "nothing",
    "notice",
    "novel",
    "now",
    "nuclear",
    "number",
    "nurse",
    "nut",
    "oak",
    "obey",
    "object",
    "oblige",
    "obscure",
    "observe",
    "obtain",
    "obvious",
    "occur",
    "ocean",
    "october",
    "odor",
    "off",
    "offer",
    "office",
    "often",
    "oil",
    "okay",
    "old",
    "olive",
    "olympic",
    "omit",
    "once",
    "one",
    "onion",
    "online",
    "only",
    "open",
    "opera",
    "opinion",
    "oppose",
    "option",
    "orange",
    "orbit",
    "orchard",
    "order",
    "ordinary",
    "organ",
    "orient",
    "original",
    "orphan",
    "ostrich",
    "other",
    "outdoor",
    "outer",
    "output",
    "outside",
    "oval",
    "oven",
    "over",
    "own",
    "owner",
    "oxygen",
    "oyster",
    "ozone",
    "pact",
    "paddle",
    "page",
    "pair",
    "palace",
    "palm",
    "panda",
    "panel",
    "panic",
    "panther",
    "paper",
    "parade",
    "parent",
    "park",
    "parrot",
    "party",
    "pass",
    "patch",
    "path",
    "patient",
    "patrol",
    "pattern",
    "pause",
    "pave",
    "payment",
    "peace",
    "peanut",
    "pear",
    "peasant",
    "pelican",
    "pen",
    "penalty",
    "pencil",
    "people",
    "pepper",
    "perfect",
    "permit",
    "person",
    "pet",
    "phone",
    "photo",
    "phrase",
    "physical",
    "piano",
    "picnic",
    "picture",
    "piece",
    "pig",
    "pigeon",
    "pill",
    "pilot",
    "pink",
    "pioneer",
    "pipe",
    "pistol",
    "pitch",
    "pizza",
    "place",
    "planet",
    "plastic",
    "plate",
    "play",
    "please",
    "pledge",
    "pluck",
    "plug",
    "plunge",
    "poem",
    "poet",
    "point",
    "polar",
    "pole",
    "police",
    "pond",
    "pony",
    "pool",
    "popular",
    "portion",
    "position",
    "possible",
    "post",
    "potato",
    "pottery",
    "poverty",
    "powder",
    "power",
    "practice",
    "praise",
    "predict",
    "prefer",
    "prepare",
    "present",
    "pretty",
    "prevent",
    "price",
    "pride",
    "primary",
    "print",
    "priority",
    "prison",
    "private",
    "prize",
    "problem",
    "process",
    "produce",
    "profit",
    "program",
    "project",
    "promote",
    "proof",
    "property",
    "prosper",
    "protect",
    "proud",
    "provide",
    "public",
    "pudding",
    "pull",
    "pulp",
    "pulse",
    "pumpkin",
    "punch",
    "pupil",
    "puppy",
    "purchase",
    "purity",
    "purpose",
    "purse",
    "push",
    "put",
    "puzzle",
    "pyramid",
    "quality",
    "quantum",
    "quarter",
    "question",
    "quick",
    "quit",
    "quiz",
    "quote",
    "rabbit",
    "raccoon",
    "race",
    "rack",
    "radar",
    "radio",
    "rail",
    "rain",
    "raise",
    "rally",
    "ramp",
    "ranch",
    "random",
    "range",
    "rapid",
    "rare",
    "rate",
    "rather",
    "raven",
    "raw",
    "razor",
    "ready",
    "real",
    "reason",
    "rebel",
    "rebuild",
    "recall",
    "receive",
    "recipe",
    "record",
    "recycle",
    "reduce",
    "reflect",
    "reform",
    "refuse",
    "region",
    "regret",
    "regular",
    "reject",
    "relax",
    "release",
    "relief",
    "rely",
    "remain",
    "remember",
    "remind",
    "remove",
    "render",
    "renew",
    "rent",
    "reopen",
    "repair",
    "repeat",
    "replace",
    "report",
    "require",
    "rescue",
    "resemble",
    "resist",
    "resource",
    "response",
    "result",
    "retire",
    "retreat",
    "return",
    "reunion",
    "reveal",
    "review",
    "reward",
    "rhythm",
    "rib",
    "ribbon",
    "rice",
    "rich",
    "ride",
    "ridge",
    "rifle",
    "right",
    "rigid",
    "ring",
    "riot",
    "ripple",
    "risk",
    "ritual",
    "rival",
    "river",
    "road",
    "roast",
    "robot",
    "robust",
    "rocket",
    "romance",
    "roof",
    "rookie",
    "room",
    "rose",
    "rotate",
    "rough",
    "round",
    "route",
    "royal",
    "rubber",
    "rude",
    "rug",
    "rule",
    "run",
    "runway",
    "rural",
    "sad",
    "saddle",
    "sadness",
    "safe",
    "sail",
    "salad",
    "salmon",
    "salon",
    "salt",
    "salute",
    "same",
    "sample",
    "sand",
    "satisfy",
    "satoshi",
    "sauce",
    "sausage",
    "save",
    "say",
    "scale",
    "scan",
    "scare",
    "scatter",
    "scene",
    "scheme",
    "school",
    "science",
    "scissors",
    "scorpion",
    "scout",
    "scrap",
    "screen",
    "script",
    "scrub",
    "sea",
    "search",
    "season",
    "seat",
    "second",
    "secret",
    "section",
    "security",
    "seed",
    "seek",
    "segment",
    "select",
    "sell",
    "seminar",
    "senior",
    "sense",
    "sentence",
    "series",
    "service",
    "session",
    "settle",
    "setup",
    "seven",
    "shadow",
    "shaft",
    "shallow",
    "share",
    "shed",
    "shell",
    "sheriff",
    "shield",
    "shift",
    "shine",
    "ship",
    "shiver",
    "shock",
    "shoe",
    "shoot",
    "shop",
    "short",
    "shoulder",
    "shove",
    "shrimp",
    "shrug",
    "shuffle",
    "shy",
    "sibling",
    "sick",
    "side",
    "siege",
    "sight",
    "sign",
    "silent",
    "silk",
    "silly",
    "silver",
    "similar",
    "simple",
    "since",
    "sing",
    "siren",
    "sister",
    "situate",
    "six",
    "size",
    "skate",
    "sketch",
    "ski",
    "skill",
    "skin",
    "skirt",
    "skull",
    "slab",
    "slam",
    "sleep",
    "slender",
    "slice",
    "slide",
    "slight",
    "slim",
    "slogan",
    "slot",
    "slow",
    "slush",
    "small",
    "smart",
    "smile",
    "smoke",
    "smooth",
    "snack",
    "snake",
    "snap",
    "sniff",
    "snow",
    "soap",
    "soccer",
    "social",
    "sock",
    "soda",
    "soft",
    "solar",
    "soldier",
    "solid",
    "solution",
    "solve",
    "someone",
    "song",
    "soon",
    "sorry",
    "sort",
    "soul",
    "sound",
    "soup",
    "source",
    "south",
    "space",
    "spare",
    "spatial",
    "spawn",
    "speak",
    "special",
    "speed",
    "spell",
    "spend",
    "sphere",
    "spice",
    "spider",
    "spike",
    "spin",
    "spirit",
    "split",
    "spoil",
    "sponsor",
    "spoon",
    "sport",
    "spot",
    "spray",
    "spread",
    "spring",
    "spy",
    "square",
    "squeeze",
    "squirrel",
    "stable",
    "stadium",
    "staff",
    "stage",
    "stairs",
    "stamp",
    "stand",
    "start",
    "state",
    "stay",
    "steak",
    "steel",
    "stem",
    "step",
    "stereo",
    "stick",
    "still",
    "sting",
    "stock",
    "stomach",
    "stone",
    "stool",
    "story",
    "stove",
    "strategy",
    "street",
    "strike",
    "strong",
    "struggle",
    "student",
    "stuff",
    "stumble",
    "style",
    "subject",
    "submit",
    "subway",
    "success",
    "such",
    "sudden",
    "suffer",
    "sugar",
    "suggest",
    "suit",
    "summer",
    "sun",
    "sunny",
    "sunset",
    "super",
    "supply",
    "supreme",
    "sure",
    "surface",
    "surge",
    "surprise",
    "surround",
    "survey",
    "suspect",
    "sustain",
    "swallow",
    "swamp",
    "swap",
    "swarm",
    "swear",
    "sweet",
    "swift",
    "swim",
    "swing",
    "switch",
    "sword",
    "symbol",
    "symptom",
    "syrup",
    "system",
    "table",
    "tackle",
    "tag",
    "tail",
    "talent",
    "talk",
    "tank",
    "tape",
    "target",
    "task",
    "taste",
    "tattoo",
    "taxi",
    "teach",
    "team",
    "tell",
    "ten",
    "tenant",
    "tennis",
    "tent",
    "term",
    "test",
    "text",
    "thank",
    "that",
    "theme",
    "then",
    "theory",
    "there",
    "they",
    "thing",
    "this",
    "thought",
    "three",
    "thrive",
    "throw",
    "thumb",
    "thunder",
    "ticket",
    "tide",
    "tiger",
    "tilt",
    "timber",
    "time",
    "tiny",
    "tip",
    "tired",
    "tissue",
    "title",
    "toast",
    "tobacco",
    "today",
    "toddler",
    "toe",
    "together",
    "toilet",
    "token",
    "tomato",
    "tomorrow",
    "tone",
    "tongue",
    "tonight",
    "tool",
    "tooth",
    "top",
    "topic",
    "topple",
    "torch",
    "tornado",
    "tortoise",
    "toss",
    "total",
    "tourist",
    "toward",
    "tower",
    "town",
    "toy",
    "track",
    "trade",
    "traffic",
    "tragic",
    "train",
    "transfer",
    "trap",
    "trash",
    "travel",
    "tray",
    "treat",
    "tree",
    "trend",
    "trial",
    "tribe",
    "trick",
    "trigger",
    "trim",
    "trip",
    "trophy",
    "trouble",
    "truck",
    "true",
    "truly",
    "trumpet",
    "trust",
    "truth",
    "try",
    "tube",
    "tuition",
    "tumble",
    "tuna",
    "tunnel",
    "turkey",
    "turn",
    "turtle",
    "twelve",
    "twenty",
    "twice",
    "twin",
    "twist",
    "two",
    "type",
    "typical",
    "ugly",
    "umbrella",
    "unable",
    "unaware",
    "uncle",
    "uncover",
    "under",
    "undo",
    "unfair",
    "unfold",
    "unhappy",
    "uniform",
    "unique",
    "unit",
    "universe",
    "unknown",
    "unlock",
    "until",
    "unusual",
    "unveil",
    "update",
    "upgrade",
    "uphold",
    "upon",
    "upper",
    "upset",
    "urban",
    "urge",
    "usage",
    "use",
    "used",
    "useful",
    "useless",
    "usual",
    "utility",
    "vacant",
    "vacuum",
    "vague",
    "valid",
    "valley",
    "valve",
    "van",
    "vanish",
    "vapor",
    "various",
    "vast",
    "vault",
    "vehicle",
    "velvet",
    "vendor",
    "venture",
    "venue",
    "verb",
    "verify",
    "version",
    "very",
    "vessel",
    "veteran",
    "viable",
    "vibrant",
    "vicious",
    "victory",
    "video",
    "view",
    "village",
    "vintage",
    "violin",
    "virtual",
    "virus",
    "visa",
    "visit",
    "visual",
    "vital",
    "vivid",
    "vocal",
    "voice",
    "void",
    "volcano",
    "volume",
    "vote",
    "voyage",
    "wage",
    "wagon",
    "wait",
    "walk",
    "wall",
    "walnut",
    "want",
    "warfare",
    "warm",
    "warrior",
    "wash",
    "wasp",
    "waste",
    "water",
    "wave",
    "way",
    "wealth",
    "weapon",
    "wear",
    "weasel",
    "weather",
    "web",
    "wedding",
    "weekend",
    "weird",
    "welcome",
    "west",
    "wet",
    "whale",
    "what",
    "wheat",
    "wheel",
    "when",
    "where",
    "whip",
    "whisper",
    "wide",
    "width",
    "wife",
    "wild",
    "will",
    "win",
    "window",
    "wine",
    "wing",
    "wink",
    "winner",
    "winter",
    "wire",
    "wisdom",
    "wise",
    "wish",
    "witness",
    "wolf",
    "woman",
    "wonder",
    "wood",
    "wool",
    "word",
    "work",
    "world",
    "worry",
    "worth",
    "wrap",
    "wreck",
    "wrestle",
    "wrist",
    "write",
    "wrong",
    "yard",
    "year",
    "yellow",
    "you",
    "young",
    "youth",
    "zebra",
    "zero",
    "zone",
    "zoo"
];
function bytesToBitstring(bytes) {
    return Array.from(bytes).map((byte)=>byte.toString(2).padStart(8, "0")).join("");
}
function deriveChecksumBits(entropy) {
    const entropyLengthBits = entropy.length * 8; // "ENT" (in bits)
    const checksumLengthBits = entropyLengthBits / 32; // "CS" (in bits)
    const hash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(entropy);
    return bytesToBitstring(hash).slice(0, checksumLengthBits);
}
function bitstringToByte(bin) {
    return parseInt(bin, 2);
}
const allowedEntropyLengths = [
    16,
    20,
    24,
    28,
    32
];
const allowedWordLengths = [
    12,
    15,
    18,
    21,
    24
];
function entropyToMnemonic(entropy) {
    if (allowedEntropyLengths.indexOf(entropy.length) === -1) {
        throw new Error("invalid input length");
    }
    const entropyBits = bytesToBitstring(entropy);
    const checksumBits = deriveChecksumBits(entropy);
    const bits = entropyBits + checksumBits;
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const chunks = bits.match(/(.{11})/g);
    const words = chunks.map((binary)=>{
        const index = bitstringToByte(binary);
        return wordlist[index];
    });
    return words.join(" ");
}
const invalidNumberOfWorks = "Invalid number of words";
const wordNotInWordlist = "Found word that is not in the wordlist";
const invalidEntropy = "Invalid entropy";
const invalidChecksum = "Invalid mnemonic checksum";
function normalize(str) {
    return str.normalize("NFKD");
}
function mnemonicToEntropy(mnemonic) {
    const words = normalize(mnemonic).split(" ");
    if (!allowedWordLengths.includes(words.length)) {
        throw new Error(invalidNumberOfWorks);
    }
    // convert word indices to 11 bit binary strings
    const bits = words.map((word)=>{
        const index = wordlist.indexOf(word);
        if (index === -1) {
            throw new Error(wordNotInWordlist);
        }
        return index.toString(2).padStart(11, "0");
    }).join("");
    // split the binary string into ENT/CS
    const dividerIndex = Math.floor(bits.length / 33) * 32;
    const entropyBits = bits.slice(0, dividerIndex);
    const checksumBits = bits.slice(dividerIndex);
    // calculate the checksum and compare
    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
    const entropyBytes = entropyBits.match(/(.{1,8})/g).map(bitstringToByte);
    if (entropyBytes.length < 16 || entropyBytes.length > 32 || entropyBytes.length % 4 !== 0) {
        throw new Error(invalidEntropy);
    }
    const entropy = Uint8Array.from(entropyBytes);
    const newChecksum = deriveChecksumBits(entropy);
    if (newChecksum !== checksumBits) {
        throw new Error(invalidChecksum);
    }
    return entropy;
}
class EnglishMnemonic {
    static wordlist = wordlist;
    // list of space separated lower case words (1 or more)
    static mnemonicMatcher = /^[a-z]+( [a-z]+)*$/;
    data;
    constructor(mnemonic){
        if (!EnglishMnemonic.mnemonicMatcher.test(mnemonic)) {
            throw new Error("Invalid mnemonic format");
        }
        const words = mnemonic.split(" ");
        const allowedWordsLengths = [
            12,
            15,
            18,
            21,
            24
        ];
        if (allowedWordsLengths.indexOf(words.length) === -1) {
            throw new Error(`Invalid word count in mnemonic (allowed: ${allowedWordsLengths} got: ${words.length})`);
        }
        for (const word of words){
            if (EnglishMnemonic.wordlist.indexOf(word) === -1) {
                throw new Error("Mnemonic contains invalid word");
            }
        }
        // Throws with informative error message if mnemonic is not valid
        mnemonicToEntropy(mnemonic);
        this.data = mnemonic;
    }
    toString() {
        return this.data;
    }
}
class Bip39 {
    /**
     * Encodes raw entropy of length 16, 20, 24, 28 or 32 bytes as an English mnemonic between 12 and 24 words.
     *
     * | Entropy            | Words |
     * |--------------------|-------|
     * | 128 bit (16 bytes) |    12 |
     * | 160 bit (20 bytes) |    15 |
     * | 192 bit (24 bytes) |    18 |
     * | 224 bit (28 bytes) |    21 |
     * | 256 bit (32 bytes) |    24 |
     *
     *
     * @see https://github.com/bitcoin/bips/blob/master/bip-0039.mediawiki#generating-the-mnemonic
     * @param entropy The entropy to be encoded. This must be cryptographically secure.
     */ static encode(entropy) {
        return new EnglishMnemonic(entropyToMnemonic(entropy));
    }
    static decode(mnemonic) {
        return mnemonicToEntropy(mnemonic.toString());
    }
    static async mnemonicToSeed(mnemonic, password) {
        const mnemonicBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toUtf8"])(normalize(mnemonic.toString()));
        const salt = "mnemonic" + (password ? normalize(password) : "");
        const saltBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toUtf8"])(salt);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$pbkdf2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pbkdf2Sha512"])(mnemonicBytes, saltBytes, 2048, 64);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/hmac.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Hmac": (()=>Hmac)
});
class Hmac {
    blockSize;
    messageHasher;
    oKeyPad;
    iKeyPad;
    hash;
    constructor(hashFunctionConstructor, originalKey){
        // This implementation is based on https://en.wikipedia.org/wiki/HMAC#Implementation
        // with the addition of incremental hashing support. Thus part of the algorithm
        // is in the constructor and the rest in digest().
        const blockSize = new hashFunctionConstructor().blockSize;
        this.hash = (data)=>new hashFunctionConstructor().update(data).digest();
        let key = originalKey;
        if (key.length > blockSize) {
            key = this.hash(key);
        }
        if (key.length < blockSize) {
            const zeroPadding = new Uint8Array(blockSize - key.length);
            key = new Uint8Array([
                ...key,
                ...zeroPadding
            ]);
        }
        // eslint-disable-next-line no-bitwise
        this.oKeyPad = key.map((keyByte)=>keyByte ^ 0x5c);
        // eslint-disable-next-line no-bitwise
        this.iKeyPad = key.map((keyByte)=>keyByte ^ 0x36);
        this.messageHasher = new hashFunctionConstructor();
        this.blockSize = blockSize;
        this.update(this.iKeyPad);
    }
    update(data) {
        this.messageHasher.update(data);
        return this;
    }
    digest() {
        const innerHash = this.messageHasher.digest();
        return this.hash(new Uint8Array([
            ...this.oKeyPad,
            ...innerHash
        ]));
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/keccak.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Keccak256": (()=>Keccak256),
    "keccak256": (()=>keccak256)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/sha3.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/utils.js [app-client] (ecmascript)");
;
;
class Keccak256 {
    blockSize = 512 / 8;
    impl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$sha3$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["keccak_256"].create();
    constructor(firstData){
        if (firstData) {
            this.update(firstData);
        }
    }
    update(data) {
        this.impl.update((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRealUint8Array"])(data));
        return this;
    }
    digest() {
        return this.impl.digest();
    }
}
function keccak256(data) {
    return new Keccak256(data).digest();
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/libsodium.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// Keep all classes requiring libsodium-js in one file as having multiple
// requiring of the libsodium-wrappers module currently crashes browsers
//
// libsodium.js API: https://gist.github.com/webmaster128/b2dbe6d54d36dd168c9fabf441b9b09c
__turbopack_context__.s({
    "Argon2id": (()=>Argon2id),
    "Ed25519": (()=>Ed25519),
    "Ed25519Keypair": (()=>Ed25519Keypair),
    "Xchacha20poly1305Ietf": (()=>Xchacha20poly1305Ietf),
    "isArgon2idOptions": (()=>isArgon2idOptions),
    "xchacha20NonceLength": (()=>xchacha20NonceLength)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$typechecks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/typechecks.js [app-client] (ecmascript)");
// Using crypto_pwhash requires sumo. Once we migrate to a standalone
// Argon2 implementation, we can use the normal libsodium-wrappers
// again: https://github.com/cosmos/cosmjs/issues/1031
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/libsodium-wrappers-sumo/dist/modules-sumo/libsodium-wrappers.js [app-client] (ecmascript)");
;
;
function isArgon2idOptions(thing) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$typechecks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObjectLike"])(thing)) return false;
    if (typeof thing.outputLength !== "number") return false;
    if (typeof thing.opsLimit !== "number") return false;
    if (typeof thing.memLimitKib !== "number") return false;
    return true;
}
class Argon2id {
    static async execute(password, salt, options) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_pwhash(options.outputLength, password, salt, options.opsLimit, options.memLimitKib * 1024, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_pwhash_ALG_ARGON2ID13);
    }
}
class Ed25519Keypair {
    // a libsodium privkey has the format `<ed25519 privkey> + <ed25519 pubkey>`
    static fromLibsodiumPrivkey(libsodiumPrivkey) {
        if (libsodiumPrivkey.length !== 64) {
            throw new Error(`Unexpected key length ${libsodiumPrivkey.length}. Must be 64.`);
        }
        return new Ed25519Keypair(libsodiumPrivkey.slice(0, 32), libsodiumPrivkey.slice(32, 64));
    }
    privkey;
    pubkey;
    constructor(privkey, pubkey){
        this.privkey = privkey;
        this.pubkey = pubkey;
    }
    toLibsodiumPrivkey() {
        return new Uint8Array([
            ...this.privkey,
            ...this.pubkey
        ]);
    }
}
class Ed25519 {
    /**
     * Generates a keypair deterministically from a given 32 bytes seed.
     *
     * This seed equals the Ed25519 private key.
     * For implementation details see crypto_sign_seed_keypair in
     * https://download.libsodium.org/doc/public-key_cryptography/public-key_signatures.html
     * and diagram on https://blog.mozilla.org/warner/2011/11/29/ed25519-keys/
     */ static async makeKeypair(seed) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        const keypair = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_sign_seed_keypair(seed);
        return Ed25519Keypair.fromLibsodiumPrivkey(keypair.privateKey);
    }
    static async createSignature(message, keyPair) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_sign_detached(message, keyPair.toLibsodiumPrivkey());
    }
    static async verifySignature(signature, message, pubkey) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_sign_verify_detached(signature, message, pubkey);
    }
}
const xchacha20NonceLength = 24;
class Xchacha20poly1305Ietf {
    static async encrypt(message, key, nonce) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        const additionalData = null;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_aead_xchacha20poly1305_ietf_encrypt(message, additionalData, null, nonce, key);
    }
    static async decrypt(ciphertext, key, nonce) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ready;
        const additionalData = null;
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$libsodium$2d$wrappers$2d$sumo$2f$dist$2f$modules$2d$sumo$2f$libsodium$2d$wrappers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].crypto_aead_xchacha20poly1305_ietf_decrypt(null, ciphertext, additionalData, nonce, key);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/random.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Random": (()=>Random)
});
class Random {
    /**
     * Returns `count` cryptographically secure random bytes
     */ static getBytes(count) {
        try {
            const globalObject = typeof window === "object" ? window : self;
            const cryptoApi = typeof globalObject.crypto !== "undefined" ? globalObject.crypto : globalObject.msCrypto;
            const out = new Uint8Array(count);
            cryptoApi.getRandomValues(out);
            return out;
        } catch  {
            try {
                // eslint-disable-next-line @typescript-eslint/no-var-requires
                const crypto = __turbopack_context__.r("[project]/node_modules/crypto/lib/index.js [app-client] (ecmascript)");
                return new Uint8Array([
                    ...crypto.randomBytes(count)
                ]);
            } catch  {
                throw new Error("No secure random number generator found");
            }
        }
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/ripemd.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Ripemd160": (()=>Ripemd160),
    "ripemd160": (()=>ripemd160)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$ripemd160$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@noble/hashes/esm/ripemd160.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/utils.js [app-client] (ecmascript)");
;
;
class Ripemd160 {
    blockSize = 512 / 8;
    impl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$noble$2f$hashes$2f$esm$2f$ripemd160$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ripemd160"].create();
    constructor(firstData){
        if (firstData) {
            this.update(firstData);
        }
    }
    update(data) {
        this.impl.update((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toRealUint8Array"])(data));
        return this;
    }
    digest() {
        return this.impl.digest();
    }
}
function ripemd160(data) {
    return new Ripemd160(data).digest();
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1signature.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ExtendedSecp256k1Signature": (()=>ExtendedSecp256k1Signature),
    "Secp256k1Signature": (()=>Secp256k1Signature)
});
function trimLeadingNullBytes(inData) {
    let numberOfLeadingNullBytes = 0;
    for (const byte of inData){
        if (byte === 0x00) {
            numberOfLeadingNullBytes++;
        } else {
            break;
        }
    }
    return inData.slice(numberOfLeadingNullBytes);
}
const derTagInteger = 0x02;
class Secp256k1Signature {
    /**
     * Takes the pair of integers (r, s) as 2x32 byte of binary data.
     *
     * Note: This is the format Cosmos SDK uses natively.
     *
     * @param data a 64 byte value containing integers r and s.
     */ static fromFixedLength(data) {
        if (data.length !== 64) {
            throw new Error(`Got invalid data length: ${data.length}. Expected 2x 32 bytes for the pair (r, s)`);
        }
        return new Secp256k1Signature(trimLeadingNullBytes(data.slice(0, 32)), trimLeadingNullBytes(data.slice(32, 64)));
    }
    static fromDer(data) {
        let pos = 0;
        if (data[pos++] !== 0x30) {
            throw new Error("Prefix 0x30 expected");
        }
        const bodyLength = data[pos++];
        if (data.length - pos !== bodyLength) {
            throw new Error("Data length mismatch detected");
        }
        // r
        const rTag = data[pos++];
        if (rTag !== derTagInteger) {
            throw new Error("INTEGER tag expected");
        }
        const rLength = data[pos++];
        if (rLength >= 0x80) {
            throw new Error("Decoding length values above 127 not supported");
        }
        const rData = data.slice(pos, pos + rLength);
        pos += rLength;
        // s
        const sTag = data[pos++];
        if (sTag !== derTagInteger) {
            throw new Error("INTEGER tag expected");
        }
        const sLength = data[pos++];
        if (sLength >= 0x80) {
            throw new Error("Decoding length values above 127 not supported");
        }
        const sData = data.slice(pos, pos + sLength);
        pos += sLength;
        return new Secp256k1Signature(// r/s data can contain leading 0 bytes to express integers being non-negative in DER
        trimLeadingNullBytes(rData), trimLeadingNullBytes(sData));
    }
    data;
    constructor(r, s){
        if (r.length > 32 || r.length === 0 || r[0] === 0x00) {
            throw new Error("Unsigned integer r must be encoded as unpadded big endian.");
        }
        if (s.length > 32 || s.length === 0 || s[0] === 0x00) {
            throw new Error("Unsigned integer s must be encoded as unpadded big endian.");
        }
        this.data = {
            r: r,
            s: s
        };
    }
    r(length) {
        if (length === undefined) {
            return this.data.r;
        } else {
            const paddingLength = length - this.data.r.length;
            if (paddingLength < 0) {
                throw new Error("Length too small to hold parameter r");
            }
            const padding = new Uint8Array(paddingLength);
            return new Uint8Array([
                ...padding,
                ...this.data.r
            ]);
        }
    }
    s(length) {
        if (length === undefined) {
            return this.data.s;
        } else {
            const paddingLength = length - this.data.s.length;
            if (paddingLength < 0) {
                throw new Error("Length too small to hold parameter s");
            }
            const padding = new Uint8Array(paddingLength);
            return new Uint8Array([
                ...padding,
                ...this.data.s
            ]);
        }
    }
    toFixedLength() {
        return new Uint8Array([
            ...this.r(32),
            ...this.s(32)
        ]);
    }
    toDer() {
        // DER supports negative integers but our data is unsigned. Thus we need to prepend
        // a leading 0 byte when the higest bit is set to differentiate nagative values
        const rEncoded = this.data.r[0] >= 0x80 ? new Uint8Array([
            0,
            ...this.data.r
        ]) : this.data.r;
        const sEncoded = this.data.s[0] >= 0x80 ? new Uint8Array([
            0,
            ...this.data.s
        ]) : this.data.s;
        const rLength = rEncoded.length;
        const sLength = sEncoded.length;
        const data = new Uint8Array([
            derTagInteger,
            rLength,
            ...rEncoded,
            derTagInteger,
            sLength,
            ...sEncoded
        ]);
        return new Uint8Array([
            0x30,
            data.length,
            ...data
        ]);
    }
}
class ExtendedSecp256k1Signature extends Secp256k1Signature {
    /**
     * Decode extended signature from the simple fixed length encoding
     * described in toFixedLength().
     */ static fromFixedLength(data) {
        if (data.length !== 65) {
            throw new Error(`Got invalid data length ${data.length}. Expected 32 + 32 + 1`);
        }
        return new ExtendedSecp256k1Signature(trimLeadingNullBytes(data.slice(0, 32)), trimLeadingNullBytes(data.slice(32, 64)), data[64]);
    }
    recovery;
    constructor(r, s, recovery){
        super(r, s);
        if (!Number.isInteger(recovery)) {
            throw new Error("The recovery parameter must be an integer.");
        }
        if (recovery < 0 || recovery > 4) {
            throw new Error("The recovery parameter must be one of 0, 1, 2, 3.");
        }
        this.recovery = recovery;
    }
    /**
     * A simple custom encoding that encodes the extended signature as
     * r (32 bytes) | s (32 bytes) | recovery param (1 byte)
     * where | denotes concatenation of bonary data.
     */ toFixedLength() {
        return new Uint8Array([
            ...this.r(32),
            ...this.s(32),
            this.recovery
        ]);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Secp256k1": (()=>Secp256k1)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bn.js/lib/bn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$elliptic$2f$lib$2f$elliptic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/elliptic/lib/elliptic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1signature.js [app-client] (ecmascript)");
;
;
;
;
const secp256k1 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$elliptic$2f$lib$2f$elliptic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ec("secp256k1");
const secp256k1N = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", "hex");
class Secp256k1 {
    /**
     * Takes a 32 byte private key and returns a privkey/pubkey pair.
     *
     * The resulting pubkey is uncompressed. For the use in Cosmos it should
     * be compressed first using `Secp256k1.compressPubkey`.
     */ static async makeKeypair(privkey) {
        if (privkey.length !== 32) {
            // is this check missing in secp256k1.validatePrivateKey?
            // https://github.com/bitjson/bitcoin-ts/issues/4
            throw new Error("input data is not a valid secp256k1 private key");
        }
        const keypair = secp256k1.keyFromPrivate(privkey);
        if (keypair.validate().result !== true) {
            throw new Error("input data is not a valid secp256k1 private key");
        }
        // range test that is not part of the elliptic implementation
        const privkeyAsBigInteger = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](privkey);
        if (privkeyAsBigInteger.gte(secp256k1N)) {
            // not strictly smaller than N
            throw new Error("input data is not a valid secp256k1 private key");
        }
        const out = {
            privkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])(keypair.getPrivate("hex")),
            // encodes uncompressed as
            // - 1-byte prefix "04"
            // - 32-byte x coordinate
            // - 32-byte y coordinate
            pubkey: Uint8Array.from(keypair.getPublic("array"))
        };
        return out;
    }
    /**
     * Creates a signature that is
     * - deterministic (RFC 6979)
     * - lowS signature
     * - DER encoded
     */ static async createSignature(messageHash, privkey) {
        if (messageHash.length === 0) {
            throw new Error("Message hash must not be empty");
        }
        if (messageHash.length > 32) {
            throw new Error("Message hash length must not exceed 32 bytes");
        }
        const keypair = secp256k1.keyFromPrivate(privkey);
        // the `canonical` option ensures creation of lowS signature representations
        const { r, s, recoveryParam } = keypair.sign(messageHash, {
            canonical: true
        });
        if (typeof recoveryParam !== "number") throw new Error("Recovery param missing");
        return new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExtendedSecp256k1Signature"](Uint8Array.from(r.toArray()), Uint8Array.from(s.toArray()), recoveryParam);
    }
    static async verifySignature(signature, messageHash, pubkey) {
        if (messageHash.length === 0) {
            throw new Error("Message hash must not be empty");
        }
        if (messageHash.length > 32) {
            throw new Error("Message hash length must not exceed 32 bytes");
        }
        const keypair = secp256k1.keyFromPublic(pubkey);
        // From https://github.com/indutny/elliptic:
        //
        //     Sign the message's hash (input must be an array, or a hex-string)
        //
        //     Signature MUST be either:
        //     1) DER-encoded signature as hex-string; or
        //     2) DER-encoded signature as buffer; or
        //     3) object with two hex-string properties (r and s); or
        //     4) object with two buffer properties (r and s)
        //
        // Uint8Array is not a Buffer, but elliptic seems to be happy with the interface
        // common to both types. Uint8Array is not an array of ints but the interface is
        // similar
        try {
            return keypair.verify(messageHash, signature.toDer());
        } catch (error) {
            return false;
        }
    }
    static recoverPubkey(signature, messageHash) {
        const signatureForElliptic = {
            r: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toHex"])(signature.r()),
            s: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toHex"])(signature.s())
        };
        const point = secp256k1.recoverPubKey(messageHash, signatureForElliptic, signature.recovery);
        const keypair = secp256k1.keyFromPublic(point);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])(keypair.getPublic(false, "hex"));
    }
    /**
     * Takes a compressed or uncompressed pubkey and return a compressed one.
     *
     * This function is idempotent.
     */ static compressPubkey(pubkey) {
        switch(pubkey.length){
            case 33:
                return pubkey;
            case 65:
                return Uint8Array.from(secp256k1.keyFromPublic(pubkey).getPublic(true, "array"));
            default:
                throw new Error("Invalid pubkey length");
        }
    }
    /**
     * Takes a compressed or uncompressed pubkey and returns an uncompressed one.
     *
     * This function is idempotent.
     */ static uncompressPubkey(pubkey) {
        switch(pubkey.length){
            case 33:
                return Uint8Array.from(secp256k1.keyFromPublic(pubkey).getPublic(false, "array"));
            case 65:
                return pubkey;
            default:
                throw new Error("Invalid pubkey length");
        }
    }
    static trimRecoveryByte(signature) {
        switch(signature.length){
            case 64:
                return signature;
            case 65:
                return signature.slice(0, 64);
            default:
                throw new Error("Invalid signature length");
        }
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/slip10.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Slip10": (()=>Slip10),
    "Slip10Curve": (()=>Slip10Curve),
    "Slip10RawIndex": (()=>Slip10RawIndex),
    "pathToString": (()=>pathToString),
    "slip10CurveFromString": (()=>slip10CurveFromString),
    "stringToPath": (()=>stringToPath)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bn.js/lib/bn.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$elliptic$2f$lib$2f$elliptic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/elliptic/lib/elliptic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/hmac.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)");
;
;
;
;
;
;
var Slip10Curve;
(function(Slip10Curve) {
    Slip10Curve["Secp256k1"] = "Bitcoin seed";
    Slip10Curve["Ed25519"] = "ed25519 seed";
})(Slip10Curve || (Slip10Curve = {}));
function slip10CurveFromString(curveString) {
    switch(curveString){
        case Slip10Curve.Ed25519:
            return Slip10Curve.Ed25519;
        case Slip10Curve.Secp256k1:
            return Slip10Curve.Secp256k1;
        default:
            throw new Error(`Unknown curve string: '${curveString}'`);
    }
}
class Slip10RawIndex extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint32"] {
    static hardened(hardenedIndex) {
        return new Slip10RawIndex(hardenedIndex + 2 ** 31);
    }
    static normal(normalIndex) {
        return new Slip10RawIndex(normalIndex);
    }
    isHardened() {
        return this.data >= 2 ** 31;
    }
}
const secp256k1 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$elliptic$2f$lib$2f$elliptic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].ec("secp256k1");
class Slip10 {
    static derivePath(curve, seed, path) {
        let result = this.master(curve, seed);
        for (const rawIndex of path){
            result = this.child(curve, result.privkey, result.chainCode, rawIndex);
        }
        return result;
    }
    static master(curve, seed) {
        const i = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hmac"](__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sha512"], (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAscii"])(curve)).update(seed).digest();
        const il = i.slice(0, 32);
        const ir = i.slice(32, 64);
        if (curve !== Slip10Curve.Ed25519 && (this.isZero(il) || this.isGteN(curve, il))) {
            return this.master(curve, i);
        }
        return {
            chainCode: ir,
            privkey: il
        };
    }
    static child(curve, parentPrivkey, parentChainCode, rawIndex) {
        let i;
        if (rawIndex.isHardened()) {
            const payload = new Uint8Array([
                0x00,
                ...parentPrivkey,
                ...rawIndex.toBytesBigEndian()
            ]);
            i = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hmac"](__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sha512"], parentChainCode).update(payload).digest();
        } else {
            if (curve === Slip10Curve.Ed25519) {
                throw new Error("Normal keys are not allowed with ed25519");
            } else {
                // Step 1 of https://github.com/satoshilabs/slips/blob/master/slip-0010.md#private-parent-key--private-child-key
                // Calculate I = HMAC-SHA512(Key = c_par, Data = ser_P(point(k_par)) || ser_32(i)).
                // where the functions point() and ser_p() are defined in BIP-0032
                const data = new Uint8Array([
                    ...Slip10.serializedPoint(curve, new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](parentPrivkey)),
                    ...rawIndex.toBytesBigEndian()
                ]);
                i = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hmac"](__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sha512"], parentChainCode).update(data).digest();
            }
        }
        return this.childImpl(curve, parentPrivkey, parentChainCode, rawIndex, i);
    }
    /**
     * Implementation of ser_P(point(k_par)) from BIP-0032
     *
     * @see https://github.com/bitcoin/bips/blob/master/bip-0032.mediawiki
     */ static serializedPoint(curve, p) {
        switch(curve){
            case Slip10Curve.Secp256k1:
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])(secp256k1.g.mul(p).encodeCompressed("hex"));
            default:
                throw new Error("curve not supported");
        }
    }
    static childImpl(curve, parentPrivkey, parentChainCode, rawIndex, i) {
        // step 2 (of the Private parent key → private child key algorithm)
        const il = i.slice(0, 32);
        const ir = i.slice(32, 64);
        // step 3
        const returnChainCode = ir;
        // step 4
        if (curve === Slip10Curve.Ed25519) {
            return {
                chainCode: returnChainCode,
                privkey: il
            };
        }
        // step 5
        const n = this.n(curve);
        const returnChildKeyAsNumber = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](il).add(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](parentPrivkey)).mod(n);
        const returnChildKey = Uint8Array.from(returnChildKeyAsNumber.toArray("be", 32));
        // step 6
        if (this.isGteN(curve, il) || this.isZero(returnChildKey)) {
            const newI = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hmac"](__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sha512"], parentChainCode).update(new Uint8Array([
                0x01,
                ...ir,
                ...rawIndex.toBytesBigEndian()
            ])).digest();
            return this.childImpl(curve, parentPrivkey, parentChainCode, rawIndex, newI);
        }
        // step 7
        return {
            chainCode: returnChainCode,
            privkey: returnChildKey
        };
    }
    static isZero(privkey) {
        return privkey.every((byte)=>byte === 0);
    }
    static isGteN(curve, privkey) {
        const keyAsNumber = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](privkey);
        return keyAsNumber.gte(this.n(curve));
    }
    static n(curve) {
        switch(curve){
            case Slip10Curve.Secp256k1:
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bn$2e$js$2f$lib$2f$bn$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", 16);
            default:
                throw new Error("curve not supported");
        }
    }
}
function pathToString(path) {
    return path.reduce((current, component)=>{
        const componentString = component.isHardened() ? `${component.toNumber() - 2 ** 31}'` : component.toString();
        return current + "/" + componentString;
    }, "m");
}
function stringToPath(input) {
    if (!input.startsWith("m")) throw new Error("Path string must start with 'm'");
    let rest = input.slice(1);
    const out = new Array();
    while(rest){
        const match = rest.match(/^\/([0-9]+)('?)/);
        if (!match) throw new Error("Syntax error while reading path component");
        const [fullMatch, numberString, apostrophe] = match;
        const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"].fromString(numberString).toNumber();
        if (value >= 2 ** 31) throw new Error("Component value too high. Must not exceed 2**31-1.");
        if (apostrophe) out.push(Slip10RawIndex.hardened(value));
        else out.push(Slip10RawIndex.normal(value));
        rest = rest.slice(fullMatch.length);
    }
    return out;
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$bip39$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/bip39.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/hmac.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$keccak$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/keccak.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/libsodium.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/random.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$ripemd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/ripemd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1signature.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/slip10.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$bip39$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/bip39.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$hmac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/hmac.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$keccak$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/keccak.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/libsodium.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/random.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$ripemd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/ripemd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$secp256k1signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/secp256k1signature.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/slip10.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <locals>");
}}),
}]);

//# sourceMappingURL=1483a_%40interchainjs_b5391a30._.js.map