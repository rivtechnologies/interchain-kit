(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Forwarding": (()=>Forwarding),
    "Hop": (()=>Hop),
    "Params": (()=>Params)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
function createBaseParams() {
    return {
        sendEnabled: false,
        receiveEnabled: false
    };
}
const Params = {
    typeUrl: "/ibc.applications.transfer.v1.Params",
    aminoType: "cosmos-sdk/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.sendEnabled === "boolean" && typeof o.receiveEnabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.send_enabled === "boolean" && typeof o.receive_enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sendEnabled === true) {
            writer.uint32(8).bool(message.sendEnabled);
        }
        if (message.receiveEnabled === true) {
            writer.uint32(16).bool(message.receiveEnabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sendEnabled = reader.bool();
                    break;
                case 2:
                    message.receiveEnabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.sendEnabled = object.sendEnabled ?? false;
        message.receiveEnabled = object.receiveEnabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        if (object.send_enabled !== undefined && object.send_enabled !== null) {
            message.sendEnabled = object.send_enabled;
        }
        if (object.receive_enabled !== undefined && object.receive_enabled !== null) {
            message.receiveEnabled = object.receive_enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.send_enabled = message.sendEnabled === false ? undefined : message.sendEnabled;
        obj.receive_enabled = message.receiveEnabled === false ? undefined : message.receiveEnabled;
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseForwarding() {
    return {
        unwind: false,
        hops: []
    };
}
const Forwarding = {
    typeUrl: "/ibc.applications.transfer.v1.Forwarding",
    aminoType: "cosmos-sdk/Forwarding",
    is (o) {
        return o && (o.$typeUrl === Forwarding.typeUrl || typeof o.unwind === "boolean" && Array.isArray(o.hops) && (!o.hops.length || Hop.is(o.hops[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Forwarding.typeUrl || typeof o.unwind === "boolean" && Array.isArray(o.hops) && (!o.hops.length || Hop.isAmino(o.hops[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.unwind === true) {
            writer.uint32(8).bool(message.unwind);
        }
        for (const v of message.hops){
            Hop.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseForwarding();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.unwind = reader.bool();
                    break;
                case 2:
                    message.hops.push(Hop.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseForwarding();
        message.unwind = object.unwind ?? false;
        message.hops = object.hops?.map((e)=>Hop.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseForwarding();
        if (object.unwind !== undefined && object.unwind !== null) {
            message.unwind = object.unwind;
        }
        message.hops = object.hops?.map((e)=>Hop.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.unwind = message.unwind === false ? undefined : message.unwind;
        if (message.hops) {
            obj.hops = message.hops.map((e)=>e ? Hop.toAmino(e) : undefined);
        } else {
            obj.hops = message.hops;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Forwarding.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Forwarding",
            value: Forwarding.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Forwarding.decode(message.value);
    },
    toProto (message) {
        return Forwarding.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.Forwarding",
            value: Forwarding.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Forwarding.typeUrl)) {
            return;
        }
        Hop.registerTypeUrl();
    }
};
function createBaseHop() {
    return {
        portId: "",
        channelId: ""
    };
}
const Hop = {
    typeUrl: "/ibc.applications.transfer.v1.Hop",
    aminoType: "cosmos-sdk/Hop",
    is (o) {
        return o && (o.$typeUrl === Hop.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Hop.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHop();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHop();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseHop();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        return obj;
    },
    fromAminoMsg (object) {
        return Hop.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Hop",
            value: Hop.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Hop.decode(message.value);
    },
    toProto (message) {
        return Hop.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.Hop",
            value: Hop.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/authz.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Allocation": (()=>Allocation),
    "AllowedForwarding": (()=>AllowedForwarding),
    "TransferAuthorization": (()=>TransferAuthorization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseAllocation() {
    return {
        sourcePort: "",
        sourceChannel: "",
        spendLimit: [],
        allowList: [],
        allowedPacketData: [],
        allowedForwarding: []
    };
}
const Allocation = {
    typeUrl: "/ibc.applications.transfer.v1.Allocation",
    aminoType: "cosmos-sdk/Allocation",
    is (o) {
        return o && (o.$typeUrl === Allocation.typeUrl || typeof o.sourcePort === "string" && typeof o.sourceChannel === "string" && Array.isArray(o.spendLimit) && (!o.spendLimit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.spendLimit[0])) && Array.isArray(o.allowList) && (!o.allowList.length || typeof o.allowList[0] === "string") && Array.isArray(o.allowedPacketData) && (!o.allowedPacketData.length || typeof o.allowedPacketData[0] === "string") && Array.isArray(o.allowedForwarding) && (!o.allowedForwarding.length || AllowedForwarding.is(o.allowedForwarding[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Allocation.typeUrl || typeof o.source_port === "string" && typeof o.source_channel === "string" && Array.isArray(o.spend_limit) && (!o.spend_limit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.spend_limit[0])) && Array.isArray(o.allow_list) && (!o.allow_list.length || typeof o.allow_list[0] === "string") && Array.isArray(o.allowed_packet_data) && (!o.allowed_packet_data.length || typeof o.allowed_packet_data[0] === "string") && Array.isArray(o.allowed_forwarding) && (!o.allowed_forwarding.length || AllowedForwarding.isAmino(o.allowed_forwarding[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sourcePort !== "") {
            writer.uint32(10).string(message.sourcePort);
        }
        if (message.sourceChannel !== "") {
            writer.uint32(18).string(message.sourceChannel);
        }
        for (const v of message.spendLimit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.allowList){
            writer.uint32(34).string(v);
        }
        for (const v of message.allowedPacketData){
            writer.uint32(42).string(v);
        }
        for (const v of message.allowedForwarding){
            AllowedForwarding.encode(v, writer.uint32(50).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAllocation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sourcePort = reader.string();
                    break;
                case 2:
                    message.sourceChannel = reader.string();
                    break;
                case 3:
                    message.spendLimit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.allowList.push(reader.string());
                    break;
                case 5:
                    message.allowedPacketData.push(reader.string());
                    break;
                case 6:
                    message.allowedForwarding.push(AllowedForwarding.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseAllocation();
        message.sourcePort = object.sourcePort ?? "";
        message.sourceChannel = object.sourceChannel ?? "";
        message.spendLimit = object.spendLimit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.allowList = object.allowList?.map((e)=>e) || [];
        message.allowedPacketData = object.allowedPacketData?.map((e)=>e) || [];
        message.allowedForwarding = object.allowedForwarding?.map((e)=>AllowedForwarding.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseAllocation();
        if (object.source_port !== undefined && object.source_port !== null) {
            message.sourcePort = object.source_port;
        }
        if (object.source_channel !== undefined && object.source_channel !== null) {
            message.sourceChannel = object.source_channel;
        }
        message.spendLimit = object.spend_limit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.allowList = object.allow_list?.map((e)=>e) || [];
        message.allowedPacketData = object.allowed_packet_data?.map((e)=>e) || [];
        message.allowedForwarding = object.allowed_forwarding?.map((e)=>AllowedForwarding.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.source_port = message.sourcePort === "" ? undefined : message.sourcePort;
        obj.source_channel = message.sourceChannel === "" ? undefined : message.sourceChannel;
        if (message.spendLimit) {
            obj.spend_limit = message.spendLimit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.spend_limit = message.spendLimit;
        }
        if (message.allowList) {
            obj.allow_list = message.allowList.map((e)=>e);
        } else {
            obj.allow_list = message.allowList;
        }
        if (message.allowedPacketData) {
            obj.allowed_packet_data = message.allowedPacketData.map((e)=>e);
        } else {
            obj.allowed_packet_data = message.allowedPacketData;
        }
        if (message.allowedForwarding) {
            obj.allowed_forwarding = message.allowedForwarding.map((e)=>e ? AllowedForwarding.toAmino(e) : undefined);
        } else {
            obj.allowed_forwarding = message.allowedForwarding;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Allocation.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Allocation",
            value: Allocation.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Allocation.decode(message.value);
    },
    toProto (message) {
        return Allocation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.Allocation",
            value: Allocation.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Allocation.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        AllowedForwarding.registerTypeUrl();
    }
};
function createBaseAllowedForwarding() {
    return {
        hops: []
    };
}
const AllowedForwarding = {
    typeUrl: "/ibc.applications.transfer.v1.AllowedForwarding",
    aminoType: "cosmos-sdk/AllowedForwarding",
    is (o) {
        return o && (o.$typeUrl === AllowedForwarding.typeUrl || Array.isArray(o.hops) && (!o.hops.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].is(o.hops[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === AllowedForwarding.typeUrl || Array.isArray(o.hops) && (!o.hops.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].isAmino(o.hops[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.hops){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAllowedForwarding();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hops.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseAllowedForwarding();
        message.hops = object.hops?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseAllowedForwarding();
        message.hops = object.hops?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.hops) {
            obj.hops = message.hops.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].toAmino(e) : undefined);
        } else {
            obj.hops = message.hops;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return AllowedForwarding.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/AllowedForwarding",
            value: AllowedForwarding.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return AllowedForwarding.decode(message.value);
    },
    toProto (message) {
        return AllowedForwarding.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.AllowedForwarding",
            value: AllowedForwarding.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(AllowedForwarding.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].registerTypeUrl();
    }
};
function createBaseTransferAuthorization() {
    return {
        allocations: []
    };
}
const TransferAuthorization = {
    typeUrl: "/ibc.applications.transfer.v1.TransferAuthorization",
    aminoType: "cosmos-sdk/TransferAuthorization",
    is (o) {
        return o && (o.$typeUrl === TransferAuthorization.typeUrl || Array.isArray(o.allocations) && (!o.allocations.length || Allocation.is(o.allocations[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === TransferAuthorization.typeUrl || Array.isArray(o.allocations) && (!o.allocations.length || Allocation.isAmino(o.allocations[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.allocations){
            Allocation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTransferAuthorization();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.allocations.push(Allocation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTransferAuthorization();
        message.allocations = object.allocations?.map((e)=>Allocation.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseTransferAuthorization();
        message.allocations = object.allocations?.map((e)=>Allocation.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.allocations) {
            obj.allocations = message.allocations.map((e)=>e ? Allocation.toAmino(e) : undefined);
        } else {
            obj.allocations = message.allocations;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return TransferAuthorization.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TransferAuthorization",
            value: TransferAuthorization.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TransferAuthorization.decode(message.value);
    },
    toProto (message) {
        return TransferAuthorization.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.TransferAuthorization",
            value: TransferAuthorization.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(TransferAuthorization.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(TransferAuthorization.typeUrl, TransferAuthorization);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(TransferAuthorization.aminoType, TransferAuthorization.typeUrl);
        Allocation.registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/ack.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "IncentivizedAcknowledgement": (()=>IncentivizedAcknowledgement)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
function createBaseIncentivizedAcknowledgement() {
    return {
        appAcknowledgement: new Uint8Array(),
        forwardRelayerAddress: "",
        underlyingAppSuccess: false
    };
}
const IncentivizedAcknowledgement = {
    typeUrl: "/ibc.applications.fee.v1.IncentivizedAcknowledgement",
    aminoType: "cosmos-sdk/IncentivizedAcknowledgement",
    is (o) {
        return o && (o.$typeUrl === IncentivizedAcknowledgement.typeUrl || (o.appAcknowledgement instanceof Uint8Array || typeof o.appAcknowledgement === "string") && typeof o.forwardRelayerAddress === "string" && typeof o.underlyingAppSuccess === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === IncentivizedAcknowledgement.typeUrl || (o.app_acknowledgement instanceof Uint8Array || typeof o.app_acknowledgement === "string") && typeof o.forward_relayer_address === "string" && typeof o.underlying_app_success === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.appAcknowledgement.length !== 0) {
            writer.uint32(10).bytes(message.appAcknowledgement);
        }
        if (message.forwardRelayerAddress !== "") {
            writer.uint32(18).string(message.forwardRelayerAddress);
        }
        if (message.underlyingAppSuccess === true) {
            writer.uint32(24).bool(message.underlyingAppSuccess);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseIncentivizedAcknowledgement();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.appAcknowledgement = reader.bytes();
                    break;
                case 2:
                    message.forwardRelayerAddress = reader.string();
                    break;
                case 3:
                    message.underlyingAppSuccess = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseIncentivizedAcknowledgement();
        message.appAcknowledgement = object.appAcknowledgement ?? new Uint8Array();
        message.forwardRelayerAddress = object.forwardRelayerAddress ?? "";
        message.underlyingAppSuccess = object.underlyingAppSuccess ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseIncentivizedAcknowledgement();
        if (object.app_acknowledgement !== undefined && object.app_acknowledgement !== null) {
            message.appAcknowledgement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.app_acknowledgement);
        }
        if (object.forward_relayer_address !== undefined && object.forward_relayer_address !== null) {
            message.forwardRelayerAddress = object.forward_relayer_address;
        }
        if (object.underlying_app_success !== undefined && object.underlying_app_success !== null) {
            message.underlyingAppSuccess = object.underlying_app_success;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.app_acknowledgement = message.appAcknowledgement ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.appAcknowledgement) : undefined;
        obj.forward_relayer_address = message.forwardRelayerAddress === "" ? undefined : message.forwardRelayerAddress;
        obj.underlying_app_success = message.underlyingAppSuccess === false ? undefined : message.underlyingAppSuccess;
        return obj;
    },
    fromAminoMsg (object) {
        return IncentivizedAcknowledgement.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/IncentivizedAcknowledgement",
            value: IncentivizedAcknowledgement.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return IncentivizedAcknowledgement.decode(message.value);
    },
    toProto (message) {
        return IncentivizedAcknowledgement.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.IncentivizedAcknowledgement",
            value: IncentivizedAcknowledgement.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/fee.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Fee": (()=>Fee),
    "IdentifiedPacketFees": (()=>IdentifiedPacketFees),
    "PacketFee": (()=>PacketFee),
    "PacketFees": (()=>PacketFees)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseFee() {
    return {
        recvFee: [],
        ackFee: [],
        timeoutFee: []
    };
}
const Fee = {
    typeUrl: "/ibc.applications.fee.v1.Fee",
    aminoType: "cosmos-sdk/Fee",
    is (o) {
        return o && (o.$typeUrl === Fee.typeUrl || Array.isArray(o.recvFee) && (!o.recvFee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.recvFee[0])) && Array.isArray(o.ackFee) && (!o.ackFee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.ackFee[0])) && Array.isArray(o.timeoutFee) && (!o.timeoutFee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.timeoutFee[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Fee.typeUrl || Array.isArray(o.recv_fee) && (!o.recv_fee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.recv_fee[0])) && Array.isArray(o.ack_fee) && (!o.ack_fee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.ack_fee[0])) && Array.isArray(o.timeout_fee) && (!o.timeout_fee.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.timeout_fee[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.recvFee){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.ackFee){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.timeoutFee){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.recvFee.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.ackFee.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.timeoutFee.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFee();
        message.recvFee = object.recvFee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.ackFee = object.ackFee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.timeoutFee = object.timeoutFee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseFee();
        message.recvFee = object.recv_fee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.ackFee = object.ack_fee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.timeoutFee = object.timeout_fee?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.recvFee) {
            obj.recv_fee = message.recvFee.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.recv_fee = message.recvFee;
        }
        if (message.ackFee) {
            obj.ack_fee = message.ackFee.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.ack_fee = message.ackFee;
        }
        if (message.timeoutFee) {
            obj.timeout_fee = message.timeoutFee.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.timeout_fee = message.timeoutFee;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Fee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Fee",
            value: Fee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Fee.decode(message.value);
    },
    toProto (message) {
        return Fee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.Fee",
            value: Fee.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Fee.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBasePacketFee() {
    return {
        fee: Fee.fromPartial({}),
        refundAddress: "",
        relayers: []
    };
}
const PacketFee = {
    typeUrl: "/ibc.applications.fee.v1.PacketFee",
    aminoType: "cosmos-sdk/PacketFee",
    is (o) {
        return o && (o.$typeUrl === PacketFee.typeUrl || Fee.is(o.fee) && typeof o.refundAddress === "string" && Array.isArray(o.relayers) && (!o.relayers.length || typeof o.relayers[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === PacketFee.typeUrl || Fee.isAmino(o.fee) && typeof o.refund_address === "string" && Array.isArray(o.relayers) && (!o.relayers.length || typeof o.relayers[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.fee !== undefined) {
            Fee.encode(message.fee, writer.uint32(10).fork()).ldelim();
        }
        if (message.refundAddress !== "") {
            writer.uint32(18).string(message.refundAddress);
        }
        for (const v of message.relayers){
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePacketFee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.fee = Fee.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.refundAddress = reader.string();
                    break;
                case 3:
                    message.relayers.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePacketFee();
        message.fee = object.fee !== undefined && object.fee !== null ? Fee.fromPartial(object.fee) : undefined;
        message.refundAddress = object.refundAddress ?? "";
        message.relayers = object.relayers?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBasePacketFee();
        if (object.fee !== undefined && object.fee !== null) {
            message.fee = Fee.fromAmino(object.fee);
        }
        if (object.refund_address !== undefined && object.refund_address !== null) {
            message.refundAddress = object.refund_address;
        }
        message.relayers = object.relayers?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.fee = message.fee ? Fee.toAmino(message.fee) : undefined;
        obj.refund_address = message.refundAddress === "" ? undefined : message.refundAddress;
        if (message.relayers) {
            obj.relayers = message.relayers.map((e)=>e);
        } else {
            obj.relayers = message.relayers;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return PacketFee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/PacketFee",
            value: PacketFee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return PacketFee.decode(message.value);
    },
    toProto (message) {
        return PacketFee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.PacketFee",
            value: PacketFee.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(PacketFee.typeUrl)) {
            return;
        }
        Fee.registerTypeUrl();
    }
};
function createBasePacketFees() {
    return {
        packetFees: []
    };
}
const PacketFees = {
    typeUrl: "/ibc.applications.fee.v1.PacketFees",
    aminoType: "cosmos-sdk/PacketFees",
    is (o) {
        return o && (o.$typeUrl === PacketFees.typeUrl || Array.isArray(o.packetFees) && (!o.packetFees.length || PacketFee.is(o.packetFees[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === PacketFees.typeUrl || Array.isArray(o.packet_fees) && (!o.packet_fees.length || PacketFee.isAmino(o.packet_fees[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.packetFees){
            PacketFee.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePacketFees();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetFees.push(PacketFee.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePacketFees();
        message.packetFees = object.packetFees?.map((e)=>PacketFee.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBasePacketFees();
        message.packetFees = object.packet_fees?.map((e)=>PacketFee.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.packetFees) {
            obj.packet_fees = message.packetFees.map((e)=>e ? PacketFee.toAmino(e) : undefined);
        } else {
            obj.packet_fees = message.packetFees;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return PacketFees.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/PacketFees",
            value: PacketFees.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return PacketFees.decode(message.value);
    },
    toProto (message) {
        return PacketFees.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.PacketFees",
            value: PacketFees.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(PacketFees.typeUrl)) {
            return;
        }
        PacketFee.registerTypeUrl();
    }
};
function createBaseIdentifiedPacketFees() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({}),
        packetFees: []
    };
}
const IdentifiedPacketFees = {
    typeUrl: "/ibc.applications.fee.v1.IdentifiedPacketFees",
    aminoType: "cosmos-sdk/IdentifiedPacketFees",
    is (o) {
        return o && (o.$typeUrl === IdentifiedPacketFees.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId) && Array.isArray(o.packetFees) && (!o.packetFees.length || PacketFee.is(o.packetFees[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === IdentifiedPacketFees.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id) && Array.isArray(o.packet_fees) && (!o.packet_fees.length || PacketFee.isAmino(o.packet_fees[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.packetFees){
            PacketFee.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseIdentifiedPacketFees();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.packetFees.push(PacketFee.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseIdentifiedPacketFees();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        message.packetFees = object.packetFees?.map((e)=>PacketFee.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseIdentifiedPacketFees();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        message.packetFees = object.packet_fees?.map((e)=>PacketFee.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        if (message.packetFees) {
            obj.packet_fees = message.packetFees.map((e)=>e ? PacketFee.toAmino(e) : undefined);
        } else {
            obj.packet_fees = message.packetFees;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return IdentifiedPacketFees.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/IdentifiedPacketFees",
            value: IdentifiedPacketFees.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return IdentifiedPacketFees.decode(message.value);
    },
    toProto (message) {
        return IdentifiedPacketFees.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.IdentifiedPacketFees",
            value: IdentifiedPacketFees.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(IdentifiedPacketFees.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
        PacketFee.registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "FeeEnabledChannel": (()=>FeeEnabledChannel),
    "ForwardRelayerAddress": (()=>ForwardRelayerAddress),
    "GenesisState": (()=>GenesisState),
    "RegisteredCounterpartyPayee": (()=>RegisteredCounterpartyPayee),
    "RegisteredPayee": (()=>RegisteredPayee)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/fee.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseGenesisState() {
    return {
        identifiedFees: [],
        feeEnabledChannels: [],
        registeredPayees: [],
        registeredCounterpartyPayees: [],
        forwardRelayers: []
    };
}
const GenesisState = {
    typeUrl: "/ibc.applications.fee.v1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || Array.isArray(o.identifiedFees) && (!o.identifiedFees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].is(o.identifiedFees[0])) && Array.isArray(o.feeEnabledChannels) && (!o.feeEnabledChannels.length || FeeEnabledChannel.is(o.feeEnabledChannels[0])) && Array.isArray(o.registeredPayees) && (!o.registeredPayees.length || RegisteredPayee.is(o.registeredPayees[0])) && Array.isArray(o.registeredCounterpartyPayees) && (!o.registeredCounterpartyPayees.length || RegisteredCounterpartyPayee.is(o.registeredCounterpartyPayees[0])) && Array.isArray(o.forwardRelayers) && (!o.forwardRelayers.length || ForwardRelayerAddress.is(o.forwardRelayers[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || Array.isArray(o.identified_fees) && (!o.identified_fees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].isAmino(o.identified_fees[0])) && Array.isArray(o.fee_enabled_channels) && (!o.fee_enabled_channels.length || FeeEnabledChannel.isAmino(o.fee_enabled_channels[0])) && Array.isArray(o.registered_payees) && (!o.registered_payees.length || RegisteredPayee.isAmino(o.registered_payees[0])) && Array.isArray(o.registered_counterparty_payees) && (!o.registered_counterparty_payees.length || RegisteredCounterpartyPayee.isAmino(o.registered_counterparty_payees[0])) && Array.isArray(o.forward_relayers) && (!o.forward_relayers.length || ForwardRelayerAddress.isAmino(o.forward_relayers[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.identifiedFees){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.feeEnabledChannels){
            FeeEnabledChannel.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.registeredPayees){
            RegisteredPayee.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.registeredCounterpartyPayees){
            RegisteredCounterpartyPayee.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.forwardRelayers){
            ForwardRelayerAddress.encode(v, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.identifiedFees.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.feeEnabledChannels.push(FeeEnabledChannel.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.registeredPayees.push(RegisteredPayee.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.registeredCounterpartyPayees.push(RegisteredCounterpartyPayee.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.forwardRelayers.push(ForwardRelayerAddress.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.identifiedFees = object.identifiedFees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromPartial(e)) || [];
        message.feeEnabledChannels = object.feeEnabledChannels?.map((e)=>FeeEnabledChannel.fromPartial(e)) || [];
        message.registeredPayees = object.registeredPayees?.map((e)=>RegisteredPayee.fromPartial(e)) || [];
        message.registeredCounterpartyPayees = object.registeredCounterpartyPayees?.map((e)=>RegisteredCounterpartyPayee.fromPartial(e)) || [];
        message.forwardRelayers = object.forwardRelayers?.map((e)=>ForwardRelayerAddress.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        message.identifiedFees = object.identified_fees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromAmino(e)) || [];
        message.feeEnabledChannels = object.fee_enabled_channels?.map((e)=>FeeEnabledChannel.fromAmino(e)) || [];
        message.registeredPayees = object.registered_payees?.map((e)=>RegisteredPayee.fromAmino(e)) || [];
        message.registeredCounterpartyPayees = object.registered_counterparty_payees?.map((e)=>RegisteredCounterpartyPayee.fromAmino(e)) || [];
        message.forwardRelayers = object.forward_relayers?.map((e)=>ForwardRelayerAddress.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.identifiedFees) {
            obj.identified_fees = message.identifiedFees.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].toAmino(e) : undefined);
        } else {
            obj.identified_fees = message.identifiedFees;
        }
        if (message.feeEnabledChannels) {
            obj.fee_enabled_channels = message.feeEnabledChannels.map((e)=>e ? FeeEnabledChannel.toAmino(e) : undefined);
        } else {
            obj.fee_enabled_channels = message.feeEnabledChannels;
        }
        if (message.registeredPayees) {
            obj.registered_payees = message.registeredPayees.map((e)=>e ? RegisteredPayee.toAmino(e) : undefined);
        } else {
            obj.registered_payees = message.registeredPayees;
        }
        if (message.registeredCounterpartyPayees) {
            obj.registered_counterparty_payees = message.registeredCounterpartyPayees.map((e)=>e ? RegisteredCounterpartyPayee.toAmino(e) : undefined);
        } else {
            obj.registered_counterparty_payees = message.registeredCounterpartyPayees;
        }
        if (message.forwardRelayers) {
            obj.forward_relayers = message.forwardRelayers.map((e)=>e ? ForwardRelayerAddress.toAmino(e) : undefined);
        } else {
            obj.forward_relayers = message.forwardRelayers;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].registerTypeUrl();
        FeeEnabledChannel.registerTypeUrl();
        RegisteredPayee.registerTypeUrl();
        RegisteredCounterpartyPayee.registerTypeUrl();
        ForwardRelayerAddress.registerTypeUrl();
    }
};
function createBaseFeeEnabledChannel() {
    return {
        portId: "",
        channelId: ""
    };
}
const FeeEnabledChannel = {
    typeUrl: "/ibc.applications.fee.v1.FeeEnabledChannel",
    aminoType: "cosmos-sdk/FeeEnabledChannel",
    is (o) {
        return o && (o.$typeUrl === FeeEnabledChannel.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === FeeEnabledChannel.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFeeEnabledChannel();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFeeEnabledChannel();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseFeeEnabledChannel();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        return obj;
    },
    fromAminoMsg (object) {
        return FeeEnabledChannel.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/FeeEnabledChannel",
            value: FeeEnabledChannel.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return FeeEnabledChannel.decode(message.value);
    },
    toProto (message) {
        return FeeEnabledChannel.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.FeeEnabledChannel",
            value: FeeEnabledChannel.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseRegisteredPayee() {
    return {
        channelId: "",
        relayer: "",
        payee: ""
    };
}
const RegisteredPayee = {
    typeUrl: "/ibc.applications.fee.v1.RegisteredPayee",
    aminoType: "cosmos-sdk/RegisteredPayee",
    is (o) {
        return o && (o.$typeUrl === RegisteredPayee.typeUrl || typeof o.channelId === "string" && typeof o.relayer === "string" && typeof o.payee === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === RegisteredPayee.typeUrl || typeof o.channel_id === "string" && typeof o.relayer === "string" && typeof o.payee === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.channelId !== "") {
            writer.uint32(10).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(18).string(message.relayer);
        }
        if (message.payee !== "") {
            writer.uint32(26).string(message.payee);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRegisteredPayee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.channelId = reader.string();
                    break;
                case 2:
                    message.relayer = reader.string();
                    break;
                case 3:
                    message.payee = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRegisteredPayee();
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        message.payee = object.payee ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseRegisteredPayee();
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        if (object.payee !== undefined && object.payee !== null) {
            message.payee = object.payee;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        obj.payee = message.payee === "" ? undefined : message.payee;
        return obj;
    },
    fromAminoMsg (object) {
        return RegisteredPayee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RegisteredPayee",
            value: RegisteredPayee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RegisteredPayee.decode(message.value);
    },
    toProto (message) {
        return RegisteredPayee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.RegisteredPayee",
            value: RegisteredPayee.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseRegisteredCounterpartyPayee() {
    return {
        channelId: "",
        relayer: "",
        counterpartyPayee: ""
    };
}
const RegisteredCounterpartyPayee = {
    typeUrl: "/ibc.applications.fee.v1.RegisteredCounterpartyPayee",
    aminoType: "cosmos-sdk/RegisteredCounterpartyPayee",
    is (o) {
        return o && (o.$typeUrl === RegisteredCounterpartyPayee.typeUrl || typeof o.channelId === "string" && typeof o.relayer === "string" && typeof o.counterpartyPayee === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === RegisteredCounterpartyPayee.typeUrl || typeof o.channel_id === "string" && typeof o.relayer === "string" && typeof o.counterparty_payee === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.channelId !== "") {
            writer.uint32(10).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(18).string(message.relayer);
        }
        if (message.counterpartyPayee !== "") {
            writer.uint32(26).string(message.counterpartyPayee);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRegisteredCounterpartyPayee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.channelId = reader.string();
                    break;
                case 2:
                    message.relayer = reader.string();
                    break;
                case 3:
                    message.counterpartyPayee = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRegisteredCounterpartyPayee();
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        message.counterpartyPayee = object.counterpartyPayee ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseRegisteredCounterpartyPayee();
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        if (object.counterparty_payee !== undefined && object.counterparty_payee !== null) {
            message.counterpartyPayee = object.counterparty_payee;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        obj.counterparty_payee = message.counterpartyPayee === "" ? undefined : message.counterpartyPayee;
        return obj;
    },
    fromAminoMsg (object) {
        return RegisteredCounterpartyPayee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RegisteredCounterpartyPayee",
            value: RegisteredCounterpartyPayee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RegisteredCounterpartyPayee.decode(message.value);
    },
    toProto (message) {
        return RegisteredCounterpartyPayee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.RegisteredCounterpartyPayee",
            value: RegisteredCounterpartyPayee.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseForwardRelayerAddress() {
    return {
        address: "",
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({})
    };
}
const ForwardRelayerAddress = {
    typeUrl: "/ibc.applications.fee.v1.ForwardRelayerAddress",
    aminoType: "cosmos-sdk/ForwardRelayerAddress",
    is (o) {
        return o && (o.$typeUrl === ForwardRelayerAddress.typeUrl || typeof o.address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ForwardRelayerAddress.typeUrl || typeof o.address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseForwardRelayerAddress();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseForwardRelayerAddress();
        message.address = object.address ?? "";
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseForwardRelayerAddress();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ForwardRelayerAddress.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ForwardRelayerAddress",
            value: ForwardRelayerAddress.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ForwardRelayerAddress.decode(message.value);
    },
    toProto (message) {
        return ForwardRelayerAddress.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.ForwardRelayerAddress",
            value: ForwardRelayerAddress.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ForwardRelayerAddress.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/metadata.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Metadata": (()=>Metadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseMetadata() {
    return {
        feeVersion: "",
        appVersion: ""
    };
}
const Metadata = {
    typeUrl: "/ibc.applications.fee.v1.Metadata",
    aminoType: "cosmos-sdk/Metadata",
    is (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.feeVersion === "string" && typeof o.appVersion === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.fee_version === "string" && typeof o.app_version === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.feeVersion !== "") {
            writer.uint32(10).string(message.feeVersion);
        }
        if (message.appVersion !== "") {
            writer.uint32(18).string(message.appVersion);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetadata();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.feeVersion = reader.string();
                    break;
                case 2:
                    message.appVersion = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMetadata();
        message.feeVersion = object.feeVersion ?? "";
        message.appVersion = object.appVersion ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMetadata();
        if (object.fee_version !== undefined && object.fee_version !== null) {
            message.feeVersion = object.fee_version;
        }
        if (object.app_version !== undefined && object.app_version !== null) {
            message.appVersion = object.app_version;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.fee_version = message.feeVersion === "" ? undefined : message.feeVersion;
        obj.app_version = message.appVersion === "" ? undefined : message.appVersion;
        return obj;
    },
    fromAminoMsg (object) {
        return Metadata.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Metadata",
            value: Metadata.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Metadata.decode(message.value);
    },
    toProto (message) {
        return Metadata.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.Metadata",
            value: Metadata.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryCounterpartyPayeeRequest": (()=>QueryCounterpartyPayeeRequest),
    "QueryCounterpartyPayeeResponse": (()=>QueryCounterpartyPayeeResponse),
    "QueryFeeEnabledChannelRequest": (()=>QueryFeeEnabledChannelRequest),
    "QueryFeeEnabledChannelResponse": (()=>QueryFeeEnabledChannelResponse),
    "QueryFeeEnabledChannelsRequest": (()=>QueryFeeEnabledChannelsRequest),
    "QueryFeeEnabledChannelsResponse": (()=>QueryFeeEnabledChannelsResponse),
    "QueryIncentivizedPacketRequest": (()=>QueryIncentivizedPacketRequest),
    "QueryIncentivizedPacketResponse": (()=>QueryIncentivizedPacketResponse),
    "QueryIncentivizedPacketsForChannelRequest": (()=>QueryIncentivizedPacketsForChannelRequest),
    "QueryIncentivizedPacketsForChannelResponse": (()=>QueryIncentivizedPacketsForChannelResponse),
    "QueryIncentivizedPacketsRequest": (()=>QueryIncentivizedPacketsRequest),
    "QueryIncentivizedPacketsResponse": (()=>QueryIncentivizedPacketsResponse),
    "QueryPayeeRequest": (()=>QueryPayeeRequest),
    "QueryPayeeResponse": (()=>QueryPayeeResponse),
    "QueryTotalAckFeesRequest": (()=>QueryTotalAckFeesRequest),
    "QueryTotalAckFeesResponse": (()=>QueryTotalAckFeesResponse),
    "QueryTotalRecvFeesRequest": (()=>QueryTotalRecvFeesRequest),
    "QueryTotalRecvFeesResponse": (()=>QueryTotalRecvFeesResponse),
    "QueryTotalTimeoutFeesRequest": (()=>QueryTotalTimeoutFeesRequest),
    "QueryTotalTimeoutFeesResponse": (()=>QueryTotalTimeoutFeesResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/fee.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/genesis.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function createBaseQueryIncentivizedPacketsRequest() {
    return {
        pagination: undefined,
        queryHeight: BigInt(0)
    };
}
const QueryIncentivizedPacketsRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsRequest",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsRequest.typeUrl || typeof o.queryHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsRequest.typeUrl || typeof o.query_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        if (message.queryHeight !== BigInt(0)) {
            writer.uint32(16).uint64(message.queryHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.queryHeight = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketsRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        message.queryHeight = object.queryHeight !== undefined && object.queryHeight !== null ? BigInt(object.queryHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketsRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        if (object.query_height !== undefined && object.query_height !== null) {
            message.queryHeight = BigInt(object.query_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        obj.query_height = message.queryHeight !== BigInt(0) ? message.queryHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketsRequest",
            value: QueryIncentivizedPacketsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsRequest",
            value: QueryIncentivizedPacketsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryIncentivizedPacketsResponse() {
    return {
        incentivizedPackets: [],
        pagination: undefined
    };
}
const QueryIncentivizedPacketsResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsResponse",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsResponse.typeUrl || Array.isArray(o.incentivizedPackets) && (!o.incentivizedPackets.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].is(o.incentivizedPackets[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsResponse.typeUrl || Array.isArray(o.incentivized_packets) && (!o.incentivized_packets.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].isAmino(o.incentivized_packets[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.incentivizedPackets){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.incentivizedPackets.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketsResponse();
        message.incentivizedPackets = object.incentivizedPackets?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketsResponse();
        message.incentivizedPackets = object.incentivized_packets?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.incentivizedPackets) {
            obj.incentivized_packets = message.incentivizedPackets.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].toAmino(e) : undefined);
        } else {
            obj.incentivized_packets = message.incentivizedPackets;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketsResponse",
            value: QueryIncentivizedPacketsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsResponse",
            value: QueryIncentivizedPacketsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryIncentivizedPacketRequest() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({}),
        queryHeight: BigInt(0)
    };
}
const QueryIncentivizedPacketRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketRequest",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketRequest",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId) && typeof o.queryHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id) && typeof o.query_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        if (message.queryHeight !== BigInt(0)) {
            writer.uint32(16).uint64(message.queryHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.queryHeight = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketRequest();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        message.queryHeight = object.queryHeight !== undefined && object.queryHeight !== null ? BigInt(object.queryHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketRequest();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        if (object.query_height !== undefined && object.query_height !== null) {
            message.queryHeight = BigInt(object.query_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        obj.query_height = message.queryHeight !== BigInt(0) ? message.queryHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketRequest",
            value: QueryIncentivizedPacketRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketRequest.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketRequest",
            value: QueryIncentivizedPacketRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
    }
};
function createBaseQueryIncentivizedPacketResponse() {
    return {
        incentivizedPacket: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromPartial({})
    };
}
const QueryIncentivizedPacketResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketResponse",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketResponse",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].is(o.incentivizedPacket));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].isAmino(o.incentivized_packet));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.incentivizedPacket !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].encode(message.incentivizedPacket, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.incentivizedPacket = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketResponse();
        message.incentivizedPacket = object.incentivizedPacket !== undefined && object.incentivizedPacket !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromPartial(object.incentivizedPacket) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketResponse();
        if (object.incentivized_packet !== undefined && object.incentivized_packet !== null) {
            message.incentivizedPacket = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromAmino(object.incentivized_packet);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.incentivized_packet = message.incentivizedPacket ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].toAmino(message.incentivizedPacket) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketResponse",
            value: QueryIncentivizedPacketResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketResponse.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketResponse",
            value: QueryIncentivizedPacketResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].registerTypeUrl();
    }
};
function createBaseQueryIncentivizedPacketsForChannelRequest() {
    return {
        pagination: undefined,
        portId: "",
        channelId: "",
        queryHeight: BigInt(0)
    };
}
const QueryIncentivizedPacketsForChannelRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsForChannelRequest",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketsForChannelRequest",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsForChannelRequest.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string" && typeof o.queryHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsForChannelRequest.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string" && typeof o.query_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        if (message.portId !== "") {
            writer.uint32(18).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(26).string(message.channelId);
        }
        if (message.queryHeight !== BigInt(0)) {
            writer.uint32(32).uint64(message.queryHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketsForChannelRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.portId = reader.string();
                    break;
                case 3:
                    message.channelId = reader.string();
                    break;
                case 4:
                    message.queryHeight = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketsForChannelRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        message.queryHeight = object.queryHeight !== undefined && object.queryHeight !== null ? BigInt(object.queryHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketsForChannelRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.query_height !== undefined && object.query_height !== null) {
            message.queryHeight = BigInt(object.query_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.query_height = message.queryHeight !== BigInt(0) ? message.queryHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketsForChannelRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketsForChannelRequest",
            value: QueryIncentivizedPacketsForChannelRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketsForChannelRequest.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketsForChannelRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsForChannelRequest",
            value: QueryIncentivizedPacketsForChannelRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketsForChannelRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryIncentivizedPacketsForChannelResponse() {
    return {
        incentivizedPackets: [],
        pagination: undefined
    };
}
const QueryIncentivizedPacketsForChannelResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsForChannelResponse",
    aminoType: "cosmos-sdk/QueryIncentivizedPacketsForChannelResponse",
    is (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsForChannelResponse.typeUrl || Array.isArray(o.incentivizedPackets) && (!o.incentivizedPackets.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].is(o.incentivizedPackets[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryIncentivizedPacketsForChannelResponse.typeUrl || Array.isArray(o.incentivized_packets) && (!o.incentivized_packets.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].isAmino(o.incentivized_packets[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.incentivizedPackets){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryIncentivizedPacketsForChannelResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.incentivizedPackets.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryIncentivizedPacketsForChannelResponse();
        message.incentivizedPackets = object.incentivizedPackets?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryIncentivizedPacketsForChannelResponse();
        message.incentivizedPackets = object.incentivized_packets?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.incentivizedPackets) {
            obj.incentivized_packets = message.incentivizedPackets.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].toAmino(e) : undefined);
        } else {
            obj.incentivized_packets = message.incentivizedPackets;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryIncentivizedPacketsForChannelResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryIncentivizedPacketsForChannelResponse",
            value: QueryIncentivizedPacketsForChannelResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryIncentivizedPacketsForChannelResponse.decode(message.value);
    },
    toProto (message) {
        return QueryIncentivizedPacketsForChannelResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryIncentivizedPacketsForChannelResponse",
            value: QueryIncentivizedPacketsForChannelResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryIncentivizedPacketsForChannelResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IdentifiedPacketFees"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryTotalRecvFeesRequest() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({})
    };
}
const QueryTotalRecvFeesRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalRecvFeesRequest",
    aminoType: "cosmos-sdk/QueryTotalRecvFeesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTotalRecvFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalRecvFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalRecvFeesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalRecvFeesRequest();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalRecvFeesRequest();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalRecvFeesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalRecvFeesRequest",
            value: QueryTotalRecvFeesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalRecvFeesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTotalRecvFeesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalRecvFeesRequest",
            value: QueryTotalRecvFeesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalRecvFeesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
    }
};
function createBaseQueryTotalRecvFeesResponse() {
    return {
        recvFees: []
    };
}
const QueryTotalRecvFeesResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalRecvFeesResponse",
    aminoType: "cosmos-sdk/QueryTotalRecvFeesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTotalRecvFeesResponse.typeUrl || Array.isArray(o.recvFees) && (!o.recvFees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.recvFees[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalRecvFeesResponse.typeUrl || Array.isArray(o.recv_fees) && (!o.recv_fees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.recv_fees[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.recvFees){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalRecvFeesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.recvFees.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalRecvFeesResponse();
        message.recvFees = object.recvFees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalRecvFeesResponse();
        message.recvFees = object.recv_fees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.recvFees) {
            obj.recv_fees = message.recvFees.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.recv_fees = message.recvFees;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalRecvFeesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalRecvFeesResponse",
            value: QueryTotalRecvFeesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalRecvFeesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTotalRecvFeesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalRecvFeesResponse",
            value: QueryTotalRecvFeesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalRecvFeesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryTotalAckFeesRequest() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({})
    };
}
const QueryTotalAckFeesRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalAckFeesRequest",
    aminoType: "cosmos-sdk/QueryTotalAckFeesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTotalAckFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalAckFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalAckFeesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalAckFeesRequest();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalAckFeesRequest();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalAckFeesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalAckFeesRequest",
            value: QueryTotalAckFeesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalAckFeesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTotalAckFeesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalAckFeesRequest",
            value: QueryTotalAckFeesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalAckFeesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
    }
};
function createBaseQueryTotalAckFeesResponse() {
    return {
        ackFees: []
    };
}
const QueryTotalAckFeesResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalAckFeesResponse",
    aminoType: "cosmos-sdk/QueryTotalAckFeesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTotalAckFeesResponse.typeUrl || Array.isArray(o.ackFees) && (!o.ackFees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.ackFees[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalAckFeesResponse.typeUrl || Array.isArray(o.ack_fees) && (!o.ack_fees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.ack_fees[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.ackFees){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalAckFeesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.ackFees.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalAckFeesResponse();
        message.ackFees = object.ackFees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalAckFeesResponse();
        message.ackFees = object.ack_fees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.ackFees) {
            obj.ack_fees = message.ackFees.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.ack_fees = message.ackFees;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalAckFeesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalAckFeesResponse",
            value: QueryTotalAckFeesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalAckFeesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTotalAckFeesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalAckFeesResponse",
            value: QueryTotalAckFeesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalAckFeesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryTotalTimeoutFeesRequest() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({})
    };
}
const QueryTotalTimeoutFeesRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalTimeoutFeesRequest",
    aminoType: "cosmos-sdk/QueryTotalTimeoutFeesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTotalTimeoutFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalTimeoutFeesRequest.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalTimeoutFeesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalTimeoutFeesRequest();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalTimeoutFeesRequest();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalTimeoutFeesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalTimeoutFeesRequest",
            value: QueryTotalTimeoutFeesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalTimeoutFeesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTotalTimeoutFeesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalTimeoutFeesRequest",
            value: QueryTotalTimeoutFeesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalTimeoutFeesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
    }
};
function createBaseQueryTotalTimeoutFeesResponse() {
    return {
        timeoutFees: []
    };
}
const QueryTotalTimeoutFeesResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryTotalTimeoutFeesResponse",
    aminoType: "cosmos-sdk/QueryTotalTimeoutFeesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTotalTimeoutFeesResponse.typeUrl || Array.isArray(o.timeoutFees) && (!o.timeoutFees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.timeoutFees[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalTimeoutFeesResponse.typeUrl || Array.isArray(o.timeout_fees) && (!o.timeout_fees.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.timeout_fees[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.timeoutFees){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalTimeoutFeesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.timeoutFees.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalTimeoutFeesResponse();
        message.timeoutFees = object.timeoutFees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalTimeoutFeesResponse();
        message.timeoutFees = object.timeout_fees?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.timeoutFees) {
            obj.timeout_fees = message.timeoutFees.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.timeout_fees = message.timeoutFees;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalTimeoutFeesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalTimeoutFeesResponse",
            value: QueryTotalTimeoutFeesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalTimeoutFeesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTotalTimeoutFeesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryTotalTimeoutFeesResponse",
            value: QueryTotalTimeoutFeesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalTimeoutFeesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryPayeeRequest() {
    return {
        channelId: "",
        relayer: ""
    };
}
const QueryPayeeRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryPayeeRequest",
    aminoType: "cosmos-sdk/QueryPayeeRequest",
    is (o) {
        return o && (o.$typeUrl === QueryPayeeRequest.typeUrl || typeof o.channelId === "string" && typeof o.relayer === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryPayeeRequest.typeUrl || typeof o.channel_id === "string" && typeof o.relayer === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.channelId !== "") {
            writer.uint32(10).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(18).string(message.relayer);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryPayeeRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.channelId = reader.string();
                    break;
                case 2:
                    message.relayer = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryPayeeRequest();
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryPayeeRequest();
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryPayeeRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryPayeeRequest",
            value: QueryPayeeRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryPayeeRequest.decode(message.value);
    },
    toProto (message) {
        return QueryPayeeRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryPayeeRequest",
            value: QueryPayeeRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryPayeeResponse() {
    return {
        payeeAddress: ""
    };
}
const QueryPayeeResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryPayeeResponse",
    aminoType: "cosmos-sdk/QueryPayeeResponse",
    is (o) {
        return o && (o.$typeUrl === QueryPayeeResponse.typeUrl || typeof o.payeeAddress === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryPayeeResponse.typeUrl || typeof o.payee_address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.payeeAddress !== "") {
            writer.uint32(10).string(message.payeeAddress);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryPayeeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.payeeAddress = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryPayeeResponse();
        message.payeeAddress = object.payeeAddress ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryPayeeResponse();
        if (object.payee_address !== undefined && object.payee_address !== null) {
            message.payeeAddress = object.payee_address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.payee_address = message.payeeAddress === "" ? undefined : message.payeeAddress;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryPayeeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryPayeeResponse",
            value: QueryPayeeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryPayeeResponse.decode(message.value);
    },
    toProto (message) {
        return QueryPayeeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryPayeeResponse",
            value: QueryPayeeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryCounterpartyPayeeRequest() {
    return {
        channelId: "",
        relayer: ""
    };
}
const QueryCounterpartyPayeeRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryCounterpartyPayeeRequest",
    aminoType: "cosmos-sdk/QueryCounterpartyPayeeRequest",
    is (o) {
        return o && (o.$typeUrl === QueryCounterpartyPayeeRequest.typeUrl || typeof o.channelId === "string" && typeof o.relayer === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryCounterpartyPayeeRequest.typeUrl || typeof o.channel_id === "string" && typeof o.relayer === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.channelId !== "") {
            writer.uint32(10).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(18).string(message.relayer);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryCounterpartyPayeeRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.channelId = reader.string();
                    break;
                case 2:
                    message.relayer = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryCounterpartyPayeeRequest();
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryCounterpartyPayeeRequest();
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryCounterpartyPayeeRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryCounterpartyPayeeRequest",
            value: QueryCounterpartyPayeeRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryCounterpartyPayeeRequest.decode(message.value);
    },
    toProto (message) {
        return QueryCounterpartyPayeeRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryCounterpartyPayeeRequest",
            value: QueryCounterpartyPayeeRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryCounterpartyPayeeResponse() {
    return {
        counterpartyPayee: ""
    };
}
const QueryCounterpartyPayeeResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryCounterpartyPayeeResponse",
    aminoType: "cosmos-sdk/QueryCounterpartyPayeeResponse",
    is (o) {
        return o && (o.$typeUrl === QueryCounterpartyPayeeResponse.typeUrl || typeof o.counterpartyPayee === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryCounterpartyPayeeResponse.typeUrl || typeof o.counterparty_payee === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.counterpartyPayee !== "") {
            writer.uint32(10).string(message.counterpartyPayee);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryCounterpartyPayeeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.counterpartyPayee = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryCounterpartyPayeeResponse();
        message.counterpartyPayee = object.counterpartyPayee ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryCounterpartyPayeeResponse();
        if (object.counterparty_payee !== undefined && object.counterparty_payee !== null) {
            message.counterpartyPayee = object.counterparty_payee;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.counterparty_payee = message.counterpartyPayee === "" ? undefined : message.counterpartyPayee;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryCounterpartyPayeeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryCounterpartyPayeeResponse",
            value: QueryCounterpartyPayeeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryCounterpartyPayeeResponse.decode(message.value);
    },
    toProto (message) {
        return QueryCounterpartyPayeeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryCounterpartyPayeeResponse",
            value: QueryCounterpartyPayeeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryFeeEnabledChannelsRequest() {
    return {
        pagination: undefined,
        queryHeight: BigInt(0)
    };
}
const QueryFeeEnabledChannelsRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelsRequest",
    aminoType: "cosmos-sdk/QueryFeeEnabledChannelsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelsRequest.typeUrl || typeof o.queryHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelsRequest.typeUrl || typeof o.query_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        if (message.queryHeight !== BigInt(0)) {
            writer.uint32(16).uint64(message.queryHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryFeeEnabledChannelsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.queryHeight = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryFeeEnabledChannelsRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        message.queryHeight = object.queryHeight !== undefined && object.queryHeight !== null ? BigInt(object.queryHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryFeeEnabledChannelsRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        if (object.query_height !== undefined && object.query_height !== null) {
            message.queryHeight = BigInt(object.query_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        obj.query_height = message.queryHeight !== BigInt(0) ? message.queryHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryFeeEnabledChannelsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryFeeEnabledChannelsRequest",
            value: QueryFeeEnabledChannelsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryFeeEnabledChannelsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryFeeEnabledChannelsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelsRequest",
            value: QueryFeeEnabledChannelsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryFeeEnabledChannelsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryFeeEnabledChannelsResponse() {
    return {
        feeEnabledChannels: [],
        pagination: undefined
    };
}
const QueryFeeEnabledChannelsResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelsResponse",
    aminoType: "cosmos-sdk/QueryFeeEnabledChannelsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelsResponse.typeUrl || Array.isArray(o.feeEnabledChannels) && (!o.feeEnabledChannels.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].is(o.feeEnabledChannels[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelsResponse.typeUrl || Array.isArray(o.fee_enabled_channels) && (!o.fee_enabled_channels.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].isAmino(o.fee_enabled_channels[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.feeEnabledChannels){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryFeeEnabledChannelsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.feeEnabledChannels.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryFeeEnabledChannelsResponse();
        message.feeEnabledChannels = object.feeEnabledChannels?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryFeeEnabledChannelsResponse();
        message.feeEnabledChannels = object.fee_enabled_channels?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.feeEnabledChannels) {
            obj.fee_enabled_channels = message.feeEnabledChannels.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].toAmino(e) : undefined);
        } else {
            obj.fee_enabled_channels = message.feeEnabledChannels;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryFeeEnabledChannelsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryFeeEnabledChannelsResponse",
            value: QueryFeeEnabledChannelsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryFeeEnabledChannelsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryFeeEnabledChannelsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelsResponse",
            value: QueryFeeEnabledChannelsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryFeeEnabledChannelsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$genesis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FeeEnabledChannel"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryFeeEnabledChannelRequest() {
    return {
        portId: "",
        channelId: ""
    };
}
const QueryFeeEnabledChannelRequest = {
    typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelRequest",
    aminoType: "cosmos-sdk/QueryFeeEnabledChannelRequest",
    is (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelRequest.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelRequest.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryFeeEnabledChannelRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryFeeEnabledChannelRequest();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryFeeEnabledChannelRequest();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryFeeEnabledChannelRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryFeeEnabledChannelRequest",
            value: QueryFeeEnabledChannelRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryFeeEnabledChannelRequest.decode(message.value);
    },
    toProto (message) {
        return QueryFeeEnabledChannelRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelRequest",
            value: QueryFeeEnabledChannelRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryFeeEnabledChannelResponse() {
    return {
        feeEnabled: false
    };
}
const QueryFeeEnabledChannelResponse = {
    typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelResponse",
    aminoType: "cosmos-sdk/QueryFeeEnabledChannelResponse",
    is (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelResponse.typeUrl || typeof o.feeEnabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryFeeEnabledChannelResponse.typeUrl || typeof o.fee_enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.feeEnabled === true) {
            writer.uint32(8).bool(message.feeEnabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryFeeEnabledChannelResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.feeEnabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryFeeEnabledChannelResponse();
        message.feeEnabled = object.feeEnabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryFeeEnabledChannelResponse();
        if (object.fee_enabled !== undefined && object.fee_enabled !== null) {
            message.feeEnabled = object.fee_enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.fee_enabled = message.feeEnabled === false ? undefined : message.feeEnabled;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryFeeEnabledChannelResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryFeeEnabledChannelResponse",
            value: QueryFeeEnabledChannelResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryFeeEnabledChannelResponse.decode(message.value);
    },
    toProto (message) {
        return QueryFeeEnabledChannelResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.QueryFeeEnabledChannelResponse",
            value: QueryFeeEnabledChannelResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgPayPacketFee": (()=>MsgPayPacketFee),
    "MsgPayPacketFeeAsync": (()=>MsgPayPacketFeeAsync),
    "MsgPayPacketFeeAsyncResponse": (()=>MsgPayPacketFeeAsyncResponse),
    "MsgPayPacketFeeResponse": (()=>MsgPayPacketFeeResponse),
    "MsgRegisterCounterpartyPayee": (()=>MsgRegisterCounterpartyPayee),
    "MsgRegisterCounterpartyPayeeResponse": (()=>MsgRegisterCounterpartyPayeeResponse),
    "MsgRegisterPayee": (()=>MsgRegisterPayee),
    "MsgRegisterPayeeResponse": (()=>MsgRegisterPayeeResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/fee.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseMsgRegisterPayee() {
    return {
        portId: "",
        channelId: "",
        relayer: "",
        payee: ""
    };
}
const MsgRegisterPayee = {
    typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayee",
    aminoType: "cosmos-sdk/MsgRegisterPayee",
    is (o) {
        return o && (o.$typeUrl === MsgRegisterPayee.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string" && typeof o.relayer === "string" && typeof o.payee === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgRegisterPayee.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string" && typeof o.relayer === "string" && typeof o.payee === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(26).string(message.relayer);
        }
        if (message.payee !== "") {
            writer.uint32(34).string(message.payee);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterPayee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                case 3:
                    message.relayer = reader.string();
                    break;
                case 4:
                    message.payee = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgRegisterPayee();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        message.payee = object.payee ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgRegisterPayee();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        if (object.payee !== undefined && object.payee !== null) {
            message.payee = object.payee;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        obj.payee = message.payee === "" ? undefined : message.payee;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterPayee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterPayee",
            value: MsgRegisterPayee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterPayee.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterPayee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayee",
            value: MsgRegisterPayee.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRegisterPayeeResponse() {
    return {};
}
const MsgRegisterPayeeResponse = {
    typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayeeResponse",
    aminoType: "cosmos-sdk/MsgRegisterPayeeResponse",
    is (o) {
        return o && o.$typeUrl === MsgRegisterPayeeResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgRegisterPayeeResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterPayeeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgRegisterPayeeResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgRegisterPayeeResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterPayeeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterPayeeResponse",
            value: MsgRegisterPayeeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterPayeeResponse.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterPayeeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayeeResponse",
            value: MsgRegisterPayeeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRegisterCounterpartyPayee() {
    return {
        portId: "",
        channelId: "",
        relayer: "",
        counterpartyPayee: ""
    };
}
const MsgRegisterCounterpartyPayee = {
    typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
    aminoType: "cosmos-sdk/MsgRegisterCounterpartyPayee",
    is (o) {
        return o && (o.$typeUrl === MsgRegisterCounterpartyPayee.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string" && typeof o.relayer === "string" && typeof o.counterpartyPayee === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgRegisterCounterpartyPayee.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string" && typeof o.relayer === "string" && typeof o.counterparty_payee === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        if (message.relayer !== "") {
            writer.uint32(26).string(message.relayer);
        }
        if (message.counterpartyPayee !== "") {
            writer.uint32(34).string(message.counterpartyPayee);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterCounterpartyPayee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                case 3:
                    message.relayer = reader.string();
                    break;
                case 4:
                    message.counterpartyPayee = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgRegisterCounterpartyPayee();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        message.relayer = object.relayer ?? "";
        message.counterpartyPayee = object.counterpartyPayee ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgRegisterCounterpartyPayee();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.relayer !== undefined && object.relayer !== null) {
            message.relayer = object.relayer;
        }
        if (object.counterparty_payee !== undefined && object.counterparty_payee !== null) {
            message.counterpartyPayee = object.counterparty_payee;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.relayer = message.relayer === "" ? undefined : message.relayer;
        obj.counterparty_payee = message.counterpartyPayee === "" ? undefined : message.counterpartyPayee;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterCounterpartyPayee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterCounterpartyPayee",
            value: MsgRegisterCounterpartyPayee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterCounterpartyPayee.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterCounterpartyPayee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
            value: MsgRegisterCounterpartyPayee.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRegisterCounterpartyPayeeResponse() {
    return {};
}
const MsgRegisterCounterpartyPayeeResponse = {
    typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayeeResponse",
    aminoType: "cosmos-sdk/MsgRegisterCounterpartyPayeeResponse",
    is (o) {
        return o && o.$typeUrl === MsgRegisterCounterpartyPayeeResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgRegisterCounterpartyPayeeResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterCounterpartyPayeeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgRegisterCounterpartyPayeeResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgRegisterCounterpartyPayeeResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterCounterpartyPayeeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterCounterpartyPayeeResponse",
            value: MsgRegisterCounterpartyPayeeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterCounterpartyPayeeResponse.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterCounterpartyPayeeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayeeResponse",
            value: MsgRegisterCounterpartyPayeeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgPayPacketFee() {
    return {
        fee: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].fromPartial({}),
        sourcePortId: "",
        sourceChannelId: "",
        signer: "",
        relayers: []
    };
}
const MsgPayPacketFee = {
    typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFee",
    aminoType: "cosmos-sdk/MsgPayPacketFee",
    is (o) {
        return o && (o.$typeUrl === MsgPayPacketFee.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].is(o.fee) && typeof o.sourcePortId === "string" && typeof o.sourceChannelId === "string" && typeof o.signer === "string" && Array.isArray(o.relayers) && (!o.relayers.length || typeof o.relayers[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgPayPacketFee.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].isAmino(o.fee) && typeof o.source_port_id === "string" && typeof o.source_channel_id === "string" && typeof o.signer === "string" && Array.isArray(o.relayers) && (!o.relayers.length || typeof o.relayers[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.fee !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].encode(message.fee, writer.uint32(10).fork()).ldelim();
        }
        if (message.sourcePortId !== "") {
            writer.uint32(18).string(message.sourcePortId);
        }
        if (message.sourceChannelId !== "") {
            writer.uint32(26).string(message.sourceChannelId);
        }
        if (message.signer !== "") {
            writer.uint32(34).string(message.signer);
        }
        for (const v of message.relayers){
            writer.uint32(42).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgPayPacketFee();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.fee = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.sourcePortId = reader.string();
                    break;
                case 3:
                    message.sourceChannelId = reader.string();
                    break;
                case 4:
                    message.signer = reader.string();
                    break;
                case 5:
                    message.relayers.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgPayPacketFee();
        message.fee = object.fee !== undefined && object.fee !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].fromPartial(object.fee) : undefined;
        message.sourcePortId = object.sourcePortId ?? "";
        message.sourceChannelId = object.sourceChannelId ?? "";
        message.signer = object.signer ?? "";
        message.relayers = object.relayers?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgPayPacketFee();
        if (object.fee !== undefined && object.fee !== null) {
            message.fee = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].fromAmino(object.fee);
        }
        if (object.source_port_id !== undefined && object.source_port_id !== null) {
            message.sourcePortId = object.source_port_id;
        }
        if (object.source_channel_id !== undefined && object.source_channel_id !== null) {
            message.sourceChannelId = object.source_channel_id;
        }
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        message.relayers = object.relayers?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.fee = message.fee ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].toAmino(message.fee) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].fromPartial({}));
        obj.source_port_id = message.sourcePortId === "" ? undefined : message.sourcePortId;
        obj.source_channel_id = message.sourceChannelId === "" ? undefined : message.sourceChannelId;
        obj.signer = message.signer === "" ? undefined : message.signer;
        if (message.relayers) {
            obj.relayers = message.relayers.map((e)=>e);
        } else {
            obj.relayers = message.relayers;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgPayPacketFee.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgPayPacketFee",
            value: MsgPayPacketFee.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgPayPacketFee.decode(message.value);
    },
    toProto (message) {
        return MsgPayPacketFee.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFee",
            value: MsgPayPacketFee.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgPayPacketFee.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fee"].registerTypeUrl();
    }
};
function createBaseMsgPayPacketFeeResponse() {
    return {};
}
const MsgPayPacketFeeResponse = {
    typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeResponse",
    aminoType: "cosmos-sdk/MsgPayPacketFeeResponse",
    is (o) {
        return o && o.$typeUrl === MsgPayPacketFeeResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgPayPacketFeeResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgPayPacketFeeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgPayPacketFeeResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgPayPacketFeeResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgPayPacketFeeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgPayPacketFeeResponse",
            value: MsgPayPacketFeeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgPayPacketFeeResponse.decode(message.value);
    },
    toProto (message) {
        return MsgPayPacketFeeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeResponse",
            value: MsgPayPacketFeeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgPayPacketFeeAsync() {
    return {
        packetId: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({}),
        packetFee: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].fromPartial({})
    };
}
const MsgPayPacketFeeAsync = {
    typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
    aminoType: "cosmos-sdk/MsgPayPacketFeeAsync",
    is (o) {
        return o && (o.$typeUrl === MsgPayPacketFeeAsync.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.packetId) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].is(o.packetFee));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgPayPacketFeeAsync.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.packet_id) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].isAmino(o.packet_fee));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.packetId !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.packetId, writer.uint32(10).fork()).ldelim();
        }
        if (message.packetFee !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].encode(message.packetFee, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgPayPacketFeeAsync();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.packetFee = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgPayPacketFeeAsync();
        message.packetId = object.packetId !== undefined && object.packetId !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.packetId) : undefined;
        message.packetFee = object.packetFee !== undefined && object.packetFee !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].fromPartial(object.packetFee) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgPayPacketFeeAsync();
        if (object.packet_id !== undefined && object.packet_id !== null) {
            message.packetId = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.packet_id);
        }
        if (object.packet_fee !== undefined && object.packet_fee !== null) {
            message.packetFee = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].fromAmino(object.packet_fee);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.packet_id = message.packetId ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.packetId) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({}));
        obj.packet_fee = message.packetFee ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].toAmino(message.packetFee) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgPayPacketFeeAsync.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgPayPacketFeeAsync",
            value: MsgPayPacketFeeAsync.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgPayPacketFeeAsync.decode(message.value);
    },
    toProto (message) {
        return MsgPayPacketFeeAsync.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
            value: MsgPayPacketFeeAsync.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgPayPacketFeeAsync.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$fee$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketFee"].registerTypeUrl();
    }
};
function createBaseMsgPayPacketFeeAsyncResponse() {
    return {};
}
const MsgPayPacketFeeAsyncResponse = {
    typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsyncResponse",
    aminoType: "cosmos-sdk/MsgPayPacketFeeAsyncResponse",
    is (o) {
        return o && o.$typeUrl === MsgPayPacketFeeAsyncResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgPayPacketFeeAsyncResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgPayPacketFeeAsyncResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgPayPacketFeeAsyncResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgPayPacketFeeAsyncResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgPayPacketFeeAsyncResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgPayPacketFeeAsyncResponse",
            value: MsgPayPacketFeeAsyncResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgPayPacketFeeAsyncResponse.decode(message.value);
    },
    toProto (message) {
        return MsgPayPacketFeeAsyncResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsyncResponse",
            value: MsgPayPacketFeeAsyncResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/controller.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Params": (()=>Params)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseParams() {
    return {
        controllerEnabled: false
    };
}
const Params = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.Params",
    aminoType: "cosmos-sdk/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.controllerEnabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.controller_enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.controllerEnabled === true) {
            writer.uint32(8).bool(message.controllerEnabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.controllerEnabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.controllerEnabled = object.controllerEnabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        if (object.controller_enabled !== undefined && object.controller_enabled !== null) {
            message.controllerEnabled = object.controller_enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.controller_enabled = message.controllerEnabled === false ? undefined : message.controllerEnabled;
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryInterchainAccountRequest": (()=>QueryInterchainAccountRequest),
    "QueryInterchainAccountResponse": (()=>QueryInterchainAccountResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/controller.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseQueryInterchainAccountRequest() {
    return {
        owner: "",
        connectionId: ""
    };
}
const QueryInterchainAccountRequest = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryInterchainAccountRequest",
    aminoType: "cosmos-sdk/QueryInterchainAccountRequest",
    is (o) {
        return o && (o.$typeUrl === QueryInterchainAccountRequest.typeUrl || typeof o.owner === "string" && typeof o.connectionId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryInterchainAccountRequest.typeUrl || typeof o.owner === "string" && typeof o.connection_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.owner !== "") {
            writer.uint32(10).string(message.owner);
        }
        if (message.connectionId !== "") {
            writer.uint32(18).string(message.connectionId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryInterchainAccountRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.owner = reader.string();
                    break;
                case 2:
                    message.connectionId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryInterchainAccountRequest();
        message.owner = object.owner ?? "";
        message.connectionId = object.connectionId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryInterchainAccountRequest();
        if (object.owner !== undefined && object.owner !== null) {
            message.owner = object.owner;
        }
        if (object.connection_id !== undefined && object.connection_id !== null) {
            message.connectionId = object.connection_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.owner = message.owner === "" ? undefined : message.owner;
        obj.connection_id = message.connectionId === "" ? undefined : message.connectionId;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryInterchainAccountRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryInterchainAccountRequest",
            value: QueryInterchainAccountRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryInterchainAccountRequest.decode(message.value);
    },
    toProto (message) {
        return QueryInterchainAccountRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryInterchainAccountRequest",
            value: QueryInterchainAccountRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryInterchainAccountResponse() {
    return {
        address: ""
    };
}
const QueryInterchainAccountResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryInterchainAccountResponse",
    aminoType: "cosmos-sdk/QueryInterchainAccountResponse",
    is (o) {
        return o && (o.$typeUrl === QueryInterchainAccountResponse.typeUrl || typeof o.address === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryInterchainAccountResponse.typeUrl || typeof o.address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryInterchainAccountResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryInterchainAccountResponse();
        message.address = object.address ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryInterchainAccountResponse();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryInterchainAccountResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryInterchainAccountResponse",
            value: QueryInterchainAccountResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryInterchainAccountResponse.decode(message.value);
    },
    toProto (message) {
        return QueryInterchainAccountResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryInterchainAccountResponse",
            value: QueryInterchainAccountResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsRequest() {
    return {};
}
const QueryParamsRequest = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        params: undefined
    };
}
const QueryParamsResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/v1/packet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CosmosTx": (()=>CosmosTx),
    "InterchainAccountPacketData": (()=>InterchainAccountPacketData),
    "Type": (()=>Type),
    "TypeAmino": (()=>TypeAmino),
    "typeFromJSON": (()=>typeFromJSON),
    "typeToJSON": (()=>typeToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
;
;
var Type;
(function(Type) {
    /** TYPE_UNSPECIFIED - Default zero value enumeration */ Type[Type["TYPE_UNSPECIFIED"] = 0] = "TYPE_UNSPECIFIED";
    /** TYPE_EXECUTE_TX - Execute a transaction on an interchain accounts host chain */ Type[Type["TYPE_EXECUTE_TX"] = 1] = "TYPE_EXECUTE_TX";
    Type[Type["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Type || (Type = {}));
const TypeAmino = Type;
function typeFromJSON(object) {
    switch(object){
        case 0:
        case "TYPE_UNSPECIFIED":
            return Type.TYPE_UNSPECIFIED;
        case 1:
        case "TYPE_EXECUTE_TX":
            return Type.TYPE_EXECUTE_TX;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Type.UNRECOGNIZED;
    }
}
function typeToJSON(object) {
    switch(object){
        case Type.TYPE_UNSPECIFIED:
            return "TYPE_UNSPECIFIED";
        case Type.TYPE_EXECUTE_TX:
            return "TYPE_EXECUTE_TX";
        case Type.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseInterchainAccountPacketData() {
    return {
        type: 0,
        data: new Uint8Array(),
        memo: ""
    };
}
const InterchainAccountPacketData = {
    typeUrl: "/ibc.applications.interchain_accounts.v1.InterchainAccountPacketData",
    aminoType: "cosmos-sdk/InterchainAccountPacketData",
    is (o) {
        return o && (o.$typeUrl === InterchainAccountPacketData.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.type) && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.memo === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === InterchainAccountPacketData.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.type) && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.memo === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.type !== 0) {
            writer.uint32(8).int32(message.type);
        }
        if (message.data.length !== 0) {
            writer.uint32(18).bytes(message.data);
        }
        if (message.memo !== "") {
            writer.uint32(26).string(message.memo);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseInterchainAccountPacketData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.type = reader.int32();
                    break;
                case 2:
                    message.data = reader.bytes();
                    break;
                case 3:
                    message.memo = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseInterchainAccountPacketData();
        message.type = object.type ?? 0;
        message.data = object.data ?? new Uint8Array();
        message.memo = object.memo ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseInterchainAccountPacketData();
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        if (object.memo !== undefined && object.memo !== null) {
            message.memo = object.memo;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.type = message.type === 0 ? undefined : message.type;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        obj.memo = message.memo === "" ? undefined : message.memo;
        return obj;
    },
    fromAminoMsg (object) {
        return InterchainAccountPacketData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/InterchainAccountPacketData",
            value: InterchainAccountPacketData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return InterchainAccountPacketData.decode(message.value);
    },
    toProto (message) {
        return InterchainAccountPacketData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.v1.InterchainAccountPacketData",
            value: InterchainAccountPacketData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseCosmosTx() {
    return {
        messages: []
    };
}
const CosmosTx = {
    typeUrl: "/ibc.applications.interchain_accounts.v1.CosmosTx",
    aminoType: "cosmos-sdk/CosmosTx",
    is (o) {
        return o && (o.$typeUrl === CosmosTx.typeUrl || Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].is(o.messages[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === CosmosTx.typeUrl || Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].isAmino(o.messages[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.messages){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCosmosTx();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.messages.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseCosmosTx();
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseCosmosTx();
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.messages) {
            obj.messages = message.messages.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(e) : undefined);
        } else {
            obj.messages = message.messages;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return CosmosTx.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/CosmosTx",
            value: CosmosTx.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return CosmosTx.decode(message.value);
    },
    toProto (message) {
        return CosmosTx.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.v1.CosmosTx",
            value: CosmosTx.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgRegisterInterchainAccount": (()=>MsgRegisterInterchainAccount),
    "MsgRegisterInterchainAccountResponse": (()=>MsgRegisterInterchainAccountResponse),
    "MsgSendTx": (()=>MsgSendTx),
    "MsgSendTxResponse": (()=>MsgSendTxResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/v1/packet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/controller.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
function createBaseMsgRegisterInterchainAccount() {
    return {
        owner: "",
        connectionId: "",
        version: "",
        ordering: 0
    };
}
const MsgRegisterInterchainAccount = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
    aminoType: "cosmos-sdk/MsgRegisterInterchainAccount",
    is (o) {
        return o && (o.$typeUrl === MsgRegisterInterchainAccount.typeUrl || typeof o.owner === "string" && typeof o.connectionId === "string" && typeof o.version === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.ordering));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgRegisterInterchainAccount.typeUrl || typeof o.owner === "string" && typeof o.connection_id === "string" && typeof o.version === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.ordering));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.owner !== "") {
            writer.uint32(10).string(message.owner);
        }
        if (message.connectionId !== "") {
            writer.uint32(18).string(message.connectionId);
        }
        if (message.version !== "") {
            writer.uint32(26).string(message.version);
        }
        if (message.ordering !== 0) {
            writer.uint32(32).int32(message.ordering);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterInterchainAccount();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.owner = reader.string();
                    break;
                case 2:
                    message.connectionId = reader.string();
                    break;
                case 3:
                    message.version = reader.string();
                    break;
                case 4:
                    message.ordering = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgRegisterInterchainAccount();
        message.owner = object.owner ?? "";
        message.connectionId = object.connectionId ?? "";
        message.version = object.version ?? "";
        message.ordering = object.ordering ?? 0;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgRegisterInterchainAccount();
        if (object.owner !== undefined && object.owner !== null) {
            message.owner = object.owner;
        }
        if (object.connection_id !== undefined && object.connection_id !== null) {
            message.connectionId = object.connection_id;
        }
        if (object.version !== undefined && object.version !== null) {
            message.version = object.version;
        }
        if (object.ordering !== undefined && object.ordering !== null) {
            message.ordering = object.ordering;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.owner = message.owner === "" ? undefined : message.owner;
        obj.connection_id = message.connectionId === "" ? undefined : message.connectionId;
        obj.version = message.version === "" ? undefined : message.version;
        obj.ordering = message.ordering === 0 ? undefined : message.ordering;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterInterchainAccount.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterInterchainAccount",
            value: MsgRegisterInterchainAccount.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterInterchainAccount.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterInterchainAccount.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
            value: MsgRegisterInterchainAccount.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRegisterInterchainAccountResponse() {
    return {
        channelId: "",
        portId: ""
    };
}
const MsgRegisterInterchainAccountResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccountResponse",
    aminoType: "cosmos-sdk/MsgRegisterInterchainAccountResponse",
    is (o) {
        return o && (o.$typeUrl === MsgRegisterInterchainAccountResponse.typeUrl || typeof o.channelId === "string" && typeof o.portId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgRegisterInterchainAccountResponse.typeUrl || typeof o.channel_id === "string" && typeof o.port_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.channelId !== "") {
            writer.uint32(10).string(message.channelId);
        }
        if (message.portId !== "") {
            writer.uint32(18).string(message.portId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRegisterInterchainAccountResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.channelId = reader.string();
                    break;
                case 2:
                    message.portId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgRegisterInterchainAccountResponse();
        message.channelId = object.channelId ?? "";
        message.portId = object.portId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgRegisterInterchainAccountResponse();
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.port_id = message.portId === "" ? undefined : message.portId;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRegisterInterchainAccountResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRegisterInterchainAccountResponse",
            value: MsgRegisterInterchainAccountResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRegisterInterchainAccountResponse.decode(message.value);
    },
    toProto (message) {
        return MsgRegisterInterchainAccountResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccountResponse",
            value: MsgRegisterInterchainAccountResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgSendTx() {
    return {
        owner: "",
        connectionId: "",
        packetData: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].fromPartial({}),
        relativeTimeout: BigInt(0)
    };
}
const MsgSendTx = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
    aminoType: "cosmos-sdk/MsgSendTx",
    is (o) {
        return o && (o.$typeUrl === MsgSendTx.typeUrl || typeof o.owner === "string" && typeof o.connectionId === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].is(o.packetData) && typeof o.relativeTimeout === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSendTx.typeUrl || typeof o.owner === "string" && typeof o.connection_id === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].isAmino(o.packet_data) && typeof o.relative_timeout === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.owner !== "") {
            writer.uint32(10).string(message.owner);
        }
        if (message.connectionId !== "") {
            writer.uint32(18).string(message.connectionId);
        }
        if (message.packetData !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].encode(message.packetData, writer.uint32(26).fork()).ldelim();
        }
        if (message.relativeTimeout !== BigInt(0)) {
            writer.uint32(32).uint64(message.relativeTimeout);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSendTx();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.owner = reader.string();
                    break;
                case 2:
                    message.connectionId = reader.string();
                    break;
                case 3:
                    message.packetData = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.relativeTimeout = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSendTx();
        message.owner = object.owner ?? "";
        message.connectionId = object.connectionId ?? "";
        message.packetData = object.packetData !== undefined && object.packetData !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].fromPartial(object.packetData) : undefined;
        message.relativeTimeout = object.relativeTimeout !== undefined && object.relativeTimeout !== null ? BigInt(object.relativeTimeout.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSendTx();
        if (object.owner !== undefined && object.owner !== null) {
            message.owner = object.owner;
        }
        if (object.connection_id !== undefined && object.connection_id !== null) {
            message.connectionId = object.connection_id;
        }
        if (object.packet_data !== undefined && object.packet_data !== null) {
            message.packetData = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].fromAmino(object.packet_data);
        }
        if (object.relative_timeout !== undefined && object.relative_timeout !== null) {
            message.relativeTimeout = BigInt(object.relative_timeout);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.owner = message.owner === "" ? undefined : message.owner;
        obj.connection_id = message.connectionId === "" ? undefined : message.connectionId;
        obj.packet_data = message.packetData ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].toAmino(message.packetData) : undefined;
        obj.relative_timeout = message.relativeTimeout !== BigInt(0) ? message.relativeTimeout?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSendTx.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSendTx",
            value: MsgSendTx.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSendTx.decode(message.value);
    },
    toProto (message) {
        return MsgSendTx.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
            value: MsgSendTx.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgSendTx.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$v1$2f$packet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainAccountPacketData"].registerTypeUrl();
    }
};
function createBaseMsgSendTxResponse() {
    return {
        sequence: BigInt(0)
    };
}
const MsgSendTxResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTxResponse",
    aminoType: "cosmos-sdk/MsgSendTxResponse",
    is (o) {
        return o && (o.$typeUrl === MsgSendTxResponse.typeUrl || typeof o.sequence === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSendTxResponse.typeUrl || typeof o.sequence === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSendTxResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSendTxResponse();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSendTxResponse();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSendTxResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSendTxResponse",
            value: MsgSendTxResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSendTxResponse.decode(message.value);
    },
    toProto (message) {
        return MsgSendTxResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTxResponse",
            value: MsgSendTxResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUpdateParams() {
    return {
        signer: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
    aminoType: "cosmos-sdk/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.signer = object.signer ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/host.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Params": (()=>Params),
    "QueryRequest": (()=>QueryRequest)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
function createBaseParams() {
    return {
        hostEnabled: false,
        allowMessages: []
    };
}
const Params = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.Params",
    aminoType: "cosmos-sdk/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.hostEnabled === "boolean" && Array.isArray(o.allowMessages) && (!o.allowMessages.length || typeof o.allowMessages[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || typeof o.host_enabled === "boolean" && Array.isArray(o.allow_messages) && (!o.allow_messages.length || typeof o.allow_messages[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.hostEnabled === true) {
            writer.uint32(8).bool(message.hostEnabled);
        }
        for (const v of message.allowMessages){
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hostEnabled = reader.bool();
                    break;
                case 2:
                    message.allowMessages.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.hostEnabled = object.hostEnabled ?? false;
        message.allowMessages = object.allowMessages?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        if (object.host_enabled !== undefined && object.host_enabled !== null) {
            message.hostEnabled = object.host_enabled;
        }
        message.allowMessages = object.allow_messages?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.host_enabled = message.hostEnabled === false ? undefined : message.hostEnabled;
        if (message.allowMessages) {
            obj.allow_messages = message.allowMessages.map((e)=>e);
        } else {
            obj.allow_messages = message.allowMessages;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryRequest() {
    return {
        path: "",
        data: new Uint8Array()
    };
}
const QueryRequest = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryRequest",
    aminoType: "cosmos-sdk/QueryRequest",
    is (o) {
        return o && (o.$typeUrl === QueryRequest.typeUrl || typeof o.path === "string" && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryRequest.typeUrl || typeof o.path === "string" && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path !== "") {
            writer.uint32(10).string(message.path);
        }
        if (message.data.length !== 0) {
            writer.uint32(18).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.string();
                    break;
                case 2:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryRequest();
        message.path = object.path ?? "";
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryRequest();
        if (object.path !== undefined && object.path !== null) {
            message.path = object.path;
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path === "" ? undefined : message.path;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryRequest",
            value: QueryRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryRequest.decode(message.value);
    },
    toProto (message) {
        return QueryRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryRequest",
            value: QueryRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/genesis/v1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ActiveChannel": (()=>ActiveChannel),
    "ControllerGenesisState": (()=>ControllerGenesisState),
    "GenesisState": (()=>GenesisState),
    "HostGenesisState": (()=>HostGenesisState),
    "RegisteredInterchainAccount": (()=>RegisteredInterchainAccount)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/controller.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/host.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseGenesisState() {
    return {
        controllerGenesisState: ControllerGenesisState.fromPartial({}),
        hostGenesisState: HostGenesisState.fromPartial({})
    };
}
const GenesisState = {
    typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || ControllerGenesisState.is(o.controllerGenesisState) && HostGenesisState.is(o.hostGenesisState));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || ControllerGenesisState.isAmino(o.controller_genesis_state) && HostGenesisState.isAmino(o.host_genesis_state));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.controllerGenesisState !== undefined) {
            ControllerGenesisState.encode(message.controllerGenesisState, writer.uint32(10).fork()).ldelim();
        }
        if (message.hostGenesisState !== undefined) {
            HostGenesisState.encode(message.hostGenesisState, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.controllerGenesisState = ControllerGenesisState.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.hostGenesisState = HostGenesisState.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.controllerGenesisState = object.controllerGenesisState !== undefined && object.controllerGenesisState !== null ? ControllerGenesisState.fromPartial(object.controllerGenesisState) : undefined;
        message.hostGenesisState = object.hostGenesisState !== undefined && object.hostGenesisState !== null ? HostGenesisState.fromPartial(object.hostGenesisState) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.controller_genesis_state !== undefined && object.controller_genesis_state !== null) {
            message.controllerGenesisState = ControllerGenesisState.fromAmino(object.controller_genesis_state);
        }
        if (object.host_genesis_state !== undefined && object.host_genesis_state !== null) {
            message.hostGenesisState = HostGenesisState.fromAmino(object.host_genesis_state);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.controller_genesis_state = message.controllerGenesisState ? ControllerGenesisState.toAmino(message.controllerGenesisState) : undefined;
        obj.host_genesis_state = message.hostGenesisState ? HostGenesisState.toAmino(message.hostGenesisState) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        ControllerGenesisState.registerTypeUrl();
        HostGenesisState.registerTypeUrl();
    }
};
function createBaseControllerGenesisState() {
    return {
        activeChannels: [],
        interchainAccounts: [],
        ports: [],
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const ControllerGenesisState = {
    typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.ControllerGenesisState",
    aminoType: "cosmos-sdk/ControllerGenesisState",
    is (o) {
        return o && (o.$typeUrl === ControllerGenesisState.typeUrl || Array.isArray(o.activeChannels) && (!o.activeChannels.length || ActiveChannel.is(o.activeChannels[0])) && Array.isArray(o.interchainAccounts) && (!o.interchainAccounts.length || RegisteredInterchainAccount.is(o.interchainAccounts[0])) && Array.isArray(o.ports) && (!o.ports.length || typeof o.ports[0] === "string") && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ControllerGenesisState.typeUrl || Array.isArray(o.active_channels) && (!o.active_channels.length || ActiveChannel.isAmino(o.active_channels[0])) && Array.isArray(o.interchain_accounts) && (!o.interchain_accounts.length || RegisteredInterchainAccount.isAmino(o.interchain_accounts[0])) && Array.isArray(o.ports) && (!o.ports.length || typeof o.ports[0] === "string") && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.activeChannels){
            ActiveChannel.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.interchainAccounts){
            RegisteredInterchainAccount.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.ports){
            writer.uint32(26).string(v);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseControllerGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.activeChannels.push(ActiveChannel.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.interchainAccounts.push(RegisteredInterchainAccount.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.ports.push(reader.string());
                    break;
                case 4:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseControllerGenesisState();
        message.activeChannels = object.activeChannels?.map((e)=>ActiveChannel.fromPartial(e)) || [];
        message.interchainAccounts = object.interchainAccounts?.map((e)=>RegisteredInterchainAccount.fromPartial(e)) || [];
        message.ports = object.ports?.map((e)=>e) || [];
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseControllerGenesisState();
        message.activeChannels = object.active_channels?.map((e)=>ActiveChannel.fromAmino(e)) || [];
        message.interchainAccounts = object.interchain_accounts?.map((e)=>RegisteredInterchainAccount.fromAmino(e)) || [];
        message.ports = object.ports?.map((e)=>e) || [];
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.activeChannels) {
            obj.active_channels = message.activeChannels.map((e)=>e ? ActiveChannel.toAmino(e) : undefined);
        } else {
            obj.active_channels = message.activeChannels;
        }
        if (message.interchainAccounts) {
            obj.interchain_accounts = message.interchainAccounts.map((e)=>e ? RegisteredInterchainAccount.toAmino(e) : undefined);
        } else {
            obj.interchain_accounts = message.interchainAccounts;
        }
        if (message.ports) {
            obj.ports = message.ports.map((e)=>e);
        } else {
            obj.ports = message.ports;
        }
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ControllerGenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ControllerGenesisState",
            value: ControllerGenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ControllerGenesisState.decode(message.value);
    },
    toProto (message) {
        return ControllerGenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.ControllerGenesisState",
            value: ControllerGenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ControllerGenesisState.typeUrl)) {
            return;
        }
        ActiveChannel.registerTypeUrl();
        RegisteredInterchainAccount.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$controller$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseHostGenesisState() {
    return {
        activeChannels: [],
        interchainAccounts: [],
        port: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const HostGenesisState = {
    typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.HostGenesisState",
    aminoType: "cosmos-sdk/HostGenesisState",
    is (o) {
        return o && (o.$typeUrl === HostGenesisState.typeUrl || Array.isArray(o.activeChannels) && (!o.activeChannels.length || ActiveChannel.is(o.activeChannels[0])) && Array.isArray(o.interchainAccounts) && (!o.interchainAccounts.length || RegisteredInterchainAccount.is(o.interchainAccounts[0])) && typeof o.port === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === HostGenesisState.typeUrl || Array.isArray(o.active_channels) && (!o.active_channels.length || ActiveChannel.isAmino(o.active_channels[0])) && Array.isArray(o.interchain_accounts) && (!o.interchain_accounts.length || RegisteredInterchainAccount.isAmino(o.interchain_accounts[0])) && typeof o.port === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.activeChannels){
            ActiveChannel.encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.interchainAccounts){
            RegisteredInterchainAccount.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.port !== "") {
            writer.uint32(26).string(message.port);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHostGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.activeChannels.push(ActiveChannel.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.interchainAccounts.push(RegisteredInterchainAccount.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.port = reader.string();
                    break;
                case 4:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHostGenesisState();
        message.activeChannels = object.activeChannels?.map((e)=>ActiveChannel.fromPartial(e)) || [];
        message.interchainAccounts = object.interchainAccounts?.map((e)=>RegisteredInterchainAccount.fromPartial(e)) || [];
        message.port = object.port ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseHostGenesisState();
        message.activeChannels = object.active_channels?.map((e)=>ActiveChannel.fromAmino(e)) || [];
        message.interchainAccounts = object.interchain_accounts?.map((e)=>RegisteredInterchainAccount.fromAmino(e)) || [];
        if (object.port !== undefined && object.port !== null) {
            message.port = object.port;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.activeChannels) {
            obj.active_channels = message.activeChannels.map((e)=>e ? ActiveChannel.toAmino(e) : undefined);
        } else {
            obj.active_channels = message.activeChannels;
        }
        if (message.interchainAccounts) {
            obj.interchain_accounts = message.interchainAccounts.map((e)=>e ? RegisteredInterchainAccount.toAmino(e) : undefined);
        } else {
            obj.interchain_accounts = message.interchainAccounts;
        }
        obj.port = message.port === "" ? undefined : message.port;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return HostGenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/HostGenesisState",
            value: HostGenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return HostGenesisState.decode(message.value);
    },
    toProto (message) {
        return HostGenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.HostGenesisState",
            value: HostGenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(HostGenesisState.typeUrl)) {
            return;
        }
        ActiveChannel.registerTypeUrl();
        RegisteredInterchainAccount.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseActiveChannel() {
    return {
        connectionId: "",
        portId: "",
        channelId: "",
        isMiddlewareEnabled: false
    };
}
const ActiveChannel = {
    typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.ActiveChannel",
    aminoType: "cosmos-sdk/ActiveChannel",
    is (o) {
        return o && (o.$typeUrl === ActiveChannel.typeUrl || typeof o.connectionId === "string" && typeof o.portId === "string" && typeof o.channelId === "string" && typeof o.isMiddlewareEnabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ActiveChannel.typeUrl || typeof o.connection_id === "string" && typeof o.port_id === "string" && typeof o.channel_id === "string" && typeof o.is_middleware_enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.connectionId !== "") {
            writer.uint32(10).string(message.connectionId);
        }
        if (message.portId !== "") {
            writer.uint32(18).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(26).string(message.channelId);
        }
        if (message.isMiddlewareEnabled === true) {
            writer.uint32(32).bool(message.isMiddlewareEnabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseActiveChannel();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.connectionId = reader.string();
                    break;
                case 2:
                    message.portId = reader.string();
                    break;
                case 3:
                    message.channelId = reader.string();
                    break;
                case 4:
                    message.isMiddlewareEnabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseActiveChannel();
        message.connectionId = object.connectionId ?? "";
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        message.isMiddlewareEnabled = object.isMiddlewareEnabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseActiveChannel();
        if (object.connection_id !== undefined && object.connection_id !== null) {
            message.connectionId = object.connection_id;
        }
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        if (object.is_middleware_enabled !== undefined && object.is_middleware_enabled !== null) {
            message.isMiddlewareEnabled = object.is_middleware_enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.connection_id = message.connectionId === "" ? undefined : message.connectionId;
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        obj.is_middleware_enabled = message.isMiddlewareEnabled === false ? undefined : message.isMiddlewareEnabled;
        return obj;
    },
    fromAminoMsg (object) {
        return ActiveChannel.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ActiveChannel",
            value: ActiveChannel.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ActiveChannel.decode(message.value);
    },
    toProto (message) {
        return ActiveChannel.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.ActiveChannel",
            value: ActiveChannel.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseRegisteredInterchainAccount() {
    return {
        connectionId: "",
        portId: "",
        accountAddress: ""
    };
}
const RegisteredInterchainAccount = {
    typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.RegisteredInterchainAccount",
    aminoType: "cosmos-sdk/RegisteredInterchainAccount",
    is (o) {
        return o && (o.$typeUrl === RegisteredInterchainAccount.typeUrl || typeof o.connectionId === "string" && typeof o.portId === "string" && typeof o.accountAddress === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === RegisteredInterchainAccount.typeUrl || typeof o.connection_id === "string" && typeof o.port_id === "string" && typeof o.account_address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.connectionId !== "") {
            writer.uint32(10).string(message.connectionId);
        }
        if (message.portId !== "") {
            writer.uint32(18).string(message.portId);
        }
        if (message.accountAddress !== "") {
            writer.uint32(26).string(message.accountAddress);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRegisteredInterchainAccount();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.connectionId = reader.string();
                    break;
                case 2:
                    message.portId = reader.string();
                    break;
                case 3:
                    message.accountAddress = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRegisteredInterchainAccount();
        message.connectionId = object.connectionId ?? "";
        message.portId = object.portId ?? "";
        message.accountAddress = object.accountAddress ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseRegisteredInterchainAccount();
        if (object.connection_id !== undefined && object.connection_id !== null) {
            message.connectionId = object.connection_id;
        }
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.account_address !== undefined && object.account_address !== null) {
            message.accountAddress = object.account_address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.connection_id = message.connectionId === "" ? undefined : message.connectionId;
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.account_address = message.accountAddress === "" ? undefined : message.accountAddress;
        return obj;
    },
    fromAminoMsg (object) {
        return RegisteredInterchainAccount.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RegisteredInterchainAccount",
            value: RegisteredInterchainAccount.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RegisteredInterchainAccount.decode(message.value);
    },
    toProto (message) {
        return RegisteredInterchainAccount.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.genesis.v1.RegisteredInterchainAccount",
            value: RegisteredInterchainAccount.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/host.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseQueryParamsRequest() {
    return {};
}
const QueryParamsRequest = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        params: undefined
    };
}
const QueryParamsResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgModuleQuerySafe": (()=>MsgModuleQuerySafe),
    "MsgModuleQuerySafeResponse": (()=>MsgModuleQuerySafeResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/host.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
function createBaseMsgUpdateParams() {
    return {
        signer: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
    aminoType: "cosmos-sdk/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.signer = object.signer ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgModuleQuerySafe() {
    return {
        signer: "",
        requests: []
    };
}
const MsgModuleQuerySafe = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
    aminoType: "cosmos-sdk/MsgModuleQuerySafe",
    is (o) {
        return o && (o.$typeUrl === MsgModuleQuerySafe.typeUrl || typeof o.signer === "string" && Array.isArray(o.requests) && (!o.requests.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].is(o.requests[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgModuleQuerySafe.typeUrl || typeof o.signer === "string" && Array.isArray(o.requests) && (!o.requests.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].isAmino(o.requests[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        for (const v of message.requests){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgModuleQuerySafe();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.requests.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgModuleQuerySafe();
        message.signer = object.signer ?? "";
        message.requests = object.requests?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgModuleQuerySafe();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        message.requests = object.requests?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        if (message.requests) {
            obj.requests = message.requests.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].toAmino(e) : undefined);
        } else {
            obj.requests = message.requests;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgModuleQuerySafe.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgModuleQuerySafe",
            value: MsgModuleQuerySafe.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgModuleQuerySafe.decode(message.value);
    },
    toProto (message) {
        return MsgModuleQuerySafe.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
            value: MsgModuleQuerySafe.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgModuleQuerySafe.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$host$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRequest"].registerTypeUrl();
    }
};
function createBaseMsgModuleQuerySafeResponse() {
    return {
        height: BigInt(0),
        responses: []
    };
}
const MsgModuleQuerySafeResponse = {
    typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafeResponse",
    aminoType: "cosmos-sdk/MsgModuleQuerySafeResponse",
    is (o) {
        return o && (o.$typeUrl === MsgModuleQuerySafeResponse.typeUrl || typeof o.height === "bigint" && Array.isArray(o.responses) && (!o.responses.length || o.responses[0] instanceof Uint8Array || typeof o.responses[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgModuleQuerySafeResponse.typeUrl || typeof o.height === "bigint" && Array.isArray(o.responses) && (!o.responses.length || o.responses[0] instanceof Uint8Array || typeof o.responses[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.height !== BigInt(0)) {
            writer.uint32(8).uint64(message.height);
        }
        for (const v of message.responses){
            writer.uint32(18).bytes(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgModuleQuerySafeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.height = reader.uint64();
                    break;
                case 2:
                    message.responses.push(reader.bytes());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgModuleQuerySafeResponse();
        message.height = object.height !== undefined && object.height !== null ? BigInt(object.height.toString()) : BigInt(0);
        message.responses = object.responses?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgModuleQuerySafeResponse();
        if (object.height !== undefined && object.height !== null) {
            message.height = BigInt(object.height);
        }
        message.responses = object.responses?.map((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.height = message.height !== BigInt(0) ? message.height?.toString() : undefined;
        if (message.responses) {
            obj.responses = message.responses.map((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(e));
        } else {
            obj.responses = message.responses;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgModuleQuerySafeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgModuleQuerySafeResponse",
            value: MsgModuleQuerySafeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgModuleQuerySafeResponse.decode(message.value);
    },
    toProto (message) {
        return MsgModuleQuerySafeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafeResponse",
            value: MsgModuleQuerySafeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/v1/account.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "InterchainAccount": (()=>InterchainAccount)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/auth/v1beta1/auth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseInterchainAccount() {
    return {
        baseAccount: undefined,
        accountOwner: ""
    };
}
const InterchainAccount = {
    typeUrl: "/ibc.applications.interchain_accounts.v1.InterchainAccount",
    aminoType: "cosmos-sdk/InterchainAccount",
    is (o) {
        return o && (o.$typeUrl === InterchainAccount.typeUrl || typeof o.accountOwner === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === InterchainAccount.typeUrl || typeof o.account_owner === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.baseAccount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].encode(message.baseAccount, writer.uint32(10).fork()).ldelim();
        }
        if (message.accountOwner !== "") {
            writer.uint32(18).string(message.accountOwner);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseInterchainAccount();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.baseAccount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.accountOwner = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseInterchainAccount();
        message.baseAccount = object.baseAccount !== undefined && object.baseAccount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].fromPartial(object.baseAccount) : undefined;
        message.accountOwner = object.accountOwner ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseInterchainAccount();
        if (object.base_account !== undefined && object.base_account !== null) {
            message.baseAccount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].fromAmino(object.base_account);
        }
        if (object.account_owner !== undefined && object.account_owner !== null) {
            message.accountOwner = object.account_owner;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.base_account = message.baseAccount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].toAmino(message.baseAccount) : undefined;
        obj.account_owner = message.accountOwner === "" ? undefined : message.accountOwner;
        return obj;
    },
    fromAminoMsg (object) {
        return InterchainAccount.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/InterchainAccount",
            value: InterchainAccount.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return InterchainAccount.decode(message.value);
    },
    toProto (message) {
        return InterchainAccount.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.v1.InterchainAccount",
            value: InterchainAccount.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(InterchainAccount.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(InterchainAccount.typeUrl, InterchainAccount);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(InterchainAccount.aminoType, InterchainAccount.typeUrl);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$auth$2f$v1beta1$2f$auth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseAccount"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/v1/metadata.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Metadata": (()=>Metadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseMetadata() {
    return {
        version: "",
        controllerConnectionId: "",
        hostConnectionId: "",
        address: "",
        encoding: "",
        txType: ""
    };
}
const Metadata = {
    typeUrl: "/ibc.applications.interchain_accounts.v1.Metadata",
    aminoType: "cosmos-sdk/Metadata",
    is (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.version === "string" && typeof o.controllerConnectionId === "string" && typeof o.hostConnectionId === "string" && typeof o.address === "string" && typeof o.encoding === "string" && typeof o.txType === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.version === "string" && typeof o.controller_connection_id === "string" && typeof o.host_connection_id === "string" && typeof o.address === "string" && typeof o.encoding === "string" && typeof o.tx_type === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.version !== "") {
            writer.uint32(10).string(message.version);
        }
        if (message.controllerConnectionId !== "") {
            writer.uint32(18).string(message.controllerConnectionId);
        }
        if (message.hostConnectionId !== "") {
            writer.uint32(26).string(message.hostConnectionId);
        }
        if (message.address !== "") {
            writer.uint32(34).string(message.address);
        }
        if (message.encoding !== "") {
            writer.uint32(42).string(message.encoding);
        }
        if (message.txType !== "") {
            writer.uint32(50).string(message.txType);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetadata();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.version = reader.string();
                    break;
                case 2:
                    message.controllerConnectionId = reader.string();
                    break;
                case 3:
                    message.hostConnectionId = reader.string();
                    break;
                case 4:
                    message.address = reader.string();
                    break;
                case 5:
                    message.encoding = reader.string();
                    break;
                case 6:
                    message.txType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMetadata();
        message.version = object.version ?? "";
        message.controllerConnectionId = object.controllerConnectionId ?? "";
        message.hostConnectionId = object.hostConnectionId ?? "";
        message.address = object.address ?? "";
        message.encoding = object.encoding ?? "";
        message.txType = object.txType ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMetadata();
        if (object.version !== undefined && object.version !== null) {
            message.version = object.version;
        }
        if (object.controller_connection_id !== undefined && object.controller_connection_id !== null) {
            message.controllerConnectionId = object.controller_connection_id;
        }
        if (object.host_connection_id !== undefined && object.host_connection_id !== null) {
            message.hostConnectionId = object.host_connection_id;
        }
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.encoding !== undefined && object.encoding !== null) {
            message.encoding = object.encoding;
        }
        if (object.tx_type !== undefined && object.tx_type !== null) {
            message.txType = object.tx_type;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.version = message.version === "" ? undefined : message.version;
        obj.controller_connection_id = message.controllerConnectionId === "" ? undefined : message.controllerConnectionId;
        obj.host_connection_id = message.hostConnectionId === "" ? undefined : message.hostConnectionId;
        obj.address = message.address === "" ? undefined : message.address;
        obj.encoding = message.encoding === "" ? undefined : message.encoding;
        obj.tx_type = message.txType === "" ? undefined : message.txType;
        return obj;
    },
    fromAminoMsg (object) {
        return Metadata.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Metadata",
            value: Metadata.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Metadata.decode(message.value);
    },
    toProto (message) {
        return Metadata.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.interchain_accounts.v1.Metadata",
            value: Metadata.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/denomtrace.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DenomTrace": (()=>DenomTrace)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseDenomTrace() {
    return {
        path: "",
        baseDenom: ""
    };
}
const DenomTrace = {
    typeUrl: "/ibc.applications.transfer.v1.DenomTrace",
    aminoType: "cosmos-sdk/DenomTrace",
    is (o) {
        return o && (o.$typeUrl === DenomTrace.typeUrl || typeof o.path === "string" && typeof o.baseDenom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === DenomTrace.typeUrl || typeof o.path === "string" && typeof o.base_denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path !== "") {
            writer.uint32(10).string(message.path);
        }
        if (message.baseDenom !== "") {
            writer.uint32(18).string(message.baseDenom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDenomTrace();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.string();
                    break;
                case 2:
                    message.baseDenom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDenomTrace();
        message.path = object.path ?? "";
        message.baseDenom = object.baseDenom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseDenomTrace();
        if (object.path !== undefined && object.path !== null) {
            message.path = object.path;
        }
        if (object.base_denom !== undefined && object.base_denom !== null) {
            message.baseDenom = object.base_denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path === "" ? undefined : message.path;
        obj.base_denom = message.baseDenom === "" ? undefined : message.baseDenom;
        return obj;
    },
    fromAminoMsg (object) {
        return DenomTrace.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DenomTrace",
            value: DenomTrace.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DenomTrace.decode(message.value);
    },
    toProto (message) {
        return DenomTrace.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.DenomTrace",
            value: DenomTrace.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryDenomHashRequest": (()=>QueryDenomHashRequest),
    "QueryDenomHashResponse": (()=>QueryDenomHashResponse),
    "QueryEscrowAddressRequest": (()=>QueryEscrowAddressRequest),
    "QueryEscrowAddressResponse": (()=>QueryEscrowAddressResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse),
    "QueryTotalEscrowForDenomRequest": (()=>QueryTotalEscrowForDenomRequest),
    "QueryTotalEscrowForDenomResponse": (()=>QueryTotalEscrowForDenomResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseQueryParamsRequest() {
    return {};
}
const QueryParamsRequest = {
    typeUrl: "/ibc.applications.transfer.v1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        params: undefined
    };
}
const QueryParamsResponse = {
    typeUrl: "/ibc.applications.transfer.v1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseQueryDenomHashRequest() {
    return {
        trace: ""
    };
}
const QueryDenomHashRequest = {
    typeUrl: "/ibc.applications.transfer.v1.QueryDenomHashRequest",
    aminoType: "cosmos-sdk/QueryDenomHashRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomHashRequest.typeUrl || typeof o.trace === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomHashRequest.typeUrl || typeof o.trace === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.trace !== "") {
            writer.uint32(10).string(message.trace);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomHashRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.trace = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomHashRequest();
        message.trace = object.trace ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomHashRequest();
        if (object.trace !== undefined && object.trace !== null) {
            message.trace = object.trace;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.trace = message.trace === "" ? undefined : message.trace;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomHashRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomHashRequest",
            value: QueryDenomHashRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomHashRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomHashRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryDenomHashRequest",
            value: QueryDenomHashRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDenomHashResponse() {
    return {
        hash: ""
    };
}
const QueryDenomHashResponse = {
    typeUrl: "/ibc.applications.transfer.v1.QueryDenomHashResponse",
    aminoType: "cosmos-sdk/QueryDenomHashResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomHashResponse.typeUrl || typeof o.hash === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomHashResponse.typeUrl || typeof o.hash === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.hash !== "") {
            writer.uint32(10).string(message.hash);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomHashResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hash = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomHashResponse();
        message.hash = object.hash ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomHashResponse();
        if (object.hash !== undefined && object.hash !== null) {
            message.hash = object.hash;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.hash = message.hash === "" ? undefined : message.hash;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomHashResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomHashResponse",
            value: QueryDenomHashResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomHashResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomHashResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryDenomHashResponse",
            value: QueryDenomHashResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryEscrowAddressRequest() {
    return {
        portId: "",
        channelId: ""
    };
}
const QueryEscrowAddressRequest = {
    typeUrl: "/ibc.applications.transfer.v1.QueryEscrowAddressRequest",
    aminoType: "cosmos-sdk/QueryEscrowAddressRequest",
    is (o) {
        return o && (o.$typeUrl === QueryEscrowAddressRequest.typeUrl || typeof o.portId === "string" && typeof o.channelId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryEscrowAddressRequest.typeUrl || typeof o.port_id === "string" && typeof o.channel_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        if (message.channelId !== "") {
            writer.uint32(18).string(message.channelId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryEscrowAddressRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.channelId = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryEscrowAddressRequest();
        message.portId = object.portId ?? "";
        message.channelId = object.channelId ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryEscrowAddressRequest();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        if (object.channel_id !== undefined && object.channel_id !== null) {
            message.channelId = object.channel_id;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        obj.channel_id = message.channelId === "" ? undefined : message.channelId;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryEscrowAddressRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryEscrowAddressRequest",
            value: QueryEscrowAddressRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryEscrowAddressRequest.decode(message.value);
    },
    toProto (message) {
        return QueryEscrowAddressRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryEscrowAddressRequest",
            value: QueryEscrowAddressRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryEscrowAddressResponse() {
    return {
        escrowAddress: ""
    };
}
const QueryEscrowAddressResponse = {
    typeUrl: "/ibc.applications.transfer.v1.QueryEscrowAddressResponse",
    aminoType: "cosmos-sdk/QueryEscrowAddressResponse",
    is (o) {
        return o && (o.$typeUrl === QueryEscrowAddressResponse.typeUrl || typeof o.escrowAddress === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryEscrowAddressResponse.typeUrl || typeof o.escrow_address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.escrowAddress !== "") {
            writer.uint32(10).string(message.escrowAddress);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryEscrowAddressResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.escrowAddress = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryEscrowAddressResponse();
        message.escrowAddress = object.escrowAddress ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryEscrowAddressResponse();
        if (object.escrow_address !== undefined && object.escrow_address !== null) {
            message.escrowAddress = object.escrow_address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.escrow_address = message.escrowAddress === "" ? undefined : message.escrowAddress;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryEscrowAddressResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryEscrowAddressResponse",
            value: QueryEscrowAddressResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryEscrowAddressResponse.decode(message.value);
    },
    toProto (message) {
        return QueryEscrowAddressResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryEscrowAddressResponse",
            value: QueryEscrowAddressResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryTotalEscrowForDenomRequest() {
    return {
        denom: ""
    };
}
const QueryTotalEscrowForDenomRequest = {
    typeUrl: "/ibc.applications.transfer.v1.QueryTotalEscrowForDenomRequest",
    aminoType: "cosmos-sdk/QueryTotalEscrowForDenomRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTotalEscrowForDenomRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalEscrowForDenomRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalEscrowForDenomRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalEscrowForDenomRequest();
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalEscrowForDenomRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalEscrowForDenomRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalEscrowForDenomRequest",
            value: QueryTotalEscrowForDenomRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalEscrowForDenomRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTotalEscrowForDenomRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryTotalEscrowForDenomRequest",
            value: QueryTotalEscrowForDenomRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryTotalEscrowForDenomResponse() {
    return {
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const QueryTotalEscrowForDenomResponse = {
    typeUrl: "/ibc.applications.transfer.v1.QueryTotalEscrowForDenomResponse",
    aminoType: "cosmos-sdk/QueryTotalEscrowForDenomResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTotalEscrowForDenomResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalEscrowForDenomResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalEscrowForDenomResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalEscrowForDenomResponse();
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalEscrowForDenomResponse();
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalEscrowForDenomResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalEscrowForDenomResponse",
            value: QueryTotalEscrowForDenomResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalEscrowForDenomResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTotalEscrowForDenomResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.QueryTotalEscrowForDenomResponse",
            value: QueryTotalEscrowForDenomResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalEscrowForDenomResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgTransfer": (()=>MsgTransfer),
    "MsgTransferResponse": (()=>MsgTransferResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/client/v1/client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
function createBaseMsgTransfer() {
    return {
        sourcePort: "",
        sourceChannel: "",
        token: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}),
        sender: "",
        receiver: "",
        timeoutHeight: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial({}),
        timeoutTimestamp: BigInt(0),
        memo: "",
        tokens: [],
        forwarding: undefined
    };
}
const MsgTransfer = {
    typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
    aminoType: "cosmos-sdk/MsgTransfer",
    is (o) {
        return o && (o.$typeUrl === MsgTransfer.typeUrl || typeof o.sourcePort === "string" && typeof o.sourceChannel === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.token) && typeof o.sender === "string" && typeof o.receiver === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].is(o.timeoutHeight) && typeof o.timeoutTimestamp === "bigint" && typeof o.memo === "string" && Array.isArray(o.tokens) && (!o.tokens.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.tokens[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgTransfer.typeUrl || typeof o.source_port === "string" && typeof o.source_channel === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.token) && typeof o.sender === "string" && typeof o.receiver === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].isAmino(o.timeout_height) && typeof o.timeout_timestamp === "bigint" && typeof o.memo === "string" && Array.isArray(o.tokens) && (!o.tokens.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.tokens[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sourcePort !== "") {
            writer.uint32(10).string(message.sourcePort);
        }
        if (message.sourceChannel !== "") {
            writer.uint32(18).string(message.sourceChannel);
        }
        if (message.token !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.token, writer.uint32(26).fork()).ldelim();
        }
        if (message.sender !== "") {
            writer.uint32(34).string(message.sender);
        }
        if (message.receiver !== "") {
            writer.uint32(42).string(message.receiver);
        }
        if (message.timeoutHeight !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].encode(message.timeoutHeight, writer.uint32(50).fork()).ldelim();
        }
        if (message.timeoutTimestamp !== BigInt(0)) {
            writer.uint32(56).uint64(message.timeoutTimestamp);
        }
        if (message.memo !== "") {
            writer.uint32(66).string(message.memo);
        }
        for (const v of message.tokens){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(74).fork()).ldelim();
        }
        if (message.forwarding !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].encode(message.forwarding, writer.uint32(82).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgTransfer();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sourcePort = reader.string();
                    break;
                case 2:
                    message.sourceChannel = reader.string();
                    break;
                case 3:
                    message.token = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.sender = reader.string();
                    break;
                case 5:
                    message.receiver = reader.string();
                    break;
                case 6:
                    message.timeoutHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].decode(reader, reader.uint32());
                    break;
                case 7:
                    message.timeoutTimestamp = reader.uint64();
                    break;
                case 8:
                    message.memo = reader.string();
                    break;
                case 9:
                    message.tokens.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.forwarding = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgTransfer();
        message.sourcePort = object.sourcePort ?? "";
        message.sourceChannel = object.sourceChannel ?? "";
        message.token = object.token !== undefined && object.token !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.token) : undefined;
        message.sender = object.sender ?? "";
        message.receiver = object.receiver ?? "";
        message.timeoutHeight = object.timeoutHeight !== undefined && object.timeoutHeight !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial(object.timeoutHeight) : undefined;
        message.timeoutTimestamp = object.timeoutTimestamp !== undefined && object.timeoutTimestamp !== null ? BigInt(object.timeoutTimestamp.toString()) : BigInt(0);
        message.memo = object.memo ?? "";
        message.tokens = object.tokens?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.forwarding = object.forwarding !== undefined && object.forwarding !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].fromPartial(object.forwarding) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgTransfer();
        if (object.source_port !== undefined && object.source_port !== null) {
            message.sourcePort = object.source_port;
        }
        if (object.source_channel !== undefined && object.source_channel !== null) {
            message.sourceChannel = object.source_channel;
        }
        if (object.token !== undefined && object.token !== null) {
            message.token = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.token);
        }
        if (object.sender !== undefined && object.sender !== null) {
            message.sender = object.sender;
        }
        if (object.receiver !== undefined && object.receiver !== null) {
            message.receiver = object.receiver;
        }
        if (object.timeout_height !== undefined && object.timeout_height !== null) {
            message.timeoutHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromAmino(object.timeout_height);
        }
        if (object.timeout_timestamp !== undefined && object.timeout_timestamp !== null) {
            message.timeoutTimestamp = BigInt(object.timeout_timestamp);
        }
        if (object.memo !== undefined && object.memo !== null) {
            message.memo = object.memo;
        }
        message.tokens = object.tokens?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.forwarding !== undefined && object.forwarding !== null) {
            message.forwarding = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].fromAmino(object.forwarding);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.source_port = message.sourcePort === "" ? undefined : message.sourcePort;
        obj.source_channel = message.sourceChannel === "" ? undefined : message.sourceChannel;
        obj.token = message.token ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.token) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        obj.sender = message.sender === "" ? undefined : message.sender;
        obj.receiver = message.receiver === "" ? undefined : message.receiver;
        obj.timeout_height = message.timeoutHeight ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].toAmino(message.timeoutHeight) : {};
        obj.timeout_timestamp = message.timeoutTimestamp !== BigInt(0) ? message.timeoutTimestamp?.toString() : undefined;
        obj.memo = message.memo === "" ? undefined : message.memo;
        if (message.tokens) {
            obj.tokens = message.tokens.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.tokens = message.tokens;
        }
        obj.forwarding = message.forwarding ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].toAmino(message.forwarding) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgTransfer.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgTransfer",
            value: MsgTransfer.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgTransfer.decode(message.value);
    },
    toProto (message) {
        return MsgTransfer.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
            value: MsgTransfer.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgTransfer.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Forwarding"].registerTypeUrl();
    }
};
function createBaseMsgTransferResponse() {
    return {
        sequence: BigInt(0)
    };
}
const MsgTransferResponse = {
    typeUrl: "/ibc.applications.transfer.v1.MsgTransferResponse",
    aminoType: "cosmos-sdk/MsgTransferResponse",
    is (o) {
        return o && (o.$typeUrl === MsgTransferResponse.typeUrl || typeof o.sequence === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgTransferResponse.typeUrl || typeof o.sequence === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgTransferResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgTransferResponse();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgTransferResponse();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgTransferResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgTransferResponse",
            value: MsgTransferResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgTransferResponse.decode(message.value);
    },
    toProto (message) {
        return MsgTransferResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.MsgTransferResponse",
            value: MsgTransferResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUpdateParams() {
    return {
        signer: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParams",
    aminoType: "cosmos-sdk/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.signer === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.signer = object.signer ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/token.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Denom": (()=>Denom),
    "Token": (()=>Token)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseToken() {
    return {
        denom: Denom.fromPartial({}),
        amount: ""
    };
}
const Token = {
    typeUrl: "/ibc.applications.transfer.v2.Token",
    aminoType: "cosmos-sdk/Token",
    is (o) {
        return o && (o.$typeUrl === Token.typeUrl || Denom.is(o.denom) && typeof o.amount === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Token.typeUrl || Denom.isAmino(o.denom) && typeof o.amount === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== undefined) {
            Denom.encode(message.denom, writer.uint32(10).fork()).ldelim();
        }
        if (message.amount !== "") {
            writer.uint32(18).string(message.amount);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseToken();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = Denom.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.amount = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseToken();
        message.denom = object.denom !== undefined && object.denom !== null ? Denom.fromPartial(object.denom) : undefined;
        message.amount = object.amount ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseToken();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = Denom.fromAmino(object.denom);
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = object.amount;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom ? Denom.toAmino(message.denom) : undefined;
        obj.amount = message.amount === "" ? undefined : message.amount;
        return obj;
    },
    fromAminoMsg (object) {
        return Token.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Token",
            value: Token.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Token.decode(message.value);
    },
    toProto (message) {
        return Token.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.Token",
            value: Token.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Token.typeUrl)) {
            return;
        }
        Denom.registerTypeUrl();
    }
};
function createBaseDenom() {
    return {
        base: "",
        trace: []
    };
}
const Denom = {
    typeUrl: "/ibc.applications.transfer.v2.Denom",
    aminoType: "cosmos-sdk/Denom",
    is (o) {
        return o && (o.$typeUrl === Denom.typeUrl || typeof o.base === "string" && Array.isArray(o.trace) && (!o.trace.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].is(o.trace[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Denom.typeUrl || typeof o.base === "string" && Array.isArray(o.trace) && (!o.trace.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].isAmino(o.trace[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.base !== "") {
            writer.uint32(10).string(message.base);
        }
        for (const v of message.trace){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDenom();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.base = reader.string();
                    break;
                case 3:
                    message.trace.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDenom();
        message.base = object.base ?? "";
        message.trace = object.trace?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDenom();
        if (object.base !== undefined && object.base !== null) {
            message.base = object.base;
        }
        message.trace = object.trace?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.base = message.base === "" ? undefined : message.base;
        if (message.trace) {
            obj.trace = message.trace.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].toAmino(e) : undefined);
        } else {
            obj.trace = message.trace;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Denom.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Denom",
            value: Denom.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Denom.decode(message.value);
    },
    toProto (message) {
        return Denom.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.Denom",
            value: Denom.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Denom.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ForwardedPacket": (()=>ForwardedPacket),
    "GenesisState": (()=>GenesisState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/token.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
;
function createBaseGenesisState() {
    return {
        portId: "",
        denoms: [],
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}),
        totalEscrowed: [],
        forwardedPackets: []
    };
}
const GenesisState = {
    typeUrl: "/ibc.applications.transfer.v2.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.portId === "string" && Array.isArray(o.denoms) && (!o.denoms.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].is(o.denoms[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params) && Array.isArray(o.totalEscrowed) && (!o.totalEscrowed.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.totalEscrowed[0])) && Array.isArray(o.forwardedPackets) && (!o.forwardedPackets.length || ForwardedPacket.is(o.forwardedPackets[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.port_id === "string" && Array.isArray(o.denoms) && (!o.denoms.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].isAmino(o.denoms[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params) && Array.isArray(o.total_escrowed) && (!o.total_escrowed.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.total_escrowed[0])) && Array.isArray(o.forwarded_packets) && (!o.forwarded_packets.length || ForwardedPacket.isAmino(o.forwarded_packets[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.portId !== "") {
            writer.uint32(10).string(message.portId);
        }
        for (const v of message.denoms){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.totalEscrowed){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.forwardedPackets){
            ForwardedPacket.encode(v, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.portId = reader.string();
                    break;
                case 2:
                    message.denoms.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.totalEscrowed.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.forwardedPackets.push(ForwardedPacket.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.portId = object.portId ?? "";
        message.denoms = object.denoms?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromPartial(e)) || [];
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        message.totalEscrowed = object.totalEscrowed?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.forwardedPackets = object.forwardedPackets?.map((e)=>ForwardedPacket.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.port_id !== undefined && object.port_id !== null) {
            message.portId = object.port_id;
        }
        message.denoms = object.denoms?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromAmino(e)) || [];
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        message.totalEscrowed = object.total_escrowed?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.forwardedPackets = object.forwarded_packets?.map((e)=>ForwardedPacket.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.port_id = message.portId === "" ? undefined : message.portId;
        if (message.denoms) {
            obj.denoms = message.denoms.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].toAmino(e) : undefined);
        } else {
            obj.denoms = message.denoms;
        }
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        if (message.totalEscrowed) {
            obj.total_escrowed = message.totalEscrowed.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.total_escrowed = message.totalEscrowed;
        }
        if (message.forwardedPackets) {
            obj.forwarded_packets = message.forwardedPackets.map((e)=>e ? ForwardedPacket.toAmino(e) : undefined);
        } else {
            obj.forwarded_packets = message.forwardedPackets;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        ForwardedPacket.registerTypeUrl();
    }
};
function createBaseForwardedPacket() {
    return {
        forwardKey: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial({}),
        packet: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].fromPartial({})
    };
}
const ForwardedPacket = {
    typeUrl: "/ibc.applications.transfer.v2.ForwardedPacket",
    aminoType: "cosmos-sdk/ForwardedPacket",
    is (o) {
        return o && (o.$typeUrl === ForwardedPacket.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].is(o.forwardKey) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].is(o.packet));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ForwardedPacket.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].isAmino(o.forward_key) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].isAmino(o.packet));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.forwardKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].encode(message.forwardKey, writer.uint32(10).fork()).ldelim();
        }
        if (message.packet !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].encode(message.packet, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseForwardedPacket();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.forwardKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.packet = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseForwardedPacket();
        message.forwardKey = object.forwardKey !== undefined && object.forwardKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromPartial(object.forwardKey) : undefined;
        message.packet = object.packet !== undefined && object.packet !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].fromPartial(object.packet) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseForwardedPacket();
        if (object.forward_key !== undefined && object.forward_key !== null) {
            message.forwardKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].fromAmino(object.forward_key);
        }
        if (object.packet !== undefined && object.packet !== null) {
            message.packet = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].fromAmino(object.packet);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.forward_key = message.forwardKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].toAmino(message.forwardKey) : undefined;
        obj.packet = message.packet ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].toAmino(message.packet) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ForwardedPacket.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ForwardedPacket",
            value: ForwardedPacket.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ForwardedPacket.decode(message.value);
    },
    toProto (message) {
        return ForwardedPacket.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.ForwardedPacket",
            value: ForwardedPacket.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ForwardedPacket.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PacketId"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Packet"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/packet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ForwardingPacketData": (()=>ForwardingPacketData),
    "FungibleTokenPacketData": (()=>FungibleTokenPacketData),
    "FungibleTokenPacketDataV2": (()=>FungibleTokenPacketDataV2)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/token.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/transfer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseFungibleTokenPacketData() {
    return {
        denom: "",
        amount: "",
        sender: "",
        receiver: "",
        memo: ""
    };
}
const FungibleTokenPacketData = {
    typeUrl: "/ibc.applications.transfer.v2.FungibleTokenPacketData",
    aminoType: "cosmos-sdk/FungibleTokenPacketData",
    is (o) {
        return o && (o.$typeUrl === FungibleTokenPacketData.typeUrl || typeof o.denom === "string" && typeof o.amount === "string" && typeof o.sender === "string" && typeof o.receiver === "string" && typeof o.memo === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === FungibleTokenPacketData.typeUrl || typeof o.denom === "string" && typeof o.amount === "string" && typeof o.sender === "string" && typeof o.receiver === "string" && typeof o.memo === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        if (message.amount !== "") {
            writer.uint32(18).string(message.amount);
        }
        if (message.sender !== "") {
            writer.uint32(26).string(message.sender);
        }
        if (message.receiver !== "") {
            writer.uint32(34).string(message.receiver);
        }
        if (message.memo !== "") {
            writer.uint32(42).string(message.memo);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFungibleTokenPacketData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                case 2:
                    message.amount = reader.string();
                    break;
                case 3:
                    message.sender = reader.string();
                    break;
                case 4:
                    message.receiver = reader.string();
                    break;
                case 5:
                    message.memo = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFungibleTokenPacketData();
        message.denom = object.denom ?? "";
        message.amount = object.amount ?? "";
        message.sender = object.sender ?? "";
        message.receiver = object.receiver ?? "";
        message.memo = object.memo ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseFungibleTokenPacketData();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = object.amount;
        }
        if (object.sender !== undefined && object.sender !== null) {
            message.sender = object.sender;
        }
        if (object.receiver !== undefined && object.receiver !== null) {
            message.receiver = object.receiver;
        }
        if (object.memo !== undefined && object.memo !== null) {
            message.memo = object.memo;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        obj.amount = message.amount === "" ? undefined : message.amount;
        obj.sender = message.sender === "" ? undefined : message.sender;
        obj.receiver = message.receiver === "" ? undefined : message.receiver;
        obj.memo = message.memo === "" ? undefined : message.memo;
        return obj;
    },
    fromAminoMsg (object) {
        return FungibleTokenPacketData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/FungibleTokenPacketData",
            value: FungibleTokenPacketData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return FungibleTokenPacketData.decode(message.value);
    },
    toProto (message) {
        return FungibleTokenPacketData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.FungibleTokenPacketData",
            value: FungibleTokenPacketData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseFungibleTokenPacketDataV2() {
    return {
        tokens: [],
        sender: "",
        receiver: "",
        memo: "",
        forwarding: ForwardingPacketData.fromPartial({})
    };
}
const FungibleTokenPacketDataV2 = {
    typeUrl: "/ibc.applications.transfer.v2.FungibleTokenPacketDataV2",
    aminoType: "cosmos-sdk/FungibleTokenPacketDataV2",
    is (o) {
        return o && (o.$typeUrl === FungibleTokenPacketDataV2.typeUrl || Array.isArray(o.tokens) && (!o.tokens.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].is(o.tokens[0])) && typeof o.sender === "string" && typeof o.receiver === "string" && typeof o.memo === "string" && ForwardingPacketData.is(o.forwarding));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FungibleTokenPacketDataV2.typeUrl || Array.isArray(o.tokens) && (!o.tokens.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].isAmino(o.tokens[0])) && typeof o.sender === "string" && typeof o.receiver === "string" && typeof o.memo === "string" && ForwardingPacketData.isAmino(o.forwarding));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.tokens){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.sender !== "") {
            writer.uint32(18).string(message.sender);
        }
        if (message.receiver !== "") {
            writer.uint32(26).string(message.receiver);
        }
        if (message.memo !== "") {
            writer.uint32(34).string(message.memo);
        }
        if (message.forwarding !== undefined) {
            ForwardingPacketData.encode(message.forwarding, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFungibleTokenPacketDataV2();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.tokens.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.sender = reader.string();
                    break;
                case 3:
                    message.receiver = reader.string();
                    break;
                case 4:
                    message.memo = reader.string();
                    break;
                case 5:
                    message.forwarding = ForwardingPacketData.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFungibleTokenPacketDataV2();
        message.tokens = object.tokens?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].fromPartial(e)) || [];
        message.sender = object.sender ?? "";
        message.receiver = object.receiver ?? "";
        message.memo = object.memo ?? "";
        message.forwarding = object.forwarding !== undefined && object.forwarding !== null ? ForwardingPacketData.fromPartial(object.forwarding) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFungibleTokenPacketDataV2();
        message.tokens = object.tokens?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].fromAmino(e)) || [];
        if (object.sender !== undefined && object.sender !== null) {
            message.sender = object.sender;
        }
        if (object.receiver !== undefined && object.receiver !== null) {
            message.receiver = object.receiver;
        }
        if (object.memo !== undefined && object.memo !== null) {
            message.memo = object.memo;
        }
        if (object.forwarding !== undefined && object.forwarding !== null) {
            message.forwarding = ForwardingPacketData.fromAmino(object.forwarding);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.tokens) {
            obj.tokens = message.tokens.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].toAmino(e) : undefined);
        } else {
            obj.tokens = message.tokens;
        }
        obj.sender = message.sender === "" ? undefined : message.sender;
        obj.receiver = message.receiver === "" ? undefined : message.receiver;
        obj.memo = message.memo === "" ? undefined : message.memo;
        obj.forwarding = message.forwarding ? ForwardingPacketData.toAmino(message.forwarding) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return FungibleTokenPacketDataV2.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/FungibleTokenPacketDataV2",
            value: FungibleTokenPacketDataV2.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return FungibleTokenPacketDataV2.decode(message.value);
    },
    toProto (message) {
        return FungibleTokenPacketDataV2.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.FungibleTokenPacketDataV2",
            value: FungibleTokenPacketDataV2.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FungibleTokenPacketDataV2.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Token"].registerTypeUrl();
        ForwardingPacketData.registerTypeUrl();
    }
};
function createBaseForwardingPacketData() {
    return {
        destinationMemo: "",
        hops: []
    };
}
const ForwardingPacketData = {
    typeUrl: "/ibc.applications.transfer.v2.ForwardingPacketData",
    aminoType: "cosmos-sdk/ForwardingPacketData",
    is (o) {
        return o && (o.$typeUrl === ForwardingPacketData.typeUrl || typeof o.destinationMemo === "string" && Array.isArray(o.hops) && (!o.hops.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].is(o.hops[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ForwardingPacketData.typeUrl || typeof o.destination_memo === "string" && Array.isArray(o.hops) && (!o.hops.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].isAmino(o.hops[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.destinationMemo !== "") {
            writer.uint32(10).string(message.destinationMemo);
        }
        for (const v of message.hops){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseForwardingPacketData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.destinationMemo = reader.string();
                    break;
                case 2:
                    message.hops.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseForwardingPacketData();
        message.destinationMemo = object.destinationMemo ?? "";
        message.hops = object.hops?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseForwardingPacketData();
        if (object.destination_memo !== undefined && object.destination_memo !== null) {
            message.destinationMemo = object.destination_memo;
        }
        message.hops = object.hops?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.destination_memo = message.destinationMemo === "" ? undefined : message.destinationMemo;
        if (message.hops) {
            obj.hops = message.hops.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].toAmino(e) : undefined);
        } else {
            obj.hops = message.hops;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return ForwardingPacketData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ForwardingPacketData",
            value: ForwardingPacketData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ForwardingPacketData.decode(message.value);
    },
    toProto (message) {
        return ForwardingPacketData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.ForwardingPacketData",
            value: ForwardingPacketData.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ForwardingPacketData.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$transfer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Hop"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/queryv2.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryDenomRequest": (()=>QueryDenomRequest),
    "QueryDenomResponse": (()=>QueryDenomResponse),
    "QueryDenomsRequest": (()=>QueryDenomsRequest),
    "QueryDenomsResponse": (()=>QueryDenomsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v2/token.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseQueryDenomRequest() {
    return {
        hash: ""
    };
}
const QueryDenomRequest = {
    typeUrl: "/ibc.applications.transfer.v2.QueryDenomRequest",
    aminoType: "cosmos-sdk/QueryDenomRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomRequest.typeUrl || typeof o.hash === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomRequest.typeUrl || typeof o.hash === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.hash !== "") {
            writer.uint32(10).string(message.hash);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hash = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomRequest();
        message.hash = object.hash ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomRequest();
        if (object.hash !== undefined && object.hash !== null) {
            message.hash = object.hash;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.hash = message.hash === "" ? undefined : message.hash;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomRequest",
            value: QueryDenomRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.QueryDenomRequest",
            value: QueryDenomRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDenomResponse() {
    return {
        denom: undefined
    };
}
const QueryDenomResponse = {
    typeUrl: "/ibc.applications.transfer.v2.QueryDenomResponse",
    aminoType: "cosmos-sdk/QueryDenomResponse",
    is (o) {
        return o && o.$typeUrl === QueryDenomResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryDenomResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].encode(message.denom, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomResponse();
        message.denom = object.denom !== undefined && object.denom !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromPartial(object.denom) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomResponse();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromAmino(object.denom);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].toAmino(message.denom) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomResponse",
            value: QueryDenomResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.QueryDenomResponse",
            value: QueryDenomResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].registerTypeUrl();
    }
};
function createBaseQueryDenomsRequest() {
    return {
        pagination: undefined
    };
}
const QueryDenomsRequest = {
    typeUrl: "/ibc.applications.transfer.v2.QueryDenomsRequest",
    aminoType: "cosmos-sdk/QueryDenomsRequest",
    is (o) {
        return o && o.$typeUrl === QueryDenomsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryDenomsRequest.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomsRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomsRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomsRequest",
            value: QueryDenomsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.QueryDenomsRequest",
            value: QueryDenomsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDenomsResponse() {
    return {
        denoms: [],
        pagination: undefined
    };
}
const QueryDenomsResponse = {
    typeUrl: "/ibc.applications.transfer.v2.QueryDenomsResponse",
    aminoType: "cosmos-sdk/QueryDenomsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomsResponse.typeUrl || Array.isArray(o.denoms) && (!o.denoms.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].is(o.denoms[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomsResponse.typeUrl || Array.isArray(o.denoms) && (!o.denoms.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].isAmino(o.denoms[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.denoms){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denoms.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomsResponse();
        message.denoms = object.denoms?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomsResponse();
        message.denoms = object.denoms?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.denoms) {
            obj.denoms = message.denoms.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].toAmino(e) : undefined);
        } else {
            obj.denoms = message.denoms;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomsResponse",
            value: QueryDenomsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.applications.transfer.v2.QueryDenomsResponse",
            value: QueryDenomsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v2$2f$token$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Denom"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/ibc.applications.fee.v1.MsgRegisterPayee",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterPayee"]
    ],
    [
        "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterCounterpartyPayee"]
    ],
    [
        "/ibc.applications.fee.v1.MsgPayPacketFee",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFee"]
    ],
    [
        "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFeeAsync"]
    ]
];
const MessageComposer = {
    encoded: {
        registerPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterPayee"].encode(value).finish()
            };
        },
        registerCounterpartyPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterCounterpartyPayee"].encode(value).finish()
            };
        },
        payPacketFee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFee"].encode(value).finish()
            };
        },
        payPacketFeeAsync (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFeeAsync"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        registerPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayee",
                value
            };
        },
        registerCounterpartyPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
                value
            };
        },
        payPacketFee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFee",
                value
            };
        },
        payPacketFeeAsync (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
                value
            };
        }
    },
    fromPartial: {
        registerPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterPayee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterPayee"].fromPartial(value)
            };
        },
        registerCounterpartyPayee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgRegisterCounterpartyPayee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterCounterpartyPayee"].fromPartial(value)
            };
        },
        payPacketFee (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFee",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFee"].fromPartial(value)
            };
        },
        payPacketFeeAsync (value) {
            return {
                typeUrl: "/ibc.applications.fee.v1.MsgPayPacketFeeAsync",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFeeAsync"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterInterchainAccount"]
    ],
    [
        "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSendTx"]
    ],
    [
        "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ]
];
const MessageComposer = {
    encoded: {
        registerInterchainAccount (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterInterchainAccount"].encode(value).finish()
            };
        },
        sendTx (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSendTx"].encode(value).finish()
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        registerInterchainAccount (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value
            };
        },
        sendTx (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value
            };
        }
    },
    fromPartial: {
        registerInterchainAccount (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgRegisterInterchainAccount",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterInterchainAccount"].fromPartial(value)
            };
        },
        sendTx (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgSendTx",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSendTx"].fromPartial(value)
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.controller.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ],
    [
        "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgModuleQuerySafe"]
    ]
];
const MessageComposer = {
    encoded: {
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        },
        moduleQuerySafe (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgModuleQuerySafe"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value
            };
        },
        moduleQuerySafe (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value
            };
        }
    },
    fromPartial: {
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        },
        moduleQuerySafe (value) {
            return {
                typeUrl: "/ibc.applications.interchain_accounts.host.v1.MsgModuleQuerySafe",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgModuleQuerySafe"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/ibc.applications.transfer.v1.MsgTransfer",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgTransfer"]
    ],
    [
        "/ibc.applications.transfer.v1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ]
];
const MessageComposer = {
    encoded: {
        transfer (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgTransfer"].encode(value).finish()
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        transfer (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
                value
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParams",
                value
            };
        }
    },
    fromPartial: {
        transfer (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgTransfer",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgTransfer"].fromPartial(value)
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/ibc.applications.transfer.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCounterpartyPayee": (()=>getCounterpartyPayee),
    "getFeeEnabledChannel": (()=>getFeeEnabledChannel),
    "getFeeEnabledChannels": (()=>getFeeEnabledChannels),
    "getIncentivizedPacket": (()=>getIncentivizedPacket),
    "getIncentivizedPackets": (()=>getIncentivizedPackets),
    "getIncentivizedPacketsForChannel": (()=>getIncentivizedPacketsForChannel),
    "getPayee": (()=>getPayee),
    "getTotalAckFees": (()=>getTotalAckFees),
    "getTotalRecvFees": (()=>getTotalRecvFees),
    "getTotalTimeoutFees": (()=>getTotalTimeoutFees)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/query.js [app-client] (ecmascript)");
;
;
const getIncentivizedPackets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "IncentivizedPackets",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsResponse"]
    ]
});
const getIncentivizedPacket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "IncentivizedPacket",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketResponse"]
    ]
});
const getIncentivizedPacketsForChannel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsForChannelRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsForChannelResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "IncentivizedPacketsForChannel",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsForChannelRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryIncentivizedPacketsForChannelResponse"]
    ]
});
const getTotalRecvFees = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalRecvFeesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalRecvFeesResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "TotalRecvFees",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalRecvFeesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalRecvFeesResponse"]
    ]
});
const getTotalAckFees = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalAckFeesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalAckFeesResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "TotalAckFees",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalAckFeesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalAckFeesResponse"]
    ]
});
const getTotalTimeoutFees = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalTimeoutFeesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalTimeoutFeesResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "TotalTimeoutFees",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalTimeoutFeesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalTimeoutFeesResponse"]
    ]
});
const getPayee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPayeeRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPayeeResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "Payee",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPayeeRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPayeeResponse"]
    ]
});
const getCounterpartyPayee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCounterpartyPayeeRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCounterpartyPayeeResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "CounterpartyPayee",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCounterpartyPayeeRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCounterpartyPayeeResponse"]
    ]
});
const getFeeEnabledChannels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelsResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "FeeEnabledChannels",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelsResponse"]
    ]
});
const getFeeEnabledChannel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelResponse"].decode,
    service: "ibc.applications.fee.v1.Query",
    method: "FeeEnabledChannel",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryFeeEnabledChannelResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getInterchainAccount": (()=>getInterchainAccount),
    "getParams": (()=>getParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/query.js [app-client] (ecmascript)");
;
;
const getInterchainAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryInterchainAccountRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryInterchainAccountResponse"].decode,
    service: "ibc.applications.interchain_accounts.controller.v1.Query",
    method: "InterchainAccount",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryInterchainAccountRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryInterchainAccountResponse"]
    ]
});
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "ibc.applications.interchain_accounts.controller.v1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getParams": (()=>getParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/query.js [app-client] (ecmascript)");
;
;
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "ibc.applications.interchain_accounts.host.v1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDenomHash": (()=>getDenomHash),
    "getEscrowAddress": (()=>getEscrowAddress),
    "getParams": (()=>getParams),
    "getTotalEscrowForDenom": (()=>getTotalEscrowForDenom)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/query.js [app-client] (ecmascript)");
;
;
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "ibc.applications.transfer.v1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
const getDenomHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomHashRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomHashResponse"].decode,
    service: "ibc.applications.transfer.v1.Query",
    method: "DenomHash",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomHashRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomHashResponse"]
    ]
});
const getEscrowAddress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryEscrowAddressRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryEscrowAddressResponse"].decode,
    service: "ibc.applications.transfer.v1.Query",
    method: "EscrowAddress",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryEscrowAddressRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryEscrowAddressResponse"]
    ]
});
const getTotalEscrowForDenom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalEscrowForDenomRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalEscrowForDenomResponse"].decode,
    service: "ibc.applications.transfer.v1.Query",
    method: "TotalEscrowForDenom",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalEscrowForDenomRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalEscrowForDenomResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "payPacketFee": (()=>payPacketFee),
    "payPacketFeeAsync": (()=>payPacketFeeAsync),
    "registerCounterpartyPayee": (()=>registerCounterpartyPayee),
    "registerPayee": (()=>registerPayee)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/fee/v1/tx.js [app-client] (ecmascript)");
;
;
const registerPayee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterPayee"]
});
const registerCounterpartyPayee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterCounterpartyPayee"]
});
const payPacketFee = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFee"]
});
const payPacketFeeAsync = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$fee$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgPayPacketFeeAsync"]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "registerInterchainAccount": (()=>registerInterchainAccount),
    "sendTx": (()=>sendTx),
    "updateParams": (()=>updateParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/controller/v1/tx.js [app-client] (ecmascript)");
;
;
const registerInterchainAccount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRegisterInterchainAccount"]
});
const sendTx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSendTx"]
});
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$controller$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "moduleQuerySafe": (()=>moduleQuerySafe),
    "updateParams": (()=>updateParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/interchain_accounts/host/v1/tx.js [app-client] (ecmascript)");
;
;
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
const moduleQuerySafe = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$interchain_accounts$2f$host$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgModuleQuerySafe"]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "transfer": (()=>transfer),
    "updateParams": (()=>updateParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.js [app-client] (ecmascript)");
;
;
const transfer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgTransfer"]
});
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_ibc_applications_a0fbb0aa._.js.map