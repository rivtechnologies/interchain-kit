(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/authz.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthorizationType": (()=>AuthorizationType),
    "AuthorizationTypeAmino": (()=>AuthorizationTypeAmino),
    "StakeAuthorization": (()=>StakeAuthorization),
    "StakeAuthorization_Validators": (()=>StakeAuthorization_Validators),
    "authorizationTypeFromJSON": (()=>authorizationTypeFromJSON),
    "authorizationTypeToJSON": (()=>authorizationTypeToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
var AuthorizationType;
(function(AuthorizationType) {
    /** AUTHORIZATION_TYPE_UNSPECIFIED - AUTHORIZATION_TYPE_UNSPECIFIED specifies an unknown authorization type */ AuthorizationType[AuthorizationType["AUTHORIZATION_TYPE_UNSPECIFIED"] = 0] = "AUTHORIZATION_TYPE_UNSPECIFIED";
    /** AUTHORIZATION_TYPE_DELEGATE - AUTHORIZATION_TYPE_DELEGATE defines an authorization type for Msg/Delegate */ AuthorizationType[AuthorizationType["AUTHORIZATION_TYPE_DELEGATE"] = 1] = "AUTHORIZATION_TYPE_DELEGATE";
    /** AUTHORIZATION_TYPE_UNDELEGATE - AUTHORIZATION_TYPE_UNDELEGATE defines an authorization type for Msg/Undelegate */ AuthorizationType[AuthorizationType["AUTHORIZATION_TYPE_UNDELEGATE"] = 2] = "AUTHORIZATION_TYPE_UNDELEGATE";
    /** AUTHORIZATION_TYPE_REDELEGATE - AUTHORIZATION_TYPE_REDELEGATE defines an authorization type for Msg/BeginRedelegate */ AuthorizationType[AuthorizationType["AUTHORIZATION_TYPE_REDELEGATE"] = 3] = "AUTHORIZATION_TYPE_REDELEGATE";
    /** AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION - AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION defines an authorization type for Msg/MsgCancelUnbondingDelegation */ AuthorizationType[AuthorizationType["AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION"] = 4] = "AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION";
    AuthorizationType[AuthorizationType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(AuthorizationType || (AuthorizationType = {}));
const AuthorizationTypeAmino = AuthorizationType;
function authorizationTypeFromJSON(object) {
    switch(object){
        case 0:
        case "AUTHORIZATION_TYPE_UNSPECIFIED":
            return AuthorizationType.AUTHORIZATION_TYPE_UNSPECIFIED;
        case 1:
        case "AUTHORIZATION_TYPE_DELEGATE":
            return AuthorizationType.AUTHORIZATION_TYPE_DELEGATE;
        case 2:
        case "AUTHORIZATION_TYPE_UNDELEGATE":
            return AuthorizationType.AUTHORIZATION_TYPE_UNDELEGATE;
        case 3:
        case "AUTHORIZATION_TYPE_REDELEGATE":
            return AuthorizationType.AUTHORIZATION_TYPE_REDELEGATE;
        case 4:
        case "AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION":
            return AuthorizationType.AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION;
        case -1:
        case "UNRECOGNIZED":
        default:
            return AuthorizationType.UNRECOGNIZED;
    }
}
function authorizationTypeToJSON(object) {
    switch(object){
        case AuthorizationType.AUTHORIZATION_TYPE_UNSPECIFIED:
            return "AUTHORIZATION_TYPE_UNSPECIFIED";
        case AuthorizationType.AUTHORIZATION_TYPE_DELEGATE:
            return "AUTHORIZATION_TYPE_DELEGATE";
        case AuthorizationType.AUTHORIZATION_TYPE_UNDELEGATE:
            return "AUTHORIZATION_TYPE_UNDELEGATE";
        case AuthorizationType.AUTHORIZATION_TYPE_REDELEGATE:
            return "AUTHORIZATION_TYPE_REDELEGATE";
        case AuthorizationType.AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION:
            return "AUTHORIZATION_TYPE_CANCEL_UNBONDING_DELEGATION";
        case AuthorizationType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseStakeAuthorization() {
    return {
        maxTokens: undefined,
        allowList: undefined,
        denyList: undefined,
        authorizationType: 0
    };
}
const StakeAuthorization = {
    typeUrl: "/cosmos.staking.v1beta1.StakeAuthorization",
    aminoType: "cosmos-sdk/StakeAuthorization",
    is (o) {
        return o && (o.$typeUrl === StakeAuthorization.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.authorizationType));
    },
    isAmino (o) {
        return o && (o.$typeUrl === StakeAuthorization.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.authorization_type));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.maxTokens !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.maxTokens, writer.uint32(10).fork()).ldelim();
        }
        if (message.allowList !== undefined) {
            StakeAuthorization_Validators.encode(message.allowList, writer.uint32(18).fork()).ldelim();
        }
        if (message.denyList !== undefined) {
            StakeAuthorization_Validators.encode(message.denyList, writer.uint32(26).fork()).ldelim();
        }
        if (message.authorizationType !== 0) {
            writer.uint32(32).int32(message.authorizationType);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseStakeAuthorization();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.maxTokens = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.allowList = StakeAuthorization_Validators.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.denyList = StakeAuthorization_Validators.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.authorizationType = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseStakeAuthorization();
        message.maxTokens = object.maxTokens !== undefined && object.maxTokens !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.maxTokens) : undefined;
        message.allowList = object.allowList !== undefined && object.allowList !== null ? StakeAuthorization_Validators.fromPartial(object.allowList) : undefined;
        message.denyList = object.denyList !== undefined && object.denyList !== null ? StakeAuthorization_Validators.fromPartial(object.denyList) : undefined;
        message.authorizationType = object.authorizationType ?? 0;
        return message;
    },
    fromAmino (object) {
        const message = createBaseStakeAuthorization();
        if (object.max_tokens !== undefined && object.max_tokens !== null) {
            message.maxTokens = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.max_tokens);
        }
        if (object.allow_list !== undefined && object.allow_list !== null) {
            message.allowList = StakeAuthorization_Validators.fromAmino(object.allow_list);
        }
        if (object.deny_list !== undefined && object.deny_list !== null) {
            message.denyList = StakeAuthorization_Validators.fromAmino(object.deny_list);
        }
        if (object.authorization_type !== undefined && object.authorization_type !== null) {
            message.authorizationType = object.authorization_type;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.max_tokens = message.maxTokens ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.maxTokens) : undefined;
        obj.allow_list = message.allowList ? StakeAuthorization_Validators.toAmino(message.allowList) : undefined;
        obj.deny_list = message.denyList ? StakeAuthorization_Validators.toAmino(message.denyList) : undefined;
        obj.authorization_type = message.authorizationType === 0 ? undefined : message.authorizationType;
        return obj;
    },
    fromAminoMsg (object) {
        return StakeAuthorization.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/StakeAuthorization",
            value: StakeAuthorization.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return StakeAuthorization.decode(message.value);
    },
    toProto (message) {
        return StakeAuthorization.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.StakeAuthorization",
            value: StakeAuthorization.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(StakeAuthorization.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(StakeAuthorization.typeUrl, StakeAuthorization);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(StakeAuthorization.aminoType, StakeAuthorization.typeUrl);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        StakeAuthorization_Validators.registerTypeUrl();
    }
};
function createBaseStakeAuthorization_Validators() {
    return {
        address: []
    };
}
const StakeAuthorization_Validators = {
    typeUrl: "/cosmos.staking.v1beta1.Validators",
    aminoType: "cosmos-sdk/Validators",
    is (o) {
        return o && (o.$typeUrl === StakeAuthorization_Validators.typeUrl || Array.isArray(o.address) && (!o.address.length || typeof o.address[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === StakeAuthorization_Validators.typeUrl || Array.isArray(o.address) && (!o.address.length || typeof o.address[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.address){
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseStakeAuthorization_Validators();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseStakeAuthorization_Validators();
        message.address = object.address?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseStakeAuthorization_Validators();
        message.address = object.address?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.address) {
            obj.address = message.address.map((e)=>e);
        } else {
            obj.address = message.address;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return StakeAuthorization_Validators.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Validators",
            value: StakeAuthorization_Validators.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return StakeAuthorization_Validators.decode(message.value);
    },
    toProto (message) {
        return StakeAuthorization_Validators.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Validators",
            value: StakeAuthorization_Validators.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/module/v1/module.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Module": (()=>Module)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseModule() {
    return {
        hooksOrder: [],
        authority: "",
        bech32PrefixValidator: "",
        bech32PrefixConsensus: ""
    };
}
const Module = {
    typeUrl: "/cosmos.staking.module.v1.Module",
    aminoType: "cosmos-sdk/Module",
    is (o) {
        return o && (o.$typeUrl === Module.typeUrl || Array.isArray(o.hooksOrder) && (!o.hooksOrder.length || typeof o.hooksOrder[0] === "string") && typeof o.authority === "string" && typeof o.bech32PrefixValidator === "string" && typeof o.bech32PrefixConsensus === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Module.typeUrl || Array.isArray(o.hooks_order) && (!o.hooks_order.length || typeof o.hooks_order[0] === "string") && typeof o.authority === "string" && typeof o.bech32_prefix_validator === "string" && typeof o.bech32_prefix_consensus === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.hooksOrder){
            writer.uint32(10).string(v);
        }
        if (message.authority !== "") {
            writer.uint32(18).string(message.authority);
        }
        if (message.bech32PrefixValidator !== "") {
            writer.uint32(26).string(message.bech32PrefixValidator);
        }
        if (message.bech32PrefixConsensus !== "") {
            writer.uint32(34).string(message.bech32PrefixConsensus);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseModule();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hooksOrder.push(reader.string());
                    break;
                case 2:
                    message.authority = reader.string();
                    break;
                case 3:
                    message.bech32PrefixValidator = reader.string();
                    break;
                case 4:
                    message.bech32PrefixConsensus = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseModule();
        message.hooksOrder = object.hooksOrder?.map((e)=>e) || [];
        message.authority = object.authority ?? "";
        message.bech32PrefixValidator = object.bech32PrefixValidator ?? "";
        message.bech32PrefixConsensus = object.bech32PrefixConsensus ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseModule();
        message.hooksOrder = object.hooks_order?.map((e)=>e) || [];
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        if (object.bech32_prefix_validator !== undefined && object.bech32_prefix_validator !== null) {
            message.bech32PrefixValidator = object.bech32_prefix_validator;
        }
        if (object.bech32_prefix_consensus !== undefined && object.bech32_prefix_consensus !== null) {
            message.bech32PrefixConsensus = object.bech32_prefix_consensus;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.hooksOrder) {
            obj.hooks_order = message.hooksOrder.map((e)=>e);
        } else {
            obj.hooks_order = message.hooksOrder;
        }
        obj.authority = message.authority === "" ? undefined : message.authority;
        obj.bech32_prefix_validator = message.bech32PrefixValidator === "" ? undefined : message.bech32PrefixValidator;
        obj.bech32_prefix_consensus = message.bech32PrefixConsensus === "" ? undefined : message.bech32PrefixConsensus;
        return obj;
    },
    fromAminoMsg (object) {
        return Module.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Module",
            value: Module.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Module.decode(message.value);
    },
    toProto (message) {
        return Module.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.module.v1.Module",
            value: Module.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/staking.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "BondStatus": (()=>BondStatus),
    "BondStatusAmino": (()=>BondStatusAmino),
    "Commission": (()=>Commission),
    "CommissionRates": (()=>CommissionRates),
    "DVPair": (()=>DVPair),
    "DVPairs": (()=>DVPairs),
    "DVVTriplet": (()=>DVVTriplet),
    "DVVTriplets": (()=>DVVTriplets),
    "Delegation": (()=>Delegation),
    "DelegationResponse": (()=>DelegationResponse),
    "Description": (()=>Description),
    "HistoricalInfo": (()=>HistoricalInfo),
    "Infraction": (()=>Infraction),
    "InfractionAmino": (()=>InfractionAmino),
    "Params": (()=>Params),
    "Pool": (()=>Pool),
    "Redelegation": (()=>Redelegation),
    "RedelegationEntry": (()=>RedelegationEntry),
    "RedelegationEntryResponse": (()=>RedelegationEntryResponse),
    "RedelegationResponse": (()=>RedelegationResponse),
    "UnbondingDelegation": (()=>UnbondingDelegation),
    "UnbondingDelegationEntry": (()=>UnbondingDelegationEntry),
    "ValAddresses": (()=>ValAddresses),
    "Validator": (()=>Validator),
    "ValidatorUpdates": (()=>ValidatorUpdates),
    "bondStatusFromJSON": (()=>bondStatusFromJSON),
    "bondStatusToJSON": (()=>bondStatusToJSON),
    "infractionFromJSON": (()=>infractionFromJSON),
    "infractionToJSON": (()=>infractionToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/tendermint/types/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/tendermint/abci/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/decimal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/pubkey.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
var BondStatus;
(function(BondStatus) {
    /** BOND_STATUS_UNSPECIFIED - UNSPECIFIED defines an invalid validator status. */ BondStatus[BondStatus["BOND_STATUS_UNSPECIFIED"] = 0] = "BOND_STATUS_UNSPECIFIED";
    /** BOND_STATUS_UNBONDED - UNBONDED defines a validator that is not bonded. */ BondStatus[BondStatus["BOND_STATUS_UNBONDED"] = 1] = "BOND_STATUS_UNBONDED";
    /** BOND_STATUS_UNBONDING - UNBONDING defines a validator that is unbonding. */ BondStatus[BondStatus["BOND_STATUS_UNBONDING"] = 2] = "BOND_STATUS_UNBONDING";
    /** BOND_STATUS_BONDED - BONDED defines a validator that is bonded. */ BondStatus[BondStatus["BOND_STATUS_BONDED"] = 3] = "BOND_STATUS_BONDED";
    BondStatus[BondStatus["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(BondStatus || (BondStatus = {}));
const BondStatusAmino = BondStatus;
function bondStatusFromJSON(object) {
    switch(object){
        case 0:
        case "BOND_STATUS_UNSPECIFIED":
            return BondStatus.BOND_STATUS_UNSPECIFIED;
        case 1:
        case "BOND_STATUS_UNBONDED":
            return BondStatus.BOND_STATUS_UNBONDED;
        case 2:
        case "BOND_STATUS_UNBONDING":
            return BondStatus.BOND_STATUS_UNBONDING;
        case 3:
        case "BOND_STATUS_BONDED":
            return BondStatus.BOND_STATUS_BONDED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return BondStatus.UNRECOGNIZED;
    }
}
function bondStatusToJSON(object) {
    switch(object){
        case BondStatus.BOND_STATUS_UNSPECIFIED:
            return "BOND_STATUS_UNSPECIFIED";
        case BondStatus.BOND_STATUS_UNBONDED:
            return "BOND_STATUS_UNBONDED";
        case BondStatus.BOND_STATUS_UNBONDING:
            return "BOND_STATUS_UNBONDING";
        case BondStatus.BOND_STATUS_BONDED:
            return "BOND_STATUS_BONDED";
        case BondStatus.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var Infraction;
(function(Infraction) {
    /** INFRACTION_UNSPECIFIED - UNSPECIFIED defines an empty infraction. */ Infraction[Infraction["INFRACTION_UNSPECIFIED"] = 0] = "INFRACTION_UNSPECIFIED";
    /** INFRACTION_DOUBLE_SIGN - DOUBLE_SIGN defines a validator that double-signs a block. */ Infraction[Infraction["INFRACTION_DOUBLE_SIGN"] = 1] = "INFRACTION_DOUBLE_SIGN";
    /** INFRACTION_DOWNTIME - DOWNTIME defines a validator that missed signing too many blocks. */ Infraction[Infraction["INFRACTION_DOWNTIME"] = 2] = "INFRACTION_DOWNTIME";
    Infraction[Infraction["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Infraction || (Infraction = {}));
const InfractionAmino = Infraction;
function infractionFromJSON(object) {
    switch(object){
        case 0:
        case "INFRACTION_UNSPECIFIED":
            return Infraction.INFRACTION_UNSPECIFIED;
        case 1:
        case "INFRACTION_DOUBLE_SIGN":
            return Infraction.INFRACTION_DOUBLE_SIGN;
        case 2:
        case "INFRACTION_DOWNTIME":
            return Infraction.INFRACTION_DOWNTIME;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Infraction.UNRECOGNIZED;
    }
}
function infractionToJSON(object) {
    switch(object){
        case Infraction.INFRACTION_UNSPECIFIED:
            return "INFRACTION_UNSPECIFIED";
        case Infraction.INFRACTION_DOUBLE_SIGN:
            return "INFRACTION_DOUBLE_SIGN";
        case Infraction.INFRACTION_DOWNTIME:
            return "INFRACTION_DOWNTIME";
        case Infraction.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseHistoricalInfo() {
    return {
        header: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].fromPartial({}),
        valset: []
    };
}
const HistoricalInfo = {
    typeUrl: "/cosmos.staking.v1beta1.HistoricalInfo",
    aminoType: "cosmos-sdk/HistoricalInfo",
    is (o) {
        return o && (o.$typeUrl === HistoricalInfo.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].is(o.header) && Array.isArray(o.valset) && (!o.valset.length || Validator.is(o.valset[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === HistoricalInfo.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].isAmino(o.header) && Array.isArray(o.valset) && (!o.valset.length || Validator.isAmino(o.valset[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.header !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].encode(message.header, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.valset){
            Validator.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHistoricalInfo();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.header = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.valset.push(Validator.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHistoricalInfo();
        message.header = object.header !== undefined && object.header !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].fromPartial(object.header) : undefined;
        message.valset = object.valset?.map((e)=>Validator.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseHistoricalInfo();
        if (object.header !== undefined && object.header !== null) {
            message.header = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].fromAmino(object.header);
        }
        message.valset = object.valset?.map((e)=>Validator.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.header = message.header ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].toAmino(message.header) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].fromPartial({}));
        if (message.valset) {
            obj.valset = message.valset.map((e)=>e ? Validator.toAmino(e) : undefined);
        } else {
            obj.valset = message.valset;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return HistoricalInfo.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/HistoricalInfo",
            value: HistoricalInfo.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return HistoricalInfo.decode(message.value);
    },
    toProto (message) {
        return HistoricalInfo.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.HistoricalInfo",
            value: HistoricalInfo.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(HistoricalInfo.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Header"].registerTypeUrl();
        Validator.registerTypeUrl();
    }
};
function createBaseCommissionRates() {
    return {
        rate: "",
        maxRate: "",
        maxChangeRate: ""
    };
}
const CommissionRates = {
    typeUrl: "/cosmos.staking.v1beta1.CommissionRates",
    aminoType: "cosmos-sdk/CommissionRates",
    is (o) {
        return o && (o.$typeUrl === CommissionRates.typeUrl || typeof o.rate === "string" && typeof o.maxRate === "string" && typeof o.maxChangeRate === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === CommissionRates.typeUrl || typeof o.rate === "string" && typeof o.max_rate === "string" && typeof o.max_change_rate === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.rate !== "") {
            writer.uint32(10).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.rate, 18).atomics);
        }
        if (message.maxRate !== "") {
            writer.uint32(18).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.maxRate, 18).atomics);
        }
        if (message.maxChangeRate !== "") {
            writer.uint32(26).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.maxChangeRate, 18).atomics);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCommissionRates();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.rate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                case 2:
                    message.maxRate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                case 3:
                    message.maxChangeRate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseCommissionRates();
        message.rate = object.rate ?? "";
        message.maxRate = object.maxRate ?? "";
        message.maxChangeRate = object.maxChangeRate ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseCommissionRates();
        if (object.rate !== undefined && object.rate !== null) {
            message.rate = object.rate;
        }
        if (object.max_rate !== undefined && object.max_rate !== null) {
            message.maxRate = object.max_rate;
        }
        if (object.max_change_rate !== undefined && object.max_change_rate !== null) {
            message.maxChangeRate = object.max_change_rate;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.rate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.rate, 18).atomics ?? "";
        obj.max_rate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.maxRate, 18).atomics ?? "";
        obj.max_change_rate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.maxChangeRate, 18).atomics ?? "";
        return obj;
    },
    fromAminoMsg (object) {
        return CommissionRates.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/CommissionRates",
            value: CommissionRates.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return CommissionRates.decode(message.value);
    },
    toProto (message) {
        return CommissionRates.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.CommissionRates",
            value: CommissionRates.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseCommission() {
    return {
        commissionRates: CommissionRates.fromPartial({}),
        updateTime: new Date()
    };
}
const Commission = {
    typeUrl: "/cosmos.staking.v1beta1.Commission",
    aminoType: "cosmos-sdk/Commission",
    is (o) {
        return o && (o.$typeUrl === Commission.typeUrl || CommissionRates.is(o.commissionRates) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.updateTime));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Commission.typeUrl || CommissionRates.isAmino(o.commission_rates) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.update_time));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.commissionRates !== undefined) {
            CommissionRates.encode(message.commissionRates, writer.uint32(10).fork()).ldelim();
        }
        if (message.updateTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.updateTime), writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCommission();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.commissionRates = CommissionRates.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.updateTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseCommission();
        message.commissionRates = object.commissionRates !== undefined && object.commissionRates !== null ? CommissionRates.fromPartial(object.commissionRates) : undefined;
        message.updateTime = object.updateTime ?? undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseCommission();
        if (object.commission_rates !== undefined && object.commission_rates !== null) {
            message.commissionRates = CommissionRates.fromAmino(object.commission_rates);
        }
        if (object.update_time !== undefined && object.update_time !== null) {
            message.updateTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.update_time));
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.commission_rates = message.commissionRates ? CommissionRates.toAmino(message.commissionRates) : CommissionRates.toAmino(CommissionRates.fromPartial({}));
        obj.update_time = message.updateTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.updateTime)) : new Date();
        return obj;
    },
    fromAminoMsg (object) {
        return Commission.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Commission",
            value: Commission.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Commission.decode(message.value);
    },
    toProto (message) {
        return Commission.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Commission",
            value: Commission.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Commission.typeUrl)) {
            return;
        }
        CommissionRates.registerTypeUrl();
    }
};
function createBaseDescription() {
    return {
        moniker: "",
        identity: "",
        website: "",
        securityContact: "",
        details: ""
    };
}
const Description = {
    typeUrl: "/cosmos.staking.v1beta1.Description",
    aminoType: "cosmos-sdk/Description",
    is (o) {
        return o && (o.$typeUrl === Description.typeUrl || typeof o.moniker === "string" && typeof o.identity === "string" && typeof o.website === "string" && typeof o.securityContact === "string" && typeof o.details === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Description.typeUrl || typeof o.moniker === "string" && typeof o.identity === "string" && typeof o.website === "string" && typeof o.security_contact === "string" && typeof o.details === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.moniker !== "") {
            writer.uint32(10).string(message.moniker);
        }
        if (message.identity !== "") {
            writer.uint32(18).string(message.identity);
        }
        if (message.website !== "") {
            writer.uint32(26).string(message.website);
        }
        if (message.securityContact !== "") {
            writer.uint32(34).string(message.securityContact);
        }
        if (message.details !== "") {
            writer.uint32(42).string(message.details);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDescription();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.moniker = reader.string();
                    break;
                case 2:
                    message.identity = reader.string();
                    break;
                case 3:
                    message.website = reader.string();
                    break;
                case 4:
                    message.securityContact = reader.string();
                    break;
                case 5:
                    message.details = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDescription();
        message.moniker = object.moniker ?? "";
        message.identity = object.identity ?? "";
        message.website = object.website ?? "";
        message.securityContact = object.securityContact ?? "";
        message.details = object.details ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseDescription();
        if (object.moniker !== undefined && object.moniker !== null) {
            message.moniker = object.moniker;
        }
        if (object.identity !== undefined && object.identity !== null) {
            message.identity = object.identity;
        }
        if (object.website !== undefined && object.website !== null) {
            message.website = object.website;
        }
        if (object.security_contact !== undefined && object.security_contact !== null) {
            message.securityContact = object.security_contact;
        }
        if (object.details !== undefined && object.details !== null) {
            message.details = object.details;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.moniker = message.moniker === "" ? undefined : message.moniker;
        obj.identity = message.identity === "" ? undefined : message.identity;
        obj.website = message.website === "" ? undefined : message.website;
        obj.security_contact = message.securityContact === "" ? undefined : message.securityContact;
        obj.details = message.details === "" ? undefined : message.details;
        return obj;
    },
    fromAminoMsg (object) {
        return Description.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Description",
            value: Description.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Description.decode(message.value);
    },
    toProto (message) {
        return Description.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Description",
            value: Description.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseValidator() {
    return {
        operatorAddress: "",
        consensusPubkey: undefined,
        jailed: false,
        status: 0,
        tokens: "",
        delegatorShares: "",
        description: Description.fromPartial({}),
        unbondingHeight: BigInt(0),
        unbondingTime: new Date(),
        commission: Commission.fromPartial({}),
        minSelfDelegation: "",
        unbondingOnHoldRefCount: BigInt(0),
        unbondingIds: []
    };
}
const Validator = {
    typeUrl: "/cosmos.staking.v1beta1.Validator",
    aminoType: "cosmos-sdk/Validator",
    is (o) {
        return o && (o.$typeUrl === Validator.typeUrl || typeof o.operatorAddress === "string" && typeof o.jailed === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && typeof o.tokens === "string" && typeof o.delegatorShares === "string" && Description.is(o.description) && typeof o.unbondingHeight === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.unbondingTime) && Commission.is(o.commission) && typeof o.minSelfDelegation === "string" && typeof o.unbondingOnHoldRefCount === "bigint" && Array.isArray(o.unbondingIds) && (!o.unbondingIds.length || typeof o.unbondingIds[0] === "bigint"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Validator.typeUrl || typeof o.operator_address === "string" && typeof o.jailed === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && typeof o.tokens === "string" && typeof o.delegator_shares === "string" && Description.isAmino(o.description) && typeof o.unbonding_height === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.unbonding_time) && Commission.isAmino(o.commission) && typeof o.min_self_delegation === "string" && typeof o.unbonding_on_hold_ref_count === "bigint" && Array.isArray(o.unbonding_ids) && (!o.unbonding_ids.length || typeof o.unbonding_ids[0] === "bigint"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.operatorAddress !== "") {
            writer.uint32(10).string(message.operatorAddress);
        }
        if (message.consensusPubkey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].wrapAny(message.consensusPubkey), writer.uint32(18).fork()).ldelim();
        }
        if (message.jailed === true) {
            writer.uint32(24).bool(message.jailed);
        }
        if (message.status !== 0) {
            writer.uint32(32).int32(message.status);
        }
        if (message.tokens !== "") {
            writer.uint32(42).string(message.tokens);
        }
        if (message.delegatorShares !== "") {
            writer.uint32(50).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.delegatorShares, 18).atomics);
        }
        if (message.description !== undefined) {
            Description.encode(message.description, writer.uint32(58).fork()).ldelim();
        }
        if (message.unbondingHeight !== BigInt(0)) {
            writer.uint32(64).int64(message.unbondingHeight);
        }
        if (message.unbondingTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.unbondingTime), writer.uint32(74).fork()).ldelim();
        }
        if (message.commission !== undefined) {
            Commission.encode(message.commission, writer.uint32(82).fork()).ldelim();
        }
        if (message.minSelfDelegation !== "") {
            writer.uint32(90).string(message.minSelfDelegation);
        }
        if (message.unbondingOnHoldRefCount !== BigInt(0)) {
            writer.uint32(96).int64(message.unbondingOnHoldRefCount);
        }
        writer.uint32(106).fork();
        for (const v of message.unbondingIds){
            writer.uint64(v);
        }
        writer.ldelim();
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseValidator();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.operatorAddress = reader.string();
                    break;
                case 2:
                    message.consensusPubkey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].unwrapAny(reader);
                    break;
                case 3:
                    message.jailed = reader.bool();
                    break;
                case 4:
                    message.status = reader.int32();
                    break;
                case 5:
                    message.tokens = reader.string();
                    break;
                case 6:
                    message.delegatorShares = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                case 7:
                    message.description = Description.decode(reader, reader.uint32());
                    break;
                case 8:
                    message.unbondingHeight = reader.int64();
                    break;
                case 9:
                    message.unbondingTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.commission = Commission.decode(reader, reader.uint32());
                    break;
                case 11:
                    message.minSelfDelegation = reader.string();
                    break;
                case 12:
                    message.unbondingOnHoldRefCount = reader.int64();
                    break;
                case 13:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.unbondingIds.push(reader.uint64());
                        }
                    } else {
                        message.unbondingIds.push(reader.uint64());
                    }
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseValidator();
        message.operatorAddress = object.operatorAddress ?? "";
        message.consensusPubkey = object.consensusPubkey !== undefined && object.consensusPubkey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromPartial(object.consensusPubkey) : undefined;
        message.jailed = object.jailed ?? false;
        message.status = object.status ?? 0;
        message.tokens = object.tokens ?? "";
        message.delegatorShares = object.delegatorShares ?? "";
        message.description = object.description !== undefined && object.description !== null ? Description.fromPartial(object.description) : undefined;
        message.unbondingHeight = object.unbondingHeight !== undefined && object.unbondingHeight !== null ? BigInt(object.unbondingHeight.toString()) : BigInt(0);
        message.unbondingTime = object.unbondingTime ?? undefined;
        message.commission = object.commission !== undefined && object.commission !== null ? Commission.fromPartial(object.commission) : undefined;
        message.minSelfDelegation = object.minSelfDelegation ?? "";
        message.unbondingOnHoldRefCount = object.unbondingOnHoldRefCount !== undefined && object.unbondingOnHoldRefCount !== null ? BigInt(object.unbondingOnHoldRefCount.toString()) : BigInt(0);
        message.unbondingIds = object.unbondingIds?.map((e)=>BigInt(e.toString())) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseValidator();
        if (object.operator_address !== undefined && object.operator_address !== null) {
            message.operatorAddress = object.operator_address;
        }
        if (object.consensus_pubkey !== undefined && object.consensus_pubkey !== null) {
            message.consensusPubkey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodePubkey"])(object.consensus_pubkey);
        }
        if (object.jailed !== undefined && object.jailed !== null) {
            message.jailed = object.jailed;
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.tokens !== undefined && object.tokens !== null) {
            message.tokens = object.tokens;
        }
        if (object.delegator_shares !== undefined && object.delegator_shares !== null) {
            message.delegatorShares = object.delegator_shares;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = Description.fromAmino(object.description);
        }
        if (object.unbonding_height !== undefined && object.unbonding_height !== null) {
            message.unbondingHeight = BigInt(object.unbonding_height);
        }
        if (object.unbonding_time !== undefined && object.unbonding_time !== null) {
            message.unbondingTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.unbonding_time));
        }
        if (object.commission !== undefined && object.commission !== null) {
            message.commission = Commission.fromAmino(object.commission);
        }
        if (object.min_self_delegation !== undefined && object.min_self_delegation !== null) {
            message.minSelfDelegation = object.min_self_delegation;
        }
        if (object.unbonding_on_hold_ref_count !== undefined && object.unbonding_on_hold_ref_count !== null) {
            message.unbondingOnHoldRefCount = BigInt(object.unbonding_on_hold_ref_count);
        }
        message.unbondingIds = object.unbonding_ids?.map((e)=>BigInt(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.operator_address = message.operatorAddress === "" ? undefined : message.operatorAddress;
        obj.consensus_pubkey = message.consensusPubkey ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodePubkey"])(message.consensusPubkey) : undefined;
        obj.jailed = message.jailed === false ? undefined : message.jailed;
        obj.status = message.status === 0 ? undefined : message.status;
        obj.tokens = message.tokens === "" ? undefined : message.tokens;
        obj.delegator_shares = message.delegatorShares === "" ? undefined : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.delegatorShares, 18).atomics;
        obj.description = message.description ? Description.toAmino(message.description) : Description.toAmino(Description.fromPartial({}));
        obj.unbonding_height = message.unbondingHeight !== BigInt(0) ? message.unbondingHeight?.toString() : undefined;
        obj.unbonding_time = message.unbondingTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.unbondingTime)) : new Date();
        obj.commission = message.commission ? Commission.toAmino(message.commission) : Commission.toAmino(Commission.fromPartial({}));
        obj.min_self_delegation = message.minSelfDelegation === "" ? undefined : message.minSelfDelegation;
        obj.unbonding_on_hold_ref_count = message.unbondingOnHoldRefCount !== BigInt(0) ? message.unbondingOnHoldRefCount?.toString() : undefined;
        if (message.unbondingIds) {
            obj.unbonding_ids = message.unbondingIds.map((e)=>e.toString());
        } else {
            obj.unbonding_ids = message.unbondingIds;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Validator.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Validator",
            value: Validator.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Validator.decode(message.value);
    },
    toProto (message) {
        return Validator.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Validator",
            value: Validator.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Validator.typeUrl)) {
            return;
        }
        Description.registerTypeUrl();
        Commission.registerTypeUrl();
    }
};
function createBaseValAddresses() {
    return {
        addresses: []
    };
}
const ValAddresses = {
    typeUrl: "/cosmos.staking.v1beta1.ValAddresses",
    aminoType: "cosmos-sdk/ValAddresses",
    is (o) {
        return o && (o.$typeUrl === ValAddresses.typeUrl || Array.isArray(o.addresses) && (!o.addresses.length || typeof o.addresses[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ValAddresses.typeUrl || Array.isArray(o.addresses) && (!o.addresses.length || typeof o.addresses[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.addresses){
            writer.uint32(10).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseValAddresses();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.addresses.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseValAddresses();
        message.addresses = object.addresses?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseValAddresses();
        message.addresses = object.addresses?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.addresses) {
            obj.addresses = message.addresses.map((e)=>e);
        } else {
            obj.addresses = message.addresses;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return ValAddresses.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ValAddresses",
            value: ValAddresses.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ValAddresses.decode(message.value);
    },
    toProto (message) {
        return ValAddresses.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.ValAddresses",
            value: ValAddresses.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseDVPair() {
    return {
        delegatorAddress: "",
        validatorAddress: ""
    };
}
const DVPair = {
    typeUrl: "/cosmos.staking.v1beta1.DVPair",
    aminoType: "cosmos-sdk/DVPair",
    is (o) {
        return o && (o.$typeUrl === DVPair.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === DVPair.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDVPair();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDVPair();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseDVPair();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        return obj;
    },
    fromAminoMsg (object) {
        return DVPair.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DVPair",
            value: DVPair.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DVPair.decode(message.value);
    },
    toProto (message) {
        return DVPair.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.DVPair",
            value: DVPair.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseDVPairs() {
    return {
        pairs: []
    };
}
const DVPairs = {
    typeUrl: "/cosmos.staking.v1beta1.DVPairs",
    aminoType: "cosmos-sdk/DVPairs",
    is (o) {
        return o && (o.$typeUrl === DVPairs.typeUrl || Array.isArray(o.pairs) && (!o.pairs.length || DVPair.is(o.pairs[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DVPairs.typeUrl || Array.isArray(o.pairs) && (!o.pairs.length || DVPair.isAmino(o.pairs[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.pairs){
            DVPair.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDVPairs();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pairs.push(DVPair.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDVPairs();
        message.pairs = object.pairs?.map((e)=>DVPair.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDVPairs();
        message.pairs = object.pairs?.map((e)=>DVPair.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.pairs) {
            obj.pairs = message.pairs.map((e)=>e ? DVPair.toAmino(e) : undefined);
        } else {
            obj.pairs = message.pairs;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return DVPairs.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DVPairs",
            value: DVPairs.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DVPairs.decode(message.value);
    },
    toProto (message) {
        return DVPairs.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.DVPairs",
            value: DVPairs.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DVPairs.typeUrl)) {
            return;
        }
        DVPair.registerTypeUrl();
    }
};
function createBaseDVVTriplet() {
    return {
        delegatorAddress: "",
        validatorSrcAddress: "",
        validatorDstAddress: ""
    };
}
const DVVTriplet = {
    typeUrl: "/cosmos.staking.v1beta1.DVVTriplet",
    aminoType: "cosmos-sdk/DVVTriplet",
    is (o) {
        return o && (o.$typeUrl === DVVTriplet.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorSrcAddress === "string" && typeof o.validatorDstAddress === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === DVVTriplet.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_src_address === "string" && typeof o.validator_dst_address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorSrcAddress !== "") {
            writer.uint32(18).string(message.validatorSrcAddress);
        }
        if (message.validatorDstAddress !== "") {
            writer.uint32(26).string(message.validatorDstAddress);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDVVTriplet();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorSrcAddress = reader.string();
                    break;
                case 3:
                    message.validatorDstAddress = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDVVTriplet();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorSrcAddress = object.validatorSrcAddress ?? "";
        message.validatorDstAddress = object.validatorDstAddress ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseDVVTriplet();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_src_address !== undefined && object.validator_src_address !== null) {
            message.validatorSrcAddress = object.validator_src_address;
        }
        if (object.validator_dst_address !== undefined && object.validator_dst_address !== null) {
            message.validatorDstAddress = object.validator_dst_address;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_src_address = message.validatorSrcAddress === "" ? undefined : message.validatorSrcAddress;
        obj.validator_dst_address = message.validatorDstAddress === "" ? undefined : message.validatorDstAddress;
        return obj;
    },
    fromAminoMsg (object) {
        return DVVTriplet.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DVVTriplet",
            value: DVVTriplet.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DVVTriplet.decode(message.value);
    },
    toProto (message) {
        return DVVTriplet.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.DVVTriplet",
            value: DVVTriplet.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseDVVTriplets() {
    return {
        triplets: []
    };
}
const DVVTriplets = {
    typeUrl: "/cosmos.staking.v1beta1.DVVTriplets",
    aminoType: "cosmos-sdk/DVVTriplets",
    is (o) {
        return o && (o.$typeUrl === DVVTriplets.typeUrl || Array.isArray(o.triplets) && (!o.triplets.length || DVVTriplet.is(o.triplets[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DVVTriplets.typeUrl || Array.isArray(o.triplets) && (!o.triplets.length || DVVTriplet.isAmino(o.triplets[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.triplets){
            DVVTriplet.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDVVTriplets();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.triplets.push(DVVTriplet.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDVVTriplets();
        message.triplets = object.triplets?.map((e)=>DVVTriplet.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDVVTriplets();
        message.triplets = object.triplets?.map((e)=>DVVTriplet.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.triplets) {
            obj.triplets = message.triplets.map((e)=>e ? DVVTriplet.toAmino(e) : undefined);
        } else {
            obj.triplets = message.triplets;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return DVVTriplets.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DVVTriplets",
            value: DVVTriplets.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DVVTriplets.decode(message.value);
    },
    toProto (message) {
        return DVVTriplets.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.DVVTriplets",
            value: DVVTriplets.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DVVTriplets.typeUrl)) {
            return;
        }
        DVVTriplet.registerTypeUrl();
    }
};
function createBaseDelegation() {
    return {
        delegatorAddress: "",
        validatorAddress: "",
        shares: ""
    };
}
const Delegation = {
    typeUrl: "/cosmos.staking.v1beta1.Delegation",
    aminoType: "cosmos-sdk/Delegation",
    is (o) {
        return o && (o.$typeUrl === Delegation.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && typeof o.shares === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Delegation.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string" && typeof o.shares === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        if (message.shares !== "") {
            writer.uint32(26).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.shares, 18).atomics);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDelegation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.shares = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDelegation();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.shares = object.shares ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseDelegation();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.shares !== undefined && object.shares !== null) {
            message.shares = object.shares;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.shares = message.shares === "" ? undefined : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.shares, 18).atomics;
        return obj;
    },
    fromAminoMsg (object) {
        return Delegation.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Delegation",
            value: Delegation.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Delegation.decode(message.value);
    },
    toProto (message) {
        return Delegation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Delegation",
            value: Delegation.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseUnbondingDelegation() {
    return {
        delegatorAddress: "",
        validatorAddress: "",
        entries: []
    };
}
const UnbondingDelegation = {
    typeUrl: "/cosmos.staking.v1beta1.UnbondingDelegation",
    aminoType: "cosmos-sdk/UnbondingDelegation",
    is (o) {
        return o && (o.$typeUrl === UnbondingDelegation.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && Array.isArray(o.entries) && (!o.entries.length || UnbondingDelegationEntry.is(o.entries[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === UnbondingDelegation.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string" && Array.isArray(o.entries) && (!o.entries.length || UnbondingDelegationEntry.isAmino(o.entries[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        for (const v of message.entries){
            UnbondingDelegationEntry.encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUnbondingDelegation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.entries.push(UnbondingDelegationEntry.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseUnbondingDelegation();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.entries = object.entries?.map((e)=>UnbondingDelegationEntry.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseUnbondingDelegation();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        message.entries = object.entries?.map((e)=>UnbondingDelegationEntry.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        if (message.entries) {
            obj.entries = message.entries.map((e)=>e ? UnbondingDelegationEntry.toAmino(e) : undefined);
        } else {
            obj.entries = message.entries;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return UnbondingDelegation.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/UnbondingDelegation",
            value: UnbondingDelegation.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return UnbondingDelegation.decode(message.value);
    },
    toProto (message) {
        return UnbondingDelegation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.UnbondingDelegation",
            value: UnbondingDelegation.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(UnbondingDelegation.typeUrl)) {
            return;
        }
        UnbondingDelegationEntry.registerTypeUrl();
    }
};
function createBaseUnbondingDelegationEntry() {
    return {
        creationHeight: BigInt(0),
        completionTime: new Date(),
        initialBalance: "",
        balance: "",
        unbondingId: BigInt(0),
        unbondingOnHoldRefCount: BigInt(0)
    };
}
const UnbondingDelegationEntry = {
    typeUrl: "/cosmos.staking.v1beta1.UnbondingDelegationEntry",
    aminoType: "cosmos-sdk/UnbondingDelegationEntry",
    is (o) {
        return o && (o.$typeUrl === UnbondingDelegationEntry.typeUrl || typeof o.creationHeight === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.completionTime) && typeof o.initialBalance === "string" && typeof o.balance === "string" && typeof o.unbondingId === "bigint" && typeof o.unbondingOnHoldRefCount === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === UnbondingDelegationEntry.typeUrl || typeof o.creation_height === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.completion_time) && typeof o.initial_balance === "string" && typeof o.balance === "string" && typeof o.unbonding_id === "bigint" && typeof o.unbonding_on_hold_ref_count === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.creationHeight !== BigInt(0)) {
            writer.uint32(8).int64(message.creationHeight);
        }
        if (message.completionTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime), writer.uint32(18).fork()).ldelim();
        }
        if (message.initialBalance !== "") {
            writer.uint32(26).string(message.initialBalance);
        }
        if (message.balance !== "") {
            writer.uint32(34).string(message.balance);
        }
        if (message.unbondingId !== BigInt(0)) {
            writer.uint32(40).uint64(message.unbondingId);
        }
        if (message.unbondingOnHoldRefCount !== BigInt(0)) {
            writer.uint32(48).int64(message.unbondingOnHoldRefCount);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUnbondingDelegationEntry();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.creationHeight = reader.int64();
                    break;
                case 2:
                    message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.initialBalance = reader.string();
                    break;
                case 4:
                    message.balance = reader.string();
                    break;
                case 5:
                    message.unbondingId = reader.uint64();
                    break;
                case 6:
                    message.unbondingOnHoldRefCount = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseUnbondingDelegationEntry();
        message.creationHeight = object.creationHeight !== undefined && object.creationHeight !== null ? BigInt(object.creationHeight.toString()) : BigInt(0);
        message.completionTime = object.completionTime ?? undefined;
        message.initialBalance = object.initialBalance ?? "";
        message.balance = object.balance ?? "";
        message.unbondingId = object.unbondingId !== undefined && object.unbondingId !== null ? BigInt(object.unbondingId.toString()) : BigInt(0);
        message.unbondingOnHoldRefCount = object.unbondingOnHoldRefCount !== undefined && object.unbondingOnHoldRefCount !== null ? BigInt(object.unbondingOnHoldRefCount.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseUnbondingDelegationEntry();
        if (object.creation_height !== undefined && object.creation_height !== null) {
            message.creationHeight = BigInt(object.creation_height);
        }
        if (object.completion_time !== undefined && object.completion_time !== null) {
            message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.completion_time));
        }
        if (object.initial_balance !== undefined && object.initial_balance !== null) {
            message.initialBalance = object.initial_balance;
        }
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = object.balance;
        }
        if (object.unbonding_id !== undefined && object.unbonding_id !== null) {
            message.unbondingId = BigInt(object.unbonding_id);
        }
        if (object.unbonding_on_hold_ref_count !== undefined && object.unbonding_on_hold_ref_count !== null) {
            message.unbondingOnHoldRefCount = BigInt(object.unbonding_on_hold_ref_count);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.creation_height = message.creationHeight !== BigInt(0) ? message.creationHeight?.toString() : undefined;
        obj.completion_time = message.completionTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime)) : new Date();
        obj.initial_balance = message.initialBalance === "" ? undefined : message.initialBalance;
        obj.balance = message.balance === "" ? undefined : message.balance;
        obj.unbonding_id = message.unbondingId !== BigInt(0) ? message.unbondingId?.toString() : undefined;
        obj.unbonding_on_hold_ref_count = message.unbondingOnHoldRefCount !== BigInt(0) ? message.unbondingOnHoldRefCount?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return UnbondingDelegationEntry.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/UnbondingDelegationEntry",
            value: UnbondingDelegationEntry.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return UnbondingDelegationEntry.decode(message.value);
    },
    toProto (message) {
        return UnbondingDelegationEntry.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.UnbondingDelegationEntry",
            value: UnbondingDelegationEntry.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseRedelegationEntry() {
    return {
        creationHeight: BigInt(0),
        completionTime: new Date(),
        initialBalance: "",
        sharesDst: "",
        unbondingId: BigInt(0),
        unbondingOnHoldRefCount: BigInt(0)
    };
}
const RedelegationEntry = {
    typeUrl: "/cosmos.staking.v1beta1.RedelegationEntry",
    aminoType: "cosmos-sdk/RedelegationEntry",
    is (o) {
        return o && (o.$typeUrl === RedelegationEntry.typeUrl || typeof o.creationHeight === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.completionTime) && typeof o.initialBalance === "string" && typeof o.sharesDst === "string" && typeof o.unbondingId === "bigint" && typeof o.unbondingOnHoldRefCount === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === RedelegationEntry.typeUrl || typeof o.creation_height === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.completion_time) && typeof o.initial_balance === "string" && typeof o.shares_dst === "string" && typeof o.unbonding_id === "bigint" && typeof o.unbonding_on_hold_ref_count === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.creationHeight !== BigInt(0)) {
            writer.uint32(8).int64(message.creationHeight);
        }
        if (message.completionTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime), writer.uint32(18).fork()).ldelim();
        }
        if (message.initialBalance !== "") {
            writer.uint32(26).string(message.initialBalance);
        }
        if (message.sharesDst !== "") {
            writer.uint32(34).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.sharesDst, 18).atomics);
        }
        if (message.unbondingId !== BigInt(0)) {
            writer.uint32(40).uint64(message.unbondingId);
        }
        if (message.unbondingOnHoldRefCount !== BigInt(0)) {
            writer.uint32(48).int64(message.unbondingOnHoldRefCount);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRedelegationEntry();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.creationHeight = reader.int64();
                    break;
                case 2:
                    message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.initialBalance = reader.string();
                    break;
                case 4:
                    message.sharesDst = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                case 5:
                    message.unbondingId = reader.uint64();
                    break;
                case 6:
                    message.unbondingOnHoldRefCount = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRedelegationEntry();
        message.creationHeight = object.creationHeight !== undefined && object.creationHeight !== null ? BigInt(object.creationHeight.toString()) : BigInt(0);
        message.completionTime = object.completionTime ?? undefined;
        message.initialBalance = object.initialBalance ?? "";
        message.sharesDst = object.sharesDst ?? "";
        message.unbondingId = object.unbondingId !== undefined && object.unbondingId !== null ? BigInt(object.unbondingId.toString()) : BigInt(0);
        message.unbondingOnHoldRefCount = object.unbondingOnHoldRefCount !== undefined && object.unbondingOnHoldRefCount !== null ? BigInt(object.unbondingOnHoldRefCount.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseRedelegationEntry();
        if (object.creation_height !== undefined && object.creation_height !== null) {
            message.creationHeight = BigInt(object.creation_height);
        }
        if (object.completion_time !== undefined && object.completion_time !== null) {
            message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.completion_time));
        }
        if (object.initial_balance !== undefined && object.initial_balance !== null) {
            message.initialBalance = object.initial_balance;
        }
        if (object.shares_dst !== undefined && object.shares_dst !== null) {
            message.sharesDst = object.shares_dst;
        }
        if (object.unbonding_id !== undefined && object.unbonding_id !== null) {
            message.unbondingId = BigInt(object.unbonding_id);
        }
        if (object.unbonding_on_hold_ref_count !== undefined && object.unbonding_on_hold_ref_count !== null) {
            message.unbondingOnHoldRefCount = BigInt(object.unbonding_on_hold_ref_count);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.creation_height = message.creationHeight !== BigInt(0) ? message.creationHeight?.toString() : undefined;
        obj.completion_time = message.completionTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime)) : new Date();
        obj.initial_balance = message.initialBalance === "" ? undefined : message.initialBalance;
        obj.shares_dst = message.sharesDst === "" ? undefined : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.sharesDst, 18).atomics;
        obj.unbonding_id = message.unbondingId !== BigInt(0) ? message.unbondingId?.toString() : undefined;
        obj.unbonding_on_hold_ref_count = message.unbondingOnHoldRefCount !== BigInt(0) ? message.unbondingOnHoldRefCount?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return RedelegationEntry.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RedelegationEntry",
            value: RedelegationEntry.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RedelegationEntry.decode(message.value);
    },
    toProto (message) {
        return RedelegationEntry.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.RedelegationEntry",
            value: RedelegationEntry.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseRedelegation() {
    return {
        delegatorAddress: "",
        validatorSrcAddress: "",
        validatorDstAddress: "",
        entries: []
    };
}
const Redelegation = {
    typeUrl: "/cosmos.staking.v1beta1.Redelegation",
    aminoType: "cosmos-sdk/Redelegation",
    is (o) {
        return o && (o.$typeUrl === Redelegation.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorSrcAddress === "string" && typeof o.validatorDstAddress === "string" && Array.isArray(o.entries) && (!o.entries.length || RedelegationEntry.is(o.entries[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Redelegation.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_src_address === "string" && typeof o.validator_dst_address === "string" && Array.isArray(o.entries) && (!o.entries.length || RedelegationEntry.isAmino(o.entries[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorSrcAddress !== "") {
            writer.uint32(18).string(message.validatorSrcAddress);
        }
        if (message.validatorDstAddress !== "") {
            writer.uint32(26).string(message.validatorDstAddress);
        }
        for (const v of message.entries){
            RedelegationEntry.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRedelegation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorSrcAddress = reader.string();
                    break;
                case 3:
                    message.validatorDstAddress = reader.string();
                    break;
                case 4:
                    message.entries.push(RedelegationEntry.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRedelegation();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorSrcAddress = object.validatorSrcAddress ?? "";
        message.validatorDstAddress = object.validatorDstAddress ?? "";
        message.entries = object.entries?.map((e)=>RedelegationEntry.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseRedelegation();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_src_address !== undefined && object.validator_src_address !== null) {
            message.validatorSrcAddress = object.validator_src_address;
        }
        if (object.validator_dst_address !== undefined && object.validator_dst_address !== null) {
            message.validatorDstAddress = object.validator_dst_address;
        }
        message.entries = object.entries?.map((e)=>RedelegationEntry.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_src_address = message.validatorSrcAddress === "" ? undefined : message.validatorSrcAddress;
        obj.validator_dst_address = message.validatorDstAddress === "" ? undefined : message.validatorDstAddress;
        if (message.entries) {
            obj.entries = message.entries.map((e)=>e ? RedelegationEntry.toAmino(e) : undefined);
        } else {
            obj.entries = message.entries;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Redelegation.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Redelegation",
            value: Redelegation.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Redelegation.decode(message.value);
    },
    toProto (message) {
        return Redelegation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Redelegation",
            value: Redelegation.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Redelegation.typeUrl)) {
            return;
        }
        RedelegationEntry.registerTypeUrl();
    }
};
function createBaseParams() {
    return {
        unbondingTime: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({}),
        maxValidators: 0,
        maxEntries: 0,
        historicalEntries: 0,
        bondDenom: "",
        minCommissionRate: ""
    };
}
const Params = {
    typeUrl: "/cosmos.staking.v1beta1.Params",
    aminoType: "cosmos-sdk/x/staking/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.unbondingTime) && typeof o.maxValidators === "number" && typeof o.maxEntries === "number" && typeof o.historicalEntries === "number" && typeof o.bondDenom === "string" && typeof o.minCommissionRate === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.unbonding_time) && typeof o.max_validators === "number" && typeof o.max_entries === "number" && typeof o.historical_entries === "number" && typeof o.bond_denom === "string" && typeof o.min_commission_rate === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.unbondingTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.unbondingTime, writer.uint32(10).fork()).ldelim();
        }
        if (message.maxValidators !== 0) {
            writer.uint32(16).uint32(message.maxValidators);
        }
        if (message.maxEntries !== 0) {
            writer.uint32(24).uint32(message.maxEntries);
        }
        if (message.historicalEntries !== 0) {
            writer.uint32(32).uint32(message.historicalEntries);
        }
        if (message.bondDenom !== "") {
            writer.uint32(42).string(message.bondDenom);
        }
        if (message.minCommissionRate !== "") {
            writer.uint32(50).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.minCommissionRate, 18).atomics);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.unbondingTime = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.maxValidators = reader.uint32();
                    break;
                case 3:
                    message.maxEntries = reader.uint32();
                    break;
                case 4:
                    message.historicalEntries = reader.uint32();
                    break;
                case 5:
                    message.bondDenom = reader.string();
                    break;
                case 6:
                    message.minCommissionRate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.unbondingTime = object.unbondingTime !== undefined && object.unbondingTime !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.unbondingTime) : undefined;
        message.maxValidators = object.maxValidators ?? 0;
        message.maxEntries = object.maxEntries ?? 0;
        message.historicalEntries = object.historicalEntries ?? 0;
        message.bondDenom = object.bondDenom ?? "";
        message.minCommissionRate = object.minCommissionRate ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        if (object.unbonding_time !== undefined && object.unbonding_time !== null) {
            message.unbondingTime = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.unbonding_time);
        }
        if (object.max_validators !== undefined && object.max_validators !== null) {
            message.maxValidators = object.max_validators;
        }
        if (object.max_entries !== undefined && object.max_entries !== null) {
            message.maxEntries = object.max_entries;
        }
        if (object.historical_entries !== undefined && object.historical_entries !== null) {
            message.historicalEntries = object.historical_entries;
        }
        if (object.bond_denom !== undefined && object.bond_denom !== null) {
            message.bondDenom = object.bond_denom;
        }
        if (object.min_commission_rate !== undefined && object.min_commission_rate !== null) {
            message.minCommissionRate = object.min_commission_rate;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.unbonding_time = message.unbondingTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.unbondingTime) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({}));
        obj.max_validators = message.maxValidators === 0 ? undefined : message.maxValidators;
        obj.max_entries = message.maxEntries === 0 ? undefined : message.maxEntries;
        obj.historical_entries = message.historicalEntries === 0 ? undefined : message.historicalEntries;
        obj.bond_denom = message.bondDenom === "" ? undefined : message.bondDenom;
        obj.min_commission_rate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.minCommissionRate, 18).atomics ?? "";
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/x/staking/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseDelegationResponse() {
    return {
        delegation: Delegation.fromPartial({}),
        balance: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const DelegationResponse = {
    typeUrl: "/cosmos.staking.v1beta1.DelegationResponse",
    aminoType: "cosmos-sdk/DelegationResponse",
    is (o) {
        return o && (o.$typeUrl === DelegationResponse.typeUrl || Delegation.is(o.delegation) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.balance));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DelegationResponse.typeUrl || Delegation.isAmino(o.delegation) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.balance));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegation !== undefined) {
            Delegation.encode(message.delegation, writer.uint32(10).fork()).ldelim();
        }
        if (message.balance !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.balance, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDelegationResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegation = Delegation.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDelegationResponse();
        message.delegation = object.delegation !== undefined && object.delegation !== null ? Delegation.fromPartial(object.delegation) : undefined;
        message.balance = object.balance !== undefined && object.balance !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.balance) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDelegationResponse();
        if (object.delegation !== undefined && object.delegation !== null) {
            message.delegation = Delegation.fromAmino(object.delegation);
        }
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.balance);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegation = message.delegation ? Delegation.toAmino(message.delegation) : Delegation.toAmino(Delegation.fromPartial({}));
        obj.balance = message.balance ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.balance) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return DelegationResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DelegationResponse",
            value: DelegationResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DelegationResponse.decode(message.value);
    },
    toProto (message) {
        return DelegationResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.DelegationResponse",
            value: DelegationResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DelegationResponse.typeUrl)) {
            return;
        }
        Delegation.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseRedelegationEntryResponse() {
    return {
        redelegationEntry: RedelegationEntry.fromPartial({}),
        balance: ""
    };
}
const RedelegationEntryResponse = {
    typeUrl: "/cosmos.staking.v1beta1.RedelegationEntryResponse",
    aminoType: "cosmos-sdk/RedelegationEntryResponse",
    is (o) {
        return o && (o.$typeUrl === RedelegationEntryResponse.typeUrl || RedelegationEntry.is(o.redelegationEntry) && typeof o.balance === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === RedelegationEntryResponse.typeUrl || RedelegationEntry.isAmino(o.redelegation_entry) && typeof o.balance === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.redelegationEntry !== undefined) {
            RedelegationEntry.encode(message.redelegationEntry, writer.uint32(10).fork()).ldelim();
        }
        if (message.balance !== "") {
            writer.uint32(34).string(message.balance);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRedelegationEntryResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.redelegationEntry = RedelegationEntry.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.balance = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRedelegationEntryResponse();
        message.redelegationEntry = object.redelegationEntry !== undefined && object.redelegationEntry !== null ? RedelegationEntry.fromPartial(object.redelegationEntry) : undefined;
        message.balance = object.balance ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseRedelegationEntryResponse();
        if (object.redelegation_entry !== undefined && object.redelegation_entry !== null) {
            message.redelegationEntry = RedelegationEntry.fromAmino(object.redelegation_entry);
        }
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = object.balance;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.redelegation_entry = message.redelegationEntry ? RedelegationEntry.toAmino(message.redelegationEntry) : RedelegationEntry.toAmino(RedelegationEntry.fromPartial({}));
        obj.balance = message.balance === "" ? undefined : message.balance;
        return obj;
    },
    fromAminoMsg (object) {
        return RedelegationEntryResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RedelegationEntryResponse",
            value: RedelegationEntryResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RedelegationEntryResponse.decode(message.value);
    },
    toProto (message) {
        return RedelegationEntryResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.RedelegationEntryResponse",
            value: RedelegationEntryResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(RedelegationEntryResponse.typeUrl)) {
            return;
        }
        RedelegationEntry.registerTypeUrl();
    }
};
function createBaseRedelegationResponse() {
    return {
        redelegation: Redelegation.fromPartial({}),
        entries: []
    };
}
const RedelegationResponse = {
    typeUrl: "/cosmos.staking.v1beta1.RedelegationResponse",
    aminoType: "cosmos-sdk/RedelegationResponse",
    is (o) {
        return o && (o.$typeUrl === RedelegationResponse.typeUrl || Redelegation.is(o.redelegation) && Array.isArray(o.entries) && (!o.entries.length || RedelegationEntryResponse.is(o.entries[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === RedelegationResponse.typeUrl || Redelegation.isAmino(o.redelegation) && Array.isArray(o.entries) && (!o.entries.length || RedelegationEntryResponse.isAmino(o.entries[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.redelegation !== undefined) {
            Redelegation.encode(message.redelegation, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.entries){
            RedelegationEntryResponse.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseRedelegationResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.redelegation = Redelegation.decode(reader, reader.uint32());
                    break;
                case 2:
                    message.entries.push(RedelegationEntryResponse.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseRedelegationResponse();
        message.redelegation = object.redelegation !== undefined && object.redelegation !== null ? Redelegation.fromPartial(object.redelegation) : undefined;
        message.entries = object.entries?.map((e)=>RedelegationEntryResponse.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseRedelegationResponse();
        if (object.redelegation !== undefined && object.redelegation !== null) {
            message.redelegation = Redelegation.fromAmino(object.redelegation);
        }
        message.entries = object.entries?.map((e)=>RedelegationEntryResponse.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.redelegation = message.redelegation ? Redelegation.toAmino(message.redelegation) : Redelegation.toAmino(Redelegation.fromPartial({}));
        if (message.entries) {
            obj.entries = message.entries.map((e)=>e ? RedelegationEntryResponse.toAmino(e) : undefined);
        } else {
            obj.entries = message.entries;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return RedelegationResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/RedelegationResponse",
            value: RedelegationResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return RedelegationResponse.decode(message.value);
    },
    toProto (message) {
        return RedelegationResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.RedelegationResponse",
            value: RedelegationResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(RedelegationResponse.typeUrl)) {
            return;
        }
        Redelegation.registerTypeUrl();
        RedelegationEntryResponse.registerTypeUrl();
    }
};
function createBasePool() {
    return {
        notBondedTokens: "",
        bondedTokens: ""
    };
}
const Pool = {
    typeUrl: "/cosmos.staking.v1beta1.Pool",
    aminoType: "cosmos-sdk/Pool",
    is (o) {
        return o && (o.$typeUrl === Pool.typeUrl || typeof o.notBondedTokens === "string" && typeof o.bondedTokens === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Pool.typeUrl || typeof o.not_bonded_tokens === "string" && typeof o.bonded_tokens === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.notBondedTokens !== "") {
            writer.uint32(10).string(message.notBondedTokens);
        }
        if (message.bondedTokens !== "") {
            writer.uint32(18).string(message.bondedTokens);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePool();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.notBondedTokens = reader.string();
                    break;
                case 2:
                    message.bondedTokens = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePool();
        message.notBondedTokens = object.notBondedTokens ?? "";
        message.bondedTokens = object.bondedTokens ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBasePool();
        if (object.not_bonded_tokens !== undefined && object.not_bonded_tokens !== null) {
            message.notBondedTokens = object.not_bonded_tokens;
        }
        if (object.bonded_tokens !== undefined && object.bonded_tokens !== null) {
            message.bondedTokens = object.bonded_tokens;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.not_bonded_tokens = message.notBondedTokens ?? "";
        obj.bonded_tokens = message.bondedTokens ?? "";
        return obj;
    },
    fromAminoMsg (object) {
        return Pool.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Pool",
            value: Pool.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Pool.decode(message.value);
    },
    toProto (message) {
        return Pool.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.Pool",
            value: Pool.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseValidatorUpdates() {
    return {
        updates: []
    };
}
const ValidatorUpdates = {
    typeUrl: "/cosmos.staking.v1beta1.ValidatorUpdates",
    aminoType: "cosmos-sdk/ValidatorUpdates",
    is (o) {
        return o && (o.$typeUrl === ValidatorUpdates.typeUrl || Array.isArray(o.updates) && (!o.updates.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].is(o.updates[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ValidatorUpdates.typeUrl || Array.isArray(o.updates) && (!o.updates.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].isAmino(o.updates[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.updates){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseValidatorUpdates();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.updates.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseValidatorUpdates();
        message.updates = object.updates?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseValidatorUpdates();
        message.updates = object.updates?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.updates) {
            obj.updates = message.updates.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].toAmino(e) : undefined);
        } else {
            obj.updates = message.updates;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return ValidatorUpdates.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ValidatorUpdates",
            value: ValidatorUpdates.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ValidatorUpdates.decode(message.value);
    },
    toProto (message) {
        return ValidatorUpdates.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.ValidatorUpdates",
            value: ValidatorUpdates.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ValidatorUpdates.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$abci$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorUpdate"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GenesisState": (()=>GenesisState),
    "LastValidatorPower": (()=>LastValidatorPower)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/staking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
function createBaseGenesisState() {
    return {
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}),
        lastTotalPower: new Uint8Array(),
        lastValidatorPowers: [],
        validators: [],
        delegations: [],
        unbondingDelegations: [],
        redelegations: [],
        exported: false
    };
}
const GenesisState = {
    typeUrl: "/cosmos.staking.v1beta1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params) && (o.lastTotalPower instanceof Uint8Array || typeof o.lastTotalPower === "string") && Array.isArray(o.lastValidatorPowers) && (!o.lastValidatorPowers.length || LastValidatorPower.is(o.lastValidatorPowers[0])) && Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].is(o.validators[0])) && Array.isArray(o.delegations) && (!o.delegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].is(o.delegations[0])) && Array.isArray(o.unbondingDelegations) && (!o.unbondingDelegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].is(o.unbondingDelegations[0])) && Array.isArray(o.redelegations) && (!o.redelegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].is(o.redelegations[0])) && typeof o.exported === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params) && (o.last_total_power instanceof Uint8Array || typeof o.last_total_power === "string") && Array.isArray(o.last_validator_powers) && (!o.last_validator_powers.length || LastValidatorPower.isAmino(o.last_validator_powers[0])) && Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].isAmino(o.validators[0])) && Array.isArray(o.delegations) && (!o.delegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].isAmino(o.delegations[0])) && Array.isArray(o.unbonding_delegations) && (!o.unbonding_delegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].isAmino(o.unbonding_delegations[0])) && Array.isArray(o.redelegations) && (!o.redelegations.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].isAmino(o.redelegations[0])) && typeof o.exported === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        if (message.lastTotalPower.length !== 0) {
            writer.uint32(18).bytes(message.lastTotalPower);
        }
        for (const v of message.lastValidatorPowers){
            LastValidatorPower.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.validators){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.delegations){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].encode(v, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.unbondingDelegations){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].encode(v, writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.redelegations){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].encode(v, writer.uint32(58).fork()).ldelim();
        }
        if (message.exported === true) {
            writer.uint32(64).bool(message.exported);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.lastTotalPower = reader.bytes();
                    break;
                case 3:
                    message.lastValidatorPowers.push(LastValidatorPower.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.validators.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.delegations.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.unbondingDelegations.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.redelegations.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.exported = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        message.lastTotalPower = object.lastTotalPower ?? new Uint8Array();
        message.lastValidatorPowers = object.lastValidatorPowers?.map((e)=>LastValidatorPower.fromPartial(e)) || [];
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial(e)) || [];
        message.delegations = object.delegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].fromPartial(e)) || [];
        message.unbondingDelegations = object.unbondingDelegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial(e)) || [];
        message.redelegations = object.redelegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].fromPartial(e)) || [];
        message.exported = object.exported ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        if (object.last_total_power !== undefined && object.last_total_power !== null) {
            message.lastTotalPower = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.last_total_power);
        }
        message.lastValidatorPowers = object.last_validator_powers?.map((e)=>LastValidatorPower.fromAmino(e)) || [];
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromAmino(e)) || [];
        message.delegations = object.delegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].fromAmino(e)) || [];
        message.unbondingDelegations = object.unbonding_delegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromAmino(e)) || [];
        message.redelegations = object.redelegations?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].fromAmino(e)) || [];
        if (object.exported !== undefined && object.exported !== null) {
            message.exported = object.exported;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        obj.last_total_power = message.lastTotalPower ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.lastTotalPower) : "";
        if (message.lastValidatorPowers) {
            obj.last_validator_powers = message.lastValidatorPowers.map((e)=>e ? LastValidatorPower.toAmino(e) : undefined);
        } else {
            obj.last_validator_powers = message.lastValidatorPowers;
        }
        if (message.validators) {
            obj.validators = message.validators.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(e) : undefined);
        } else {
            obj.validators = message.validators;
        }
        if (message.delegations) {
            obj.delegations = message.delegations.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].toAmino(e) : undefined);
        } else {
            obj.delegations = message.delegations;
        }
        if (message.unbondingDelegations) {
            obj.unbonding_delegations = message.unbondingDelegations.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].toAmino(e) : undefined);
        } else {
            obj.unbonding_delegations = message.unbondingDelegations;
        }
        if (message.redelegations) {
            obj.redelegations = message.redelegations.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].toAmino(e) : undefined);
        } else {
            obj.redelegations = message.redelegations;
        }
        obj.exported = message.exported === false ? undefined : message.exported;
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
        LastValidatorPower.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Delegation"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Redelegation"].registerTypeUrl();
    }
};
function createBaseLastValidatorPower() {
    return {
        address: "",
        power: BigInt(0)
    };
}
const LastValidatorPower = {
    typeUrl: "/cosmos.staking.v1beta1.LastValidatorPower",
    aminoType: "cosmos-sdk/LastValidatorPower",
    is (o) {
        return o && (o.$typeUrl === LastValidatorPower.typeUrl || typeof o.address === "string" && typeof o.power === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === LastValidatorPower.typeUrl || typeof o.address === "string" && typeof o.power === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.power !== BigInt(0)) {
            writer.uint32(16).int64(message.power);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLastValidatorPower();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.power = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseLastValidatorPower();
        message.address = object.address ?? "";
        message.power = object.power !== undefined && object.power !== null ? BigInt(object.power.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseLastValidatorPower();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.power !== undefined && object.power !== null) {
            message.power = BigInt(object.power);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.power = message.power !== BigInt(0) ? message.power?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return LastValidatorPower.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/LastValidatorPower",
            value: LastValidatorPower.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return LastValidatorPower.decode(message.value);
    },
    toProto (message) {
        return LastValidatorPower.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.LastValidatorPower",
            value: LastValidatorPower.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryDelegationRequest": (()=>QueryDelegationRequest),
    "QueryDelegationResponse": (()=>QueryDelegationResponse),
    "QueryDelegatorDelegationsRequest": (()=>QueryDelegatorDelegationsRequest),
    "QueryDelegatorDelegationsResponse": (()=>QueryDelegatorDelegationsResponse),
    "QueryDelegatorUnbondingDelegationsRequest": (()=>QueryDelegatorUnbondingDelegationsRequest),
    "QueryDelegatorUnbondingDelegationsResponse": (()=>QueryDelegatorUnbondingDelegationsResponse),
    "QueryDelegatorValidatorRequest": (()=>QueryDelegatorValidatorRequest),
    "QueryDelegatorValidatorResponse": (()=>QueryDelegatorValidatorResponse),
    "QueryDelegatorValidatorsRequest": (()=>QueryDelegatorValidatorsRequest),
    "QueryDelegatorValidatorsResponse": (()=>QueryDelegatorValidatorsResponse),
    "QueryHistoricalInfoRequest": (()=>QueryHistoricalInfoRequest),
    "QueryHistoricalInfoResponse": (()=>QueryHistoricalInfoResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse),
    "QueryPoolRequest": (()=>QueryPoolRequest),
    "QueryPoolResponse": (()=>QueryPoolResponse),
    "QueryRedelegationsRequest": (()=>QueryRedelegationsRequest),
    "QueryRedelegationsResponse": (()=>QueryRedelegationsResponse),
    "QueryUnbondingDelegationRequest": (()=>QueryUnbondingDelegationRequest),
    "QueryUnbondingDelegationResponse": (()=>QueryUnbondingDelegationResponse),
    "QueryValidatorDelegationsRequest": (()=>QueryValidatorDelegationsRequest),
    "QueryValidatorDelegationsResponse": (()=>QueryValidatorDelegationsResponse),
    "QueryValidatorRequest": (()=>QueryValidatorRequest),
    "QueryValidatorResponse": (()=>QueryValidatorResponse),
    "QueryValidatorUnbondingDelegationsRequest": (()=>QueryValidatorUnbondingDelegationsRequest),
    "QueryValidatorUnbondingDelegationsResponse": (()=>QueryValidatorUnbondingDelegationsResponse),
    "QueryValidatorsRequest": (()=>QueryValidatorsRequest),
    "QueryValidatorsResponse": (()=>QueryValidatorsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/staking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseQueryValidatorsRequest() {
    return {
        status: "",
        pagination: undefined
    };
}
const QueryValidatorsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorsRequest",
    aminoType: "cosmos-sdk/QueryValidatorsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorsRequest.typeUrl || typeof o.status === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorsRequest.typeUrl || typeof o.status === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.status !== "") {
            writer.uint32(10).string(message.status);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.status = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorsRequest();
        message.status = object.status ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorsRequest();
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.status = message.status === "" ? undefined : message.status;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorsRequest",
            value: QueryValidatorsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorsRequest",
            value: QueryValidatorsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryValidatorsResponse() {
    return {
        validators: [],
        pagination: undefined
    };
}
const QueryValidatorsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorsResponse",
    aminoType: "cosmos-sdk/QueryValidatorsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorsResponse.typeUrl || Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].is(o.validators[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorsResponse.typeUrl || Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].isAmino(o.validators[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.validators){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validators.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorsResponse();
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorsResponse();
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.validators) {
            obj.validators = message.validators.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(e) : undefined);
        } else {
            obj.validators = message.validators;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorsResponse",
            value: QueryValidatorsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorsResponse",
            value: QueryValidatorsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryValidatorRequest() {
    return {
        validatorAddr: ""
    };
}
const QueryValidatorRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorRequest",
    aminoType: "cosmos-sdk/QueryValidatorRequest",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorRequest.typeUrl || typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorRequest.typeUrl || typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.validatorAddr !== "") {
            writer.uint32(10).string(message.validatorAddr);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validatorAddr = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorRequest();
        message.validatorAddr = object.validatorAddr ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorRequest();
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorRequest",
            value: QueryValidatorRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorRequest.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorRequest",
            value: QueryValidatorRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryValidatorResponse() {
    return {
        validator: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial({})
    };
}
const QueryValidatorResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorResponse",
    aminoType: "cosmos-sdk/QueryValidatorResponse",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].is(o.validator));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].isAmino(o.validator));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.validator !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].encode(message.validator, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validator = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorResponse();
        message.validator = object.validator !== undefined && object.validator !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial(object.validator) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorResponse();
        if (object.validator !== undefined && object.validator !== null) {
            message.validator = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromAmino(object.validator);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.validator = message.validator ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(message.validator) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorResponse",
            value: QueryValidatorResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorResponse.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorResponse",
            value: QueryValidatorResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].registerTypeUrl();
    }
};
function createBaseQueryValidatorDelegationsRequest() {
    return {
        validatorAddr: "",
        pagination: undefined
    };
}
const QueryValidatorDelegationsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorDelegationsRequest",
    aminoType: "cosmos-sdk/QueryValidatorDelegationsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorDelegationsRequest.typeUrl || typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorDelegationsRequest.typeUrl || typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.validatorAddr !== "") {
            writer.uint32(10).string(message.validatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorDelegationsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validatorAddr = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorDelegationsRequest();
        message.validatorAddr = object.validatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorDelegationsRequest();
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorDelegationsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorDelegationsRequest",
            value: QueryValidatorDelegationsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorDelegationsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorDelegationsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorDelegationsRequest",
            value: QueryValidatorDelegationsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorDelegationsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryValidatorDelegationsResponse() {
    return {
        delegationResponses: [],
        pagination: undefined
    };
}
const QueryValidatorDelegationsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorDelegationsResponse",
    aminoType: "cosmos-sdk/QueryValidatorDelegationsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorDelegationsResponse.typeUrl || Array.isArray(o.delegationResponses) && (!o.delegationResponses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].is(o.delegationResponses[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorDelegationsResponse.typeUrl || Array.isArray(o.delegation_responses) && (!o.delegation_responses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].isAmino(o.delegation_responses[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.delegationResponses){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorDelegationsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegationResponses.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorDelegationsResponse();
        message.delegationResponses = object.delegationResponses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorDelegationsResponse();
        message.delegationResponses = object.delegation_responses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.delegationResponses) {
            obj.delegation_responses = message.delegationResponses.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].toAmino(e) : undefined);
        } else {
            obj.delegation_responses = message.delegationResponses;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorDelegationsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorDelegationsResponse",
            value: QueryValidatorDelegationsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorDelegationsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorDelegationsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorDelegationsResponse",
            value: QueryValidatorDelegationsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorDelegationsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryValidatorUnbondingDelegationsRequest() {
    return {
        validatorAddr: "",
        pagination: undefined
    };
}
const QueryValidatorUnbondingDelegationsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorUnbondingDelegationsRequest",
    aminoType: "cosmos-sdk/QueryValidatorUnbondingDelegationsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorUnbondingDelegationsRequest.typeUrl || typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorUnbondingDelegationsRequest.typeUrl || typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.validatorAddr !== "") {
            writer.uint32(10).string(message.validatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorUnbondingDelegationsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validatorAddr = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorUnbondingDelegationsRequest();
        message.validatorAddr = object.validatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorUnbondingDelegationsRequest();
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorUnbondingDelegationsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorUnbondingDelegationsRequest",
            value: QueryValidatorUnbondingDelegationsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorUnbondingDelegationsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorUnbondingDelegationsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorUnbondingDelegationsRequest",
            value: QueryValidatorUnbondingDelegationsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorUnbondingDelegationsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryValidatorUnbondingDelegationsResponse() {
    return {
        unbondingResponses: [],
        pagination: undefined
    };
}
const QueryValidatorUnbondingDelegationsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryValidatorUnbondingDelegationsResponse",
    aminoType: "cosmos-sdk/QueryValidatorUnbondingDelegationsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryValidatorUnbondingDelegationsResponse.typeUrl || Array.isArray(o.unbondingResponses) && (!o.unbondingResponses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].is(o.unbondingResponses[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryValidatorUnbondingDelegationsResponse.typeUrl || Array.isArray(o.unbonding_responses) && (!o.unbonding_responses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].isAmino(o.unbonding_responses[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.unbondingResponses){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryValidatorUnbondingDelegationsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.unbondingResponses.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryValidatorUnbondingDelegationsResponse();
        message.unbondingResponses = object.unbondingResponses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryValidatorUnbondingDelegationsResponse();
        message.unbondingResponses = object.unbonding_responses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.unbondingResponses) {
            obj.unbonding_responses = message.unbondingResponses.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].toAmino(e) : undefined);
        } else {
            obj.unbonding_responses = message.unbondingResponses;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryValidatorUnbondingDelegationsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryValidatorUnbondingDelegationsResponse",
            value: QueryValidatorUnbondingDelegationsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryValidatorUnbondingDelegationsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryValidatorUnbondingDelegationsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryValidatorUnbondingDelegationsResponse",
            value: QueryValidatorUnbondingDelegationsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryValidatorUnbondingDelegationsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDelegationRequest() {
    return {
        delegatorAddr: "",
        validatorAddr: ""
    };
}
const QueryDelegationRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegationRequest",
    aminoType: "cosmos-sdk/QueryDelegationRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDelegationRequest.typeUrl || typeof o.delegatorAddr === "string" && typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegationRequest.typeUrl || typeof o.delegator_addr === "string" && typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.validatorAddr !== "") {
            writer.uint32(18).string(message.validatorAddr);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegationRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.validatorAddr = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegationRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.validatorAddr = object.validatorAddr ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegationRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegationRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegationRequest",
            value: QueryDelegationRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegationRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDelegationRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegationRequest",
            value: QueryDelegationRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDelegationResponse() {
    return {
        delegationResponse: undefined
    };
}
const QueryDelegationResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegationResponse",
    aminoType: "cosmos-sdk/QueryDelegationResponse",
    is (o) {
        return o && o.$typeUrl === QueryDelegationResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryDelegationResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegationResponse !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].encode(message.delegationResponse, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegationResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegationResponse = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegationResponse();
        message.delegationResponse = object.delegationResponse !== undefined && object.delegationResponse !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromPartial(object.delegationResponse) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegationResponse();
        if (object.delegation_response !== undefined && object.delegation_response !== null) {
            message.delegationResponse = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromAmino(object.delegation_response);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegation_response = message.delegationResponse ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].toAmino(message.delegationResponse) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegationResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegationResponse",
            value: QueryDelegationResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegationResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDelegationResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegationResponse",
            value: QueryDelegationResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegationResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].registerTypeUrl();
    }
};
function createBaseQueryUnbondingDelegationRequest() {
    return {
        delegatorAddr: "",
        validatorAddr: ""
    };
}
const QueryUnbondingDelegationRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryUnbondingDelegationRequest",
    aminoType: "cosmos-sdk/QueryUnbondingDelegationRequest",
    is (o) {
        return o && (o.$typeUrl === QueryUnbondingDelegationRequest.typeUrl || typeof o.delegatorAddr === "string" && typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryUnbondingDelegationRequest.typeUrl || typeof o.delegator_addr === "string" && typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.validatorAddr !== "") {
            writer.uint32(18).string(message.validatorAddr);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryUnbondingDelegationRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.validatorAddr = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryUnbondingDelegationRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.validatorAddr = object.validatorAddr ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryUnbondingDelegationRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryUnbondingDelegationRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryUnbondingDelegationRequest",
            value: QueryUnbondingDelegationRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryUnbondingDelegationRequest.decode(message.value);
    },
    toProto (message) {
        return QueryUnbondingDelegationRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryUnbondingDelegationRequest",
            value: QueryUnbondingDelegationRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryUnbondingDelegationResponse() {
    return {
        unbond: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial({})
    };
}
const QueryUnbondingDelegationResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryUnbondingDelegationResponse",
    aminoType: "cosmos-sdk/QueryUnbondingDelegationResponse",
    is (o) {
        return o && (o.$typeUrl === QueryUnbondingDelegationResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].is(o.unbond));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryUnbondingDelegationResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].isAmino(o.unbond));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.unbond !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].encode(message.unbond, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryUnbondingDelegationResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.unbond = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryUnbondingDelegationResponse();
        message.unbond = object.unbond !== undefined && object.unbond !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial(object.unbond) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryUnbondingDelegationResponse();
        if (object.unbond !== undefined && object.unbond !== null) {
            message.unbond = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromAmino(object.unbond);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.unbond = message.unbond ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].toAmino(message.unbond) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryUnbondingDelegationResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryUnbondingDelegationResponse",
            value: QueryUnbondingDelegationResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryUnbondingDelegationResponse.decode(message.value);
    },
    toProto (message) {
        return QueryUnbondingDelegationResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryUnbondingDelegationResponse",
            value: QueryUnbondingDelegationResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryUnbondingDelegationResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorDelegationsRequest() {
    return {
        delegatorAddr: "",
        pagination: undefined
    };
}
const QueryDelegatorDelegationsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorDelegationsRequest",
    aminoType: "cosmos-sdk/QueryDelegatorDelegationsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorDelegationsRequest.typeUrl || typeof o.delegatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorDelegationsRequest.typeUrl || typeof o.delegator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorDelegationsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorDelegationsRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorDelegationsRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorDelegationsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorDelegationsRequest",
            value: QueryDelegatorDelegationsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorDelegationsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorDelegationsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorDelegationsRequest",
            value: QueryDelegatorDelegationsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorDelegationsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorDelegationsResponse() {
    return {
        delegationResponses: [],
        pagination: undefined
    };
}
const QueryDelegatorDelegationsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorDelegationsResponse",
    aminoType: "cosmos-sdk/QueryDelegatorDelegationsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorDelegationsResponse.typeUrl || Array.isArray(o.delegationResponses) && (!o.delegationResponses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].is(o.delegationResponses[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorDelegationsResponse.typeUrl || Array.isArray(o.delegation_responses) && (!o.delegation_responses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].isAmino(o.delegation_responses[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.delegationResponses){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorDelegationsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegationResponses.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorDelegationsResponse();
        message.delegationResponses = object.delegationResponses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorDelegationsResponse();
        message.delegationResponses = object.delegation_responses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.delegationResponses) {
            obj.delegation_responses = message.delegationResponses.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].toAmino(e) : undefined);
        } else {
            obj.delegation_responses = message.delegationResponses;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorDelegationsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorDelegationsResponse",
            value: QueryDelegatorDelegationsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorDelegationsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorDelegationsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorDelegationsResponse",
            value: QueryDelegatorDelegationsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorDelegationsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DelegationResponse"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorUnbondingDelegationsRequest() {
    return {
        delegatorAddr: "",
        pagination: undefined
    };
}
const QueryDelegatorUnbondingDelegationsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorUnbondingDelegationsRequest",
    aminoType: "cosmos-sdk/QueryDelegatorUnbondingDelegationsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorUnbondingDelegationsRequest.typeUrl || typeof o.delegatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorUnbondingDelegationsRequest.typeUrl || typeof o.delegator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorUnbondingDelegationsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorUnbondingDelegationsRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorUnbondingDelegationsRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorUnbondingDelegationsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorUnbondingDelegationsRequest",
            value: QueryDelegatorUnbondingDelegationsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorUnbondingDelegationsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorUnbondingDelegationsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorUnbondingDelegationsRequest",
            value: QueryDelegatorUnbondingDelegationsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorUnbondingDelegationsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorUnbondingDelegationsResponse() {
    return {
        unbondingResponses: [],
        pagination: undefined
    };
}
const QueryDelegatorUnbondingDelegationsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorUnbondingDelegationsResponse",
    aminoType: "cosmos-sdk/QueryDelegatorUnbondingDelegationsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorUnbondingDelegationsResponse.typeUrl || Array.isArray(o.unbondingResponses) && (!o.unbondingResponses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].is(o.unbondingResponses[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorUnbondingDelegationsResponse.typeUrl || Array.isArray(o.unbonding_responses) && (!o.unbonding_responses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].isAmino(o.unbonding_responses[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.unbondingResponses){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorUnbondingDelegationsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.unbondingResponses.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorUnbondingDelegationsResponse();
        message.unbondingResponses = object.unbondingResponses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorUnbondingDelegationsResponse();
        message.unbondingResponses = object.unbonding_responses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.unbondingResponses) {
            obj.unbonding_responses = message.unbondingResponses.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].toAmino(e) : undefined);
        } else {
            obj.unbonding_responses = message.unbondingResponses;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorUnbondingDelegationsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorUnbondingDelegationsResponse",
            value: QueryDelegatorUnbondingDelegationsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorUnbondingDelegationsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorUnbondingDelegationsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorUnbondingDelegationsResponse",
            value: QueryDelegatorUnbondingDelegationsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorUnbondingDelegationsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnbondingDelegation"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryRedelegationsRequest() {
    return {
        delegatorAddr: "",
        srcValidatorAddr: "",
        dstValidatorAddr: "",
        pagination: undefined
    };
}
const QueryRedelegationsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryRedelegationsRequest",
    aminoType: "cosmos-sdk/QueryRedelegationsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryRedelegationsRequest.typeUrl || typeof o.delegatorAddr === "string" && typeof o.srcValidatorAddr === "string" && typeof o.dstValidatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryRedelegationsRequest.typeUrl || typeof o.delegator_addr === "string" && typeof o.src_validator_addr === "string" && typeof o.dst_validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.srcValidatorAddr !== "") {
            writer.uint32(18).string(message.srcValidatorAddr);
        }
        if (message.dstValidatorAddr !== "") {
            writer.uint32(26).string(message.dstValidatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryRedelegationsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.srcValidatorAddr = reader.string();
                    break;
                case 3:
                    message.dstValidatorAddr = reader.string();
                    break;
                case 4:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryRedelegationsRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.srcValidatorAddr = object.srcValidatorAddr ?? "";
        message.dstValidatorAddr = object.dstValidatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryRedelegationsRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.src_validator_addr !== undefined && object.src_validator_addr !== null) {
            message.srcValidatorAddr = object.src_validator_addr;
        }
        if (object.dst_validator_addr !== undefined && object.dst_validator_addr !== null) {
            message.dstValidatorAddr = object.dst_validator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.src_validator_addr = message.srcValidatorAddr === "" ? undefined : message.srcValidatorAddr;
        obj.dst_validator_addr = message.dstValidatorAddr === "" ? undefined : message.dstValidatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryRedelegationsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryRedelegationsRequest",
            value: QueryRedelegationsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryRedelegationsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryRedelegationsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryRedelegationsRequest",
            value: QueryRedelegationsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryRedelegationsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryRedelegationsResponse() {
    return {
        redelegationResponses: [],
        pagination: undefined
    };
}
const QueryRedelegationsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryRedelegationsResponse",
    aminoType: "cosmos-sdk/QueryRedelegationsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryRedelegationsResponse.typeUrl || Array.isArray(o.redelegationResponses) && (!o.redelegationResponses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].is(o.redelegationResponses[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryRedelegationsResponse.typeUrl || Array.isArray(o.redelegation_responses) && (!o.redelegation_responses.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].isAmino(o.redelegation_responses[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.redelegationResponses){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryRedelegationsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.redelegationResponses.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryRedelegationsResponse();
        message.redelegationResponses = object.redelegationResponses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryRedelegationsResponse();
        message.redelegationResponses = object.redelegation_responses?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.redelegationResponses) {
            obj.redelegation_responses = message.redelegationResponses.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].toAmino(e) : undefined);
        } else {
            obj.redelegation_responses = message.redelegationResponses;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryRedelegationsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryRedelegationsResponse",
            value: QueryRedelegationsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryRedelegationsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryRedelegationsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryRedelegationsResponse",
            value: QueryRedelegationsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryRedelegationsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RedelegationResponse"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorValidatorsRequest() {
    return {
        delegatorAddr: "",
        pagination: undefined
    };
}
const QueryDelegatorValidatorsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorsRequest",
    aminoType: "cosmos-sdk/QueryDelegatorValidatorsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorsRequest.typeUrl || typeof o.delegatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorsRequest.typeUrl || typeof o.delegator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorValidatorsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorValidatorsRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorValidatorsRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorValidatorsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorValidatorsRequest",
            value: QueryDelegatorValidatorsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorValidatorsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorValidatorsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorsRequest",
            value: QueryDelegatorValidatorsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorValidatorsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorValidatorsResponse() {
    return {
        validators: [],
        pagination: undefined
    };
}
const QueryDelegatorValidatorsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorsResponse",
    aminoType: "cosmos-sdk/QueryDelegatorValidatorsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorsResponse.typeUrl || Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].is(o.validators[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorsResponse.typeUrl || Array.isArray(o.validators) && (!o.validators.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].isAmino(o.validators[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.validators){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorValidatorsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validators.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorValidatorsResponse();
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorValidatorsResponse();
        message.validators = object.validators?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.validators) {
            obj.validators = message.validators.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(e) : undefined);
        } else {
            obj.validators = message.validators;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorValidatorsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorValidatorsResponse",
            value: QueryDelegatorValidatorsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorValidatorsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorValidatorsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorsResponse",
            value: QueryDelegatorValidatorsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorValidatorsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDelegatorValidatorRequest() {
    return {
        delegatorAddr: "",
        validatorAddr: ""
    };
}
const QueryDelegatorValidatorRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorRequest",
    aminoType: "cosmos-sdk/QueryDelegatorValidatorRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorRequest.typeUrl || typeof o.delegatorAddr === "string" && typeof o.validatorAddr === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorRequest.typeUrl || typeof o.delegator_addr === "string" && typeof o.validator_addr === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddr !== "") {
            writer.uint32(10).string(message.delegatorAddr);
        }
        if (message.validatorAddr !== "") {
            writer.uint32(18).string(message.validatorAddr);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorValidatorRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddr = reader.string();
                    break;
                case 2:
                    message.validatorAddr = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorValidatorRequest();
        message.delegatorAddr = object.delegatorAddr ?? "";
        message.validatorAddr = object.validatorAddr ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorValidatorRequest();
        if (object.delegator_addr !== undefined && object.delegator_addr !== null) {
            message.delegatorAddr = object.delegator_addr;
        }
        if (object.validator_addr !== undefined && object.validator_addr !== null) {
            message.validatorAddr = object.validator_addr;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_addr = message.delegatorAddr === "" ? undefined : message.delegatorAddr;
        obj.validator_addr = message.validatorAddr === "" ? undefined : message.validatorAddr;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorValidatorRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorValidatorRequest",
            value: QueryDelegatorValidatorRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorValidatorRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorValidatorRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorRequest",
            value: QueryDelegatorValidatorRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDelegatorValidatorResponse() {
    return {
        validator: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial({})
    };
}
const QueryDelegatorValidatorResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorResponse",
    aminoType: "cosmos-sdk/QueryDelegatorValidatorResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].is(o.validator));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDelegatorValidatorResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].isAmino(o.validator));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.validator !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].encode(message.validator, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDelegatorValidatorResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.validator = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDelegatorValidatorResponse();
        message.validator = object.validator !== undefined && object.validator !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial(object.validator) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDelegatorValidatorResponse();
        if (object.validator !== undefined && object.validator !== null) {
            message.validator = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromAmino(object.validator);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.validator = message.validator ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(message.validator) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDelegatorValidatorResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDelegatorValidatorResponse",
            value: QueryDelegatorValidatorResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDelegatorValidatorResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDelegatorValidatorResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryDelegatorValidatorResponse",
            value: QueryDelegatorValidatorResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDelegatorValidatorResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Validator"].registerTypeUrl();
    }
};
function createBaseQueryHistoricalInfoRequest() {
    return {
        height: BigInt(0)
    };
}
const QueryHistoricalInfoRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryHistoricalInfoRequest",
    aminoType: "cosmos-sdk/QueryHistoricalInfoRequest",
    is (o) {
        return o && (o.$typeUrl === QueryHistoricalInfoRequest.typeUrl || typeof o.height === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryHistoricalInfoRequest.typeUrl || typeof o.height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.height !== BigInt(0)) {
            writer.uint32(8).int64(message.height);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryHistoricalInfoRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.height = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryHistoricalInfoRequest();
        message.height = object.height !== undefined && object.height !== null ? BigInt(object.height.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryHistoricalInfoRequest();
        if (object.height !== undefined && object.height !== null) {
            message.height = BigInt(object.height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.height = message.height !== BigInt(0) ? message.height?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryHistoricalInfoRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryHistoricalInfoRequest",
            value: QueryHistoricalInfoRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryHistoricalInfoRequest.decode(message.value);
    },
    toProto (message) {
        return QueryHistoricalInfoRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryHistoricalInfoRequest",
            value: QueryHistoricalInfoRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryHistoricalInfoResponse() {
    return {
        hist: undefined
    };
}
const QueryHistoricalInfoResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryHistoricalInfoResponse",
    aminoType: "cosmos-sdk/QueryHistoricalInfoResponse",
    is (o) {
        return o && o.$typeUrl === QueryHistoricalInfoResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryHistoricalInfoResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.hist !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].encode(message.hist, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryHistoricalInfoResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.hist = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryHistoricalInfoResponse();
        message.hist = object.hist !== undefined && object.hist !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].fromPartial(object.hist) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryHistoricalInfoResponse();
        if (object.hist !== undefined && object.hist !== null) {
            message.hist = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].fromAmino(object.hist);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.hist = message.hist ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].toAmino(message.hist) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryHistoricalInfoResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryHistoricalInfoResponse",
            value: QueryHistoricalInfoResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryHistoricalInfoResponse.decode(message.value);
    },
    toProto (message) {
        return QueryHistoricalInfoResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryHistoricalInfoResponse",
            value: QueryHistoricalInfoResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryHistoricalInfoResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HistoricalInfo"].registerTypeUrl();
    }
};
function createBaseQueryPoolRequest() {
    return {};
}
const QueryPoolRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryPoolRequest",
    aminoType: "cosmos-sdk/QueryPoolRequest",
    is (o) {
        return o && o.$typeUrl === QueryPoolRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryPoolRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryPoolRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryPoolRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryPoolRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryPoolRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryPoolRequest",
            value: QueryPoolRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryPoolRequest.decode(message.value);
    },
    toProto (message) {
        return QueryPoolRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryPoolRequest",
            value: QueryPoolRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryPoolResponse() {
    return {
        pool: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].fromPartial({})
    };
}
const QueryPoolResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryPoolResponse",
    aminoType: "cosmos-sdk/QueryPoolResponse",
    is (o) {
        return o && (o.$typeUrl === QueryPoolResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].is(o.pool));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryPoolResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].isAmino(o.pool));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pool !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].encode(message.pool, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryPoolResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pool = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryPoolResponse();
        message.pool = object.pool !== undefined && object.pool !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].fromPartial(object.pool) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryPoolResponse();
        if (object.pool !== undefined && object.pool !== null) {
            message.pool = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].fromAmino(object.pool);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pool = message.pool ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].toAmino(message.pool) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryPoolResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryPoolResponse",
            value: QueryPoolResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryPoolResponse.decode(message.value);
    },
    toProto (message) {
        return QueryPoolResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryPoolResponse",
            value: QueryPoolResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryPoolResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pool"].registerTypeUrl();
    }
};
function createBaseQueryParamsRequest() {
    return {};
}
const QueryParamsRequest = {
    typeUrl: "/cosmos.staking.v1beta1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const QueryParamsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgBeginRedelegate": (()=>MsgBeginRedelegate),
    "MsgBeginRedelegateResponse": (()=>MsgBeginRedelegateResponse),
    "MsgCancelUnbondingDelegation": (()=>MsgCancelUnbondingDelegation),
    "MsgCancelUnbondingDelegationResponse": (()=>MsgCancelUnbondingDelegationResponse),
    "MsgCreateValidator": (()=>MsgCreateValidator),
    "MsgCreateValidatorResponse": (()=>MsgCreateValidatorResponse),
    "MsgDelegate": (()=>MsgDelegate),
    "MsgDelegateResponse": (()=>MsgDelegateResponse),
    "MsgEditValidator": (()=>MsgEditValidator),
    "MsgEditValidatorResponse": (()=>MsgEditValidatorResponse),
    "MsgUndelegate": (()=>MsgUndelegate),
    "MsgUndelegateResponse": (()=>MsgUndelegateResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/staking.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/pubkey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/decimal.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
function createBaseMsgCreateValidator() {
    return {
        description: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial({}),
        commission: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].fromPartial({}),
        minSelfDelegation: "",
        delegatorAddress: "",
        validatorAddress: "",
        pubkey: undefined,
        value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const MsgCreateValidator = {
    typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidator",
    aminoType: "cosmos-sdk/MsgCreateValidator",
    is (o) {
        return o && (o.$typeUrl === MsgCreateValidator.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].is(o.description) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].is(o.commission) && typeof o.minSelfDelegation === "string" && typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.value));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgCreateValidator.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].isAmino(o.description) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].isAmino(o.commission) && typeof o.min_self_delegation === "string" && typeof o.delegator_address === "string" && typeof o.validator_address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.value));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.description !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].encode(message.description, writer.uint32(10).fork()).ldelim();
        }
        if (message.commission !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].encode(message.commission, writer.uint32(18).fork()).ldelim();
        }
        if (message.minSelfDelegation !== "") {
            writer.uint32(26).string(message.minSelfDelegation);
        }
        if (message.delegatorAddress !== "") {
            writer.uint32(34).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(42).string(message.validatorAddress);
        }
        if (message.pubkey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].wrapAny(message.pubkey), writer.uint32(50).fork()).ldelim();
        }
        if (message.value !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.value, writer.uint32(58).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCreateValidator();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.description = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.commission = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.minSelfDelegation = reader.string();
                    break;
                case 4:
                    message.delegatorAddress = reader.string();
                    break;
                case 5:
                    message.validatorAddress = reader.string();
                    break;
                case 6:
                    message.pubkey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].unwrapAny(reader);
                    break;
                case 7:
                    message.value = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgCreateValidator();
        message.description = object.description !== undefined && object.description !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial(object.description) : undefined;
        message.commission = object.commission !== undefined && object.commission !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].fromPartial(object.commission) : undefined;
        message.minSelfDelegation = object.minSelfDelegation ?? "";
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.pubkey = object.pubkey !== undefined && object.pubkey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromPartial(object.pubkey) : undefined;
        message.value = object.value !== undefined && object.value !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.value) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgCreateValidator();
        if (object.description !== undefined && object.description !== null) {
            message.description = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromAmino(object.description);
        }
        if (object.commission !== undefined && object.commission !== null) {
            message.commission = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].fromAmino(object.commission);
        }
        if (object.min_self_delegation !== undefined && object.min_self_delegation !== null) {
            message.minSelfDelegation = object.min_self_delegation;
        }
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.pubkey !== undefined && object.pubkey !== null) {
            message.pubkey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodePubkey"])(object.pubkey);
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.value);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.description = message.description ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].toAmino(message.description) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial({}));
        obj.commission = message.commission ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].toAmino(message.commission) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommissionRates"].fromPartial({}));
        obj.min_self_delegation = message.minSelfDelegation ?? "";
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.pubkey = message.pubkey ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodePubkey"])(message.pubkey) : undefined;
        obj.value = message.value ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.value) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCreateValidator.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgCreateValidator",
            value: MsgCreateValidator.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCreateValidator.decode(message.value);
    },
    toProto (message) {
        return MsgCreateValidator.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidator",
            value: MsgCreateValidator.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgCreateValidator.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgCreateValidatorResponse() {
    return {};
}
const MsgCreateValidatorResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidatorResponse",
    aminoType: "cosmos-sdk/MsgCreateValidatorResponse",
    is (o) {
        return o && o.$typeUrl === MsgCreateValidatorResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgCreateValidatorResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCreateValidatorResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgCreateValidatorResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgCreateValidatorResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCreateValidatorResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgCreateValidatorResponse",
            value: MsgCreateValidatorResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCreateValidatorResponse.decode(message.value);
    },
    toProto (message) {
        return MsgCreateValidatorResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidatorResponse",
            value: MsgCreateValidatorResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgEditValidator() {
    return {
        description: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial({}),
        validatorAddress: "",
        commissionRate: "",
        minSelfDelegation: ""
    };
}
const MsgEditValidator = {
    typeUrl: "/cosmos.staking.v1beta1.MsgEditValidator",
    aminoType: "cosmos-sdk/MsgEditValidator",
    is (o) {
        return o && (o.$typeUrl === MsgEditValidator.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].is(o.description) && typeof o.validatorAddress === "string" && typeof o.commissionRate === "string" && typeof o.minSelfDelegation === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgEditValidator.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].isAmino(o.description) && typeof o.validator_address === "string" && typeof o.commission_rate === "string" && typeof o.min_self_delegation === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.description !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].encode(message.description, writer.uint32(10).fork()).ldelim();
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        if (message.commissionRate !== "") {
            writer.uint32(26).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.commissionRate, 18).atomics);
        }
        if (message.minSelfDelegation !== "") {
            writer.uint32(34).string(message.minSelfDelegation);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgEditValidator();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.description = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.commissionRate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                case 4:
                    message.minSelfDelegation = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgEditValidator();
        message.description = object.description !== undefined && object.description !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial(object.description) : undefined;
        message.validatorAddress = object.validatorAddress ?? "";
        message.commissionRate = object.commissionRate ?? "";
        message.minSelfDelegation = object.minSelfDelegation ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgEditValidator();
        if (object.description !== undefined && object.description !== null) {
            message.description = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromAmino(object.description);
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.commission_rate !== undefined && object.commission_rate !== null) {
            message.commissionRate = object.commission_rate;
        }
        if (object.min_self_delegation !== undefined && object.min_self_delegation !== null) {
            message.minSelfDelegation = object.min_self_delegation;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.description = message.description ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].toAmino(message.description) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].fromPartial({}));
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.commission_rate = message.commissionRate === "" ? undefined : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.commissionRate, 18).atomics;
        obj.min_self_delegation = message.minSelfDelegation === "" ? undefined : message.minSelfDelegation;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgEditValidator.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgEditValidator",
            value: MsgEditValidator.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgEditValidator.decode(message.value);
    },
    toProto (message) {
        return MsgEditValidator.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgEditValidator",
            value: MsgEditValidator.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgEditValidator.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].registerTypeUrl();
    }
};
function createBaseMsgEditValidatorResponse() {
    return {};
}
const MsgEditValidatorResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgEditValidatorResponse",
    aminoType: "cosmos-sdk/MsgEditValidatorResponse",
    is (o) {
        return o && o.$typeUrl === MsgEditValidatorResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgEditValidatorResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgEditValidatorResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgEditValidatorResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgEditValidatorResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgEditValidatorResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgEditValidatorResponse",
            value: MsgEditValidatorResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgEditValidatorResponse.decode(message.value);
    },
    toProto (message) {
        return MsgEditValidatorResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgEditValidatorResponse",
            value: MsgEditValidatorResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgDelegate() {
    return {
        delegatorAddress: "",
        validatorAddress: "",
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const MsgDelegate = {
    typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
    aminoType: "cosmos-sdk/MsgDelegate",
    is (o) {
        return o && (o.$typeUrl === MsgDelegate.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgDelegate.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDelegate();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgDelegate();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgDelegate();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDelegate.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgDelegate",
            value: MsgDelegate.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDelegate.decode(message.value);
    },
    toProto (message) {
        return MsgDelegate.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
            value: MsgDelegate.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgDelegate.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgDelegateResponse() {
    return {};
}
const MsgDelegateResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgDelegateResponse",
    aminoType: "cosmos-sdk/MsgDelegateResponse",
    is (o) {
        return o && o.$typeUrl === MsgDelegateResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgDelegateResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDelegateResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgDelegateResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgDelegateResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDelegateResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgDelegateResponse",
            value: MsgDelegateResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDelegateResponse.decode(message.value);
    },
    toProto (message) {
        return MsgDelegateResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgDelegateResponse",
            value: MsgDelegateResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgBeginRedelegate() {
    return {
        delegatorAddress: "",
        validatorSrcAddress: "",
        validatorDstAddress: "",
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const MsgBeginRedelegate = {
    typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegate",
    aminoType: "cosmos-sdk/MsgBeginRedelegate",
    is (o) {
        return o && (o.$typeUrl === MsgBeginRedelegate.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorSrcAddress === "string" && typeof o.validatorDstAddress === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgBeginRedelegate.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_src_address === "string" && typeof o.validator_dst_address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorSrcAddress !== "") {
            writer.uint32(18).string(message.validatorSrcAddress);
        }
        if (message.validatorDstAddress !== "") {
            writer.uint32(26).string(message.validatorDstAddress);
        }
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgBeginRedelegate();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorSrcAddress = reader.string();
                    break;
                case 3:
                    message.validatorDstAddress = reader.string();
                    break;
                case 4:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgBeginRedelegate();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorSrcAddress = object.validatorSrcAddress ?? "";
        message.validatorDstAddress = object.validatorDstAddress ?? "";
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgBeginRedelegate();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_src_address !== undefined && object.validator_src_address !== null) {
            message.validatorSrcAddress = object.validator_src_address;
        }
        if (object.validator_dst_address !== undefined && object.validator_dst_address !== null) {
            message.validatorDstAddress = object.validator_dst_address;
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_src_address = message.validatorSrcAddress === "" ? undefined : message.validatorSrcAddress;
        obj.validator_dst_address = message.validatorDstAddress === "" ? undefined : message.validatorDstAddress;
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgBeginRedelegate.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgBeginRedelegate",
            value: MsgBeginRedelegate.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgBeginRedelegate.decode(message.value);
    },
    toProto (message) {
        return MsgBeginRedelegate.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegate",
            value: MsgBeginRedelegate.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgBeginRedelegate.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgBeginRedelegateResponse() {
    return {
        completionTime: new Date()
    };
}
const MsgBeginRedelegateResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegateResponse",
    aminoType: "cosmos-sdk/MsgBeginRedelegateResponse",
    is (o) {
        return o && (o.$typeUrl === MsgBeginRedelegateResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.completionTime));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgBeginRedelegateResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.completion_time));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.completionTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime), writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgBeginRedelegateResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgBeginRedelegateResponse();
        message.completionTime = object.completionTime ?? undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgBeginRedelegateResponse();
        if (object.completion_time !== undefined && object.completion_time !== null) {
            message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.completion_time));
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.completion_time = message.completionTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime)) : new Date();
        return obj;
    },
    fromAminoMsg (object) {
        return MsgBeginRedelegateResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgBeginRedelegateResponse",
            value: MsgBeginRedelegateResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgBeginRedelegateResponse.decode(message.value);
    },
    toProto (message) {
        return MsgBeginRedelegateResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegateResponse",
            value: MsgBeginRedelegateResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUndelegate() {
    return {
        delegatorAddress: "",
        validatorAddress: "",
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const MsgUndelegate = {
    typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
    aminoType: "cosmos-sdk/MsgUndelegate",
    is (o) {
        return o && (o.$typeUrl === MsgUndelegate.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUndelegate.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUndelegate();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUndelegate();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUndelegate();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUndelegate.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUndelegate",
            value: MsgUndelegate.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUndelegate.decode(message.value);
    },
    toProto (message) {
        return MsgUndelegate.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
            value: MsgUndelegate.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUndelegate.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgUndelegateResponse() {
    return {
        completionTime: new Date(),
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const MsgUndelegateResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgUndelegateResponse",
    aminoType: "cosmos-sdk/MsgUndelegateResponse",
    is (o) {
        return o && (o.$typeUrl === MsgUndelegateResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.completionTime) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUndelegateResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.completion_time) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.completionTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime), writer.uint32(10).fork()).ldelim();
        }
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUndelegateResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUndelegateResponse();
        message.completionTime = object.completionTime ?? undefined;
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUndelegateResponse();
        if (object.completion_time !== undefined && object.completion_time !== null) {
            message.completionTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.completion_time));
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.completion_time = message.completionTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.completionTime)) : new Date();
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUndelegateResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUndelegateResponse",
            value: MsgUndelegateResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUndelegateResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUndelegateResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgUndelegateResponse",
            value: MsgUndelegateResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUndelegateResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgCancelUnbondingDelegation() {
    return {
        delegatorAddress: "",
        validatorAddress: "",
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}),
        creationHeight: BigInt(0)
    };
}
const MsgCancelUnbondingDelegation = {
    typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
    aminoType: "cosmos-sdk/MsgCancelUnbondingDelegation",
    is (o) {
        return o && (o.$typeUrl === MsgCancelUnbondingDelegation.typeUrl || typeof o.delegatorAddress === "string" && typeof o.validatorAddress === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount) && typeof o.creationHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgCancelUnbondingDelegation.typeUrl || typeof o.delegator_address === "string" && typeof o.validator_address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount) && typeof o.creation_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.delegatorAddress !== "") {
            writer.uint32(10).string(message.delegatorAddress);
        }
        if (message.validatorAddress !== "") {
            writer.uint32(18).string(message.validatorAddress);
        }
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(26).fork()).ldelim();
        }
        if (message.creationHeight !== BigInt(0)) {
            writer.uint32(32).int64(message.creationHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCancelUnbondingDelegation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.delegatorAddress = reader.string();
                    break;
                case 2:
                    message.validatorAddress = reader.string();
                    break;
                case 3:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.creationHeight = reader.int64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgCancelUnbondingDelegation();
        message.delegatorAddress = object.delegatorAddress ?? "";
        message.validatorAddress = object.validatorAddress ?? "";
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        message.creationHeight = object.creationHeight !== undefined && object.creationHeight !== null ? BigInt(object.creationHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgCancelUnbondingDelegation();
        if (object.delegator_address !== undefined && object.delegator_address !== null) {
            message.delegatorAddress = object.delegator_address;
        }
        if (object.validator_address !== undefined && object.validator_address !== null) {
            message.validatorAddress = object.validator_address;
        }
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        if (object.creation_height !== undefined && object.creation_height !== null) {
            message.creationHeight = BigInt(object.creation_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.delegator_address = message.delegatorAddress === "" ? undefined : message.delegatorAddress;
        obj.validator_address = message.validatorAddress === "" ? undefined : message.validatorAddress;
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        obj.creation_height = message.creationHeight !== BigInt(0) ? message.creationHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCancelUnbondingDelegation.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgCancelUnbondingDelegation",
            value: MsgCancelUnbondingDelegation.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCancelUnbondingDelegation.decode(message.value);
    },
    toProto (message) {
        return MsgCancelUnbondingDelegation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
            value: MsgCancelUnbondingDelegation.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgCancelUnbondingDelegation.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgCancelUnbondingDelegationResponse() {
    return {};
}
const MsgCancelUnbondingDelegationResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegationResponse",
    aminoType: "cosmos-sdk/MsgCancelUnbondingDelegationResponse",
    is (o) {
        return o && o.$typeUrl === MsgCancelUnbondingDelegationResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgCancelUnbondingDelegationResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCancelUnbondingDelegationResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgCancelUnbondingDelegationResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgCancelUnbondingDelegationResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCancelUnbondingDelegationResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgCancelUnbondingDelegationResponse",
            value: MsgCancelUnbondingDelegationResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCancelUnbondingDelegationResponse.decode(message.value);
    },
    toProto (message) {
        return MsgCancelUnbondingDelegationResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegationResponse",
            value: MsgCancelUnbondingDelegationResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUpdateParams() {
    return {
        authority: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParams",
    aminoType: "cosmos-sdk/x/staking/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.authority !== "") {
            writer.uint32(10).string(message.authority);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.authority = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.authority = object.authority ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.authority = message.authority === "" ? undefined : message.authority;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/x/staking/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$staking$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/cosmos.staking.v1beta1.MsgCreateValidator",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCreateValidator"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgEditValidator",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgEditValidator"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgDelegate",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDelegate"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgBeginRedelegate",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgBeginRedelegate"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgUndelegate",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUndelegate"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelUnbondingDelegation"]
    ],
    [
        "/cosmos.staking.v1beta1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ]
];
const MessageComposer = {
    encoded: {
        createValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidator",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCreateValidator"].encode(value).finish()
            };
        },
        editValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgEditValidator",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgEditValidator"].encode(value).finish()
            };
        },
        delegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDelegate"].encode(value).finish()
            };
        },
        beginRedelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgBeginRedelegate"].encode(value).finish()
            };
        },
        undelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUndelegate"].encode(value).finish()
            };
        },
        cancelUnbondingDelegation (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelUnbondingDelegation"].encode(value).finish()
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        createValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidator",
                value
            };
        },
        editValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgEditValidator",
                value
            };
        },
        delegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
                value
            };
        },
        beginRedelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegate",
                value
            };
        },
        undelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
                value
            };
        },
        cancelUnbondingDelegation (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
                value
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParams",
                value
            };
        }
    },
    fromPartial: {
        createValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCreateValidator",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCreateValidator"].fromPartial(value)
            };
        },
        editValidator (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgEditValidator",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgEditValidator"].fromPartial(value)
            };
        },
        delegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgDelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDelegate"].fromPartial(value)
            };
        },
        beginRedelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgBeginRedelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgBeginRedelegate"].fromPartial(value)
            };
        },
        undelegate (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUndelegate",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUndelegate"].fromPartial(value)
            };
        },
        cancelUnbondingDelegation (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgCancelUnbondingDelegation",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelUnbondingDelegation"].fromPartial(value)
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.staking.v1beta1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDelegation": (()=>getDelegation),
    "getDelegatorDelegations": (()=>getDelegatorDelegations),
    "getDelegatorUnbondingDelegations": (()=>getDelegatorUnbondingDelegations),
    "getDelegatorValidator": (()=>getDelegatorValidator),
    "getDelegatorValidators": (()=>getDelegatorValidators),
    "getHistoricalInfo": (()=>getHistoricalInfo),
    "getParams": (()=>getParams),
    "getPool": (()=>getPool),
    "getRedelegations": (()=>getRedelegations),
    "getUnbondingDelegation": (()=>getUnbondingDelegation),
    "getValidator": (()=>getValidator),
    "getValidatorDelegations": (()=>getValidatorDelegations),
    "getValidatorUnbondingDelegations": (()=>getValidatorUnbondingDelegations),
    "getValidators": (()=>getValidators)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/query.js [app-client] (ecmascript)");
;
;
const getValidators = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Validators",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorsResponse"]
    ]
});
const getValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Validator",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorResponse"]
    ]
});
const getValidatorDelegations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorDelegationsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorDelegationsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "ValidatorDelegations",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorDelegationsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorDelegationsResponse"]
    ]
});
const getValidatorUnbondingDelegations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorUnbondingDelegationsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorUnbondingDelegationsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "ValidatorUnbondingDelegations",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorUnbondingDelegationsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryValidatorUnbondingDelegationsResponse"]
    ]
});
const getDelegation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegationRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegationResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Delegation",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegationRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegationResponse"]
    ]
});
const getUnbondingDelegation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryUnbondingDelegationRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryUnbondingDelegationResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "UnbondingDelegation",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryUnbondingDelegationRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryUnbondingDelegationResponse"]
    ]
});
const getDelegatorDelegations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorDelegationsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorDelegationsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "DelegatorDelegations",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorDelegationsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorDelegationsResponse"]
    ]
});
const getDelegatorUnbondingDelegations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorUnbondingDelegationsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorUnbondingDelegationsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "DelegatorUnbondingDelegations",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorUnbondingDelegationsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorUnbondingDelegationsResponse"]
    ]
});
const getRedelegations = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRedelegationsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRedelegationsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Redelegations",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRedelegationsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryRedelegationsResponse"]
    ]
});
const getDelegatorValidators = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "DelegatorValidators",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorsResponse"]
    ]
});
const getDelegatorValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "DelegatorValidator",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDelegatorValidatorResponse"]
    ]
});
const getHistoricalInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryHistoricalInfoRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryHistoricalInfoResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "HistoricalInfo",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryHistoricalInfoRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryHistoricalInfoResponse"]
    ]
});
const getPool = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPoolRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPoolResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Pool",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPoolRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryPoolResponse"]
    ]
});
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "cosmos.staking.v1beta1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "beginRedelegate": (()=>beginRedelegate),
    "cancelUnbondingDelegation": (()=>cancelUnbondingDelegation),
    "createValidator": (()=>createValidator),
    "delegate": (()=>delegate),
    "editValidator": (()=>editValidator),
    "undelegate": (()=>undelegate),
    "updateParams": (()=>updateParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/staking/v1beta1/tx.js [app-client] (ecmascript)");
;
;
const createValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCreateValidator"]
});
const editValidator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgEditValidator"]
});
const delegate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDelegate"]
});
const beginRedelegate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgBeginRedelegate"]
});
const undelegate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUndelegate"]
});
const cancelUnbondingDelegation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelUnbondingDelegation"]
});
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$staking$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_cosmos_staking_6acf5107._.js.map