(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/authz.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "SendAuthorization": (()=>SendAuthorization)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseSendAuthorization() {
    return {
        spendLimit: [],
        allowList: []
    };
}
const SendAuthorization = {
    typeUrl: "/cosmos.bank.v1beta1.SendAuthorization",
    aminoType: "cosmos-sdk/SendAuthorization",
    is (o) {
        return o && (o.$typeUrl === SendAuthorization.typeUrl || Array.isArray(o.spendLimit) && (!o.spendLimit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.spendLimit[0])) && Array.isArray(o.allowList) && (!o.allowList.length || typeof o.allowList[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === SendAuthorization.typeUrl || Array.isArray(o.spend_limit) && (!o.spend_limit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.spend_limit[0])) && Array.isArray(o.allow_list) && (!o.allow_list.length || typeof o.allow_list[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.spendLimit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.allowList){
            writer.uint32(18).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSendAuthorization();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.spendLimit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.allowList.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSendAuthorization();
        message.spendLimit = object.spendLimit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.allowList = object.allowList?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseSendAuthorization();
        message.spendLimit = object.spend_limit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.allowList = object.allow_list?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.spendLimit) {
            obj.spend_limit = message.spendLimit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.spend_limit = message.spendLimit;
        }
        if (message.allowList) {
            obj.allow_list = message.allowList.map((e)=>e);
        } else {
            obj.allow_list = message.allowList;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return SendAuthorization.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SendAuthorization",
            value: SendAuthorization.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SendAuthorization.decode(message.value);
    },
    toProto (message) {
        return SendAuthorization.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.SendAuthorization",
            value: SendAuthorization.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(SendAuthorization.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(SendAuthorization.typeUrl, SendAuthorization);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(SendAuthorization.aminoType, SendAuthorization.typeUrl);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/module/v1/module.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Module": (()=>Module)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseModule() {
    return {
        blockedModuleAccountsOverride: [],
        authority: "",
        restrictionsOrder: []
    };
}
const Module = {
    typeUrl: "/cosmos.bank.module.v1.Module",
    aminoType: "cosmos-sdk/Module",
    is (o) {
        return o && (o.$typeUrl === Module.typeUrl || Array.isArray(o.blockedModuleAccountsOverride) && (!o.blockedModuleAccountsOverride.length || typeof o.blockedModuleAccountsOverride[0] === "string") && typeof o.authority === "string" && Array.isArray(o.restrictionsOrder) && (!o.restrictionsOrder.length || typeof o.restrictionsOrder[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Module.typeUrl || Array.isArray(o.blocked_module_accounts_override) && (!o.blocked_module_accounts_override.length || typeof o.blocked_module_accounts_override[0] === "string") && typeof o.authority === "string" && Array.isArray(o.restrictions_order) && (!o.restrictions_order.length || typeof o.restrictions_order[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.blockedModuleAccountsOverride){
            writer.uint32(10).string(v);
        }
        if (message.authority !== "") {
            writer.uint32(18).string(message.authority);
        }
        for (const v of message.restrictionsOrder){
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseModule();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.blockedModuleAccountsOverride.push(reader.string());
                    break;
                case 2:
                    message.authority = reader.string();
                    break;
                case 3:
                    message.restrictionsOrder.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseModule();
        message.blockedModuleAccountsOverride = object.blockedModuleAccountsOverride?.map((e)=>e) || [];
        message.authority = object.authority ?? "";
        message.restrictionsOrder = object.restrictionsOrder?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseModule();
        message.blockedModuleAccountsOverride = object.blocked_module_accounts_override?.map((e)=>e) || [];
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        message.restrictionsOrder = object.restrictions_order?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.blockedModuleAccountsOverride) {
            obj.blocked_module_accounts_override = message.blockedModuleAccountsOverride.map((e)=>e);
        } else {
            obj.blocked_module_accounts_override = message.blockedModuleAccountsOverride;
        }
        obj.authority = message.authority === "" ? undefined : message.authority;
        if (message.restrictionsOrder) {
            obj.restrictions_order = message.restrictionsOrder.map((e)=>e);
        } else {
            obj.restrictions_order = message.restrictionsOrder;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Module.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Module",
            value: Module.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Module.decode(message.value);
    },
    toProto (message) {
        return Module.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.module.v1.Module",
            value: Module.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/bank.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DenomUnit": (()=>DenomUnit),
    "Input": (()=>Input),
    "Metadata": (()=>Metadata),
    "Output": (()=>Output),
    "Params": (()=>Params),
    "SendEnabled": (()=>SendEnabled),
    "Supply": (()=>Supply)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseParams() {
    return {
        sendEnabled: [],
        defaultSendEnabled: false
    };
}
const Params = {
    typeUrl: "/cosmos.bank.v1beta1.Params",
    aminoType: "cosmos-sdk/x/bank/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || Array.isArray(o.sendEnabled) && (!o.sendEnabled.length || SendEnabled.is(o.sendEnabled[0])) && typeof o.defaultSendEnabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || Array.isArray(o.send_enabled) && (!o.send_enabled.length || SendEnabled.isAmino(o.send_enabled[0])) && typeof o.default_send_enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.sendEnabled){
            SendEnabled.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.defaultSendEnabled === true) {
            writer.uint32(16).bool(message.defaultSendEnabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sendEnabled.push(SendEnabled.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.defaultSendEnabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.sendEnabled = object.sendEnabled?.map((e)=>SendEnabled.fromPartial(e)) || [];
        message.defaultSendEnabled = object.defaultSendEnabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        message.sendEnabled = object.send_enabled?.map((e)=>SendEnabled.fromAmino(e)) || [];
        if (object.default_send_enabled !== undefined && object.default_send_enabled !== null) {
            message.defaultSendEnabled = object.default_send_enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.sendEnabled) {
            obj.send_enabled = message.sendEnabled.map((e)=>e ? SendEnabled.toAmino(e) : undefined);
        } else {
            obj.send_enabled = message.sendEnabled;
        }
        obj.default_send_enabled = message.defaultSendEnabled === false ? undefined : message.defaultSendEnabled;
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/x/bank/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Params.typeUrl)) {
            return;
        }
        SendEnabled.registerTypeUrl();
    }
};
function createBaseSendEnabled() {
    return {
        denom: "",
        enabled: false
    };
}
const SendEnabled = {
    typeUrl: "/cosmos.bank.v1beta1.SendEnabled",
    aminoType: "cosmos-sdk/SendEnabled",
    is (o) {
        return o && (o.$typeUrl === SendEnabled.typeUrl || typeof o.denom === "string" && typeof o.enabled === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === SendEnabled.typeUrl || typeof o.denom === "string" && typeof o.enabled === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        if (message.enabled === true) {
            writer.uint32(16).bool(message.enabled);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSendEnabled();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                case 2:
                    message.enabled = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSendEnabled();
        message.denom = object.denom ?? "";
        message.enabled = object.enabled ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseSendEnabled();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        if (object.enabled !== undefined && object.enabled !== null) {
            message.enabled = object.enabled;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        obj.enabled = message.enabled === false ? undefined : message.enabled;
        return obj;
    },
    fromAminoMsg (object) {
        return SendEnabled.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SendEnabled",
            value: SendEnabled.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SendEnabled.decode(message.value);
    },
    toProto (message) {
        return SendEnabled.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.SendEnabled",
            value: SendEnabled.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseInput() {
    return {
        address: "",
        coins: []
    };
}
const Input = {
    typeUrl: "/cosmos.bank.v1beta1.Input",
    aminoType: "cosmos-sdk/Input",
    is (o) {
        return o && (o.$typeUrl === Input.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.coins[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Input.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.coins[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        for (const v of message.coins){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseInput();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.coins.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseInput();
        message.address = object.address ?? "";
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseInput();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        if (message.coins) {
            obj.coins = message.coins.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.coins = message.coins;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Input.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Input",
            value: Input.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Input.decode(message.value);
    },
    toProto (message) {
        return Input.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Input",
            value: Input.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Input.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseOutput() {
    return {
        address: "",
        coins: []
    };
}
const Output = {
    typeUrl: "/cosmos.bank.v1beta1.Output",
    aminoType: "cosmos-sdk/Output",
    is (o) {
        return o && (o.$typeUrl === Output.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.coins[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Output.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.coins[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        for (const v of message.coins){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOutput();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.coins.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseOutput();
        message.address = object.address ?? "";
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseOutput();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        if (message.coins) {
            obj.coins = message.coins.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.coins = message.coins;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Output.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Output",
            value: Output.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Output.decode(message.value);
    },
    toProto (message) {
        return Output.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Output",
            value: Output.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Output.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseSupply() {
    return {
        total: []
    };
}
const Supply = {
    typeUrl: "/cosmos.bank.v1beta1.Supply",
    aminoType: "cosmos-sdk/Supply",
    is (o) {
        return o && (o.$typeUrl === Supply.typeUrl || Array.isArray(o.total) && (!o.total.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.total[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Supply.typeUrl || Array.isArray(o.total) && (!o.total.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.total[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.total){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSupply();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.total.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSupply();
        message.total = object.total?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseSupply();
        message.total = object.total?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.total) {
            obj.total = message.total.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.total = message.total;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Supply.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Supply",
            value: Supply.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Supply.decode(message.value);
    },
    toProto (message) {
        return Supply.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Supply",
            value: Supply.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Supply.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(Supply.typeUrl, Supply);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(Supply.aminoType, Supply.typeUrl);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseDenomUnit() {
    return {
        denom: "",
        exponent: 0,
        aliases: []
    };
}
const DenomUnit = {
    typeUrl: "/cosmos.bank.v1beta1.DenomUnit",
    aminoType: "cosmos-sdk/DenomUnit",
    is (o) {
        return o && (o.$typeUrl === DenomUnit.typeUrl || typeof o.denom === "string" && typeof o.exponent === "number" && Array.isArray(o.aliases) && (!o.aliases.length || typeof o.aliases[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DenomUnit.typeUrl || typeof o.denom === "string" && typeof o.exponent === "number" && Array.isArray(o.aliases) && (!o.aliases.length || typeof o.aliases[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        if (message.exponent !== 0) {
            writer.uint32(16).uint32(message.exponent);
        }
        for (const v of message.aliases){
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDenomUnit();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                case 2:
                    message.exponent = reader.uint32();
                    break;
                case 3:
                    message.aliases.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDenomUnit();
        message.denom = object.denom ?? "";
        message.exponent = object.exponent ?? 0;
        message.aliases = object.aliases?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDenomUnit();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        if (object.exponent !== undefined && object.exponent !== null) {
            message.exponent = object.exponent;
        }
        message.aliases = object.aliases?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        obj.exponent = message.exponent === 0 ? undefined : message.exponent;
        if (message.aliases) {
            obj.aliases = message.aliases.map((e)=>e);
        } else {
            obj.aliases = message.aliases;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return DenomUnit.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DenomUnit",
            value: DenomUnit.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DenomUnit.decode(message.value);
    },
    toProto (message) {
        return DenomUnit.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.DenomUnit",
            value: DenomUnit.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMetadata() {
    return {
        description: "",
        denomUnits: [],
        base: "",
        display: "",
        name: "",
        symbol: "",
        uri: "",
        uriHash: ""
    };
}
const Metadata = {
    typeUrl: "/cosmos.bank.v1beta1.Metadata",
    aminoType: "cosmos-sdk/Metadata",
    is (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.description === "string" && Array.isArray(o.denomUnits) && (!o.denomUnits.length || DenomUnit.is(o.denomUnits[0])) && typeof o.base === "string" && typeof o.display === "string" && typeof o.name === "string" && typeof o.symbol === "string" && typeof o.uri === "string" && typeof o.uriHash === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Metadata.typeUrl || typeof o.description === "string" && Array.isArray(o.denom_units) && (!o.denom_units.length || DenomUnit.isAmino(o.denom_units[0])) && typeof o.base === "string" && typeof o.display === "string" && typeof o.name === "string" && typeof o.symbol === "string" && typeof o.uri === "string" && typeof o.uri_hash === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.description !== "") {
            writer.uint32(10).string(message.description);
        }
        for (const v of message.denomUnits){
            DenomUnit.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.base !== "") {
            writer.uint32(26).string(message.base);
        }
        if (message.display !== "") {
            writer.uint32(34).string(message.display);
        }
        if (message.name !== "") {
            writer.uint32(42).string(message.name);
        }
        if (message.symbol !== "") {
            writer.uint32(50).string(message.symbol);
        }
        if (message.uri !== "") {
            writer.uint32(58).string(message.uri);
        }
        if (message.uriHash !== "") {
            writer.uint32(66).string(message.uriHash);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMetadata();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.description = reader.string();
                    break;
                case 2:
                    message.denomUnits.push(DenomUnit.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.base = reader.string();
                    break;
                case 4:
                    message.display = reader.string();
                    break;
                case 5:
                    message.name = reader.string();
                    break;
                case 6:
                    message.symbol = reader.string();
                    break;
                case 7:
                    message.uri = reader.string();
                    break;
                case 8:
                    message.uriHash = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMetadata();
        message.description = object.description ?? "";
        message.denomUnits = object.denomUnits?.map((e)=>DenomUnit.fromPartial(e)) || [];
        message.base = object.base ?? "";
        message.display = object.display ?? "";
        message.name = object.name ?? "";
        message.symbol = object.symbol ?? "";
        message.uri = object.uri ?? "";
        message.uriHash = object.uriHash ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMetadata();
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        message.denomUnits = object.denom_units?.map((e)=>DenomUnit.fromAmino(e)) || [];
        if (object.base !== undefined && object.base !== null) {
            message.base = object.base;
        }
        if (object.display !== undefined && object.display !== null) {
            message.display = object.display;
        }
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.symbol !== undefined && object.symbol !== null) {
            message.symbol = object.symbol;
        }
        if (object.uri !== undefined && object.uri !== null) {
            message.uri = object.uri;
        }
        if (object.uri_hash !== undefined && object.uri_hash !== null) {
            message.uriHash = object.uri_hash;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.description = message.description === "" ? undefined : message.description;
        if (message.denomUnits) {
            obj.denom_units = message.denomUnits.map((e)=>e ? DenomUnit.toAmino(e) : undefined);
        } else {
            obj.denom_units = message.denomUnits;
        }
        obj.base = message.base === "" ? undefined : message.base;
        obj.display = message.display === "" ? undefined : message.display;
        obj.name = message.name === "" ? undefined : message.name;
        obj.symbol = message.symbol === "" ? undefined : message.symbol;
        obj.uri = message.uri === "" ? undefined : message.uri;
        obj.uri_hash = message.uriHash === "" ? undefined : message.uriHash;
        return obj;
    },
    fromAminoMsg (object) {
        return Metadata.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Metadata",
            value: Metadata.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Metadata.decode(message.value);
    },
    toProto (message) {
        return Metadata.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Metadata",
            value: Metadata.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Metadata.typeUrl)) {
            return;
        }
        DenomUnit.registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Balance": (()=>Balance),
    "GenesisState": (()=>GenesisState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/bank.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseGenesisState() {
    return {
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}),
        balances: [],
        supply: [],
        denomMetadata: [],
        sendEnabled: []
    };
}
const GenesisState = {
    typeUrl: "/cosmos.bank.v1beta1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params) && Array.isArray(o.balances) && (!o.balances.length || Balance.is(o.balances[0])) && Array.isArray(o.supply) && (!o.supply.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.supply[0])) && Array.isArray(o.denomMetadata) && (!o.denomMetadata.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].is(o.denomMetadata[0])) && Array.isArray(o.sendEnabled) && (!o.sendEnabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].is(o.sendEnabled[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params) && Array.isArray(o.balances) && (!o.balances.length || Balance.isAmino(o.balances[0])) && Array.isArray(o.supply) && (!o.supply.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.supply[0])) && Array.isArray(o.denom_metadata) && (!o.denom_metadata.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].isAmino(o.denom_metadata[0])) && Array.isArray(o.send_enabled) && (!o.send_enabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].isAmino(o.send_enabled[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.balances){
            Balance.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.supply){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.denomMetadata){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.sendEnabled){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].encode(v, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.balances.push(Balance.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.supply.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.denomMetadata.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.sendEnabled.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        message.balances = object.balances?.map((e)=>Balance.fromPartial(e)) || [];
        message.supply = object.supply?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.denomMetadata = object.denomMetadata?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial(e)) || [];
        message.sendEnabled = object.sendEnabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        message.balances = object.balances?.map((e)=>Balance.fromAmino(e)) || [];
        message.supply = object.supply?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        message.denomMetadata = object.denom_metadata?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromAmino(e)) || [];
        message.sendEnabled = object.send_enabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        if (message.balances) {
            obj.balances = message.balances.map((e)=>e ? Balance.toAmino(e) : undefined);
        } else {
            obj.balances = message.balances;
        }
        if (message.supply) {
            obj.supply = message.supply.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.supply = message.supply;
        }
        if (message.denomMetadata) {
            obj.denom_metadata = message.denomMetadata.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(e) : undefined);
        } else {
            obj.denom_metadata = message.denomMetadata;
        }
        if (message.sendEnabled) {
            obj.send_enabled = message.sendEnabled.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].toAmino(e) : undefined);
        } else {
            obj.send_enabled = message.sendEnabled;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
        Balance.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].registerTypeUrl();
    }
};
function createBaseBalance() {
    return {
        address: "",
        coins: []
    };
}
const Balance = {
    typeUrl: "/cosmos.bank.v1beta1.Balance",
    aminoType: "cosmos-sdk/Balance",
    is (o) {
        return o && (o.$typeUrl === Balance.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.coins[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Balance.typeUrl || typeof o.address === "string" && Array.isArray(o.coins) && (!o.coins.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.coins[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        for (const v of message.coins){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseBalance();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.coins.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseBalance();
        message.address = object.address ?? "";
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseBalance();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        message.coins = object.coins?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        if (message.coins) {
            obj.coins = message.coins.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.coins = message.coins;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Balance.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Balance",
            value: Balance.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Balance.decode(message.value);
    },
    toProto (message) {
        return Balance.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.Balance",
            value: Balance.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Balance.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DenomOwner": (()=>DenomOwner),
    "QueryAllBalancesRequest": (()=>QueryAllBalancesRequest),
    "QueryAllBalancesResponse": (()=>QueryAllBalancesResponse),
    "QueryBalanceRequest": (()=>QueryBalanceRequest),
    "QueryBalanceResponse": (()=>QueryBalanceResponse),
    "QueryDenomMetadataByQueryStringRequest": (()=>QueryDenomMetadataByQueryStringRequest),
    "QueryDenomMetadataByQueryStringResponse": (()=>QueryDenomMetadataByQueryStringResponse),
    "QueryDenomMetadataRequest": (()=>QueryDenomMetadataRequest),
    "QueryDenomMetadataResponse": (()=>QueryDenomMetadataResponse),
    "QueryDenomOwnersByQueryRequest": (()=>QueryDenomOwnersByQueryRequest),
    "QueryDenomOwnersByQueryResponse": (()=>QueryDenomOwnersByQueryResponse),
    "QueryDenomOwnersRequest": (()=>QueryDenomOwnersRequest),
    "QueryDenomOwnersResponse": (()=>QueryDenomOwnersResponse),
    "QueryDenomsMetadataRequest": (()=>QueryDenomsMetadataRequest),
    "QueryDenomsMetadataResponse": (()=>QueryDenomsMetadataResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse),
    "QuerySendEnabledRequest": (()=>QuerySendEnabledRequest),
    "QuerySendEnabledResponse": (()=>QuerySendEnabledResponse),
    "QuerySpendableBalanceByDenomRequest": (()=>QuerySpendableBalanceByDenomRequest),
    "QuerySpendableBalanceByDenomResponse": (()=>QuerySpendableBalanceByDenomResponse),
    "QuerySpendableBalancesRequest": (()=>QuerySpendableBalancesRequest),
    "QuerySpendableBalancesResponse": (()=>QuerySpendableBalancesResponse),
    "QuerySupplyOfRequest": (()=>QuerySupplyOfRequest),
    "QuerySupplyOfResponse": (()=>QuerySupplyOfResponse),
    "QueryTotalSupplyRequest": (()=>QueryTotalSupplyRequest),
    "QueryTotalSupplyResponse": (()=>QueryTotalSupplyResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/bank.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
function createBaseQueryBalanceRequest() {
    return {
        address: "",
        denom: ""
    };
}
const QueryBalanceRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryBalanceRequest",
    aminoType: "cosmos-sdk/QueryBalanceRequest",
    is (o) {
        return o && (o.$typeUrl === QueryBalanceRequest.typeUrl || typeof o.address === "string" && typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryBalanceRequest.typeUrl || typeof o.address === "string" && typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.denom !== "") {
            writer.uint32(18).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryBalanceRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryBalanceRequest();
        message.address = object.address ?? "";
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryBalanceRequest();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryBalanceRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryBalanceRequest",
            value: QueryBalanceRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryBalanceRequest.decode(message.value);
    },
    toProto (message) {
        return QueryBalanceRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryBalanceRequest",
            value: QueryBalanceRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryBalanceResponse() {
    return {
        balance: undefined
    };
}
const QueryBalanceResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryBalanceResponse",
    aminoType: "cosmos-sdk/QueryBalanceResponse",
    is (o) {
        return o && o.$typeUrl === QueryBalanceResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryBalanceResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.balance !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.balance, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryBalanceResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryBalanceResponse();
        message.balance = object.balance !== undefined && object.balance !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.balance) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryBalanceResponse();
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.balance);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.balance = message.balance ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.balance) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryBalanceResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryBalanceResponse",
            value: QueryBalanceResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryBalanceResponse.decode(message.value);
    },
    toProto (message) {
        return QueryBalanceResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryBalanceResponse",
            value: QueryBalanceResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryBalanceResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryAllBalancesRequest() {
    return {
        address: "",
        pagination: undefined,
        resolveDenom: false
    };
}
const QueryAllBalancesRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryAllBalancesRequest",
    aminoType: "cosmos-sdk/QueryAllBalancesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryAllBalancesRequest.typeUrl || typeof o.address === "string" && typeof o.resolveDenom === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryAllBalancesRequest.typeUrl || typeof o.address === "string" && typeof o.resolve_denom === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        if (message.resolveDenom === true) {
            writer.uint32(24).bool(message.resolveDenom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryAllBalancesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.resolveDenom = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryAllBalancesRequest();
        message.address = object.address ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        message.resolveDenom = object.resolveDenom ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryAllBalancesRequest();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        if (object.resolve_denom !== undefined && object.resolve_denom !== null) {
            message.resolveDenom = object.resolve_denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        obj.resolve_denom = message.resolveDenom === false ? undefined : message.resolveDenom;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryAllBalancesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryAllBalancesRequest",
            value: QueryAllBalancesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryAllBalancesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryAllBalancesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryAllBalancesRequest",
            value: QueryAllBalancesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryAllBalancesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryAllBalancesResponse() {
    return {
        balances: [],
        pagination: undefined
    };
}
const QueryAllBalancesResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryAllBalancesResponse",
    aminoType: "cosmos-sdk/QueryAllBalancesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryAllBalancesResponse.typeUrl || Array.isArray(o.balances) && (!o.balances.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.balances[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryAllBalancesResponse.typeUrl || Array.isArray(o.balances) && (!o.balances.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.balances[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.balances){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryAllBalancesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.balances.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryAllBalancesResponse();
        message.balances = object.balances?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryAllBalancesResponse();
        message.balances = object.balances?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.balances) {
            obj.balances = message.balances.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.balances = message.balances;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryAllBalancesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryAllBalancesResponse",
            value: QueryAllBalancesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryAllBalancesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryAllBalancesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryAllBalancesResponse",
            value: QueryAllBalancesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryAllBalancesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQuerySpendableBalancesRequest() {
    return {
        address: "",
        pagination: undefined
    };
}
const QuerySpendableBalancesRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalancesRequest",
    aminoType: "cosmos-sdk/QuerySpendableBalancesRequest",
    is (o) {
        return o && (o.$typeUrl === QuerySpendableBalancesRequest.typeUrl || typeof o.address === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySpendableBalancesRequest.typeUrl || typeof o.address === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySpendableBalancesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySpendableBalancesRequest();
        message.address = object.address ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySpendableBalancesRequest();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySpendableBalancesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySpendableBalancesRequest",
            value: QuerySpendableBalancesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySpendableBalancesRequest.decode(message.value);
    },
    toProto (message) {
        return QuerySpendableBalancesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalancesRequest",
            value: QuerySpendableBalancesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySpendableBalancesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQuerySpendableBalancesResponse() {
    return {
        balances: [],
        pagination: undefined
    };
}
const QuerySpendableBalancesResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalancesResponse",
    aminoType: "cosmos-sdk/QuerySpendableBalancesResponse",
    is (o) {
        return o && (o.$typeUrl === QuerySpendableBalancesResponse.typeUrl || Array.isArray(o.balances) && (!o.balances.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.balances[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySpendableBalancesResponse.typeUrl || Array.isArray(o.balances) && (!o.balances.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.balances[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.balances){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySpendableBalancesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.balances.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySpendableBalancesResponse();
        message.balances = object.balances?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySpendableBalancesResponse();
        message.balances = object.balances?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.balances) {
            obj.balances = message.balances.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.balances = message.balances;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySpendableBalancesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySpendableBalancesResponse",
            value: QuerySpendableBalancesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySpendableBalancesResponse.decode(message.value);
    },
    toProto (message) {
        return QuerySpendableBalancesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalancesResponse",
            value: QuerySpendableBalancesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySpendableBalancesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQuerySpendableBalanceByDenomRequest() {
    return {
        address: "",
        denom: ""
    };
}
const QuerySpendableBalanceByDenomRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalanceByDenomRequest",
    aminoType: "cosmos-sdk/QuerySpendableBalanceByDenomRequest",
    is (o) {
        return o && (o.$typeUrl === QuerySpendableBalanceByDenomRequest.typeUrl || typeof o.address === "string" && typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySpendableBalanceByDenomRequest.typeUrl || typeof o.address === "string" && typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.denom !== "") {
            writer.uint32(18).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySpendableBalanceByDenomRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySpendableBalanceByDenomRequest();
        message.address = object.address ?? "";
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySpendableBalanceByDenomRequest();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySpendableBalanceByDenomRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySpendableBalanceByDenomRequest",
            value: QuerySpendableBalanceByDenomRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySpendableBalanceByDenomRequest.decode(message.value);
    },
    toProto (message) {
        return QuerySpendableBalanceByDenomRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalanceByDenomRequest",
            value: QuerySpendableBalanceByDenomRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQuerySpendableBalanceByDenomResponse() {
    return {
        balance: undefined
    };
}
const QuerySpendableBalanceByDenomResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalanceByDenomResponse",
    aminoType: "cosmos-sdk/QuerySpendableBalanceByDenomResponse",
    is (o) {
        return o && o.$typeUrl === QuerySpendableBalanceByDenomResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QuerySpendableBalanceByDenomResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.balance !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.balance, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySpendableBalanceByDenomResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySpendableBalanceByDenomResponse();
        message.balance = object.balance !== undefined && object.balance !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.balance) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySpendableBalanceByDenomResponse();
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.balance);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.balance = message.balance ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.balance) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySpendableBalanceByDenomResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySpendableBalanceByDenomResponse",
            value: QuerySpendableBalanceByDenomResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySpendableBalanceByDenomResponse.decode(message.value);
    },
    toProto (message) {
        return QuerySpendableBalanceByDenomResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySpendableBalanceByDenomResponse",
            value: QuerySpendableBalanceByDenomResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySpendableBalanceByDenomResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryTotalSupplyRequest() {
    return {
        pagination: undefined
    };
}
const QueryTotalSupplyRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryTotalSupplyRequest",
    aminoType: "cosmos-sdk/QueryTotalSupplyRequest",
    is (o) {
        return o && o.$typeUrl === QueryTotalSupplyRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryTotalSupplyRequest.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalSupplyRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalSupplyRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalSupplyRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalSupplyRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalSupplyRequest",
            value: QueryTotalSupplyRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalSupplyRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTotalSupplyRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryTotalSupplyRequest",
            value: QueryTotalSupplyRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalSupplyRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryTotalSupplyResponse() {
    return {
        supply: [],
        pagination: undefined
    };
}
const QueryTotalSupplyResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryTotalSupplyResponse",
    aminoType: "cosmos-sdk/QueryTotalSupplyResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTotalSupplyResponse.typeUrl || Array.isArray(o.supply) && (!o.supply.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.supply[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTotalSupplyResponse.typeUrl || Array.isArray(o.supply) && (!o.supply.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.supply[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.supply){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTotalSupplyResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.supply.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTotalSupplyResponse();
        message.supply = object.supply?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTotalSupplyResponse();
        message.supply = object.supply?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.supply) {
            obj.supply = message.supply.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.supply = message.supply;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTotalSupplyResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTotalSupplyResponse",
            value: QueryTotalSupplyResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTotalSupplyResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTotalSupplyResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryTotalSupplyResponse",
            value: QueryTotalSupplyResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTotalSupplyResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQuerySupplyOfRequest() {
    return {
        denom: ""
    };
}
const QuerySupplyOfRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySupplyOfRequest",
    aminoType: "cosmos-sdk/QuerySupplyOfRequest",
    is (o) {
        return o && (o.$typeUrl === QuerySupplyOfRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySupplyOfRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySupplyOfRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySupplyOfRequest();
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySupplyOfRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySupplyOfRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySupplyOfRequest",
            value: QuerySupplyOfRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySupplyOfRequest.decode(message.value);
    },
    toProto (message) {
        return QuerySupplyOfRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySupplyOfRequest",
            value: QuerySupplyOfRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQuerySupplyOfResponse() {
    return {
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const QuerySupplyOfResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySupplyOfResponse",
    aminoType: "cosmos-sdk/QuerySupplyOfResponse",
    is (o) {
        return o && (o.$typeUrl === QuerySupplyOfResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySupplyOfResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.amount !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.amount, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySupplyOfResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySupplyOfResponse();
        message.amount = object.amount !== undefined && object.amount !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.amount) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySupplyOfResponse();
        if (object.amount !== undefined && object.amount !== null) {
            message.amount = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.amount);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.amount = message.amount ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.amount) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySupplyOfResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySupplyOfResponse",
            value: QuerySupplyOfResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySupplyOfResponse.decode(message.value);
    },
    toProto (message) {
        return QuerySupplyOfResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySupplyOfResponse",
            value: QuerySupplyOfResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySupplyOfResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryParamsRequest() {
    return {};
}
const QueryParamsRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryParamsRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const QueryParamsResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseQueryDenomsMetadataRequest() {
    return {
        pagination: undefined
    };
}
const QueryDenomsMetadataRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomsMetadataRequest",
    aminoType: "cosmos-sdk/QueryDenomsMetadataRequest",
    is (o) {
        return o && o.$typeUrl === QueryDenomsMetadataRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryDenomsMetadataRequest.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomsMetadataRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomsMetadataRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomsMetadataRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomsMetadataRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomsMetadataRequest",
            value: QueryDenomsMetadataRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomsMetadataRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomsMetadataRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomsMetadataRequest",
            value: QueryDenomsMetadataRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomsMetadataRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDenomsMetadataResponse() {
    return {
        metadatas: [],
        pagination: undefined
    };
}
const QueryDenomsMetadataResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomsMetadataResponse",
    aminoType: "cosmos-sdk/QueryDenomsMetadataResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomsMetadataResponse.typeUrl || Array.isArray(o.metadatas) && (!o.metadatas.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].is(o.metadatas[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomsMetadataResponse.typeUrl || Array.isArray(o.metadatas) && (!o.metadatas.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].isAmino(o.metadatas[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.metadatas){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomsMetadataResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.metadatas.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomsMetadataResponse();
        message.metadatas = object.metadatas?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomsMetadataResponse();
        message.metadatas = object.metadatas?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.metadatas) {
            obj.metadatas = message.metadatas.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(e) : undefined);
        } else {
            obj.metadatas = message.metadatas;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomsMetadataResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomsMetadataResponse",
            value: QueryDenomsMetadataResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomsMetadataResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomsMetadataResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomsMetadataResponse",
            value: QueryDenomsMetadataResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomsMetadataResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDenomMetadataRequest() {
    return {
        denom: ""
    };
}
const QueryDenomMetadataRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataRequest",
    aminoType: "cosmos-sdk/QueryDenomMetadataRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomMetadataRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomMetadataRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomMetadataRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomMetadataRequest();
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomMetadataRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomMetadataRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomMetadataRequest",
            value: QueryDenomMetadataRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomMetadataRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomMetadataRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataRequest",
            value: QueryDenomMetadataRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDenomMetadataResponse() {
    return {
        metadata: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial({})
    };
}
const QueryDenomMetadataResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataResponse",
    aminoType: "cosmos-sdk/QueryDenomMetadataResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomMetadataResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].is(o.metadata));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomMetadataResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].isAmino(o.metadata));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.metadata !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].encode(message.metadata, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomMetadataResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.metadata = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomMetadataResponse();
        message.metadata = object.metadata !== undefined && object.metadata !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial(object.metadata) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomMetadataResponse();
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromAmino(object.metadata);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.metadata = message.metadata ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(message.metadata) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomMetadataResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomMetadataResponse",
            value: QueryDenomMetadataResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomMetadataResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomMetadataResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataResponse",
            value: QueryDenomMetadataResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomMetadataResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].registerTypeUrl();
    }
};
function createBaseQueryDenomMetadataByQueryStringRequest() {
    return {
        denom: ""
    };
}
const QueryDenomMetadataByQueryStringRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataByQueryStringRequest",
    aminoType: "cosmos-sdk/QueryDenomMetadataByQueryStringRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomMetadataByQueryStringRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomMetadataByQueryStringRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomMetadataByQueryStringRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomMetadataByQueryStringRequest();
        message.denom = object.denom ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomMetadataByQueryStringRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomMetadataByQueryStringRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomMetadataByQueryStringRequest",
            value: QueryDenomMetadataByQueryStringRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomMetadataByQueryStringRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomMetadataByQueryStringRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataByQueryStringRequest",
            value: QueryDenomMetadataByQueryStringRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDenomMetadataByQueryStringResponse() {
    return {
        metadata: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial({})
    };
}
const QueryDenomMetadataByQueryStringResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataByQueryStringResponse",
    aminoType: "cosmos-sdk/QueryDenomMetadataByQueryStringResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomMetadataByQueryStringResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].is(o.metadata));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomMetadataByQueryStringResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].isAmino(o.metadata));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.metadata !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].encode(message.metadata, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomMetadataByQueryStringResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.metadata = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomMetadataByQueryStringResponse();
        message.metadata = object.metadata !== undefined && object.metadata !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial(object.metadata) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomMetadataByQueryStringResponse();
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromAmino(object.metadata);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.metadata = message.metadata ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(message.metadata) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomMetadataByQueryStringResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomMetadataByQueryStringResponse",
            value: QueryDenomMetadataByQueryStringResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomMetadataByQueryStringResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomMetadataByQueryStringResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomMetadataByQueryStringResponse",
            value: QueryDenomMetadataByQueryStringResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomMetadataByQueryStringResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Metadata"].registerTypeUrl();
    }
};
function createBaseQueryDenomOwnersRequest() {
    return {
        denom: "",
        pagination: undefined
    };
}
const QueryDenomOwnersRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersRequest",
    aminoType: "cosmos-sdk/QueryDenomOwnersRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomOwnersRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomOwnersRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomOwnersRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomOwnersRequest();
        message.denom = object.denom ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomOwnersRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomOwnersRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomOwnersRequest",
            value: QueryDenomOwnersRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomOwnersRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomOwnersRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersRequest",
            value: QueryDenomOwnersRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomOwnersRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseDenomOwner() {
    return {
        address: "",
        balance: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({})
    };
}
const DenomOwner = {
    typeUrl: "/cosmos.bank.v1beta1.DenomOwner",
    aminoType: "cosmos-sdk/DenomOwner",
    is (o) {
        return o && (o.$typeUrl === DenomOwner.typeUrl || typeof o.address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.balance));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DenomOwner.typeUrl || typeof o.address === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.balance));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.address !== "") {
            writer.uint32(10).string(message.address);
        }
        if (message.balance !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(message.balance, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDenomOwner();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.address = reader.string();
                    break;
                case 2:
                    message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDenomOwner();
        message.address = object.address ?? "";
        message.balance = object.balance !== undefined && object.balance !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(object.balance) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDenomOwner();
        if (object.address !== undefined && object.address !== null) {
            message.address = object.address;
        }
        if (object.balance !== undefined && object.balance !== null) {
            message.balance = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(object.balance);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.address = message.address === "" ? undefined : message.address;
        obj.balance = message.balance ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(message.balance) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return DenomOwner.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DenomOwner",
            value: DenomOwner.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DenomOwner.decode(message.value);
    },
    toProto (message) {
        return DenomOwner.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.DenomOwner",
            value: DenomOwner.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DenomOwner.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseQueryDenomOwnersResponse() {
    return {
        denomOwners: [],
        pagination: undefined
    };
}
const QueryDenomOwnersResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersResponse",
    aminoType: "cosmos-sdk/QueryDenomOwnersResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomOwnersResponse.typeUrl || Array.isArray(o.denomOwners) && (!o.denomOwners.length || DenomOwner.is(o.denomOwners[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomOwnersResponse.typeUrl || Array.isArray(o.denom_owners) && (!o.denom_owners.length || DenomOwner.isAmino(o.denom_owners[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.denomOwners){
            DenomOwner.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomOwnersResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denomOwners.push(DenomOwner.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomOwnersResponse();
        message.denomOwners = object.denomOwners?.map((e)=>DenomOwner.fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomOwnersResponse();
        message.denomOwners = object.denom_owners?.map((e)=>DenomOwner.fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.denomOwners) {
            obj.denom_owners = message.denomOwners.map((e)=>e ? DenomOwner.toAmino(e) : undefined);
        } else {
            obj.denom_owners = message.denomOwners;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomOwnersResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomOwnersResponse",
            value: QueryDenomOwnersResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomOwnersResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomOwnersResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersResponse",
            value: QueryDenomOwnersResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomOwnersResponse.typeUrl)) {
            return;
        }
        DenomOwner.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryDenomOwnersByQueryRequest() {
    return {
        denom: "",
        pagination: undefined
    };
}
const QueryDenomOwnersByQueryRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersByQueryRequest",
    aminoType: "cosmos-sdk/QueryDenomOwnersByQueryRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDenomOwnersByQueryRequest.typeUrl || typeof o.denom === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomOwnersByQueryRequest.typeUrl || typeof o.denom === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.denom !== "") {
            writer.uint32(10).string(message.denom);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomOwnersByQueryRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denom = reader.string();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomOwnersByQueryRequest();
        message.denom = object.denom ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomOwnersByQueryRequest();
        if (object.denom !== undefined && object.denom !== null) {
            message.denom = object.denom;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.denom = message.denom === "" ? undefined : message.denom;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomOwnersByQueryRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomOwnersByQueryRequest",
            value: QueryDenomOwnersByQueryRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomOwnersByQueryRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDenomOwnersByQueryRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersByQueryRequest",
            value: QueryDenomOwnersByQueryRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomOwnersByQueryRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDenomOwnersByQueryResponse() {
    return {
        denomOwners: [],
        pagination: undefined
    };
}
const QueryDenomOwnersByQueryResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersByQueryResponse",
    aminoType: "cosmos-sdk/QueryDenomOwnersByQueryResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDenomOwnersByQueryResponse.typeUrl || Array.isArray(o.denomOwners) && (!o.denomOwners.length || DenomOwner.is(o.denomOwners[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDenomOwnersByQueryResponse.typeUrl || Array.isArray(o.denom_owners) && (!o.denom_owners.length || DenomOwner.isAmino(o.denom_owners[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.denomOwners){
            DenomOwner.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDenomOwnersByQueryResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denomOwners.push(DenomOwner.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDenomOwnersByQueryResponse();
        message.denomOwners = object.denomOwners?.map((e)=>DenomOwner.fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDenomOwnersByQueryResponse();
        message.denomOwners = object.denom_owners?.map((e)=>DenomOwner.fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.denomOwners) {
            obj.denom_owners = message.denomOwners.map((e)=>e ? DenomOwner.toAmino(e) : undefined);
        } else {
            obj.denom_owners = message.denomOwners;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDenomOwnersByQueryResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDenomOwnersByQueryResponse",
            value: QueryDenomOwnersByQueryResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDenomOwnersByQueryResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDenomOwnersByQueryResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QueryDenomOwnersByQueryResponse",
            value: QueryDenomOwnersByQueryResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDenomOwnersByQueryResponse.typeUrl)) {
            return;
        }
        DenomOwner.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQuerySendEnabledRequest() {
    return {
        denoms: [],
        pagination: undefined
    };
}
const QuerySendEnabledRequest = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySendEnabledRequest",
    aminoType: "cosmos-sdk/QuerySendEnabledRequest",
    is (o) {
        return o && (o.$typeUrl === QuerySendEnabledRequest.typeUrl || Array.isArray(o.denoms) && (!o.denoms.length || typeof o.denoms[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySendEnabledRequest.typeUrl || Array.isArray(o.denoms) && (!o.denoms.length || typeof o.denoms[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.denoms){
            writer.uint32(10).string(v);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(794).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySendEnabledRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.denoms.push(reader.string());
                    break;
                case 99:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySendEnabledRequest();
        message.denoms = object.denoms?.map((e)=>e) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySendEnabledRequest();
        message.denoms = object.denoms?.map((e)=>e) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.denoms) {
            obj.denoms = message.denoms.map((e)=>e);
        } else {
            obj.denoms = message.denoms;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySendEnabledRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySendEnabledRequest",
            value: QuerySendEnabledRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySendEnabledRequest.decode(message.value);
    },
    toProto (message) {
        return QuerySendEnabledRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySendEnabledRequest",
            value: QuerySendEnabledRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySendEnabledRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQuerySendEnabledResponse() {
    return {
        sendEnabled: [],
        pagination: undefined
    };
}
const QuerySendEnabledResponse = {
    typeUrl: "/cosmos.bank.v1beta1.QuerySendEnabledResponse",
    aminoType: "cosmos-sdk/QuerySendEnabledResponse",
    is (o) {
        return o && (o.$typeUrl === QuerySendEnabledResponse.typeUrl || Array.isArray(o.sendEnabled) && (!o.sendEnabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].is(o.sendEnabled[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QuerySendEnabledResponse.typeUrl || Array.isArray(o.send_enabled) && (!o.send_enabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].isAmino(o.send_enabled[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.sendEnabled){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(794).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQuerySendEnabledResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sendEnabled.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].decode(reader, reader.uint32()));
                    break;
                case 99:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQuerySendEnabledResponse();
        message.sendEnabled = object.sendEnabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQuerySendEnabledResponse();
        message.sendEnabled = object.send_enabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.sendEnabled) {
            obj.send_enabled = message.sendEnabled.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].toAmino(e) : undefined);
        } else {
            obj.send_enabled = message.sendEnabled;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QuerySendEnabledResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QuerySendEnabledResponse",
            value: QuerySendEnabledResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QuerySendEnabledResponse.decode(message.value);
    },
    toProto (message) {
        return QuerySendEnabledResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.QuerySendEnabledResponse",
            value: QuerySendEnabledResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QuerySendEnabledResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgMultiSend": (()=>MsgMultiSend),
    "MsgMultiSendResponse": (()=>MsgMultiSendResponse),
    "MsgSend": (()=>MsgSend),
    "MsgSendResponse": (()=>MsgSendResponse),
    "MsgSetSendEnabled": (()=>MsgSetSendEnabled),
    "MsgSetSendEnabledResponse": (()=>MsgSetSendEnabledResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/bank.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
function createBaseMsgSend() {
    return {
        fromAddress: "",
        toAddress: "",
        amount: []
    };
}
const MsgSend = {
    typeUrl: "/cosmos.bank.v1beta1.MsgSend",
    aminoType: "cosmos-sdk/MsgSend",
    is (o) {
        return o && (o.$typeUrl === MsgSend.typeUrl || typeof o.fromAddress === "string" && typeof o.toAddress === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSend.typeUrl || typeof o.from_address === "string" && typeof o.to_address === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.fromAddress !== "") {
            writer.uint32(10).string(message.fromAddress);
        }
        if (message.toAddress !== "") {
            writer.uint32(18).string(message.toAddress);
        }
        for (const v of message.amount){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSend();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.fromAddress = reader.string();
                    break;
                case 2:
                    message.toAddress = reader.string();
                    break;
                case 3:
                    message.amount.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSend();
        message.fromAddress = object.fromAddress ?? "";
        message.toAddress = object.toAddress ?? "";
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSend();
        if (object.from_address !== undefined && object.from_address !== null) {
            message.fromAddress = object.from_address;
        }
        if (object.to_address !== undefined && object.to_address !== null) {
            message.toAddress = object.to_address;
        }
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.from_address = message.fromAddress === "" ? undefined : message.fromAddress;
        obj.to_address = message.toAddress === "" ? undefined : message.toAddress;
        if (message.amount) {
            obj.amount = message.amount.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.amount = message.amount;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSend.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSend",
            value: MsgSend.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSend.decode(message.value);
    },
    toProto (message) {
        return MsgSend.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgSend",
            value: MsgSend.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgSend.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgSendResponse() {
    return {};
}
const MsgSendResponse = {
    typeUrl: "/cosmos.bank.v1beta1.MsgSendResponse",
    aminoType: "cosmos-sdk/MsgSendResponse",
    is (o) {
        return o && o.$typeUrl === MsgSendResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgSendResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSendResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgSendResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgSendResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSendResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSendResponse",
            value: MsgSendResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSendResponse.decode(message.value);
    },
    toProto (message) {
        return MsgSendResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgSendResponse",
            value: MsgSendResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgMultiSend() {
    return {
        inputs: [],
        outputs: []
    };
}
const MsgMultiSend = {
    typeUrl: "/cosmos.bank.v1beta1.MsgMultiSend",
    aminoType: "cosmos-sdk/MsgMultiSend",
    is (o) {
        return o && (o.$typeUrl === MsgMultiSend.typeUrl || Array.isArray(o.inputs) && (!o.inputs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].is(o.inputs[0])) && Array.isArray(o.outputs) && (!o.outputs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].is(o.outputs[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgMultiSend.typeUrl || Array.isArray(o.inputs) && (!o.inputs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].isAmino(o.inputs[0])) && Array.isArray(o.outputs) && (!o.outputs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].isAmino(o.outputs[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.inputs){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.outputs){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgMultiSend();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.inputs.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.outputs.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgMultiSend();
        message.inputs = object.inputs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].fromPartial(e)) || [];
        message.outputs = object.outputs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgMultiSend();
        message.inputs = object.inputs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].fromAmino(e)) || [];
        message.outputs = object.outputs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.inputs) {
            obj.inputs = message.inputs.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].toAmino(e) : undefined);
        } else {
            obj.inputs = message.inputs;
        }
        if (message.outputs) {
            obj.outputs = message.outputs.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].toAmino(e) : undefined);
        } else {
            obj.outputs = message.outputs;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgMultiSend.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgMultiSend",
            value: MsgMultiSend.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgMultiSend.decode(message.value);
    },
    toProto (message) {
        return MsgMultiSend.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgMultiSend",
            value: MsgMultiSend.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgMultiSend.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Output"].registerTypeUrl();
    }
};
function createBaseMsgMultiSendResponse() {
    return {};
}
const MsgMultiSendResponse = {
    typeUrl: "/cosmos.bank.v1beta1.MsgMultiSendResponse",
    aminoType: "cosmos-sdk/MsgMultiSendResponse",
    is (o) {
        return o && o.$typeUrl === MsgMultiSendResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgMultiSendResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgMultiSendResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgMultiSendResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgMultiSendResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgMultiSendResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgMultiSendResponse",
            value: MsgMultiSendResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgMultiSendResponse.decode(message.value);
    },
    toProto (message) {
        return MsgMultiSendResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgMultiSendResponse",
            value: MsgMultiSendResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUpdateParams() {
    return {
        authority: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParams",
    aminoType: "cosmos-sdk/x/bank/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.authority !== "") {
            writer.uint32(10).string(message.authority);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.authority = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.authority = object.authority ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.authority = message.authority === "" ? undefined : message.authority;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/x/bank/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgSetSendEnabled() {
    return {
        authority: "",
        sendEnabled: [],
        useDefaultFor: []
    };
}
const MsgSetSendEnabled = {
    typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabled",
    aminoType: "cosmos-sdk/MsgSetSendEnabled",
    is (o) {
        return o && (o.$typeUrl === MsgSetSendEnabled.typeUrl || typeof o.authority === "string" && Array.isArray(o.sendEnabled) && (!o.sendEnabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].is(o.sendEnabled[0])) && Array.isArray(o.useDefaultFor) && (!o.useDefaultFor.length || typeof o.useDefaultFor[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSetSendEnabled.typeUrl || typeof o.authority === "string" && Array.isArray(o.send_enabled) && (!o.send_enabled.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].isAmino(o.send_enabled[0])) && Array.isArray(o.use_default_for) && (!o.use_default_for.length || typeof o.use_default_for[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.authority !== "") {
            writer.uint32(10).string(message.authority);
        }
        for (const v of message.sendEnabled){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.useDefaultFor){
            writer.uint32(26).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSetSendEnabled();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.authority = reader.string();
                    break;
                case 2:
                    message.sendEnabled.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.useDefaultFor.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSetSendEnabled();
        message.authority = object.authority ?? "";
        message.sendEnabled = object.sendEnabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromPartial(e)) || [];
        message.useDefaultFor = object.useDefaultFor?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSetSendEnabled();
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        message.sendEnabled = object.send_enabled?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].fromAmino(e)) || [];
        message.useDefaultFor = object.use_default_for?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.authority = message.authority === "" ? undefined : message.authority;
        if (message.sendEnabled) {
            obj.send_enabled = message.sendEnabled.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].toAmino(e) : undefined);
        } else {
            obj.send_enabled = message.sendEnabled;
        }
        if (message.useDefaultFor) {
            obj.use_default_for = message.useDefaultFor.map((e)=>e);
        } else {
            obj.use_default_for = message.useDefaultFor;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSetSendEnabled.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSetSendEnabled",
            value: MsgSetSendEnabled.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSetSendEnabled.decode(message.value);
    },
    toProto (message) {
        return MsgSetSendEnabled.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabled",
            value: MsgSetSendEnabled.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgSetSendEnabled.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$bank$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SendEnabled"].registerTypeUrl();
    }
};
function createBaseMsgSetSendEnabledResponse() {
    return {};
}
const MsgSetSendEnabledResponse = {
    typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabledResponse",
    aminoType: "cosmos-sdk/MsgSetSendEnabledResponse",
    is (o) {
        return o && o.$typeUrl === MsgSetSendEnabledResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgSetSendEnabledResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSetSendEnabledResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgSetSendEnabledResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgSetSendEnabledResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSetSendEnabledResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSetSendEnabledResponse",
            value: MsgSetSendEnabledResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSetSendEnabledResponse.decode(message.value);
    },
    toProto (message) {
        return MsgSetSendEnabledResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabledResponse",
            value: MsgSetSendEnabledResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/cosmos.bank.v1beta1.MsgSend",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSend"]
    ],
    [
        "/cosmos.bank.v1beta1.MsgMultiSend",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMultiSend"]
    ],
    [
        "/cosmos.bank.v1beta1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ],
    [
        "/cosmos.bank.v1beta1.MsgSetSendEnabled",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSetSendEnabled"]
    ]
];
const MessageComposer = {
    encoded: {
        send (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSend",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSend"].encode(value).finish()
            };
        },
        multiSend (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgMultiSend",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMultiSend"].encode(value).finish()
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        },
        setSendEnabled (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabled",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSetSendEnabled"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        send (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSend",
                value
            };
        },
        multiSend (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgMultiSend",
                value
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParams",
                value
            };
        },
        setSendEnabled (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabled",
                value
            };
        }
    },
    fromPartial: {
        send (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSend",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSend"].fromPartial(value)
            };
        },
        multiSend (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgMultiSend",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMultiSend"].fromPartial(value)
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        },
        setSendEnabled (value) {
            return {
                typeUrl: "/cosmos.bank.v1beta1.MsgSetSendEnabled",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSetSendEnabled"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getAllBalances": (()=>getAllBalances),
    "getBalance": (()=>getBalance),
    "getDenomMetadata": (()=>getDenomMetadata),
    "getDenomMetadataByQueryString": (()=>getDenomMetadataByQueryString),
    "getDenomOwners": (()=>getDenomOwners),
    "getDenomOwnersByQuery": (()=>getDenomOwnersByQuery),
    "getDenomsMetadata": (()=>getDenomsMetadata),
    "getParams": (()=>getParams),
    "getSendEnabled": (()=>getSendEnabled),
    "getSpendableBalanceByDenom": (()=>getSpendableBalanceByDenom),
    "getSpendableBalances": (()=>getSpendableBalances),
    "getSupplyOf": (()=>getSupplyOf),
    "getTotalSupply": (()=>getTotalSupply)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/query.js [app-client] (ecmascript)");
;
;
const getBalance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryBalanceRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryBalanceResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "Balance",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryBalanceRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryBalanceResponse"]
    ]
});
const getAllBalances = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryAllBalancesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryAllBalancesResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "AllBalances",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryAllBalancesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryAllBalancesResponse"]
    ]
});
const getSpendableBalances = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalancesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalancesResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "SpendableBalances",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalancesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalancesResponse"]
    ]
});
const getSpendableBalanceByDenom = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalanceByDenomRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalanceByDenomResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "SpendableBalanceByDenom",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalanceByDenomRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySpendableBalanceByDenomResponse"]
    ]
});
const getTotalSupply = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalSupplyRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalSupplyResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "TotalSupply",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalSupplyRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTotalSupplyResponse"]
    ]
});
const getSupplyOf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySupplyOfRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySupplyOfResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "SupplyOf",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySupplyOfRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySupplyOfResponse"]
    ]
});
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
const getDenomMetadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "DenomMetadata",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataResponse"]
    ]
});
const getDenomMetadataByQueryString = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataByQueryStringRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataByQueryStringResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "DenomMetadataByQueryString",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataByQueryStringRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomMetadataByQueryStringResponse"]
    ]
});
const getDenomsMetadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomsMetadataRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomsMetadataResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "DenomsMetadata",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomsMetadataRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomsMetadataResponse"]
    ]
});
const getDenomOwners = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "DenomOwners",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersResponse"]
    ]
});
const getDenomOwnersByQuery = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersByQueryRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersByQueryResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "DenomOwnersByQuery",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersByQueryRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDenomOwnersByQueryResponse"]
    ]
});
const getSendEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySendEnabledRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySendEnabledResponse"].decode,
    service: "cosmos.bank.v1beta1.Query",
    method: "SendEnabled",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySendEnabledRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QuerySendEnabledResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "multiSend": (()=>multiSend),
    "send": (()=>send),
    "setSendEnabled": (()=>setSendEnabled),
    "updateParams": (()=>updateParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.js [app-client] (ecmascript)");
;
;
const send = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSend"]
});
const multiSend = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMultiSend"]
});
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
const setSendEnabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSetSendEnabled"]
});
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_cosmos_bank_02958e97._.js.map