(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/1483a_interchainjs_esm_google_944958ee._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_auth_ba549113._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_base_8c18d348._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_authz_f359c70d._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_bank_02958e97._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_staking_6acf5107._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_distribution_f3a7fb93._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_gov_b3131bf8._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_group_5f130137._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_nft_b68d5265._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_tx_ef8836df._.js",
  "static/chunks/1483a_interchainjs_esm_cosmos_e2ccffc1._.js",
  "static/chunks/1483a_interchainjs_esm_cosmwasm_ed26858e._.js",
  "static/chunks/1483a_interchainjs_esm_ibc_applications_a0fbb0aa._.js",
  "static/chunks/1483a_interchainjs_esm_ibc_core_05231cc0._.js",
  "static/chunks/1483a_interchainjs_esm_ibc_lightclients_b54c8a72._.js",
  "static/chunks/1483a_interchainjs_esm_ibc_bundle_16c20253.js",
  "static/chunks/1483a_interchainjs_esm_tendermint_46f83eee._.js",
  "static/chunks/1483a_interchainjs_esm_6465b6f5._.js",
  "static/chunks/1483a_@interchainjs_b1a3c069._.js",
  "static/chunks/examples_e2e_src_08198630._.js"
],
    source: "dynamic"
});
