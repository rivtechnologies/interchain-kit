(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/module/v1/module.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Module": (()=>Module)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseModule() {
    return {
        maxMetadataLen: BigInt(0),
        authority: ""
    };
}
const Module = {
    typeUrl: "/cosmos.gov.module.v1.Module",
    aminoType: "cosmos-sdk/Module",
    is (o) {
        return o && (o.$typeUrl === Module.typeUrl || typeof o.maxMetadataLen === "bigint" && typeof o.authority === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Module.typeUrl || typeof o.max_metadata_len === "bigint" && typeof o.authority === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.maxMetadataLen !== BigInt(0)) {
            writer.uint32(8).uint64(message.maxMetadataLen);
        }
        if (message.authority !== "") {
            writer.uint32(18).string(message.authority);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseModule();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.maxMetadataLen = reader.uint64();
                    break;
                case 2:
                    message.authority = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseModule();
        message.maxMetadataLen = object.maxMetadataLen !== undefined && object.maxMetadataLen !== null ? BigInt(object.maxMetadataLen.toString()) : BigInt(0);
        message.authority = object.authority ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseModule();
        if (object.max_metadata_len !== undefined && object.max_metadata_len !== null) {
            message.maxMetadataLen = BigInt(object.max_metadata_len);
        }
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.max_metadata_len = message.maxMetadataLen !== BigInt(0) ? message.maxMetadataLen?.toString() : undefined;
        obj.authority = message.authority === "" ? undefined : message.authority;
        return obj;
    },
    fromAminoMsg (object) {
        return Module.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Module",
            value: Module.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Module.decode(message.value);
    },
    toProto (message) {
        return Module.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.module.v1.Module",
            value: Module.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/gov.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Deposit": (()=>Deposit),
    "DepositParams": (()=>DepositParams),
    "Params": (()=>Params),
    "Proposal": (()=>Proposal),
    "ProposalStatus": (()=>ProposalStatus),
    "ProposalStatusAmino": (()=>ProposalStatusAmino),
    "TallyParams": (()=>TallyParams),
    "TallyResult": (()=>TallyResult),
    "Vote": (()=>Vote),
    "VoteOption": (()=>VoteOption),
    "VoteOptionAmino": (()=>VoteOptionAmino),
    "VotingParams": (()=>VotingParams),
    "WeightedVoteOption": (()=>WeightedVoteOption),
    "proposalStatusFromJSON": (()=>proposalStatusFromJSON),
    "proposalStatusToJSON": (()=>proposalStatusToJSON),
    "voteOptionFromJSON": (()=>voteOptionFromJSON),
    "voteOptionToJSON": (()=>voteOptionToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
var VoteOption;
(function(VoteOption) {
    /** VOTE_OPTION_UNSPECIFIED - VOTE_OPTION_UNSPECIFIED defines a no-op vote option. */ VoteOption[VoteOption["VOTE_OPTION_UNSPECIFIED"] = 0] = "VOTE_OPTION_UNSPECIFIED";
    /** VOTE_OPTION_YES - VOTE_OPTION_YES defines a yes vote option. */ VoteOption[VoteOption["VOTE_OPTION_YES"] = 1] = "VOTE_OPTION_YES";
    /** VOTE_OPTION_ABSTAIN - VOTE_OPTION_ABSTAIN defines an abstain vote option. */ VoteOption[VoteOption["VOTE_OPTION_ABSTAIN"] = 2] = "VOTE_OPTION_ABSTAIN";
    /** VOTE_OPTION_NO - VOTE_OPTION_NO defines a no vote option. */ VoteOption[VoteOption["VOTE_OPTION_NO"] = 3] = "VOTE_OPTION_NO";
    /** VOTE_OPTION_NO_WITH_VETO - VOTE_OPTION_NO_WITH_VETO defines a no with veto vote option. */ VoteOption[VoteOption["VOTE_OPTION_NO_WITH_VETO"] = 4] = "VOTE_OPTION_NO_WITH_VETO";
    VoteOption[VoteOption["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(VoteOption || (VoteOption = {}));
const VoteOptionAmino = VoteOption;
function voteOptionFromJSON(object) {
    switch(object){
        case 0:
        case "VOTE_OPTION_UNSPECIFIED":
            return VoteOption.VOTE_OPTION_UNSPECIFIED;
        case 1:
        case "VOTE_OPTION_YES":
            return VoteOption.VOTE_OPTION_YES;
        case 2:
        case "VOTE_OPTION_ABSTAIN":
            return VoteOption.VOTE_OPTION_ABSTAIN;
        case 3:
        case "VOTE_OPTION_NO":
            return VoteOption.VOTE_OPTION_NO;
        case 4:
        case "VOTE_OPTION_NO_WITH_VETO":
            return VoteOption.VOTE_OPTION_NO_WITH_VETO;
        case -1:
        case "UNRECOGNIZED":
        default:
            return VoteOption.UNRECOGNIZED;
    }
}
function voteOptionToJSON(object) {
    switch(object){
        case VoteOption.VOTE_OPTION_UNSPECIFIED:
            return "VOTE_OPTION_UNSPECIFIED";
        case VoteOption.VOTE_OPTION_YES:
            return "VOTE_OPTION_YES";
        case VoteOption.VOTE_OPTION_ABSTAIN:
            return "VOTE_OPTION_ABSTAIN";
        case VoteOption.VOTE_OPTION_NO:
            return "VOTE_OPTION_NO";
        case VoteOption.VOTE_OPTION_NO_WITH_VETO:
            return "VOTE_OPTION_NO_WITH_VETO";
        case VoteOption.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var ProposalStatus;
(function(ProposalStatus) {
    /** PROPOSAL_STATUS_UNSPECIFIED - PROPOSAL_STATUS_UNSPECIFIED defines the default proposal status. */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_UNSPECIFIED"] = 0] = "PROPOSAL_STATUS_UNSPECIFIED";
    /**
     * PROPOSAL_STATUS_DEPOSIT_PERIOD - PROPOSAL_STATUS_DEPOSIT_PERIOD defines a proposal status during the deposit
     * period.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_DEPOSIT_PERIOD"] = 1] = "PROPOSAL_STATUS_DEPOSIT_PERIOD";
    /**
     * PROPOSAL_STATUS_VOTING_PERIOD - PROPOSAL_STATUS_VOTING_PERIOD defines a proposal status during the voting
     * period.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_VOTING_PERIOD"] = 2] = "PROPOSAL_STATUS_VOTING_PERIOD";
    /**
     * PROPOSAL_STATUS_PASSED - PROPOSAL_STATUS_PASSED defines a proposal status of a proposal that has
     * passed.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_PASSED"] = 3] = "PROPOSAL_STATUS_PASSED";
    /**
     * PROPOSAL_STATUS_REJECTED - PROPOSAL_STATUS_REJECTED defines a proposal status of a proposal that has
     * been rejected.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_REJECTED"] = 4] = "PROPOSAL_STATUS_REJECTED";
    /**
     * PROPOSAL_STATUS_FAILED - PROPOSAL_STATUS_FAILED defines a proposal status of a proposal that has
     * failed.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_FAILED"] = 5] = "PROPOSAL_STATUS_FAILED";
    ProposalStatus[ProposalStatus["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ProposalStatus || (ProposalStatus = {}));
const ProposalStatusAmino = ProposalStatus;
function proposalStatusFromJSON(object) {
    switch(object){
        case 0:
        case "PROPOSAL_STATUS_UNSPECIFIED":
            return ProposalStatus.PROPOSAL_STATUS_UNSPECIFIED;
        case 1:
        case "PROPOSAL_STATUS_DEPOSIT_PERIOD":
            return ProposalStatus.PROPOSAL_STATUS_DEPOSIT_PERIOD;
        case 2:
        case "PROPOSAL_STATUS_VOTING_PERIOD":
            return ProposalStatus.PROPOSAL_STATUS_VOTING_PERIOD;
        case 3:
        case "PROPOSAL_STATUS_PASSED":
            return ProposalStatus.PROPOSAL_STATUS_PASSED;
        case 4:
        case "PROPOSAL_STATUS_REJECTED":
            return ProposalStatus.PROPOSAL_STATUS_REJECTED;
        case 5:
        case "PROPOSAL_STATUS_FAILED":
            return ProposalStatus.PROPOSAL_STATUS_FAILED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ProposalStatus.UNRECOGNIZED;
    }
}
function proposalStatusToJSON(object) {
    switch(object){
        case ProposalStatus.PROPOSAL_STATUS_UNSPECIFIED:
            return "PROPOSAL_STATUS_UNSPECIFIED";
        case ProposalStatus.PROPOSAL_STATUS_DEPOSIT_PERIOD:
            return "PROPOSAL_STATUS_DEPOSIT_PERIOD";
        case ProposalStatus.PROPOSAL_STATUS_VOTING_PERIOD:
            return "PROPOSAL_STATUS_VOTING_PERIOD";
        case ProposalStatus.PROPOSAL_STATUS_PASSED:
            return "PROPOSAL_STATUS_PASSED";
        case ProposalStatus.PROPOSAL_STATUS_REJECTED:
            return "PROPOSAL_STATUS_REJECTED";
        case ProposalStatus.PROPOSAL_STATUS_FAILED:
            return "PROPOSAL_STATUS_FAILED";
        case ProposalStatus.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseWeightedVoteOption() {
    return {
        option: 0,
        weight: ""
    };
}
const WeightedVoteOption = {
    typeUrl: "/cosmos.gov.v1.WeightedVoteOption",
    aminoType: "cosmos-sdk/v1/WeightedVoteOption",
    is (o) {
        return o && (o.$typeUrl === WeightedVoteOption.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.weight === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === WeightedVoteOption.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.weight === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.option !== 0) {
            writer.uint32(8).int32(message.option);
        }
        if (message.weight !== "") {
            writer.uint32(18).string(message.weight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseWeightedVoteOption();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.option = reader.int32();
                    break;
                case 2:
                    message.weight = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseWeightedVoteOption();
        message.option = object.option ?? 0;
        message.weight = object.weight ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseWeightedVoteOption();
        if (object.option !== undefined && object.option !== null) {
            message.option = object.option;
        }
        if (object.weight !== undefined && object.weight !== null) {
            message.weight = object.weight;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.option = message.option === 0 ? undefined : message.option;
        obj.weight = message.weight === "" ? undefined : message.weight;
        return obj;
    },
    fromAminoMsg (object) {
        return WeightedVoteOption.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/WeightedVoteOption",
            value: WeightedVoteOption.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return WeightedVoteOption.decode(message.value);
    },
    toProto (message) {
        return WeightedVoteOption.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.WeightedVoteOption",
            value: WeightedVoteOption.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseDeposit() {
    return {
        proposalId: BigInt(0),
        depositor: "",
        amount: []
    };
}
const Deposit = {
    typeUrl: "/cosmos.gov.v1.Deposit",
    aminoType: "cosmos-sdk/v1/Deposit",
    is (o) {
        return o && (o.$typeUrl === Deposit.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Deposit.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        for (const v of message.amount){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeposit();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                case 3:
                    message.amount.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDeposit();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDeposit();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        if (message.amount) {
            obj.amount = message.amount.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.amount = message.amount;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Deposit.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/Deposit",
            value: Deposit.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Deposit.decode(message.value);
    },
    toProto (message) {
        return Deposit.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.Deposit",
            value: Deposit.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Deposit.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseProposal() {
    return {
        id: BigInt(0),
        messages: [],
        status: 0,
        finalTallyResult: undefined,
        submitTime: undefined,
        depositEndTime: undefined,
        totalDeposit: [],
        votingStartTime: undefined,
        votingEndTime: undefined,
        metadata: "",
        title: "",
        summary: "",
        proposer: "",
        expedited: false,
        failedReason: ""
    };
}
const Proposal = {
    typeUrl: "/cosmos.gov.v1.Proposal",
    aminoType: "cosmos-sdk/v1/Proposal",
    is (o) {
        return o && (o.$typeUrl === Proposal.typeUrl || typeof o.id === "bigint" && Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].is(o.messages[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && Array.isArray(o.totalDeposit) && (!o.totalDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.totalDeposit[0])) && typeof o.metadata === "string" && typeof o.title === "string" && typeof o.summary === "string" && typeof o.proposer === "string" && typeof o.expedited === "boolean" && typeof o.failedReason === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Proposal.typeUrl || typeof o.id === "bigint" && Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].isAmino(o.messages[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && Array.isArray(o.total_deposit) && (!o.total_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.total_deposit[0])) && typeof o.metadata === "string" && typeof o.title === "string" && typeof o.summary === "string" && typeof o.proposer === "string" && typeof o.expedited === "boolean" && typeof o.failed_reason === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.id !== BigInt(0)) {
            writer.uint32(8).uint64(message.id);
        }
        for (const v of message.messages){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.status !== 0) {
            writer.uint32(24).int32(message.status);
        }
        if (message.finalTallyResult !== undefined) {
            TallyResult.encode(message.finalTallyResult, writer.uint32(34).fork()).ldelim();
        }
        if (message.submitTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.submitTime), writer.uint32(42).fork()).ldelim();
        }
        if (message.depositEndTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.depositEndTime), writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.totalDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(58).fork()).ldelim();
        }
        if (message.votingStartTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingStartTime), writer.uint32(66).fork()).ldelim();
        }
        if (message.votingEndTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingEndTime), writer.uint32(74).fork()).ldelim();
        }
        if (message.metadata !== "") {
            writer.uint32(82).string(message.metadata);
        }
        if (message.title !== "") {
            writer.uint32(90).string(message.title);
        }
        if (message.summary !== "") {
            writer.uint32(98).string(message.summary);
        }
        if (message.proposer !== "") {
            writer.uint32(106).string(message.proposer);
        }
        if (message.expedited === true) {
            writer.uint32(112).bool(message.expedited);
        }
        if (message.failedReason !== "") {
            writer.uint32(122).string(message.failedReason);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.id = reader.uint64();
                    break;
                case 2:
                    message.messages.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.status = reader.int32();
                    break;
                case 4:
                    message.finalTallyResult = TallyResult.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.submitTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.depositEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.totalDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.votingStartTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 9:
                    message.votingEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.metadata = reader.string();
                    break;
                case 11:
                    message.title = reader.string();
                    break;
                case 12:
                    message.summary = reader.string();
                    break;
                case 13:
                    message.proposer = reader.string();
                    break;
                case 14:
                    message.expedited = reader.bool();
                    break;
                case 15:
                    message.failedReason = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseProposal();
        message.id = object.id !== undefined && object.id !== null ? BigInt(object.id.toString()) : BigInt(0);
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(e)) || [];
        message.status = object.status ?? 0;
        message.finalTallyResult = object.finalTallyResult !== undefined && object.finalTallyResult !== null ? TallyResult.fromPartial(object.finalTallyResult) : undefined;
        message.submitTime = object.submitTime ?? undefined;
        message.depositEndTime = object.depositEndTime ?? undefined;
        message.totalDeposit = object.totalDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.votingStartTime = object.votingStartTime ?? undefined;
        message.votingEndTime = object.votingEndTime ?? undefined;
        message.metadata = object.metadata ?? "";
        message.title = object.title ?? "";
        message.summary = object.summary ?? "";
        message.proposer = object.proposer ?? "";
        message.expedited = object.expedited ?? false;
        message.failedReason = object.failedReason ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseProposal();
        if (object.id !== undefined && object.id !== null) {
            message.id = BigInt(object.id);
        }
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(e)) || [];
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.final_tally_result !== undefined && object.final_tally_result !== null) {
            message.finalTallyResult = TallyResult.fromAmino(object.final_tally_result);
        }
        if (object.submit_time !== undefined && object.submit_time !== null) {
            message.submitTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.submit_time));
        }
        if (object.deposit_end_time !== undefined && object.deposit_end_time !== null) {
            message.depositEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.deposit_end_time));
        }
        message.totalDeposit = object.total_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.voting_start_time !== undefined && object.voting_start_time !== null) {
            message.votingStartTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.voting_start_time));
        }
        if (object.voting_end_time !== undefined && object.voting_end_time !== null) {
            message.votingEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.voting_end_time));
        }
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = object.metadata;
        }
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        if (object.summary !== undefined && object.summary !== null) {
            message.summary = object.summary;
        }
        if (object.proposer !== undefined && object.proposer !== null) {
            message.proposer = object.proposer;
        }
        if (object.expedited !== undefined && object.expedited !== null) {
            message.expedited = object.expedited;
        }
        if (object.failed_reason !== undefined && object.failed_reason !== null) {
            message.failedReason = object.failed_reason;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.id = message.id !== BigInt(0) ? message.id?.toString() : undefined;
        if (message.messages) {
            obj.messages = message.messages.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(e) : undefined);
        } else {
            obj.messages = message.messages;
        }
        obj.status = message.status === 0 ? undefined : message.status;
        obj.final_tally_result = message.finalTallyResult ? TallyResult.toAmino(message.finalTallyResult) : undefined;
        obj.submit_time = message.submitTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.submitTime)) : undefined;
        obj.deposit_end_time = message.depositEndTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.depositEndTime)) : undefined;
        if (message.totalDeposit) {
            obj.total_deposit = message.totalDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.total_deposit = message.totalDeposit;
        }
        obj.voting_start_time = message.votingStartTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingStartTime)) : undefined;
        obj.voting_end_time = message.votingEndTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingEndTime)) : undefined;
        obj.metadata = message.metadata === "" ? undefined : message.metadata;
        obj.title = message.title === "" ? undefined : message.title;
        obj.summary = message.summary === "" ? undefined : message.summary;
        obj.proposer = message.proposer === "" ? undefined : message.proposer;
        obj.expedited = message.expedited === false ? undefined : message.expedited;
        obj.failed_reason = message.failedReason === "" ? undefined : message.failedReason;
        return obj;
    },
    fromAminoMsg (object) {
        return Proposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/Proposal",
            value: Proposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Proposal.decode(message.value);
    },
    toProto (message) {
        return Proposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.Proposal",
            value: Proposal.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Proposal.typeUrl)) {
            return;
        }
        TallyResult.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseTallyResult() {
    return {
        yesCount: "",
        abstainCount: "",
        noCount: "",
        noWithVetoCount: ""
    };
}
const TallyResult = {
    typeUrl: "/cosmos.gov.v1.TallyResult",
    aminoType: "cosmos-sdk/v1/TallyResult",
    is (o) {
        return o && (o.$typeUrl === TallyResult.typeUrl || typeof o.yesCount === "string" && typeof o.abstainCount === "string" && typeof o.noCount === "string" && typeof o.noWithVetoCount === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TallyResult.typeUrl || typeof o.yes_count === "string" && typeof o.abstain_count === "string" && typeof o.no_count === "string" && typeof o.no_with_veto_count === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.yesCount !== "") {
            writer.uint32(10).string(message.yesCount);
        }
        if (message.abstainCount !== "") {
            writer.uint32(18).string(message.abstainCount);
        }
        if (message.noCount !== "") {
            writer.uint32(26).string(message.noCount);
        }
        if (message.noWithVetoCount !== "") {
            writer.uint32(34).string(message.noWithVetoCount);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTallyResult();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.yesCount = reader.string();
                    break;
                case 2:
                    message.abstainCount = reader.string();
                    break;
                case 3:
                    message.noCount = reader.string();
                    break;
                case 4:
                    message.noWithVetoCount = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTallyResult();
        message.yesCount = object.yesCount ?? "";
        message.abstainCount = object.abstainCount ?? "";
        message.noCount = object.noCount ?? "";
        message.noWithVetoCount = object.noWithVetoCount ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseTallyResult();
        if (object.yes_count !== undefined && object.yes_count !== null) {
            message.yesCount = object.yes_count;
        }
        if (object.abstain_count !== undefined && object.abstain_count !== null) {
            message.abstainCount = object.abstain_count;
        }
        if (object.no_count !== undefined && object.no_count !== null) {
            message.noCount = object.no_count;
        }
        if (object.no_with_veto_count !== undefined && object.no_with_veto_count !== null) {
            message.noWithVetoCount = object.no_with_veto_count;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.yes_count = message.yesCount === "" ? undefined : message.yesCount;
        obj.abstain_count = message.abstainCount === "" ? undefined : message.abstainCount;
        obj.no_count = message.noCount === "" ? undefined : message.noCount;
        obj.no_with_veto_count = message.noWithVetoCount === "" ? undefined : message.noWithVetoCount;
        return obj;
    },
    fromAminoMsg (object) {
        return TallyResult.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/TallyResult",
            value: TallyResult.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TallyResult.decode(message.value);
    },
    toProto (message) {
        return TallyResult.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.TallyResult",
            value: TallyResult.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseVote() {
    return {
        proposalId: BigInt(0),
        voter: "",
        options: [],
        metadata: ""
    };
}
const Vote = {
    typeUrl: "/cosmos.gov.v1.Vote",
    aminoType: "cosmos-sdk/v1/Vote",
    is (o) {
        return o && (o.$typeUrl === Vote.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || WeightedVoteOption.is(o.options[0])) && typeof o.metadata === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Vote.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || WeightedVoteOption.isAmino(o.options[0])) && typeof o.metadata === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        for (const v of message.options){
            WeightedVoteOption.encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.metadata !== "") {
            writer.uint32(42).string(message.metadata);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVote();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 4:
                    message.options.push(WeightedVoteOption.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.metadata = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseVote();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.options = object.options?.map((e)=>WeightedVoteOption.fromPartial(e)) || [];
        message.metadata = object.metadata ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseVote();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        message.options = object.options?.map((e)=>WeightedVoteOption.fromAmino(e)) || [];
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = object.metadata;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.voter = message.voter === "" ? undefined : message.voter;
        if (message.options) {
            obj.options = message.options.map((e)=>e ? WeightedVoteOption.toAmino(e) : undefined);
        } else {
            obj.options = message.options;
        }
        obj.metadata = message.metadata === "" ? undefined : message.metadata;
        return obj;
    },
    fromAminoMsg (object) {
        return Vote.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/Vote",
            value: Vote.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Vote.decode(message.value);
    },
    toProto (message) {
        return Vote.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.Vote",
            value: Vote.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Vote.typeUrl)) {
            return;
        }
        WeightedVoteOption.registerTypeUrl();
    }
};
function createBaseDepositParams() {
    return {
        minDeposit: [],
        maxDepositPeriod: undefined
    };
}
const DepositParams = {
    typeUrl: "/cosmos.gov.v1.DepositParams",
    aminoType: "cosmos-sdk/v1/DepositParams",
    is (o) {
        return o && (o.$typeUrl === DepositParams.typeUrl || Array.isArray(o.minDeposit) && (!o.minDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.minDeposit[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DepositParams.typeUrl || Array.isArray(o.min_deposit) && (!o.min_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.min_deposit[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.minDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.maxDepositPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.maxDepositPeriod, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDepositParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.minDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDepositParams();
        message.minDeposit = object.minDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.maxDepositPeriod = object.maxDepositPeriod !== undefined && object.maxDepositPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.maxDepositPeriod) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDepositParams();
        message.minDeposit = object.min_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.max_deposit_period !== undefined && object.max_deposit_period !== null) {
            message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.max_deposit_period);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.minDeposit) {
            obj.min_deposit = message.minDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.min_deposit = message.minDeposit;
        }
        obj.max_deposit_period = message.maxDepositPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.maxDepositPeriod) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return DepositParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/DepositParams",
            value: DepositParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DepositParams.decode(message.value);
    },
    toProto (message) {
        return DepositParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.DepositParams",
            value: DepositParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DepositParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseVotingParams() {
    return {
        votingPeriod: undefined
    };
}
const VotingParams = {
    typeUrl: "/cosmos.gov.v1.VotingParams",
    aminoType: "cosmos-sdk/v1/VotingParams",
    is (o) {
        return o && o.$typeUrl === VotingParams.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === VotingParams.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.votingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.votingPeriod, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVotingParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseVotingParams();
        message.votingPeriod = object.votingPeriod !== undefined && object.votingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.votingPeriod) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseVotingParams();
        if (object.voting_period !== undefined && object.voting_period !== null) {
            message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.voting_period);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.voting_period = message.votingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.votingPeriod) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return VotingParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/VotingParams",
            value: VotingParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return VotingParams.decode(message.value);
    },
    toProto (message) {
        return VotingParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.VotingParams",
            value: VotingParams.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseTallyParams() {
    return {
        quorum: "",
        threshold: "",
        vetoThreshold: ""
    };
}
const TallyParams = {
    typeUrl: "/cosmos.gov.v1.TallyParams",
    aminoType: "cosmos-sdk/v1/TallyParams",
    is (o) {
        return o && (o.$typeUrl === TallyParams.typeUrl || typeof o.quorum === "string" && typeof o.threshold === "string" && typeof o.vetoThreshold === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TallyParams.typeUrl || typeof o.quorum === "string" && typeof o.threshold === "string" && typeof o.veto_threshold === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.quorum !== "") {
            writer.uint32(10).string(message.quorum);
        }
        if (message.threshold !== "") {
            writer.uint32(18).string(message.threshold);
        }
        if (message.vetoThreshold !== "") {
            writer.uint32(26).string(message.vetoThreshold);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTallyParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.quorum = reader.string();
                    break;
                case 2:
                    message.threshold = reader.string();
                    break;
                case 3:
                    message.vetoThreshold = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTallyParams();
        message.quorum = object.quorum ?? "";
        message.threshold = object.threshold ?? "";
        message.vetoThreshold = object.vetoThreshold ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseTallyParams();
        if (object.quorum !== undefined && object.quorum !== null) {
            message.quorum = object.quorum;
        }
        if (object.threshold !== undefined && object.threshold !== null) {
            message.threshold = object.threshold;
        }
        if (object.veto_threshold !== undefined && object.veto_threshold !== null) {
            message.vetoThreshold = object.veto_threshold;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.quorum = message.quorum === "" ? undefined : message.quorum;
        obj.threshold = message.threshold === "" ? undefined : message.threshold;
        obj.veto_threshold = message.vetoThreshold === "" ? undefined : message.vetoThreshold;
        return obj;
    },
    fromAminoMsg (object) {
        return TallyParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/TallyParams",
            value: TallyParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TallyParams.decode(message.value);
    },
    toProto (message) {
        return TallyParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.TallyParams",
            value: TallyParams.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseParams() {
    return {
        minDeposit: [],
        maxDepositPeriod: undefined,
        votingPeriod: undefined,
        quorum: "",
        threshold: "",
        vetoThreshold: "",
        minInitialDepositRatio: "",
        proposalCancelRatio: "",
        proposalCancelDest: "",
        expeditedVotingPeriod: undefined,
        expeditedThreshold: "",
        expeditedMinDeposit: [],
        burnVoteQuorum: false,
        burnProposalDepositPrevote: false,
        burnVoteVeto: false,
        minDepositRatio: ""
    };
}
const Params = {
    typeUrl: "/cosmos.gov.v1.Params",
    aminoType: "cosmos-sdk/v1/Params",
    is (o) {
        return o && (o.$typeUrl === Params.typeUrl || Array.isArray(o.minDeposit) && (!o.minDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.minDeposit[0])) && typeof o.quorum === "string" && typeof o.threshold === "string" && typeof o.vetoThreshold === "string" && typeof o.minInitialDepositRatio === "string" && typeof o.proposalCancelRatio === "string" && typeof o.proposalCancelDest === "string" && typeof o.expeditedThreshold === "string" && Array.isArray(o.expeditedMinDeposit) && (!o.expeditedMinDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.expeditedMinDeposit[0])) && typeof o.burnVoteQuorum === "boolean" && typeof o.burnProposalDepositPrevote === "boolean" && typeof o.burnVoteVeto === "boolean" && typeof o.minDepositRatio === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Params.typeUrl || Array.isArray(o.min_deposit) && (!o.min_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.min_deposit[0])) && typeof o.quorum === "string" && typeof o.threshold === "string" && typeof o.veto_threshold === "string" && typeof o.min_initial_deposit_ratio === "string" && typeof o.proposal_cancel_ratio === "string" && typeof o.proposal_cancel_dest === "string" && typeof o.expedited_threshold === "string" && Array.isArray(o.expedited_min_deposit) && (!o.expedited_min_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.expedited_min_deposit[0])) && typeof o.burn_vote_quorum === "boolean" && typeof o.burn_proposal_deposit_prevote === "boolean" && typeof o.burn_vote_veto === "boolean" && typeof o.min_deposit_ratio === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.minDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.maxDepositPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.maxDepositPeriod, writer.uint32(18).fork()).ldelim();
        }
        if (message.votingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.votingPeriod, writer.uint32(26).fork()).ldelim();
        }
        if (message.quorum !== "") {
            writer.uint32(34).string(message.quorum);
        }
        if (message.threshold !== "") {
            writer.uint32(42).string(message.threshold);
        }
        if (message.vetoThreshold !== "") {
            writer.uint32(50).string(message.vetoThreshold);
        }
        if (message.minInitialDepositRatio !== "") {
            writer.uint32(58).string(message.minInitialDepositRatio);
        }
        if (message.proposalCancelRatio !== "") {
            writer.uint32(66).string(message.proposalCancelRatio);
        }
        if (message.proposalCancelDest !== "") {
            writer.uint32(74).string(message.proposalCancelDest);
        }
        if (message.expeditedVotingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.expeditedVotingPeriod, writer.uint32(82).fork()).ldelim();
        }
        if (message.expeditedThreshold !== "") {
            writer.uint32(90).string(message.expeditedThreshold);
        }
        for (const v of message.expeditedMinDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(98).fork()).ldelim();
        }
        if (message.burnVoteQuorum === true) {
            writer.uint32(104).bool(message.burnVoteQuorum);
        }
        if (message.burnProposalDepositPrevote === true) {
            writer.uint32(112).bool(message.burnProposalDepositPrevote);
        }
        if (message.burnVoteVeto === true) {
            writer.uint32(120).bool(message.burnVoteVeto);
        }
        if (message.minDepositRatio !== "") {
            writer.uint32(130).string(message.minDepositRatio);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.minDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.quorum = reader.string();
                    break;
                case 5:
                    message.threshold = reader.string();
                    break;
                case 6:
                    message.vetoThreshold = reader.string();
                    break;
                case 7:
                    message.minInitialDepositRatio = reader.string();
                    break;
                case 8:
                    message.proposalCancelRatio = reader.string();
                    break;
                case 9:
                    message.proposalCancelDest = reader.string();
                    break;
                case 10:
                    message.expeditedVotingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 11:
                    message.expeditedThreshold = reader.string();
                    break;
                case 12:
                    message.expeditedMinDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 13:
                    message.burnVoteQuorum = reader.bool();
                    break;
                case 14:
                    message.burnProposalDepositPrevote = reader.bool();
                    break;
                case 15:
                    message.burnVoteVeto = reader.bool();
                    break;
                case 16:
                    message.minDepositRatio = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseParams();
        message.minDeposit = object.minDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.maxDepositPeriod = object.maxDepositPeriod !== undefined && object.maxDepositPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.maxDepositPeriod) : undefined;
        message.votingPeriod = object.votingPeriod !== undefined && object.votingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.votingPeriod) : undefined;
        message.quorum = object.quorum ?? "";
        message.threshold = object.threshold ?? "";
        message.vetoThreshold = object.vetoThreshold ?? "";
        message.minInitialDepositRatio = object.minInitialDepositRatio ?? "";
        message.proposalCancelRatio = object.proposalCancelRatio ?? "";
        message.proposalCancelDest = object.proposalCancelDest ?? "";
        message.expeditedVotingPeriod = object.expeditedVotingPeriod !== undefined && object.expeditedVotingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.expeditedVotingPeriod) : undefined;
        message.expeditedThreshold = object.expeditedThreshold ?? "";
        message.expeditedMinDeposit = object.expeditedMinDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.burnVoteQuorum = object.burnVoteQuorum ?? false;
        message.burnProposalDepositPrevote = object.burnProposalDepositPrevote ?? false;
        message.burnVoteVeto = object.burnVoteVeto ?? false;
        message.minDepositRatio = object.minDepositRatio ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseParams();
        message.minDeposit = object.min_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.max_deposit_period !== undefined && object.max_deposit_period !== null) {
            message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.max_deposit_period);
        }
        if (object.voting_period !== undefined && object.voting_period !== null) {
            message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.voting_period);
        }
        if (object.quorum !== undefined && object.quorum !== null) {
            message.quorum = object.quorum;
        }
        if (object.threshold !== undefined && object.threshold !== null) {
            message.threshold = object.threshold;
        }
        if (object.veto_threshold !== undefined && object.veto_threshold !== null) {
            message.vetoThreshold = object.veto_threshold;
        }
        if (object.min_initial_deposit_ratio !== undefined && object.min_initial_deposit_ratio !== null) {
            message.minInitialDepositRatio = object.min_initial_deposit_ratio;
        }
        if (object.proposal_cancel_ratio !== undefined && object.proposal_cancel_ratio !== null) {
            message.proposalCancelRatio = object.proposal_cancel_ratio;
        }
        if (object.proposal_cancel_dest !== undefined && object.proposal_cancel_dest !== null) {
            message.proposalCancelDest = object.proposal_cancel_dest;
        }
        if (object.expedited_voting_period !== undefined && object.expedited_voting_period !== null) {
            message.expeditedVotingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.expedited_voting_period);
        }
        if (object.expedited_threshold !== undefined && object.expedited_threshold !== null) {
            message.expeditedThreshold = object.expedited_threshold;
        }
        message.expeditedMinDeposit = object.expedited_min_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.burn_vote_quorum !== undefined && object.burn_vote_quorum !== null) {
            message.burnVoteQuorum = object.burn_vote_quorum;
        }
        if (object.burn_proposal_deposit_prevote !== undefined && object.burn_proposal_deposit_prevote !== null) {
            message.burnProposalDepositPrevote = object.burn_proposal_deposit_prevote;
        }
        if (object.burn_vote_veto !== undefined && object.burn_vote_veto !== null) {
            message.burnVoteVeto = object.burn_vote_veto;
        }
        if (object.min_deposit_ratio !== undefined && object.min_deposit_ratio !== null) {
            message.minDepositRatio = object.min_deposit_ratio;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.minDeposit) {
            obj.min_deposit = message.minDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.min_deposit = message.minDeposit;
        }
        obj.max_deposit_period = message.maxDepositPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.maxDepositPeriod) : undefined;
        obj.voting_period = message.votingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.votingPeriod) : undefined;
        obj.quorum = message.quorum === "" ? undefined : message.quorum;
        obj.threshold = message.threshold === "" ? undefined : message.threshold;
        obj.veto_threshold = message.vetoThreshold === "" ? undefined : message.vetoThreshold;
        obj.min_initial_deposit_ratio = message.minInitialDepositRatio === "" ? undefined : message.minInitialDepositRatio;
        obj.proposal_cancel_ratio = message.proposalCancelRatio === "" ? undefined : message.proposalCancelRatio;
        obj.proposal_cancel_dest = message.proposalCancelDest === "" ? undefined : message.proposalCancelDest;
        obj.expedited_voting_period = message.expeditedVotingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.expeditedVotingPeriod) : undefined;
        obj.expedited_threshold = message.expeditedThreshold === "" ? undefined : message.expeditedThreshold;
        if (message.expeditedMinDeposit) {
            obj.expedited_min_deposit = message.expeditedMinDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.expedited_min_deposit = message.expeditedMinDeposit;
        }
        obj.burn_vote_quorum = message.burnVoteQuorum === false ? undefined : message.burnVoteQuorum;
        obj.burn_proposal_deposit_prevote = message.burnProposalDepositPrevote === false ? undefined : message.burnProposalDepositPrevote;
        obj.burn_vote_veto = message.burnVoteVeto === false ? undefined : message.burnVoteVeto;
        obj.min_deposit_ratio = message.minDepositRatio === "" ? undefined : message.minDepositRatio;
        return obj;
    },
    fromAminoMsg (object) {
        return Params.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/Params",
            value: Params.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Params.decode(message.value);
    },
    toProto (message) {
        return Params.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.Params",
            value: Params.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Params.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GenesisState": (()=>GenesisState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseGenesisState() {
    return {
        startingProposalId: BigInt(0),
        deposits: [],
        votes: [],
        proposals: [],
        depositParams: undefined,
        votingParams: undefined,
        tallyParams: undefined,
        params: undefined,
        constitution: ""
    };
}
const GenesisState = {
    typeUrl: "/cosmos.gov.v1.GenesisState",
    aminoType: "cosmos-sdk/v1/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.startingProposalId === "bigint" && Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].is(o.deposits[0])) && Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].is(o.votes[0])) && Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].is(o.proposals[0])) && typeof o.constitution === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.starting_proposal_id === "bigint" && Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].isAmino(o.deposits[0])) && Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].isAmino(o.votes[0])) && Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].isAmino(o.proposals[0])) && typeof o.constitution === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.startingProposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.startingProposalId);
        }
        for (const v of message.deposits){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.votes){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.proposals){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.depositParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].encode(message.depositParams, writer.uint32(42).fork()).ldelim();
        }
        if (message.votingParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].encode(message.votingParams, writer.uint32(50).fork()).ldelim();
        }
        if (message.tallyParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].encode(message.tallyParams, writer.uint32(58).fork()).ldelim();
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(66).fork()).ldelim();
        }
        if (message.constitution !== "") {
            writer.uint32(74).string(message.constitution);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.startingProposalId = reader.uint64();
                    break;
                case 2:
                    message.deposits.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.votes.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.proposals.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].decode(reader, reader.uint32());
                    break;
                case 6:
                    message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].decode(reader, reader.uint32());
                    break;
                case 7:
                    message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].decode(reader, reader.uint32());
                    break;
                case 8:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                case 9:
                    message.constitution = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.startingProposalId = object.startingProposalId !== undefined && object.startingProposalId !== null ? BigInt(object.startingProposalId.toString()) : BigInt(0);
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(e)) || [];
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(e)) || [];
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(e)) || [];
        message.depositParams = object.depositParams !== undefined && object.depositParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial(object.depositParams) : undefined;
        message.votingParams = object.votingParams !== undefined && object.votingParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial(object.votingParams) : undefined;
        message.tallyParams = object.tallyParams !== undefined && object.tallyParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial(object.tallyParams) : undefined;
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        message.constitution = object.constitution ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.starting_proposal_id !== undefined && object.starting_proposal_id !== null) {
            message.startingProposalId = BigInt(object.starting_proposal_id);
        }
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(e)) || [];
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(e)) || [];
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(e)) || [];
        if (object.deposit_params !== undefined && object.deposit_params !== null) {
            message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromAmino(object.deposit_params);
        }
        if (object.voting_params !== undefined && object.voting_params !== null) {
            message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromAmino(object.voting_params);
        }
        if (object.tally_params !== undefined && object.tally_params !== null) {
            message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromAmino(object.tally_params);
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        if (object.constitution !== undefined && object.constitution !== null) {
            message.constitution = object.constitution;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.starting_proposal_id = message.startingProposalId !== BigInt(0) ? message.startingProposalId?.toString() : undefined;
        if (message.deposits) {
            obj.deposits = message.deposits.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(e) : undefined);
        } else {
            obj.deposits = message.deposits;
        }
        if (message.votes) {
            obj.votes = message.votes.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(e) : undefined);
        } else {
            obj.votes = message.votes;
        }
        if (message.proposals) {
            obj.proposals = message.proposals.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(e) : undefined);
        } else {
            obj.proposals = message.proposals;
        }
        obj.deposit_params = message.depositParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(message.depositParams) : undefined;
        obj.voting_params = message.votingParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(message.votingParams) : undefined;
        obj.tally_params = message.tallyParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(message.tallyParams) : undefined;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        obj.constitution = message.constitution === "" ? undefined : message.constitution;
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryConstitutionRequest": (()=>QueryConstitutionRequest),
    "QueryConstitutionResponse": (()=>QueryConstitutionResponse),
    "QueryDepositRequest": (()=>QueryDepositRequest),
    "QueryDepositResponse": (()=>QueryDepositResponse),
    "QueryDepositsRequest": (()=>QueryDepositsRequest),
    "QueryDepositsResponse": (()=>QueryDepositsResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse),
    "QueryProposalRequest": (()=>QueryProposalRequest),
    "QueryProposalResponse": (()=>QueryProposalResponse),
    "QueryProposalsRequest": (()=>QueryProposalsRequest),
    "QueryProposalsResponse": (()=>QueryProposalsResponse),
    "QueryTallyResultRequest": (()=>QueryTallyResultRequest),
    "QueryTallyResultResponse": (()=>QueryTallyResultResponse),
    "QueryVoteRequest": (()=>QueryVoteRequest),
    "QueryVoteResponse": (()=>QueryVoteResponse),
    "QueryVotesRequest": (()=>QueryVotesRequest),
    "QueryVotesResponse": (()=>QueryVotesResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
function createBaseQueryConstitutionRequest() {
    return {};
}
const QueryConstitutionRequest = {
    typeUrl: "/cosmos.gov.v1.QueryConstitutionRequest",
    aminoType: "cosmos-sdk/v1/QueryConstitutionRequest",
    is (o) {
        return o && o.$typeUrl === QueryConstitutionRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryConstitutionRequest.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryConstitutionRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseQueryConstitutionRequest();
        return message;
    },
    fromAmino (_) {
        const message = createBaseQueryConstitutionRequest();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return QueryConstitutionRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryConstitutionRequest",
            value: QueryConstitutionRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryConstitutionRequest.decode(message.value);
    },
    toProto (message) {
        return QueryConstitutionRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryConstitutionRequest",
            value: QueryConstitutionRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryConstitutionResponse() {
    return {
        constitution: ""
    };
}
const QueryConstitutionResponse = {
    typeUrl: "/cosmos.gov.v1.QueryConstitutionResponse",
    aminoType: "cosmos-sdk/v1/QueryConstitutionResponse",
    is (o) {
        return o && (o.$typeUrl === QueryConstitutionResponse.typeUrl || typeof o.constitution === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryConstitutionResponse.typeUrl || typeof o.constitution === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.constitution !== "") {
            writer.uint32(10).string(message.constitution);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryConstitutionResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.constitution = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryConstitutionResponse();
        message.constitution = object.constitution ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryConstitutionResponse();
        if (object.constitution !== undefined && object.constitution !== null) {
            message.constitution = object.constitution;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.constitution = message.constitution === "" ? undefined : message.constitution;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryConstitutionResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryConstitutionResponse",
            value: QueryConstitutionResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryConstitutionResponse.decode(message.value);
    },
    toProto (message) {
        return QueryConstitutionResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryConstitutionResponse",
            value: QueryConstitutionResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryProposalRequest() {
    return {
        proposalId: BigInt(0)
    };
}
const QueryProposalRequest = {
    typeUrl: "/cosmos.gov.v1.QueryProposalRequest",
    aminoType: "cosmos-sdk/v1/QueryProposalRequest",
    is (o) {
        return o && (o.$typeUrl === QueryProposalRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryProposalRequest",
            value: QueryProposalRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalRequest.decode(message.value);
    },
    toProto (message) {
        return QueryProposalRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryProposalRequest",
            value: QueryProposalRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryProposalResponse() {
    return {
        proposal: undefined
    };
}
const QueryProposalResponse = {
    typeUrl: "/cosmos.gov.v1.QueryProposalResponse",
    aminoType: "cosmos-sdk/v1/QueryProposalResponse",
    is (o) {
        return o && o.$typeUrl === QueryProposalResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryProposalResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposal !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(message.proposal, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposal = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalResponse();
        message.proposal = object.proposal !== undefined && object.proposal !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(object.proposal) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalResponse();
        if (object.proposal !== undefined && object.proposal !== null) {
            message.proposal = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(object.proposal);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal = message.proposal ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(message.proposal) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryProposalResponse",
            value: QueryProposalResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalResponse.decode(message.value);
    },
    toProto (message) {
        return QueryProposalResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryProposalResponse",
            value: QueryProposalResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
    }
};
function createBaseQueryProposalsRequest() {
    return {
        proposalStatus: 0,
        voter: "",
        depositor: "",
        pagination: undefined
    };
}
const QueryProposalsRequest = {
    typeUrl: "/cosmos.gov.v1.QueryProposalsRequest",
    aminoType: "cosmos-sdk/v1/QueryProposalsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryProposalsRequest.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.proposalStatus) && typeof o.voter === "string" && typeof o.depositor === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalsRequest.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.proposal_status) && typeof o.voter === "string" && typeof o.depositor === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalStatus !== 0) {
            writer.uint32(8).int32(message.proposalStatus);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        if (message.depositor !== "") {
            writer.uint32(26).string(message.depositor);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalStatus = reader.int32();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.depositor = reader.string();
                    break;
                case 4:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalsRequest();
        message.proposalStatus = object.proposalStatus ?? 0;
        message.voter = object.voter ?? "";
        message.depositor = object.depositor ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalsRequest();
        if (object.proposal_status !== undefined && object.proposal_status !== null) {
            message.proposalStatus = object.proposal_status;
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_status = message.proposalStatus === 0 ? undefined : message.proposalStatus;
        obj.voter = message.voter === "" ? undefined : message.voter;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryProposalsRequest",
            value: QueryProposalsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryProposalsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryProposalsRequest",
            value: QueryProposalsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryProposalsResponse() {
    return {
        proposals: [],
        pagination: undefined
    };
}
const QueryProposalsResponse = {
    typeUrl: "/cosmos.gov.v1.QueryProposalsResponse",
    aminoType: "cosmos-sdk/v1/QueryProposalsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryProposalsResponse.typeUrl || Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].is(o.proposals[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalsResponse.typeUrl || Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].isAmino(o.proposals[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.proposals){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposals.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalsResponse();
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalsResponse();
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.proposals) {
            obj.proposals = message.proposals.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(e) : undefined);
        } else {
            obj.proposals = message.proposals;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryProposalsResponse",
            value: QueryProposalsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryProposalsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryProposalsResponse",
            value: QueryProposalsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryVoteRequest() {
    return {
        proposalId: BigInt(0),
        voter: ""
    };
}
const QueryVoteRequest = {
    typeUrl: "/cosmos.gov.v1.QueryVoteRequest",
    aminoType: "cosmos-sdk/v1/QueryVoteRequest",
    is (o) {
        return o && (o.$typeUrl === QueryVoteRequest.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVoteRequest.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVoteRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVoteRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVoteRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.voter = message.voter === "" ? undefined : message.voter;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVoteRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryVoteRequest",
            value: QueryVoteRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVoteRequest.decode(message.value);
    },
    toProto (message) {
        return QueryVoteRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryVoteRequest",
            value: QueryVoteRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryVoteResponse() {
    return {
        vote: undefined
    };
}
const QueryVoteResponse = {
    typeUrl: "/cosmos.gov.v1.QueryVoteResponse",
    aminoType: "cosmos-sdk/v1/QueryVoteResponse",
    is (o) {
        return o && o.$typeUrl === QueryVoteResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryVoteResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.vote !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(message.vote, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVoteResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.vote = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVoteResponse();
        message.vote = object.vote !== undefined && object.vote !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(object.vote) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVoteResponse();
        if (object.vote !== undefined && object.vote !== null) {
            message.vote = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(object.vote);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.vote = message.vote ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(message.vote) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVoteResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryVoteResponse",
            value: QueryVoteResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVoteResponse.decode(message.value);
    },
    toProto (message) {
        return QueryVoteResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryVoteResponse",
            value: QueryVoteResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVoteResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
    }
};
function createBaseQueryVotesRequest() {
    return {
        proposalId: BigInt(0),
        pagination: undefined
    };
}
const QueryVotesRequest = {
    typeUrl: "/cosmos.gov.v1.QueryVotesRequest",
    aminoType: "cosmos-sdk/v1/QueryVotesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryVotesRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVotesRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVotesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVotesRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVotesRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVotesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryVotesRequest",
            value: QueryVotesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVotesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryVotesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryVotesRequest",
            value: QueryVotesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVotesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryVotesResponse() {
    return {
        votes: [],
        pagination: undefined
    };
}
const QueryVotesResponse = {
    typeUrl: "/cosmos.gov.v1.QueryVotesResponse",
    aminoType: "cosmos-sdk/v1/QueryVotesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryVotesResponse.typeUrl || Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].is(o.votes[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVotesResponse.typeUrl || Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].isAmino(o.votes[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.votes){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVotesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votes.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVotesResponse();
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVotesResponse();
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.votes) {
            obj.votes = message.votes.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(e) : undefined);
        } else {
            obj.votes = message.votes;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVotesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryVotesResponse",
            value: QueryVotesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVotesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryVotesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryVotesResponse",
            value: QueryVotesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVotesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryParamsRequest() {
    return {
        paramsType: ""
    };
}
const QueryParamsRequest = {
    typeUrl: "/cosmos.gov.v1.QueryParamsRequest",
    aminoType: "cosmos-sdk/v1/QueryParamsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryParamsRequest.typeUrl || typeof o.paramsType === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryParamsRequest.typeUrl || typeof o.params_type === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.paramsType !== "") {
            writer.uint32(10).string(message.paramsType);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.paramsType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsRequest();
        message.paramsType = object.paramsType ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsRequest();
        if (object.params_type !== undefined && object.params_type !== null) {
            message.paramsType = object.params_type;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params_type = message.paramsType === "" ? undefined : message.paramsType;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        votingParams: undefined,
        depositParams: undefined,
        tallyParams: undefined,
        params: undefined
    };
}
const QueryParamsResponse = {
    typeUrl: "/cosmos.gov.v1.QueryParamsResponse",
    aminoType: "cosmos-sdk/v1/QueryParamsResponse",
    is (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryParamsResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.votingParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].encode(message.votingParams, writer.uint32(10).fork()).ldelim();
        }
        if (message.depositParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].encode(message.depositParams, writer.uint32(18).fork()).ldelim();
        }
        if (message.tallyParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].encode(message.tallyParams, writer.uint32(26).fork()).ldelim();
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.votingParams = object.votingParams !== undefined && object.votingParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial(object.votingParams) : undefined;
        message.depositParams = object.depositParams !== undefined && object.depositParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial(object.depositParams) : undefined;
        message.tallyParams = object.tallyParams !== undefined && object.tallyParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial(object.tallyParams) : undefined;
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.voting_params !== undefined && object.voting_params !== null) {
            message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromAmino(object.voting_params);
        }
        if (object.deposit_params !== undefined && object.deposit_params !== null) {
            message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromAmino(object.deposit_params);
        }
        if (object.tally_params !== undefined && object.tally_params !== null) {
            message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromAmino(object.tally_params);
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.voting_params = message.votingParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(message.votingParams) : undefined;
        obj.deposit_params = message.depositParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(message.depositParams) : undefined;
        obj.tally_params = message.tallyParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(message.tallyParams) : undefined;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseQueryDepositRequest() {
    return {
        proposalId: BigInt(0),
        depositor: ""
    };
}
const QueryDepositRequest = {
    typeUrl: "/cosmos.gov.v1.QueryDepositRequest",
    aminoType: "cosmos-sdk/v1/QueryDepositRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDepositRequest.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositRequest.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryDepositRequest",
            value: QueryDepositRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDepositRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryDepositRequest",
            value: QueryDepositRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDepositResponse() {
    return {
        deposit: undefined
    };
}
const QueryDepositResponse = {
    typeUrl: "/cosmos.gov.v1.QueryDepositResponse",
    aminoType: "cosmos-sdk/v1/QueryDepositResponse",
    is (o) {
        return o && o.$typeUrl === QueryDepositResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryDepositResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.deposit !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(message.deposit, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.deposit = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositResponse();
        message.deposit = object.deposit !== undefined && object.deposit !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(object.deposit) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositResponse();
        if (object.deposit !== undefined && object.deposit !== null) {
            message.deposit = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(object.deposit);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.deposit = message.deposit ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(message.deposit) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryDepositResponse",
            value: QueryDepositResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDepositResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryDepositResponse",
            value: QueryDepositResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
    }
};
function createBaseQueryDepositsRequest() {
    return {
        proposalId: BigInt(0),
        pagination: undefined
    };
}
const QueryDepositsRequest = {
    typeUrl: "/cosmos.gov.v1.QueryDepositsRequest",
    aminoType: "cosmos-sdk/v1/QueryDepositsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDepositsRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositsRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositsRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositsRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryDepositsRequest",
            value: QueryDepositsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDepositsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryDepositsRequest",
            value: QueryDepositsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDepositsResponse() {
    return {
        deposits: [],
        pagination: undefined
    };
}
const QueryDepositsResponse = {
    typeUrl: "/cosmos.gov.v1.QueryDepositsResponse",
    aminoType: "cosmos-sdk/v1/QueryDepositsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDepositsResponse.typeUrl || Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].is(o.deposits[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositsResponse.typeUrl || Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].isAmino(o.deposits[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.deposits){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.deposits.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositsResponse();
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositsResponse();
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.deposits) {
            obj.deposits = message.deposits.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(e) : undefined);
        } else {
            obj.deposits = message.deposits;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryDepositsResponse",
            value: QueryDepositsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDepositsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryDepositsResponse",
            value: QueryDepositsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryTallyResultRequest() {
    return {
        proposalId: BigInt(0)
    };
}
const QueryTallyResultRequest = {
    typeUrl: "/cosmos.gov.v1.QueryTallyResultRequest",
    aminoType: "cosmos-sdk/v1/QueryTallyResultRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTallyResultRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTallyResultRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTallyResultRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTallyResultRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTallyResultRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTallyResultRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryTallyResultRequest",
            value: QueryTallyResultRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTallyResultRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTallyResultRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryTallyResultRequest",
            value: QueryTallyResultRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryTallyResultResponse() {
    return {
        tally: undefined
    };
}
const QueryTallyResultResponse = {
    typeUrl: "/cosmos.gov.v1.QueryTallyResultResponse",
    aminoType: "cosmos-sdk/v1/QueryTallyResultResponse",
    is (o) {
        return o && o.$typeUrl === QueryTallyResultResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryTallyResultResponse.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.tally !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].encode(message.tally, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTallyResultResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.tally = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTallyResultResponse();
        message.tally = object.tally !== undefined && object.tally !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromPartial(object.tally) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTallyResultResponse();
        if (object.tally !== undefined && object.tally !== null) {
            message.tally = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromAmino(object.tally);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.tally = message.tally ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].toAmino(message.tally) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTallyResultResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/QueryTallyResultResponse",
            value: QueryTallyResultResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTallyResultResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTallyResultResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.QueryTallyResultResponse",
            value: QueryTallyResultResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTallyResultResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/gov.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Deposit": (()=>Deposit),
    "DepositParams": (()=>DepositParams),
    "Proposal": (()=>Proposal),
    "ProposalStatus": (()=>ProposalStatus),
    "ProposalStatusAmino": (()=>ProposalStatusAmino),
    "TallyParams": (()=>TallyParams),
    "TallyResult": (()=>TallyResult),
    "TextProposal": (()=>TextProposal),
    "Vote": (()=>Vote),
    "VoteOption": (()=>VoteOption),
    "VoteOptionAmino": (()=>VoteOptionAmino),
    "VotingParams": (()=>VotingParams),
    "WeightedVoteOption": (()=>WeightedVoteOption),
    "proposalStatusFromJSON": (()=>proposalStatusFromJSON),
    "proposalStatusToJSON": (()=>proposalStatusToJSON),
    "voteOptionFromJSON": (()=>voteOptionFromJSON),
    "voteOptionToJSON": (()=>voteOptionToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/distribution/v1beta1/distribution.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/params/v1beta1/params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/upgrade/v1beta1/upgrade.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmwasm/wasm/v1/proposal_legacy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/decimal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
var VoteOption;
(function(VoteOption) {
    /** VOTE_OPTION_UNSPECIFIED - VOTE_OPTION_UNSPECIFIED defines a no-op vote option. */ VoteOption[VoteOption["VOTE_OPTION_UNSPECIFIED"] = 0] = "VOTE_OPTION_UNSPECIFIED";
    /** VOTE_OPTION_YES - VOTE_OPTION_YES defines a yes vote option. */ VoteOption[VoteOption["VOTE_OPTION_YES"] = 1] = "VOTE_OPTION_YES";
    /** VOTE_OPTION_ABSTAIN - VOTE_OPTION_ABSTAIN defines an abstain vote option. */ VoteOption[VoteOption["VOTE_OPTION_ABSTAIN"] = 2] = "VOTE_OPTION_ABSTAIN";
    /** VOTE_OPTION_NO - VOTE_OPTION_NO defines a no vote option. */ VoteOption[VoteOption["VOTE_OPTION_NO"] = 3] = "VOTE_OPTION_NO";
    /** VOTE_OPTION_NO_WITH_VETO - VOTE_OPTION_NO_WITH_VETO defines a no with veto vote option. */ VoteOption[VoteOption["VOTE_OPTION_NO_WITH_VETO"] = 4] = "VOTE_OPTION_NO_WITH_VETO";
    VoteOption[VoteOption["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(VoteOption || (VoteOption = {}));
const VoteOptionAmino = VoteOption;
function voteOptionFromJSON(object) {
    switch(object){
        case 0:
        case "VOTE_OPTION_UNSPECIFIED":
            return VoteOption.VOTE_OPTION_UNSPECIFIED;
        case 1:
        case "VOTE_OPTION_YES":
            return VoteOption.VOTE_OPTION_YES;
        case 2:
        case "VOTE_OPTION_ABSTAIN":
            return VoteOption.VOTE_OPTION_ABSTAIN;
        case 3:
        case "VOTE_OPTION_NO":
            return VoteOption.VOTE_OPTION_NO;
        case 4:
        case "VOTE_OPTION_NO_WITH_VETO":
            return VoteOption.VOTE_OPTION_NO_WITH_VETO;
        case -1:
        case "UNRECOGNIZED":
        default:
            return VoteOption.UNRECOGNIZED;
    }
}
function voteOptionToJSON(object) {
    switch(object){
        case VoteOption.VOTE_OPTION_UNSPECIFIED:
            return "VOTE_OPTION_UNSPECIFIED";
        case VoteOption.VOTE_OPTION_YES:
            return "VOTE_OPTION_YES";
        case VoteOption.VOTE_OPTION_ABSTAIN:
            return "VOTE_OPTION_ABSTAIN";
        case VoteOption.VOTE_OPTION_NO:
            return "VOTE_OPTION_NO";
        case VoteOption.VOTE_OPTION_NO_WITH_VETO:
            return "VOTE_OPTION_NO_WITH_VETO";
        case VoteOption.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var ProposalStatus;
(function(ProposalStatus) {
    /** PROPOSAL_STATUS_UNSPECIFIED - PROPOSAL_STATUS_UNSPECIFIED defines the default proposal status. */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_UNSPECIFIED"] = 0] = "PROPOSAL_STATUS_UNSPECIFIED";
    /**
     * PROPOSAL_STATUS_DEPOSIT_PERIOD - PROPOSAL_STATUS_DEPOSIT_PERIOD defines a proposal status during the deposit
     * period.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_DEPOSIT_PERIOD"] = 1] = "PROPOSAL_STATUS_DEPOSIT_PERIOD";
    /**
     * PROPOSAL_STATUS_VOTING_PERIOD - PROPOSAL_STATUS_VOTING_PERIOD defines a proposal status during the voting
     * period.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_VOTING_PERIOD"] = 2] = "PROPOSAL_STATUS_VOTING_PERIOD";
    /**
     * PROPOSAL_STATUS_PASSED - PROPOSAL_STATUS_PASSED defines a proposal status of a proposal that has
     * passed.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_PASSED"] = 3] = "PROPOSAL_STATUS_PASSED";
    /**
     * PROPOSAL_STATUS_REJECTED - PROPOSAL_STATUS_REJECTED defines a proposal status of a proposal that has
     * been rejected.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_REJECTED"] = 4] = "PROPOSAL_STATUS_REJECTED";
    /**
     * PROPOSAL_STATUS_FAILED - PROPOSAL_STATUS_FAILED defines a proposal status of a proposal that has
     * failed.
     */ ProposalStatus[ProposalStatus["PROPOSAL_STATUS_FAILED"] = 5] = "PROPOSAL_STATUS_FAILED";
    ProposalStatus[ProposalStatus["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ProposalStatus || (ProposalStatus = {}));
const ProposalStatusAmino = ProposalStatus;
function proposalStatusFromJSON(object) {
    switch(object){
        case 0:
        case "PROPOSAL_STATUS_UNSPECIFIED":
            return ProposalStatus.PROPOSAL_STATUS_UNSPECIFIED;
        case 1:
        case "PROPOSAL_STATUS_DEPOSIT_PERIOD":
            return ProposalStatus.PROPOSAL_STATUS_DEPOSIT_PERIOD;
        case 2:
        case "PROPOSAL_STATUS_VOTING_PERIOD":
            return ProposalStatus.PROPOSAL_STATUS_VOTING_PERIOD;
        case 3:
        case "PROPOSAL_STATUS_PASSED":
            return ProposalStatus.PROPOSAL_STATUS_PASSED;
        case 4:
        case "PROPOSAL_STATUS_REJECTED":
            return ProposalStatus.PROPOSAL_STATUS_REJECTED;
        case 5:
        case "PROPOSAL_STATUS_FAILED":
            return ProposalStatus.PROPOSAL_STATUS_FAILED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ProposalStatus.UNRECOGNIZED;
    }
}
function proposalStatusToJSON(object) {
    switch(object){
        case ProposalStatus.PROPOSAL_STATUS_UNSPECIFIED:
            return "PROPOSAL_STATUS_UNSPECIFIED";
        case ProposalStatus.PROPOSAL_STATUS_DEPOSIT_PERIOD:
            return "PROPOSAL_STATUS_DEPOSIT_PERIOD";
        case ProposalStatus.PROPOSAL_STATUS_VOTING_PERIOD:
            return "PROPOSAL_STATUS_VOTING_PERIOD";
        case ProposalStatus.PROPOSAL_STATUS_PASSED:
            return "PROPOSAL_STATUS_PASSED";
        case ProposalStatus.PROPOSAL_STATUS_REJECTED:
            return "PROPOSAL_STATUS_REJECTED";
        case ProposalStatus.PROPOSAL_STATUS_FAILED:
            return "PROPOSAL_STATUS_FAILED";
        case ProposalStatus.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseWeightedVoteOption() {
    return {
        option: 0,
        weight: ""
    };
}
const WeightedVoteOption = {
    typeUrl: "/cosmos.gov.v1beta1.WeightedVoteOption",
    aminoType: "cosmos-sdk/WeightedVoteOption",
    is (o) {
        return o && (o.$typeUrl === WeightedVoteOption.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.weight === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === WeightedVoteOption.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.weight === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.option !== 0) {
            writer.uint32(8).int32(message.option);
        }
        if (message.weight !== "") {
            writer.uint32(18).string(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.weight, 18).atomics);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseWeightedVoteOption();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.option = reader.int32();
                    break;
                case 2:
                    message.weight = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(reader.string(), 18).toString();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseWeightedVoteOption();
        message.option = object.option ?? 0;
        message.weight = object.weight ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseWeightedVoteOption();
        if (object.option !== undefined && object.option !== null) {
            message.option = object.option;
        }
        if (object.weight !== undefined && object.weight !== null) {
            message.weight = object.weight;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.option = message.option === 0 ? undefined : message.option;
        obj.weight = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromUserInput(message.weight, 18).atomics ?? "";
        return obj;
    },
    fromAminoMsg (object) {
        return WeightedVoteOption.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/WeightedVoteOption",
            value: WeightedVoteOption.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return WeightedVoteOption.decode(message.value);
    },
    toProto (message) {
        return WeightedVoteOption.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.WeightedVoteOption",
            value: WeightedVoteOption.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseTextProposal() {
    return {
        title: "",
        description: ""
    };
}
const TextProposal = {
    typeUrl: "/cosmos.gov.v1beta1.TextProposal",
    aminoType: "cosmos-sdk/TextProposal",
    is (o) {
        return o && (o.$typeUrl === TextProposal.typeUrl || typeof o.title === "string" && typeof o.description === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TextProposal.typeUrl || typeof o.title === "string" && typeof o.description === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.title !== "") {
            writer.uint32(10).string(message.title);
        }
        if (message.description !== "") {
            writer.uint32(18).string(message.description);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTextProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.title = reader.string();
                    break;
                case 2:
                    message.description = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTextProposal();
        message.title = object.title ?? "";
        message.description = object.description ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseTextProposal();
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        if (object.description !== undefined && object.description !== null) {
            message.description = object.description;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.title = message.title === "" ? undefined : message.title;
        obj.description = message.description === "" ? undefined : message.description;
        return obj;
    },
    fromAminoMsg (object) {
        return TextProposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TextProposal",
            value: TextProposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TextProposal.decode(message.value);
    },
    toProto (message) {
        return TextProposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.TextProposal",
            value: TextProposal.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(TextProposal.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].register(TextProposal.typeUrl, TextProposal);
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerAminoProtoMapping(TextProposal.aminoType, TextProposal.typeUrl);
    }
};
function createBaseDeposit() {
    return {
        proposalId: BigInt(0),
        depositor: "",
        amount: []
    };
}
const Deposit = {
    typeUrl: "/cosmos.gov.v1beta1.Deposit",
    aminoType: "cosmos-sdk/Deposit",
    is (o) {
        return o && (o.$typeUrl === Deposit.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Deposit.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        for (const v of message.amount){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDeposit();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                case 3:
                    message.amount.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDeposit();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDeposit();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        if (message.amount) {
            obj.amount = message.amount.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.amount = message.amount;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Deposit.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Deposit",
            value: Deposit.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Deposit.decode(message.value);
    },
    toProto (message) {
        return Deposit.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.Deposit",
            value: Deposit.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Deposit.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseProposal() {
    return {
        proposalId: BigInt(0),
        content: undefined,
        status: 0,
        finalTallyResult: TallyResult.fromPartial({}),
        submitTime: new Date(),
        depositEndTime: new Date(),
        totalDeposit: [],
        votingStartTime: new Date(),
        votingEndTime: new Date()
    };
}
const Proposal = {
    typeUrl: "/cosmos.gov.v1beta1.Proposal",
    aminoType: "cosmos-sdk/Proposal",
    is (o) {
        return o && (o.$typeUrl === Proposal.typeUrl || typeof o.proposalId === "bigint" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && TallyResult.is(o.finalTallyResult) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.submitTime) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.depositEndTime) && Array.isArray(o.totalDeposit) && (!o.totalDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.totalDeposit[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.votingStartTime) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.votingEndTime));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Proposal.typeUrl || typeof o.proposal_id === "bigint" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.status) && TallyResult.isAmino(o.final_tally_result) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.submit_time) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.deposit_end_time) && Array.isArray(o.total_deposit) && (!o.total_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.total_deposit[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.voting_start_time) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.voting_end_time));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.content !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].wrapAny(message.content), writer.uint32(18).fork()).ldelim();
        }
        if (message.status !== 0) {
            writer.uint32(24).int32(message.status);
        }
        if (message.finalTallyResult !== undefined) {
            TallyResult.encode(message.finalTallyResult, writer.uint32(34).fork()).ldelim();
        }
        if (message.submitTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.submitTime), writer.uint32(42).fork()).ldelim();
        }
        if (message.depositEndTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.depositEndTime), writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.totalDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(58).fork()).ldelim();
        }
        if (message.votingStartTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingStartTime), writer.uint32(66).fork()).ldelim();
        }
        if (message.votingEndTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingEndTime), writer.uint32(74).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].unwrapAny(reader);
                    break;
                case 3:
                    message.status = reader.int32();
                    break;
                case 4:
                    message.finalTallyResult = TallyResult.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.submitTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.depositEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.totalDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.votingStartTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 9:
                    message.votingEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseProposal();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.content = object.content !== undefined && object.content !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromPartial(object.content) : undefined;
        message.status = object.status ?? 0;
        message.finalTallyResult = object.finalTallyResult !== undefined && object.finalTallyResult !== null ? TallyResult.fromPartial(object.finalTallyResult) : undefined;
        message.submitTime = object.submitTime ?? undefined;
        message.depositEndTime = object.depositEndTime ?? undefined;
        message.totalDeposit = object.totalDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.votingStartTime = object.votingStartTime ?? undefined;
        message.votingEndTime = object.votingEndTime ?? undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseProposal();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.content !== undefined && object.content !== null) {
            message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromAminoMsg(object.content);
        }
        if (object.status !== undefined && object.status !== null) {
            message.status = object.status;
        }
        if (object.final_tally_result !== undefined && object.final_tally_result !== null) {
            message.finalTallyResult = TallyResult.fromAmino(object.final_tally_result);
        }
        if (object.submit_time !== undefined && object.submit_time !== null) {
            message.submitTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.submit_time));
        }
        if (object.deposit_end_time !== undefined && object.deposit_end_time !== null) {
            message.depositEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.deposit_end_time));
        }
        message.totalDeposit = object.total_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.voting_start_time !== undefined && object.voting_start_time !== null) {
            message.votingStartTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.voting_start_time));
        }
        if (object.voting_end_time !== undefined && object.voting_end_time !== null) {
            message.votingEndTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.voting_end_time));
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.content = message.content ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].toAminoMsg(message.content) : undefined;
        obj.status = message.status === 0 ? undefined : message.status;
        obj.final_tally_result = message.finalTallyResult ? TallyResult.toAmino(message.finalTallyResult) : TallyResult.toAmino(TallyResult.fromPartial({}));
        obj.submit_time = message.submitTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.submitTime)) : new Date();
        obj.deposit_end_time = message.depositEndTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.depositEndTime)) : new Date();
        if (message.totalDeposit) {
            obj.total_deposit = message.totalDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.total_deposit = message.totalDeposit;
        }
        obj.voting_start_time = message.votingStartTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingStartTime)) : new Date();
        obj.voting_end_time = message.votingEndTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.votingEndTime)) : new Date();
        return obj;
    },
    fromAminoMsg (object) {
        return Proposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Proposal",
            value: Proposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Proposal.decode(message.value);
    },
    toProto (message) {
        return Proposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.Proposal",
            value: Proposal.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Proposal.typeUrl)) {
            return;
        }
        TextProposal.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposalWithDeposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ParameterChangeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CancelSoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreCodeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContract2Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SudoContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExecuteContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClearAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnpinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateInstantiateConfigProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreAndInstantiateContractProposal"].registerTypeUrl();
        TallyResult.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseTallyResult() {
    return {
        yes: "",
        abstain: "",
        no: "",
        noWithVeto: ""
    };
}
const TallyResult = {
    typeUrl: "/cosmos.gov.v1beta1.TallyResult",
    aminoType: "cosmos-sdk/TallyResult",
    is (o) {
        return o && (o.$typeUrl === TallyResult.typeUrl || typeof o.yes === "string" && typeof o.abstain === "string" && typeof o.no === "string" && typeof o.noWithVeto === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TallyResult.typeUrl || typeof o.yes === "string" && typeof o.abstain === "string" && typeof o.no === "string" && typeof o.no_with_veto === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.yes !== "") {
            writer.uint32(10).string(message.yes);
        }
        if (message.abstain !== "") {
            writer.uint32(18).string(message.abstain);
        }
        if (message.no !== "") {
            writer.uint32(26).string(message.no);
        }
        if (message.noWithVeto !== "") {
            writer.uint32(34).string(message.noWithVeto);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTallyResult();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.yes = reader.string();
                    break;
                case 2:
                    message.abstain = reader.string();
                    break;
                case 3:
                    message.no = reader.string();
                    break;
                case 4:
                    message.noWithVeto = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTallyResult();
        message.yes = object.yes ?? "";
        message.abstain = object.abstain ?? "";
        message.no = object.no ?? "";
        message.noWithVeto = object.noWithVeto ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseTallyResult();
        if (object.yes !== undefined && object.yes !== null) {
            message.yes = object.yes;
        }
        if (object.abstain !== undefined && object.abstain !== null) {
            message.abstain = object.abstain;
        }
        if (object.no !== undefined && object.no !== null) {
            message.no = object.no;
        }
        if (object.no_with_veto !== undefined && object.no_with_veto !== null) {
            message.noWithVeto = object.no_with_veto;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.yes = message.yes === "" ? undefined : message.yes;
        obj.abstain = message.abstain === "" ? undefined : message.abstain;
        obj.no = message.no === "" ? undefined : message.no;
        obj.no_with_veto = message.noWithVeto === "" ? undefined : message.noWithVeto;
        return obj;
    },
    fromAminoMsg (object) {
        return TallyResult.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TallyResult",
            value: TallyResult.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TallyResult.decode(message.value);
    },
    toProto (message) {
        return TallyResult.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.TallyResult",
            value: TallyResult.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseVote() {
    return {
        proposalId: BigInt(0),
        voter: "",
        option: 0,
        options: []
    };
}
const Vote = {
    typeUrl: "/cosmos.gov.v1beta1.Vote",
    aminoType: "cosmos-sdk/Vote",
    is (o) {
        return o && (o.$typeUrl === Vote.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && Array.isArray(o.options) && (!o.options.length || WeightedVoteOption.is(o.options[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Vote.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && Array.isArray(o.options) && (!o.options.length || WeightedVoteOption.isAmino(o.options[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        if (message.option !== 0) {
            writer.uint32(24).int32(message.option);
        }
        for (const v of message.options){
            WeightedVoteOption.encode(v, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVote();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.option = reader.int32();
                    break;
                case 4:
                    message.options.push(WeightedVoteOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseVote();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.option = object.option ?? 0;
        message.options = object.options?.map((e)=>WeightedVoteOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseVote();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        if (object.option !== undefined && object.option !== null) {
            message.option = object.option;
        }
        message.options = object.options?.map((e)=>WeightedVoteOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.voter = message.voter === "" ? undefined : message.voter;
        obj.option = message.option === 0 ? undefined : message.option;
        if (message.options) {
            obj.options = message.options.map((e)=>e ? WeightedVoteOption.toAmino(e) : undefined);
        } else {
            obj.options = message.options;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Vote.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Vote",
            value: Vote.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Vote.decode(message.value);
    },
    toProto (message) {
        return Vote.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.Vote",
            value: Vote.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Vote.typeUrl)) {
            return;
        }
        WeightedVoteOption.registerTypeUrl();
    }
};
function createBaseDepositParams() {
    return {
        minDeposit: [],
        maxDepositPeriod: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({})
    };
}
const DepositParams = {
    typeUrl: "/cosmos.gov.v1beta1.DepositParams",
    aminoType: "cosmos-sdk/DepositParams",
    is (o) {
        return o && (o.$typeUrl === DepositParams.typeUrl || Array.isArray(o.minDeposit) && (!o.minDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.minDeposit[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.maxDepositPeriod));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DepositParams.typeUrl || Array.isArray(o.min_deposit) && (!o.min_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.min_deposit[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.max_deposit_period));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.minDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.maxDepositPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.maxDepositPeriod, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDepositParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.minDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDepositParams();
        message.minDeposit = object.minDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.maxDepositPeriod = object.maxDepositPeriod !== undefined && object.maxDepositPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.maxDepositPeriod) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDepositParams();
        message.minDeposit = object.min_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.max_deposit_period !== undefined && object.max_deposit_period !== null) {
            message.maxDepositPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.max_deposit_period);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.minDeposit) {
            obj.min_deposit = message.minDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.min_deposit = message.minDeposit;
        }
        obj.max_deposit_period = message.maxDepositPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.maxDepositPeriod) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return DepositParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/DepositParams",
            value: DepositParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return DepositParams.decode(message.value);
    },
    toProto (message) {
        return DepositParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.DepositParams",
            value: DepositParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DepositParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseVotingParams() {
    return {
        votingPeriod: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({})
    };
}
const VotingParams = {
    typeUrl: "/cosmos.gov.v1beta1.VotingParams",
    aminoType: "cosmos-sdk/VotingParams",
    is (o) {
        return o && (o.$typeUrl === VotingParams.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.votingPeriod));
    },
    isAmino (o) {
        return o && (o.$typeUrl === VotingParams.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.voting_period));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.votingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.votingPeriod, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseVotingParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseVotingParams();
        message.votingPeriod = object.votingPeriod !== undefined && object.votingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.votingPeriod) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseVotingParams();
        if (object.voting_period !== undefined && object.voting_period !== null) {
            message.votingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.voting_period);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.voting_period = message.votingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.votingPeriod) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return VotingParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/VotingParams",
            value: VotingParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return VotingParams.decode(message.value);
    },
    toProto (message) {
        return VotingParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.VotingParams",
            value: VotingParams.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseTallyParams() {
    return {
        quorum: new Uint8Array(),
        threshold: new Uint8Array(),
        vetoThreshold: new Uint8Array()
    };
}
const TallyParams = {
    typeUrl: "/cosmos.gov.v1beta1.TallyParams",
    aminoType: "cosmos-sdk/TallyParams",
    is (o) {
        return o && (o.$typeUrl === TallyParams.typeUrl || (o.quorum instanceof Uint8Array || typeof o.quorum === "string") && (o.threshold instanceof Uint8Array || typeof o.threshold === "string") && (o.vetoThreshold instanceof Uint8Array || typeof o.vetoThreshold === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === TallyParams.typeUrl || (o.quorum instanceof Uint8Array || typeof o.quorum === "string") && (o.threshold instanceof Uint8Array || typeof o.threshold === "string") && (o.veto_threshold instanceof Uint8Array || typeof o.veto_threshold === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.quorum.length !== 0) {
            writer.uint32(10).bytes(message.quorum);
        }
        if (message.threshold.length !== 0) {
            writer.uint32(18).bytes(message.threshold);
        }
        if (message.vetoThreshold.length !== 0) {
            writer.uint32(26).bytes(message.vetoThreshold);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTallyParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.quorum = reader.bytes();
                    break;
                case 2:
                    message.threshold = reader.bytes();
                    break;
                case 3:
                    message.vetoThreshold = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTallyParams();
        message.quorum = object.quorum ?? new Uint8Array();
        message.threshold = object.threshold ?? new Uint8Array();
        message.vetoThreshold = object.vetoThreshold ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseTallyParams();
        if (object.quorum !== undefined && object.quorum !== null) {
            message.quorum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.quorum);
        }
        if (object.threshold !== undefined && object.threshold !== null) {
            message.threshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.threshold);
        }
        if (object.veto_threshold !== undefined && object.veto_threshold !== null) {
            message.vetoThreshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.veto_threshold);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.quorum = message.quorum ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.quorum) : undefined;
        obj.threshold = message.threshold ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.threshold) : undefined;
        obj.veto_threshold = message.vetoThreshold ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.vetoThreshold) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return TallyParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TallyParams",
            value: TallyParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TallyParams.decode(message.value);
    },
    toProto (message) {
        return TallyParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.TallyParams",
            value: TallyParams.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgCancelProposal": (()=>MsgCancelProposal),
    "MsgCancelProposalResponse": (()=>MsgCancelProposalResponse),
    "MsgDeposit": (()=>MsgDeposit),
    "MsgDepositResponse": (()=>MsgDepositResponse),
    "MsgExecLegacyContent": (()=>MsgExecLegacyContent),
    "MsgExecLegacyContentResponse": (()=>MsgExecLegacyContentResponse),
    "MsgSubmitProposal": (()=>MsgSubmitProposal),
    "MsgSubmitProposalResponse": (()=>MsgSubmitProposalResponse),
    "MsgUpdateParams": (()=>MsgUpdateParams),
    "MsgUpdateParamsResponse": (()=>MsgUpdateParamsResponse),
    "MsgVote": (()=>MsgVote),
    "MsgVoteResponse": (()=>MsgVoteResponse),
    "MsgVoteWeighted": (()=>MsgVoteWeighted),
    "MsgVoteWeightedResponse": (()=>MsgVoteWeightedResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/distribution/v1beta1/distribution.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/params/v1beta1/params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/upgrade/v1beta1/upgrade.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmwasm/wasm/v1/proposal_legacy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
function createBaseMsgSubmitProposal() {
    return {
        messages: [],
        initialDeposit: [],
        proposer: "",
        metadata: "",
        title: "",
        summary: "",
        expedited: false
    };
}
const MsgSubmitProposal = {
    typeUrl: "/cosmos.gov.v1.MsgSubmitProposal",
    aminoType: "cosmos-sdk/v1/MsgSubmitProposal",
    is (o) {
        return o && (o.$typeUrl === MsgSubmitProposal.typeUrl || Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].is(o.messages[0])) && Array.isArray(o.initialDeposit) && (!o.initialDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.initialDeposit[0])) && typeof o.proposer === "string" && typeof o.metadata === "string" && typeof o.title === "string" && typeof o.summary === "string" && typeof o.expedited === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSubmitProposal.typeUrl || Array.isArray(o.messages) && (!o.messages.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].isAmino(o.messages[0])) && Array.isArray(o.initial_deposit) && (!o.initial_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.initial_deposit[0])) && typeof o.proposer === "string" && typeof o.metadata === "string" && typeof o.title === "string" && typeof o.summary === "string" && typeof o.expedited === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.messages){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.initialDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.proposer !== "") {
            writer.uint32(26).string(message.proposer);
        }
        if (message.metadata !== "") {
            writer.uint32(34).string(message.metadata);
        }
        if (message.title !== "") {
            writer.uint32(42).string(message.title);
        }
        if (message.summary !== "") {
            writer.uint32(50).string(message.summary);
        }
        if (message.expedited === true) {
            writer.uint32(56).bool(message.expedited);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSubmitProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.messages.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.initialDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.proposer = reader.string();
                    break;
                case 4:
                    message.metadata = reader.string();
                    break;
                case 5:
                    message.title = reader.string();
                    break;
                case 6:
                    message.summary = reader.string();
                    break;
                case 7:
                    message.expedited = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSubmitProposal();
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(e)) || [];
        message.initialDeposit = object.initialDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.proposer = object.proposer ?? "";
        message.metadata = object.metadata ?? "";
        message.title = object.title ?? "";
        message.summary = object.summary ?? "";
        message.expedited = object.expedited ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSubmitProposal();
        message.messages = object.messages?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(e)) || [];
        message.initialDeposit = object.initial_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.proposer !== undefined && object.proposer !== null) {
            message.proposer = object.proposer;
        }
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = object.metadata;
        }
        if (object.title !== undefined && object.title !== null) {
            message.title = object.title;
        }
        if (object.summary !== undefined && object.summary !== null) {
            message.summary = object.summary;
        }
        if (object.expedited !== undefined && object.expedited !== null) {
            message.expedited = object.expedited;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.messages) {
            obj.messages = message.messages.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(e) : undefined);
        } else {
            obj.messages = message.messages;
        }
        if (message.initialDeposit) {
            obj.initial_deposit = message.initialDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.initial_deposit = message.initialDeposit;
        }
        obj.proposer = message.proposer === "" ? undefined : message.proposer;
        obj.metadata = message.metadata === "" ? undefined : message.metadata;
        obj.title = message.title === "" ? undefined : message.title;
        obj.summary = message.summary === "" ? undefined : message.summary;
        obj.expedited = message.expedited === false ? undefined : message.expedited;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSubmitProposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgSubmitProposal",
            value: MsgSubmitProposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSubmitProposal.decode(message.value);
    },
    toProto (message) {
        return MsgSubmitProposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgSubmitProposal",
            value: MsgSubmitProposal.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgSubmitProposal.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgSubmitProposalResponse() {
    return {
        proposalId: BigInt(0)
    };
}
const MsgSubmitProposalResponse = {
    typeUrl: "/cosmos.gov.v1.MsgSubmitProposalResponse",
    aminoType: "cosmos-sdk/v1/MsgSubmitProposalResponse",
    is (o) {
        return o && (o.$typeUrl === MsgSubmitProposalResponse.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSubmitProposalResponse.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSubmitProposalResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSubmitProposalResponse();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSubmitProposalResponse();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSubmitProposalResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgSubmitProposalResponse",
            value: MsgSubmitProposalResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSubmitProposalResponse.decode(message.value);
    },
    toProto (message) {
        return MsgSubmitProposalResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgSubmitProposalResponse",
            value: MsgSubmitProposalResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgExecLegacyContent() {
    return {
        content: undefined,
        authority: ""
    };
}
const MsgExecLegacyContent = {
    typeUrl: "/cosmos.gov.v1.MsgExecLegacyContent",
    aminoType: "cosmos-sdk/v1/MsgExecLegacyContent",
    is (o) {
        return o && (o.$typeUrl === MsgExecLegacyContent.typeUrl || typeof o.authority === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgExecLegacyContent.typeUrl || typeof o.authority === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.content !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].wrapAny(message.content), writer.uint32(10).fork()).ldelim();
        }
        if (message.authority !== "") {
            writer.uint32(18).string(message.authority);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgExecLegacyContent();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].unwrapAny(reader);
                    break;
                case 2:
                    message.authority = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgExecLegacyContent();
        message.content = object.content !== undefined && object.content !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromPartial(object.content) : undefined;
        message.authority = object.authority ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgExecLegacyContent();
        if (object.content !== undefined && object.content !== null) {
            message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromAminoMsg(object.content);
        }
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.content = message.content ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].toAminoMsg(message.content) : undefined;
        obj.authority = message.authority === "" ? undefined : message.authority;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgExecLegacyContent.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgExecLegacyContent",
            value: MsgExecLegacyContent.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgExecLegacyContent.decode(message.value);
    },
    toProto (message) {
        return MsgExecLegacyContent.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgExecLegacyContent",
            value: MsgExecLegacyContent.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgExecLegacyContent.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposalWithDeposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ParameterChangeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CancelSoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreCodeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContract2Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SudoContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExecuteContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClearAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnpinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateInstantiateConfigProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreAndInstantiateContractProposal"].registerTypeUrl();
    }
};
function createBaseMsgExecLegacyContentResponse() {
    return {};
}
const MsgExecLegacyContentResponse = {
    typeUrl: "/cosmos.gov.v1.MsgExecLegacyContentResponse",
    aminoType: "cosmos-sdk/v1/MsgExecLegacyContentResponse",
    is (o) {
        return o && o.$typeUrl === MsgExecLegacyContentResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgExecLegacyContentResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgExecLegacyContentResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgExecLegacyContentResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgExecLegacyContentResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgExecLegacyContentResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgExecLegacyContentResponse",
            value: MsgExecLegacyContentResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgExecLegacyContentResponse.decode(message.value);
    },
    toProto (message) {
        return MsgExecLegacyContentResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgExecLegacyContentResponse",
            value: MsgExecLegacyContentResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVote() {
    return {
        proposalId: BigInt(0),
        voter: "",
        option: 0,
        metadata: ""
    };
}
const MsgVote = {
    typeUrl: "/cosmos.gov.v1.MsgVote",
    aminoType: "cosmos-sdk/v1/MsgVote",
    is (o) {
        return o && (o.$typeUrl === MsgVote.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.metadata === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgVote.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option) && typeof o.metadata === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        if (message.option !== 0) {
            writer.uint32(24).int32(message.option);
        }
        if (message.metadata !== "") {
            writer.uint32(34).string(message.metadata);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVote();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.option = reader.int32();
                    break;
                case 4:
                    message.metadata = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgVote();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.option = object.option ?? 0;
        message.metadata = object.metadata ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgVote();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        if (object.option !== undefined && object.option !== null) {
            message.option = object.option;
        }
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = object.metadata;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.voter = message.voter === "" ? undefined : message.voter;
        obj.option = message.option === 0 ? undefined : message.option;
        obj.metadata = message.metadata === "" ? undefined : message.metadata;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVote.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgVote",
            value: MsgVote.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVote.decode(message.value);
    },
    toProto (message) {
        return MsgVote.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgVote",
            value: MsgVote.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVoteResponse() {
    return {};
}
const MsgVoteResponse = {
    typeUrl: "/cosmos.gov.v1.MsgVoteResponse",
    aminoType: "cosmos-sdk/v1/MsgVoteResponse",
    is (o) {
        return o && o.$typeUrl === MsgVoteResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgVoteResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgVoteResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgVoteResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgVoteResponse",
            value: MsgVoteResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteResponse.decode(message.value);
    },
    toProto (message) {
        return MsgVoteResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgVoteResponse",
            value: MsgVoteResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVoteWeighted() {
    return {
        proposalId: BigInt(0),
        voter: "",
        options: [],
        metadata: ""
    };
}
const MsgVoteWeighted = {
    typeUrl: "/cosmos.gov.v1.MsgVoteWeighted",
    aminoType: "cosmos-sdk/v1/MsgVoteWeighted",
    is (o) {
        return o && (o.$typeUrl === MsgVoteWeighted.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].is(o.options[0])) && typeof o.metadata === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgVoteWeighted.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].isAmino(o.options[0])) && typeof o.metadata === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        for (const v of message.options){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        if (message.metadata !== "") {
            writer.uint32(34).string(message.metadata);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteWeighted();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.options.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.metadata = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgVoteWeighted();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.options = object.options?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].fromPartial(e)) || [];
        message.metadata = object.metadata ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgVoteWeighted();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        message.options = object.options?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].fromAmino(e)) || [];
        if (object.metadata !== undefined && object.metadata !== null) {
            message.metadata = object.metadata;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.voter = message.voter === "" ? undefined : message.voter;
        if (message.options) {
            obj.options = message.options.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].toAmino(e) : undefined);
        } else {
            obj.options = message.options;
        }
        obj.metadata = message.metadata === "" ? undefined : message.metadata;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteWeighted.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgVoteWeighted",
            value: MsgVoteWeighted.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteWeighted.decode(message.value);
    },
    toProto (message) {
        return MsgVoteWeighted.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgVoteWeighted",
            value: MsgVoteWeighted.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgVoteWeighted.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].registerTypeUrl();
    }
};
function createBaseMsgVoteWeightedResponse() {
    return {};
}
const MsgVoteWeightedResponse = {
    typeUrl: "/cosmos.gov.v1.MsgVoteWeightedResponse",
    aminoType: "cosmos-sdk/v1/MsgVoteWeightedResponse",
    is (o) {
        return o && o.$typeUrl === MsgVoteWeightedResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgVoteWeightedResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteWeightedResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgVoteWeightedResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgVoteWeightedResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteWeightedResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgVoteWeightedResponse",
            value: MsgVoteWeightedResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteWeightedResponse.decode(message.value);
    },
    toProto (message) {
        return MsgVoteWeightedResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgVoteWeightedResponse",
            value: MsgVoteWeightedResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgDeposit() {
    return {
        proposalId: BigInt(0),
        depositor: "",
        amount: []
    };
}
const MsgDeposit = {
    typeUrl: "/cosmos.gov.v1.MsgDeposit",
    aminoType: "cosmos-sdk/v1/MsgDeposit",
    is (o) {
        return o && (o.$typeUrl === MsgDeposit.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgDeposit.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        for (const v of message.amount){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeposit();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                case 3:
                    message.amount.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgDeposit();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgDeposit();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        if (message.amount) {
            obj.amount = message.amount.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.amount = message.amount;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDeposit.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgDeposit",
            value: MsgDeposit.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDeposit.decode(message.value);
    },
    toProto (message) {
        return MsgDeposit.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgDeposit",
            value: MsgDeposit.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgDeposit.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgDepositResponse() {
    return {};
}
const MsgDepositResponse = {
    typeUrl: "/cosmos.gov.v1.MsgDepositResponse",
    aminoType: "cosmos-sdk/v1/MsgDepositResponse",
    is (o) {
        return o && o.$typeUrl === MsgDepositResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgDepositResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDepositResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgDepositResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgDepositResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDepositResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgDepositResponse",
            value: MsgDepositResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDepositResponse.decode(message.value);
    },
    toProto (message) {
        return MsgDepositResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgDepositResponse",
            value: MsgDepositResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgUpdateParams() {
    return {
        authority: "",
        params: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({})
    };
}
const MsgUpdateParams = {
    typeUrl: "/cosmos.gov.v1.MsgUpdateParams",
    aminoType: "cosmos-sdk/x/gov/v1/MsgUpdateParams",
    is (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].is(o.params));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgUpdateParams.typeUrl || typeof o.authority === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].isAmino(o.params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.authority !== "") {
            writer.uint32(10).string(message.authority);
        }
        if (message.params !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].encode(message.params, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParams();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.authority = reader.string();
                    break;
                case 2:
                    message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgUpdateParams();
        message.authority = object.authority ?? "";
        message.params = object.params !== undefined && object.params !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial(object.params) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgUpdateParams();
        if (object.authority !== undefined && object.authority !== null) {
            message.authority = object.authority;
        }
        if (object.params !== undefined && object.params !== null) {
            message.params = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromAmino(object.params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.authority = message.authority === "" ? undefined : message.authority;
        obj.params = message.params ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(message.params) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParams.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/x/gov/v1/MsgUpdateParams",
            value: MsgUpdateParams.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParams.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParams.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgUpdateParams",
            value: MsgUpdateParams.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgUpdateParams.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Params"].registerTypeUrl();
    }
};
function createBaseMsgUpdateParamsResponse() {
    return {};
}
const MsgUpdateParamsResponse = {
    typeUrl: "/cosmos.gov.v1.MsgUpdateParamsResponse",
    aminoType: "cosmos-sdk/v1/MsgUpdateParamsResponse",
    is (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgUpdateParamsResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgUpdateParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgUpdateParamsResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgUpdateParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgUpdateParamsResponse.decode(message.value);
    },
    toProto (message) {
        return MsgUpdateParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgUpdateParamsResponse",
            value: MsgUpdateParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgCancelProposal() {
    return {
        proposalId: BigInt(0),
        proposer: ""
    };
}
const MsgCancelProposal = {
    typeUrl: "/cosmos.gov.v1.MsgCancelProposal",
    aminoType: "cosmos-sdk/v1/MsgCancelProposal",
    is (o) {
        return o && (o.$typeUrl === MsgCancelProposal.typeUrl || typeof o.proposalId === "bigint" && typeof o.proposer === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgCancelProposal.typeUrl || typeof o.proposal_id === "bigint" && typeof o.proposer === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.proposer !== "") {
            writer.uint32(18).string(message.proposer);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCancelProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.proposer = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgCancelProposal();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.proposer = object.proposer ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgCancelProposal();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.proposer !== undefined && object.proposer !== null) {
            message.proposer = object.proposer;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.proposer = message.proposer === "" ? undefined : message.proposer;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCancelProposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgCancelProposal",
            value: MsgCancelProposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCancelProposal.decode(message.value);
    },
    toProto (message) {
        return MsgCancelProposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgCancelProposal",
            value: MsgCancelProposal.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgCancelProposalResponse() {
    return {
        proposalId: BigInt(0),
        canceledTime: new Date(),
        canceledHeight: BigInt(0)
    };
}
const MsgCancelProposalResponse = {
    typeUrl: "/cosmos.gov.v1.MsgCancelProposalResponse",
    aminoType: "cosmos-sdk/v1/MsgCancelProposalResponse",
    is (o) {
        return o && (o.$typeUrl === MsgCancelProposalResponse.typeUrl || typeof o.proposalId === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.canceledTime) && typeof o.canceledHeight === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgCancelProposalResponse.typeUrl || typeof o.proposal_id === "bigint" && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.canceled_time) && typeof o.canceled_height === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.canceledTime !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.canceledTime), writer.uint32(18).fork()).ldelim();
        }
        if (message.canceledHeight !== BigInt(0)) {
            writer.uint32(24).uint64(message.canceledHeight);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgCancelProposalResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.canceledTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.canceledHeight = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgCancelProposalResponse();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.canceledTime = object.canceledTime ?? undefined;
        message.canceledHeight = object.canceledHeight !== undefined && object.canceledHeight !== null ? BigInt(object.canceledHeight.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgCancelProposalResponse();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.canceled_time !== undefined && object.canceled_time !== null) {
            message.canceledTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.canceled_time));
        }
        if (object.canceled_height !== undefined && object.canceled_height !== null) {
            message.canceledHeight = BigInt(object.canceled_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.canceled_time = message.canceledTime ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.canceledTime)) : undefined;
        obj.canceled_height = message.canceledHeight !== BigInt(0) ? message.canceledHeight?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgCancelProposalResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/v1/MsgCancelProposalResponse",
            value: MsgCancelProposalResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgCancelProposalResponse.decode(message.value);
    },
    toProto (message) {
        return MsgCancelProposalResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1.MsgCancelProposalResponse",
            value: MsgCancelProposalResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GenesisState": (()=>GenesisState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseGenesisState() {
    return {
        startingProposalId: BigInt(0),
        deposits: [],
        votes: [],
        proposals: [],
        depositParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial({}),
        votingParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial({}),
        tallyParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial({})
    };
}
const GenesisState = {
    typeUrl: "/cosmos.gov.v1beta1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.startingProposalId === "bigint" && Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].is(o.deposits[0])) && Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].is(o.votes[0])) && Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].is(o.proposals[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].is(o.depositParams) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].is(o.votingParams) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].is(o.tallyParams));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || typeof o.starting_proposal_id === "bigint" && Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].isAmino(o.deposits[0])) && Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].isAmino(o.votes[0])) && Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].isAmino(o.proposals[0])) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].isAmino(o.deposit_params) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].isAmino(o.voting_params) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].isAmino(o.tally_params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.startingProposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.startingProposalId);
        }
        for (const v of message.deposits){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.votes){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.proposals){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(v, writer.uint32(34).fork()).ldelim();
        }
        if (message.depositParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].encode(message.depositParams, writer.uint32(42).fork()).ldelim();
        }
        if (message.votingParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].encode(message.votingParams, writer.uint32(50).fork()).ldelim();
        }
        if (message.tallyParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].encode(message.tallyParams, writer.uint32(58).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.startingProposalId = reader.uint64();
                    break;
                case 2:
                    message.deposits.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.votes.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.proposals.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].decode(reader, reader.uint32());
                    break;
                case 6:
                    message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].decode(reader, reader.uint32());
                    break;
                case 7:
                    message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.startingProposalId = object.startingProposalId !== undefined && object.startingProposalId !== null ? BigInt(object.startingProposalId.toString()) : BigInt(0);
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(e)) || [];
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(e)) || [];
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(e)) || [];
        message.depositParams = object.depositParams !== undefined && object.depositParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial(object.depositParams) : undefined;
        message.votingParams = object.votingParams !== undefined && object.votingParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial(object.votingParams) : undefined;
        message.tallyParams = object.tallyParams !== undefined && object.tallyParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial(object.tallyParams) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        if (object.starting_proposal_id !== undefined && object.starting_proposal_id !== null) {
            message.startingProposalId = BigInt(object.starting_proposal_id);
        }
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(e)) || [];
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(e)) || [];
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(e)) || [];
        if (object.deposit_params !== undefined && object.deposit_params !== null) {
            message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromAmino(object.deposit_params);
        }
        if (object.voting_params !== undefined && object.voting_params !== null) {
            message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromAmino(object.voting_params);
        }
        if (object.tally_params !== undefined && object.tally_params !== null) {
            message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromAmino(object.tally_params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.starting_proposal_id = message.startingProposalId !== BigInt(0) ? message.startingProposalId?.toString() : undefined;
        if (message.deposits) {
            obj.deposits = message.deposits.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(e) : undefined);
        } else {
            obj.deposits = message.deposits;
        }
        if (message.votes) {
            obj.votes = message.votes.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(e) : undefined);
        } else {
            obj.votes = message.votes;
        }
        if (message.proposals) {
            obj.proposals = message.proposals.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(e) : undefined);
        } else {
            obj.proposals = message.proposals;
        }
        obj.deposit_params = message.depositParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(message.depositParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial({}));
        obj.voting_params = message.votingParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(message.votingParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial({}));
        obj.tally_params = message.tallyParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(message.tallyParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryDepositRequest": (()=>QueryDepositRequest),
    "QueryDepositResponse": (()=>QueryDepositResponse),
    "QueryDepositsRequest": (()=>QueryDepositsRequest),
    "QueryDepositsResponse": (()=>QueryDepositsResponse),
    "QueryParamsRequest": (()=>QueryParamsRequest),
    "QueryParamsResponse": (()=>QueryParamsResponse),
    "QueryProposalRequest": (()=>QueryProposalRequest),
    "QueryProposalResponse": (()=>QueryProposalResponse),
    "QueryProposalsRequest": (()=>QueryProposalsRequest),
    "QueryProposalsResponse": (()=>QueryProposalsResponse),
    "QueryTallyResultRequest": (()=>QueryTallyResultRequest),
    "QueryTallyResultResponse": (()=>QueryTallyResultResponse),
    "QueryVoteRequest": (()=>QueryVoteRequest),
    "QueryVoteResponse": (()=>QueryVoteResponse),
    "QueryVotesRequest": (()=>QueryVotesRequest),
    "QueryVotesResponse": (()=>QueryVotesResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
;
;
function createBaseQueryProposalRequest() {
    return {
        proposalId: BigInt(0)
    };
}
const QueryProposalRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryProposalRequest",
    aminoType: "cosmos-sdk/QueryProposalRequest",
    is (o) {
        return o && (o.$typeUrl === QueryProposalRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryProposalRequest",
            value: QueryProposalRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalRequest.decode(message.value);
    },
    toProto (message) {
        return QueryProposalRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryProposalRequest",
            value: QueryProposalRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryProposalResponse() {
    return {
        proposal: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial({})
    };
}
const QueryProposalResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryProposalResponse",
    aminoType: "cosmos-sdk/QueryProposalResponse",
    is (o) {
        return o && (o.$typeUrl === QueryProposalResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].is(o.proposal));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].isAmino(o.proposal));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposal !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(message.proposal, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposal = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalResponse();
        message.proposal = object.proposal !== undefined && object.proposal !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(object.proposal) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalResponse();
        if (object.proposal !== undefined && object.proposal !== null) {
            message.proposal = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(object.proposal);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal = message.proposal ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(message.proposal) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryProposalResponse",
            value: QueryProposalResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalResponse.decode(message.value);
    },
    toProto (message) {
        return QueryProposalResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryProposalResponse",
            value: QueryProposalResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
    }
};
function createBaseQueryProposalsRequest() {
    return {
        proposalStatus: 0,
        voter: "",
        depositor: "",
        pagination: undefined
    };
}
const QueryProposalsRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryProposalsRequest",
    aminoType: "cosmos-sdk/QueryProposalsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryProposalsRequest.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.proposalStatus) && typeof o.voter === "string" && typeof o.depositor === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalsRequest.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.proposal_status) && typeof o.voter === "string" && typeof o.depositor === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalStatus !== 0) {
            writer.uint32(8).int32(message.proposalStatus);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        if (message.depositor !== "") {
            writer.uint32(26).string(message.depositor);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalStatus = reader.int32();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.depositor = reader.string();
                    break;
                case 4:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalsRequest();
        message.proposalStatus = object.proposalStatus ?? 0;
        message.voter = object.voter ?? "";
        message.depositor = object.depositor ?? "";
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalsRequest();
        if (object.proposal_status !== undefined && object.proposal_status !== null) {
            message.proposalStatus = object.proposal_status;
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_status = message.proposalStatus === 0 ? undefined : message.proposalStatus;
        obj.voter = message.voter === "" ? undefined : message.voter;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryProposalsRequest",
            value: QueryProposalsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryProposalsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryProposalsRequest",
            value: QueryProposalsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryProposalsResponse() {
    return {
        proposals: [],
        pagination: undefined
    };
}
const QueryProposalsResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryProposalsResponse",
    aminoType: "cosmos-sdk/QueryProposalsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryProposalsResponse.typeUrl || Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].is(o.proposals[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryProposalsResponse.typeUrl || Array.isArray(o.proposals) && (!o.proposals.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].isAmino(o.proposals[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.proposals){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryProposalsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposals.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryProposalsResponse();
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryProposalsResponse();
        message.proposals = object.proposals?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.proposals) {
            obj.proposals = message.proposals.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].toAmino(e) : undefined);
        } else {
            obj.proposals = message.proposals;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryProposalsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryProposalsResponse",
            value: QueryProposalsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryProposalsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryProposalsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryProposalsResponse",
            value: QueryProposalsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryProposalsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryVoteRequest() {
    return {
        proposalId: BigInt(0),
        voter: ""
    };
}
const QueryVoteRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryVoteRequest",
    aminoType: "cosmos-sdk/QueryVoteRequest",
    is (o) {
        return o && (o.$typeUrl === QueryVoteRequest.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVoteRequest.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVoteRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVoteRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVoteRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.voter = message.voter === "" ? undefined : message.voter;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVoteRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryVoteRequest",
            value: QueryVoteRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVoteRequest.decode(message.value);
    },
    toProto (message) {
        return QueryVoteRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryVoteRequest",
            value: QueryVoteRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryVoteResponse() {
    return {
        vote: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial({})
    };
}
const QueryVoteResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryVoteResponse",
    aminoType: "cosmos-sdk/QueryVoteResponse",
    is (o) {
        return o && (o.$typeUrl === QueryVoteResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].is(o.vote));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVoteResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].isAmino(o.vote));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.vote !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(message.vote, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVoteResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.vote = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVoteResponse();
        message.vote = object.vote !== undefined && object.vote !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(object.vote) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVoteResponse();
        if (object.vote !== undefined && object.vote !== null) {
            message.vote = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(object.vote);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.vote = message.vote ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(message.vote) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVoteResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryVoteResponse",
            value: QueryVoteResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVoteResponse.decode(message.value);
    },
    toProto (message) {
        return QueryVoteResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryVoteResponse",
            value: QueryVoteResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVoteResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
    }
};
function createBaseQueryVotesRequest() {
    return {
        proposalId: BigInt(0),
        pagination: undefined
    };
}
const QueryVotesRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryVotesRequest",
    aminoType: "cosmos-sdk/QueryVotesRequest",
    is (o) {
        return o && (o.$typeUrl === QueryVotesRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVotesRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVotesRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVotesRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVotesRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVotesRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryVotesRequest",
            value: QueryVotesRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVotesRequest.decode(message.value);
    },
    toProto (message) {
        return QueryVotesRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryVotesRequest",
            value: QueryVotesRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVotesRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryVotesResponse() {
    return {
        votes: [],
        pagination: undefined
    };
}
const QueryVotesResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryVotesResponse",
    aminoType: "cosmos-sdk/QueryVotesResponse",
    is (o) {
        return o && (o.$typeUrl === QueryVotesResponse.typeUrl || Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].is(o.votes[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryVotesResponse.typeUrl || Array.isArray(o.votes) && (!o.votes.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].isAmino(o.votes[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.votes){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryVotesResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votes.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryVotesResponse();
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryVotesResponse();
        message.votes = object.votes?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.votes) {
            obj.votes = message.votes.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].toAmino(e) : undefined);
        } else {
            obj.votes = message.votes;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryVotesResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryVotesResponse",
            value: QueryVotesResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryVotesResponse.decode(message.value);
    },
    toProto (message) {
        return QueryVotesResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryVotesResponse",
            value: QueryVotesResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryVotesResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Vote"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryParamsRequest() {
    return {
        paramsType: ""
    };
}
const QueryParamsRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryParamsRequest",
    aminoType: "cosmos-sdk/QueryParamsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryParamsRequest.typeUrl || typeof o.paramsType === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryParamsRequest.typeUrl || typeof o.params_type === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.paramsType !== "") {
            writer.uint32(10).string(message.paramsType);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.paramsType = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsRequest();
        message.paramsType = object.paramsType ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsRequest();
        if (object.params_type !== undefined && object.params_type !== null) {
            message.paramsType = object.params_type;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.params_type = message.paramsType === "" ? undefined : message.paramsType;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsRequest",
            value: QueryParamsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryParamsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryParamsRequest",
            value: QueryParamsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryParamsResponse() {
    return {
        votingParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial({}),
        depositParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial({}),
        tallyParams: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial({})
    };
}
const QueryParamsResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryParamsResponse",
    aminoType: "cosmos-sdk/QueryParamsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].is(o.votingParams) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].is(o.depositParams) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].is(o.tallyParams));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryParamsResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].isAmino(o.voting_params) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].isAmino(o.deposit_params) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].isAmino(o.tally_params));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.votingParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].encode(message.votingParams, writer.uint32(10).fork()).ldelim();
        }
        if (message.depositParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].encode(message.depositParams, writer.uint32(18).fork()).ldelim();
        }
        if (message.tallyParams !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].encode(message.tallyParams, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryParamsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryParamsResponse();
        message.votingParams = object.votingParams !== undefined && object.votingParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial(object.votingParams) : undefined;
        message.depositParams = object.depositParams !== undefined && object.depositParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial(object.depositParams) : undefined;
        message.tallyParams = object.tallyParams !== undefined && object.tallyParams !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial(object.tallyParams) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryParamsResponse();
        if (object.voting_params !== undefined && object.voting_params !== null) {
            message.votingParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromAmino(object.voting_params);
        }
        if (object.deposit_params !== undefined && object.deposit_params !== null) {
            message.depositParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromAmino(object.deposit_params);
        }
        if (object.tally_params !== undefined && object.tally_params !== null) {
            message.tallyParams = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromAmino(object.tally_params);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.voting_params = message.votingParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(message.votingParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].fromPartial({}));
        obj.deposit_params = message.depositParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(message.depositParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].fromPartial({}));
        obj.tally_params = message.tallyParams ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(message.tallyParams) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryParamsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryParamsResponse",
            value: QueryParamsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryParamsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryParamsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryParamsResponse",
            value: QueryParamsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryParamsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VotingParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DepositParams"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyParams"].registerTypeUrl();
    }
};
function createBaseQueryDepositRequest() {
    return {
        proposalId: BigInt(0),
        depositor: ""
    };
}
const QueryDepositRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryDepositRequest",
    aminoType: "cosmos-sdk/QueryDepositRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDepositRequest.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositRequest.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDepositRequest",
            value: QueryDepositRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDepositRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryDepositRequest",
            value: QueryDepositRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryDepositResponse() {
    return {
        deposit: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial({})
    };
}
const QueryDepositResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryDepositResponse",
    aminoType: "cosmos-sdk/QueryDepositResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDepositResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].is(o.deposit));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].isAmino(o.deposit));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.deposit !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(message.deposit, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.deposit = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositResponse();
        message.deposit = object.deposit !== undefined && object.deposit !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(object.deposit) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositResponse();
        if (object.deposit !== undefined && object.deposit !== null) {
            message.deposit = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(object.deposit);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.deposit = message.deposit ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(message.deposit) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDepositResponse",
            value: QueryDepositResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDepositResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryDepositResponse",
            value: QueryDepositResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
    }
};
function createBaseQueryDepositsRequest() {
    return {
        proposalId: BigInt(0),
        pagination: undefined
    };
}
const QueryDepositsRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryDepositsRequest",
    aminoType: "cosmos-sdk/QueryDepositsRequest",
    is (o) {
        return o && (o.$typeUrl === QueryDepositsRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositsRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositsRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositsRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDepositsRequest",
            value: QueryDepositsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryDepositsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryDepositsRequest",
            value: QueryDepositsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryDepositsResponse() {
    return {
        deposits: [],
        pagination: undefined
    };
}
const QueryDepositsResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryDepositsResponse",
    aminoType: "cosmos-sdk/QueryDepositsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryDepositsResponse.typeUrl || Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].is(o.deposits[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryDepositsResponse.typeUrl || Array.isArray(o.deposits) && (!o.deposits.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].isAmino(o.deposits[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.deposits){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryDepositsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.deposits.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryDepositsResponse();
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromPartial(e)) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryDepositsResponse();
        message.deposits = object.deposits?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].fromAmino(e)) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.deposits) {
            obj.deposits = message.deposits.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].toAmino(e) : undefined);
        } else {
            obj.deposits = message.deposits;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryDepositsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryDepositsResponse",
            value: QueryDepositsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryDepositsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryDepositsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryDepositsResponse",
            value: QueryDepositsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryDepositsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Deposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryTallyResultRequest() {
    return {
        proposalId: BigInt(0)
    };
}
const QueryTallyResultRequest = {
    typeUrl: "/cosmos.gov.v1beta1.QueryTallyResultRequest",
    aminoType: "cosmos-sdk/QueryTallyResultRequest",
    is (o) {
        return o && (o.$typeUrl === QueryTallyResultRequest.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTallyResultRequest.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTallyResultRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTallyResultRequest();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTallyResultRequest();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTallyResultRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTallyResultRequest",
            value: QueryTallyResultRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTallyResultRequest.decode(message.value);
    },
    toProto (message) {
        return QueryTallyResultRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryTallyResultRequest",
            value: QueryTallyResultRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryTallyResultResponse() {
    return {
        tally: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromPartial({})
    };
}
const QueryTallyResultResponse = {
    typeUrl: "/cosmos.gov.v1beta1.QueryTallyResultResponse",
    aminoType: "cosmos-sdk/QueryTallyResultResponse",
    is (o) {
        return o && (o.$typeUrl === QueryTallyResultResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].is(o.tally));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryTallyResultResponse.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].isAmino(o.tally));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.tally !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].encode(message.tally, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryTallyResultResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.tally = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryTallyResultResponse();
        message.tally = object.tally !== undefined && object.tally !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromPartial(object.tally) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryTallyResultResponse();
        if (object.tally !== undefined && object.tally !== null) {
            message.tally = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromAmino(object.tally);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.tally = message.tally ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].toAmino(message.tally) : __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].toAmino(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].fromPartial({}));
        return obj;
    },
    fromAminoMsg (object) {
        return QueryTallyResultResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryTallyResultResponse",
            value: QueryTallyResultResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryTallyResultResponse.decode(message.value);
    },
    toProto (message) {
        return QueryTallyResultResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.QueryTallyResultResponse",
            value: QueryTallyResultResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryTallyResultResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TallyResult"].registerTypeUrl();
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgDeposit": (()=>MsgDeposit),
    "MsgDepositResponse": (()=>MsgDepositResponse),
    "MsgSubmitProposal": (()=>MsgSubmitProposal),
    "MsgSubmitProposalResponse": (()=>MsgSubmitProposalResponse),
    "MsgVote": (()=>MsgVote),
    "MsgVoteResponse": (()=>MsgVoteResponse),
    "MsgVoteWeighted": (()=>MsgVoteWeighted),
    "MsgVoteWeightedResponse": (()=>MsgVoteWeightedResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/gov.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/distribution/v1beta1/distribution.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/params/v1beta1/params.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/upgrade/v1beta1/upgrade.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmwasm/wasm/v1/proposal_legacy.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function createBaseMsgSubmitProposal() {
    return {
        content: undefined,
        initialDeposit: [],
        proposer: ""
    };
}
const MsgSubmitProposal = {
    typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposal",
    aminoType: "cosmos-sdk/MsgSubmitProposal",
    is (o) {
        return o && (o.$typeUrl === MsgSubmitProposal.typeUrl || Array.isArray(o.initialDeposit) && (!o.initialDeposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.initialDeposit[0])) && typeof o.proposer === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSubmitProposal.typeUrl || Array.isArray(o.initial_deposit) && (!o.initial_deposit.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.initial_deposit[0])) && typeof o.proposer === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.content !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].wrapAny(message.content), writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.initialDeposit){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.proposer !== "") {
            writer.uint32(26).string(message.proposer);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSubmitProposal();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].unwrapAny(reader);
                    break;
                case 2:
                    message.initialDeposit.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.proposer = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSubmitProposal();
        message.content = object.content !== undefined && object.content !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromPartial(object.content) : undefined;
        message.initialDeposit = object.initialDeposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        message.proposer = object.proposer ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSubmitProposal();
        if (object.content !== undefined && object.content !== null) {
            message.content = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].fromAminoMsg(object.content);
        }
        message.initialDeposit = object.initial_deposit?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        if (object.proposer !== undefined && object.proposer !== null) {
            message.proposer = object.proposer;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.content = message.content ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].toAminoMsg(message.content) : undefined;
        if (message.initialDeposit) {
            obj.initial_deposit = message.initialDeposit.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.initial_deposit = message.initialDeposit;
        }
        obj.proposer = message.proposer === "" ? undefined : message.proposer;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSubmitProposal.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSubmitProposal",
            value: MsgSubmitProposal.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSubmitProposal.decode(message.value);
    },
    toProto (message) {
        return MsgSubmitProposal.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposal",
            value: MsgSubmitProposal.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgSubmitProposal.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$distribution$2f$v1beta1$2f$distribution$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommunityPoolSpendProposalWithDeposit"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$params$2f$v1beta1$2f$params$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ParameterChangeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$upgrade$2f$v1beta1$2f$upgrade$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CancelSoftwareUpgradeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreCodeProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InstantiateContract2Proposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MigrateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SudoContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExecuteContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ClearAdminProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UnpinCodesProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UpdateInstantiateConfigProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmwasm$2f$wasm$2f$v1$2f$proposal_legacy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreAndInstantiateContractProposal"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgSubmitProposalResponse() {
    return {
        proposalId: BigInt(0)
    };
}
const MsgSubmitProposalResponse = {
    typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposalResponse",
    aminoType: "cosmos-sdk/MsgSubmitProposalResponse",
    is (o) {
        return o && (o.$typeUrl === MsgSubmitProposalResponse.typeUrl || typeof o.proposalId === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgSubmitProposalResponse.typeUrl || typeof o.proposal_id === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgSubmitProposalResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgSubmitProposalResponse();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgSubmitProposalResponse();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        return obj;
    },
    fromAminoMsg (object) {
        return MsgSubmitProposalResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgSubmitProposalResponse",
            value: MsgSubmitProposalResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgSubmitProposalResponse.decode(message.value);
    },
    toProto (message) {
        return MsgSubmitProposalResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposalResponse",
            value: MsgSubmitProposalResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVote() {
    return {
        proposalId: BigInt(0),
        voter: "",
        option: 0
    };
}
const MsgVote = {
    typeUrl: "/cosmos.gov.v1beta1.MsgVote",
    aminoType: "cosmos-sdk/MsgVote",
    is (o) {
        return o && (o.$typeUrl === MsgVote.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgVote.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.option));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        if (message.option !== 0) {
            writer.uint32(24).int32(message.option);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVote();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.option = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgVote();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.option = object.option ?? 0;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgVote();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        if (object.option !== undefined && object.option !== null) {
            message.option = object.option;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId !== BigInt(0) ? message.proposalId?.toString() : undefined;
        obj.voter = message.voter === "" ? undefined : message.voter;
        obj.option = message.option === 0 ? undefined : message.option;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVote.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgVote",
            value: MsgVote.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVote.decode(message.value);
    },
    toProto (message) {
        return MsgVote.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgVote",
            value: MsgVote.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVoteResponse() {
    return {};
}
const MsgVoteResponse = {
    typeUrl: "/cosmos.gov.v1beta1.MsgVoteResponse",
    aminoType: "cosmos-sdk/MsgVoteResponse",
    is (o) {
        return o && o.$typeUrl === MsgVoteResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgVoteResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgVoteResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgVoteResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgVoteResponse",
            value: MsgVoteResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteResponse.decode(message.value);
    },
    toProto (message) {
        return MsgVoteResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgVoteResponse",
            value: MsgVoteResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgVoteWeighted() {
    return {
        proposalId: BigInt(0),
        voter: "",
        options: []
    };
}
const MsgVoteWeighted = {
    typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeighted",
    aminoType: "cosmos-sdk/MsgVoteWeighted",
    is (o) {
        return o && (o.$typeUrl === MsgVoteWeighted.typeUrl || typeof o.proposalId === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].is(o.options[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgVoteWeighted.typeUrl || typeof o.proposal_id === "bigint" && typeof o.voter === "string" && Array.isArray(o.options) && (!o.options.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].isAmino(o.options[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.voter !== "") {
            writer.uint32(18).string(message.voter);
        }
        for (const v of message.options){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteWeighted();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.voter = reader.string();
                    break;
                case 3:
                    message.options.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgVoteWeighted();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.voter = object.voter ?? "";
        message.options = object.options?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgVoteWeighted();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.voter !== undefined && object.voter !== null) {
            message.voter = object.voter;
        }
        message.options = object.options?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.voter = message.voter === "" ? undefined : message.voter;
        if (message.options) {
            obj.options = message.options.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].toAmino(e) : undefined);
        } else {
            obj.options = message.options;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteWeighted.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgVoteWeighted",
            value: MsgVoteWeighted.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteWeighted.decode(message.value);
    },
    toProto (message) {
        return MsgVoteWeighted.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeighted",
            value: MsgVoteWeighted.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgVoteWeighted.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$gov$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WeightedVoteOption"].registerTypeUrl();
    }
};
function createBaseMsgVoteWeightedResponse() {
    return {};
}
const MsgVoteWeightedResponse = {
    typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeightedResponse",
    aminoType: "cosmos-sdk/MsgVoteWeightedResponse",
    is (o) {
        return o && o.$typeUrl === MsgVoteWeightedResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgVoteWeightedResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgVoteWeightedResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgVoteWeightedResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgVoteWeightedResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgVoteWeightedResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgVoteWeightedResponse",
            value: MsgVoteWeightedResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgVoteWeightedResponse.decode(message.value);
    },
    toProto (message) {
        return MsgVoteWeightedResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeightedResponse",
            value: MsgVoteWeightedResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgDeposit() {
    return {
        proposalId: BigInt(0),
        depositor: "",
        amount: []
    };
}
const MsgDeposit = {
    typeUrl: "/cosmos.gov.v1beta1.MsgDeposit",
    aminoType: "cosmos-sdk/MsgDeposit",
    is (o) {
        return o && (o.$typeUrl === MsgDeposit.typeUrl || typeof o.proposalId === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].is(o.amount[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgDeposit.typeUrl || typeof o.proposal_id === "bigint" && typeof o.depositor === "string" && Array.isArray(o.amount) && (!o.amount.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].isAmino(o.amount[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.proposalId !== BigInt(0)) {
            writer.uint32(8).uint64(message.proposalId);
        }
        if (message.depositor !== "") {
            writer.uint32(18).string(message.depositor);
        }
        for (const v of message.amount){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].encode(v, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDeposit();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.proposalId = reader.uint64();
                    break;
                case 2:
                    message.depositor = reader.string();
                    break;
                case 3:
                    message.amount.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgDeposit();
        message.proposalId = object.proposalId !== undefined && object.proposalId !== null ? BigInt(object.proposalId.toString()) : BigInt(0);
        message.depositor = object.depositor ?? "";
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgDeposit();
        if (object.proposal_id !== undefined && object.proposal_id !== null) {
            message.proposalId = BigInt(object.proposal_id);
        }
        if (object.depositor !== undefined && object.depositor !== null) {
            message.depositor = object.depositor;
        }
        message.amount = object.amount?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.proposal_id = message.proposalId ? message.proposalId?.toString() : "0";
        obj.depositor = message.depositor === "" ? undefined : message.depositor;
        if (message.amount) {
            obj.amount = message.amount.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].toAmino(e) : undefined);
        } else {
            obj.amount = message.amount;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDeposit.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgDeposit",
            value: MsgDeposit.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDeposit.decode(message.value);
    },
    toProto (message) {
        return MsgDeposit.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgDeposit",
            value: MsgDeposit.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MsgDeposit.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$v1beta1$2f$coin$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Coin"].registerTypeUrl();
    }
};
function createBaseMsgDepositResponse() {
    return {};
}
const MsgDepositResponse = {
    typeUrl: "/cosmos.gov.v1beta1.MsgDepositResponse",
    aminoType: "cosmos-sdk/MsgDepositResponse",
    is (o) {
        return o && o.$typeUrl === MsgDepositResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgDepositResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgDepositResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgDepositResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgDepositResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgDepositResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgDepositResponse",
            value: MsgDepositResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgDepositResponse.decode(message.value);
    },
    toProto (message) {
        return MsgDepositResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/cosmos.gov.v1beta1.MsgDepositResponse",
            value: MsgDepositResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/cosmos.gov.v1.MsgSubmitProposal",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"]
    ],
    [
        "/cosmos.gov.v1.MsgExecLegacyContent",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgExecLegacyContent"]
    ],
    [
        "/cosmos.gov.v1.MsgVote",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"]
    ],
    [
        "/cosmos.gov.v1.MsgVoteWeighted",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"]
    ],
    [
        "/cosmos.gov.v1.MsgDeposit",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"]
    ],
    [
        "/cosmos.gov.v1.MsgUpdateParams",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
    ],
    [
        "/cosmos.gov.v1.MsgCancelProposal",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelProposal"]
    ]
];
const MessageComposer = {
    encoded: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgSubmitProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"].encode(value).finish()
            };
        },
        execLegacyContent (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgExecLegacyContent",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgExecLegacyContent"].encode(value).finish()
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVote",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"].encode(value).finish()
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVoteWeighted",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"].encode(value).finish()
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgDeposit",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"].encode(value).finish()
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].encode(value).finish()
            };
        },
        cancelProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgCancelProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelProposal"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgSubmitProposal",
                value
            };
        },
        execLegacyContent (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgExecLegacyContent",
                value
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVote",
                value
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVoteWeighted",
                value
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgDeposit",
                value
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgUpdateParams",
                value
            };
        },
        cancelProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgCancelProposal",
                value
            };
        }
    },
    fromPartial: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgSubmitProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"].fromPartial(value)
            };
        },
        execLegacyContent (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgExecLegacyContent",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgExecLegacyContent"].fromPartial(value)
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVote",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"].fromPartial(value)
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgVoteWeighted",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"].fromPartial(value)
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgDeposit",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"].fromPartial(value)
            };
        },
        updateParams (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgUpdateParams",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"].fromPartial(value)
            };
        },
        cancelProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1.MsgCancelProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelProposal"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/cosmos.gov.v1beta1.MsgSubmitProposal",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"]
    ],
    [
        "/cosmos.gov.v1beta1.MsgVote",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"]
    ],
    [
        "/cosmos.gov.v1beta1.MsgVoteWeighted",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"]
    ],
    [
        "/cosmos.gov.v1beta1.MsgDeposit",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"]
    ]
];
const MessageComposer = {
    encoded: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"].encode(value).finish()
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVote",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"].encode(value).finish()
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeighted",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"].encode(value).finish()
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgDeposit",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposal",
                value
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVote",
                value
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeighted",
                value
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgDeposit",
                value
            };
        }
    },
    fromPartial: {
        submitProposal (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgSubmitProposal",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"].fromPartial(value)
            };
        },
        vote (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVote",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"].fromPartial(value)
            };
        },
        voteWeighted (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgVoteWeighted",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"].fromPartial(value)
            };
        },
        deposit (value) {
            return {
                typeUrl: "/cosmos.gov.v1beta1.MsgDeposit",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getConstitution": (()=>getConstitution),
    "getDeposit": (()=>getDeposit),
    "getDeposits": (()=>getDeposits),
    "getParams": (()=>getParams),
    "getProposal": (()=>getProposal),
    "getProposals": (()=>getProposals),
    "getTallyResult": (()=>getTallyResult),
    "getVote": (()=>getVote),
    "getVotes": (()=>getVotes)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/query.js [app-client] (ecmascript)");
;
;
const getConstitution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryConstitutionRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryConstitutionResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Constitution",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryConstitutionRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryConstitutionResponse"]
    ]
});
const getProposal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Proposal",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalResponse"]
    ]
});
const getProposals = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Proposals",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsResponse"]
    ]
});
const getVote = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Vote",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteResponse"]
    ]
});
const getVotes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Votes",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesResponse"]
    ]
});
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
const getDeposit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Deposit",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositResponse"]
    ]
});
const getDeposits = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "Deposits",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsResponse"]
    ]
});
const getTallyResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultResponse"].decode,
    service: "cosmos.gov.v1.Query",
    method: "TallyResult",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getDeposit": (()=>getDeposit),
    "getDeposits": (()=>getDeposits),
    "getParams": (()=>getParams),
    "getProposal": (()=>getProposal),
    "getProposals": (()=>getProposals),
    "getTallyResult": (()=>getTallyResult),
    "getVote": (()=>getVote),
    "getVotes": (()=>getVotes)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/query.js [app-client] (ecmascript)");
;
;
const getProposal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Proposal",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalResponse"]
    ]
});
const getProposals = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Proposals",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryProposalsResponse"]
    ]
});
const getVote = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Vote",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVoteResponse"]
    ]
});
const getVotes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Votes",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryVotesResponse"]
    ]
});
const getParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Params",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryParamsResponse"]
    ]
});
const getDeposit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Deposit",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositResponse"]
    ]
});
const getDeposits = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "Deposits",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryDepositsResponse"]
    ]
});
const getTallyResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultResponse"].decode,
    service: "cosmos.gov.v1beta1.Query",
    method: "TallyResult",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryTallyResultResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cancelProposal": (()=>cancelProposal),
    "deposit": (()=>deposit),
    "execLegacyContent": (()=>execLegacyContent),
    "submitProposal": (()=>submitProposal),
    "updateParams": (()=>updateParams),
    "vote": (()=>vote),
    "voteWeighted": (()=>voteWeighted)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1/tx.js [app-client] (ecmascript)");
;
;
const submitProposal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"]
});
const execLegacyContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgExecLegacyContent"]
});
const vote = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"]
});
const voteWeighted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"]
});
const deposit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"]
});
const updateParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgUpdateParams"]
});
const cancelProposal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgCancelProposal"]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "deposit": (()=>deposit),
    "submitProposal": (()=>submitProposal),
    "vote": (()=>vote),
    "voteWeighted": (()=>voteWeighted)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/gov/v1beta1/tx.js [app-client] (ecmascript)");
;
;
const submitProposal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgSubmitProposal"]
});
const vote = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVote"]
});
const voteWeighted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgVoteWeighted"]
});
const deposit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$gov$2f$v1beta1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgDeposit"]
});
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_cosmos_gov_b3131bf8._.js.map