(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/src/hook/useSendToken.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useSendToken": (()=>useSendToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/hook.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChainWallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/tx.rpc.func.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/applications/transfer/v1/tx.rpc.func.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const useSendToken = (chainName, walletName)=>{
    _s();
    const { chainInfo } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"])(chainName);
    const { signingClient, address: fromAddress, assetList } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"])(chainName, walletName);
    const denom = assetList.assets[0].base;
    const sendNativeToken = async (toAddress, amount)=>{
        const fee = {
            amount: [
                {
                    denom,
                    amount
                }
            ],
            gas: "100000"
        };
        if (signingClient) {
            const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$tx$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["send"])(signingClient, fromAddress, {
                fromAddress: fromAddress,
                toAddress: toAddress,
                amount: [
                    {
                        denom,
                        amount: amount
                    }
                ]
            }, fee, 'send native token');
            console.log('Transaction result:', res);
        }
    };
    const sendIbcToken = async (toAddress, amount)=>{
        if (signingClient) {
            const fee = {
                amount: [
                    {
                        denom,
                        amount: "1000"
                    }
                ],
                gas: "200000"
            };
            const token = {
                amount,
                denom
            };
            const currentTime = Math.floor(Date.now()) * 1000000;
            const timeoutTime = currentTime + 300 * 1000000000; // 5 minutes
            const ibcInfos = chainInfo.fetcher.getChainIbcData(chainName);
            const chains = chainInfo.fetcher.chains;
            const toChain = chains.find((c)=>c.bech32_prefix === toAddress.split('1')[0]);
            const ibcInfo = ibcInfos.find((i)=>i.chain_1.chain_name === chainName && i.chain_2.chain_name === toChain?.chain_name);
            const { port_id: sourcePort, channel_id: sourceChannel } = ibcInfo.channels[0].chain_1;
            console.log(sourcePort, sourceChannel);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transfer"])(signingClient, fromAddress, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$applications$2f$transfer$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgTransfer"].fromPartial({
                sourcePort,
                sourceChannel,
                token,
                sender: fromAddress,
                receiver: toAddress,
                timeoutHeight: undefined,
                timeoutTimestamp: BigInt(timeoutTime),
                memo: 'test transfer'
            }), fee, "send ibc");
        }
    };
    const sendToken = async (toAddress, amount)=>{
        const fromChainPrefix = fromAddress.split('1')[0];
        const toChainPrefix = toAddress.split('1')[0];
        console.log('fromChainPrefix:', fromChainPrefix);
        console.log('toChainPrefix:', toChainPrefix);
        if (fromChainPrefix === toChainPrefix) {
            await sendNativeToken(toAddress, amount);
        } else {
            await sendIbcToken(toAddress, amount);
        }
    };
    return sendToken;
};
_s(useSendToken, "Ll1dJrtLSod5eONF8B93UWmInWI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/app/transaction/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ReceiverWallet": (()=>ReceiverWallet),
    "SenderWalletBlock": (()=>SenderWalletBlock),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/wallet/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChainWallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/bank/v1beta1/query.rpc.func.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/hook.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$hook$2f$useSendToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/hook/useSendToken.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const SenderWalletBlock = ({ chainName, amountToSend })=>{
    _s();
    const { creditFromFaucet, getCoin } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"])(chainName);
    const senderChainWallet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"])(chainName, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["senderWallet"].info.name);
    const sendToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$hook$2f$useSendToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendToken"])(chainName, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["senderWallet"].info.name);
    const osmosisReceiverWallet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"])("osmosis", __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["receiverWallet"].info.name);
    const handleFaucet = async ()=>{
        const res = await creditFromFaucet(senderChainWallet.address, (await getCoin()).base);
        await handleGetAllBalances();
    };
    const [allBalances, setAllBalances] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const denom = senderChainWallet.assetList.assets[0].base;
    const handleGetAllBalances = async ()=>{
        const balances = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllBalances"])(senderChainWallet.rpcEndpoint, {
            address: senderChainWallet.address,
            resolveDenom: true
        });
        console.log("All balances:", balances.balances);
        setAllBalances(balances.balances);
    };
    const [sendTokenDone, setSendTokenDone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleSendToken = async ()=>{
        setSendTokenDone(false);
        await sendToken(osmosisReceiverWallet.address, amountToSend);
        setSendTokenDone(true);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": `sender-wallet-${chainName}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                children: [
                    "Sender Wallet ",
                    chainName,
                    " "
                ]
            }, void 0, true, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "address: ",
                    senderChainWallet.address
                ]
            }, void 0, true, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: senderChainWallet.connect,
                children: "connect"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleFaucet,
                children: "faucet sender wallet"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleGetAllBalances,
                children: "get balance"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleSendToken,
                children: [
                    "send token ",
                    amountToSend,
                    " ",
                    denom,
                    sendTokenDone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: " (done)"
                    }, void 0, false, {
                        fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                        lineNumber: 71,
                        columnNumber: 27
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: allBalances.map((balance)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: [
                            balance.amount,
                            " ",
                            balance.denom,
                            " "
                        ]
                    }, balance.denom, true, {
                        fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 73,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
};
_s(SenderWalletBlock, "LKi1gwZbXkXq1zvKaogENfN3YJ0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$hook$2f$useSendToken$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendToken"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"]
    ];
});
_c = SenderWalletBlock;
const ReceiverWallet = ()=>{
    _s1();
    const { address, rpcEndpoint, connect, status } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"])("osmosis", __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["receiverWallet"].info.name);
    const [allBalances, setAllBalances] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const handleGetAllBalances = async ()=>{
        const balances = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$bank$2f$v1beta1$2f$query$2e$rpc$2e$func$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAllBalances"])(rpcEndpoint, {
            address,
            resolveDenom: true
        });
        console.log("All balances:", balances.balances);
        setAllBalances(balances.balances);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-testid": "receiver-wallet",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                children: "Receiver Wallet Osmosis"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "address: ",
                    address
                ]
            }, void 0, true, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: [
                    "status:",
                    status
                ]
            }, void 0, true, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: connect,
                children: "connect"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 106,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleGetAllBalances,
                children: "get balances"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 107,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: allBalances.map((balance)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    balance.amount,
                                    " ",
                                    balance.denom,
                                    " "
                                ]
                            }, balance.denom, true, {
                                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                                lineNumber: 111,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true))
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
};
_s1(ReceiverWallet, "3x4tgvPKOor2mkh0QxL5ZzDH3QA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChainWallet"]
    ];
});
_c1 = ReceiverWallet;
function __TURBOPACK__default__export__() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SenderWalletBlock, {
                chainName: "osmosis",
                amountToSend: "1111111111"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SenderWalletBlock, {
                chainName: "cosmoshub",
                amountToSend: "2222222222"
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 126,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReceiverWallet, {}, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
                lineNumber: 127,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/examples/e2e/src/app/transaction/page.tsx",
        lineNumber: 124,
        columnNumber: 5
    }, this);
}
var _c, _c1;
__turbopack_context__.k.register(_c, "SenderWalletBlock");
__turbopack_context__.k.register(_c1, "ReceiverWallet");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=examples_e2e_src_08198630._.js.map