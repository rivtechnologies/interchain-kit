(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "isEd25519Pubkey": (()=>isEd25519Pubkey),
    "isMultisigThresholdPubkey": (()=>isMultisigThresholdPubkey),
    "isSecp256k1Pubkey": (()=>isSecp256k1Pubkey),
    "isSinglePubkey": (()=>isSinglePubkey),
    "pubkeyType": (()=>pubkeyType)
});
function isEd25519Pubkey(pubkey) {
    return pubkey.type === "tendermint/PubKeyEd25519";
}
function isSecp256k1Pubkey(pubkey) {
    return pubkey.type === "tendermint/PubKeySecp256k1";
}
const pubkeyType = {
    /** @see https://github.com/tendermint/tendermint/blob/v0.33.0/crypto/ed25519/ed25519.go#L22 */ secp256k1: "tendermint/PubKeySecp256k1",
    /** @see https://github.com/tendermint/tendermint/blob/v0.33.0/crypto/secp256k1/secp256k1.go#L23 */ ed25519: "tendermint/PubKeyEd25519",
    /** @see https://github.com/tendermint/tendermint/blob/v0.33.0/crypto/sr25519/codec.go#L12 */ sr25519: "tendermint/PubKeySr25519",
    multisigThreshold: "tendermint/PubKeyMultisigThreshold"
};
function isSinglePubkey(pubkey) {
    const singPubkeyTypes = [
        pubkeyType.ed25519,
        pubkeyType.secp256k1,
        pubkeyType.sr25519
    ];
    return singPubkeyTypes.includes(pubkey.type);
}
function isMultisigThresholdPubkey(pubkey) {
    return pubkey.type === "tendermint/PubKeyMultisigThreshold";
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "decodeAminoPubkey": (()=>decodeAminoPubkey),
    "decodeBech32Pubkey": (()=>decodeBech32Pubkey),
    "encodeAminoPubkey": (()=>encodeAminoPubkey),
    "encodeBech32Pubkey": (()=>encodeBech32Pubkey),
    "encodeEd25519Pubkey": (()=>encodeEd25519Pubkey),
    "encodeSecp256k1Pubkey": (()=>encodeSecp256k1Pubkey)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/arrays.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
;
;
;
;
function encodeSecp256k1Pubkey(pubkey) {
    if (pubkey.length !== 33 || pubkey[0] !== 0x02 && pubkey[0] !== 0x03) {
        throw new Error("Public key must be compressed secp256k1, i.e. 33 bytes starting with 0x02 or 0x03");
    }
    return {
        type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].secp256k1,
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(pubkey)
    };
}
function encodeEd25519Pubkey(pubkey) {
    if (pubkey.length !== 32) {
        throw new Error("Ed25519 public key must be 32 bytes long");
    }
    return {
        type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].ed25519,
        value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(pubkey)
    };
}
// As discussed in https://github.com/binance-chain/javascript-sdk/issues/163
// Prefixes listed here: https://github.com/tendermint/tendermint/blob/d419fffe18531317c28c29a292ad7d253f6cafdf/docs/spec/blockchain/encoding.md#public-key-cryptography
// Last bytes is varint-encoded length prefix
const pubkeyAminoPrefixSecp256k1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])("eb5ae987" + "21" /* fixed length */ );
const pubkeyAminoPrefixEd25519 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])("1624de64" + "20" /* fixed length */ );
const pubkeyAminoPrefixSr25519 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])("0dfb1005" + "20" /* fixed length */ );
/** See https://github.com/tendermint/tendermint/commit/38b401657e4ad7a7eeb3c30a3cbf512037df3740 */ const pubkeyAminoPrefixMultisigThreshold = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromHex"])("22c1f7e2" /* variable length not included */ );
function decodeAminoPubkey(data) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWithArray"])(data, pubkeyAminoPrefixSecp256k1)) {
        const rest = data.slice(pubkeyAminoPrefixSecp256k1.length);
        if (rest.length !== 33) {
            throw new Error("Invalid rest data length. Expected 33 bytes (compressed secp256k1 pubkey).");
        }
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].secp256k1,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(rest)
        };
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWithArray"])(data, pubkeyAminoPrefixEd25519)) {
        const rest = data.slice(pubkeyAminoPrefixEd25519.length);
        if (rest.length !== 32) {
            throw new Error("Invalid rest data length. Expected 32 bytes (Ed25519 pubkey).");
        }
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].ed25519,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(rest)
        };
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWithArray"])(data, pubkeyAminoPrefixSr25519)) {
        const rest = data.slice(pubkeyAminoPrefixSr25519.length);
        if (rest.length !== 32) {
            throw new Error("Invalid rest data length. Expected 32 bytes (Sr25519 pubkey).");
        }
        return {
            type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].sr25519,
            value: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(rest)
        };
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWithArray"])(data, pubkeyAminoPrefixMultisigThreshold)) {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        return decodeMultisigPubkey(data);
    } else {
        throw new Error("Unsupported public key type. Amino data starts with: " + (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toHex"])(data.slice(0, 5)));
    }
}
function decodeBech32Pubkey(bechEncoded) {
    const { data } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBech32"])(bechEncoded);
    return decodeAminoPubkey(data);
}
/**
 * Uvarint decoder for Amino.
 * @see https://github.com/tendermint/go-amino/blob/8e779b71f40d175/decoder.go#L64-76
 * @returns varint as number, and bytes count occupied by varaint
 */ function decodeUvarint(reader) {
    if (reader.length < 1) {
        throw new Error("Can't decode varint. EOF");
    }
    if (reader[0] > 127) {
        throw new Error("Decoding numbers > 127 is not supported here. Please tell those lazy CosmJS maintainers to port the binary.Varint implementation from the Go standard library and write some tests.");
    }
    return [
        reader[0],
        1
    ];
}
/**
 * Decodes a multisig pubkey to type object.
 * Pubkey structure [ prefix + const + threshold + loop:(const + pubkeyLength + pubkey            ) ]
 *                  [   4b   + 1b    +  varint   + loop:(1b    +    varint    + pubkeyLength bytes) ]
 * @param data encoded pubkey
 */ function decodeMultisigPubkey(data) {
    const reader = Array.from(data);
    // remove multisig amino prefix;
    const prefixFromReader = reader.splice(0, pubkeyAminoPrefixMultisigThreshold.length);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$utils$2f$esm$2f$arrays$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startsWithArray"])(prefixFromReader, pubkeyAminoPrefixMultisigThreshold)) {
        throw new Error("Invalid multisig prefix.");
    }
    // remove 0x08 threshold prefix;
    if (reader.shift() != 0x08) {
        throw new Error("Invalid multisig data. Expecting 0x08 prefix before threshold.");
    }
    // read threshold
    const [threshold, thresholdBytesLength] = decodeUvarint(reader);
    reader.splice(0, thresholdBytesLength);
    // read participants pubkeys
    const pubkeys = [];
    while(reader.length > 0){
        // remove 0x12 threshold prefix;
        if (reader.shift() != 0x12) {
            throw new Error("Invalid multisig data. Expecting 0x12 prefix before participant pubkey length.");
        }
        // read pubkey length
        const [pubkeyLength, pubkeyLengthBytesSize] = decodeUvarint(reader);
        reader.splice(0, pubkeyLengthBytesSize);
        // verify that we can read pubkey
        if (reader.length < pubkeyLength) {
            throw new Error("Invalid multisig data length.");
        }
        // read and decode participant pubkey
        const encodedPubkey = reader.splice(0, pubkeyLength);
        const pubkey = decodeAminoPubkey(Uint8Array.from(encodedPubkey));
        pubkeys.push(pubkey);
    }
    return {
        type: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].multisigThreshold,
        value: {
            threshold: threshold.toString(),
            pubkeys: pubkeys
        }
    };
}
/**
 * Uvarint encoder for Amino. This is the same encoding as `binary.PutUvarint` from the Go
 * standard library.
 *
 * @see https://github.com/tendermint/go-amino/blob/8e779b71f40d175/encoder.go#L77-L85
 */ function encodeUvarint(value) {
    const checked = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"].fromString(value.toString()).toNumber();
    if (checked > 127) {
        throw new Error("Encoding numbers > 127 is not supported here. Please tell those lazy CosmJS maintainers to port the binary.PutUvarint implementation from the Go standard library and write some tests.");
    }
    return [
        checked
    ];
}
function encodeAminoPubkey(pubkey) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMultisigThresholdPubkey"])(pubkey)) {
        const out = Array.from(pubkeyAminoPrefixMultisigThreshold);
        out.push(0x08); // TODO: What is this?
        out.push(...encodeUvarint(pubkey.value.threshold));
        for (const pubkeyData of pubkey.value.pubkeys.map((p)=>encodeAminoPubkey(p))){
            out.push(0x12); // TODO: What is this?
            out.push(...encodeUvarint(pubkeyData.length));
            out.push(...pubkeyData);
        }
        return new Uint8Array(out);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEd25519Pubkey"])(pubkey)) {
        return new Uint8Array([
            ...pubkeyAminoPrefixEd25519,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value)
        ]);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSecp256k1Pubkey"])(pubkey)) {
        return new Uint8Array([
            ...pubkeyAminoPrefixSecp256k1,
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value)
        ]);
    } else {
        throw new Error("Unsupported pubkey type");
    }
}
function encodeBech32Pubkey(pubkey, prefix) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBech32"])(prefix, encodeAminoPubkey(pubkey));
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/addresses.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// See https://github.com/tendermint/tendermint/blob/f2ada0a604b4c0763bda2f64fac53d506d3beca7/docs/spec/blockchain/encoding.md#public-key-cryptography
__turbopack_context__.s({
    "pubkeyToAddress": (()=>pubkeyToAddress),
    "pubkeyToRawAddress": (()=>pubkeyToRawAddress),
    "rawEd25519PubkeyToRawAddress": (()=>rawEd25519PubkeyToRawAddress),
    "rawSecp256k1PubkeyToRawAddress": (()=>rawSecp256k1PubkeyToRawAddress)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$ripemd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/ripemd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/sha.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/bech32.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
;
;
;
;
function rawEd25519PubkeyToRawAddress(pubkeyData) {
    if (pubkeyData.length !== 32) {
        throw new Error(`Invalid Ed25519 pubkey length: ${pubkeyData.length}`);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(pubkeyData).slice(0, 20);
}
function rawSecp256k1PubkeyToRawAddress(pubkeyData) {
    if (pubkeyData.length !== 33) {
        throw new Error(`Invalid Secp256k1 pubkey length (compressed): ${pubkeyData.length}`);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$ripemd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ripemd160"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(pubkeyData));
}
function pubkeyToRawAddress(pubkey) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSecp256k1Pubkey"])(pubkey)) {
        const pubkeyData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value);
        return rawSecp256k1PubkeyToRawAddress(pubkeyData);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEd25519Pubkey"])(pubkey)) {
        const pubkeyData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value);
        return rawEd25519PubkeyToRawAddress(pubkeyData);
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMultisigThresholdPubkey"])(pubkey)) {
        // https://github.com/tendermint/tendermint/blob/38b401657e4ad7a7eeb3c30a3cbf512037df3740/crypto/multisig/threshold_pubkey.go#L71-L74
        const pubkeyData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeAminoPubkey"])(pubkey);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$sha$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sha256"])(pubkeyData).slice(0, 20);
    } else {
        throw new Error("Unsupported public key type");
    }
}
function pubkeyToAddress(pubkey, prefix) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$bech32$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBech32"])(prefix, pubkeyToRawAddress(pubkey));
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/coins.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "addCoins": (()=>addCoins),
    "coin": (()=>coin),
    "coins": (()=>coins),
    "parseCoins": (()=>parseCoins)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/decimal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
;
function coin(amount, denom) {
    let outAmount;
    if (typeof amount === "number") {
        try {
            outAmount = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"](amount).toString();
        } catch (_err) {
            throw new Error("Given amount is not a safe integer. Consider using a string instead to overcome the limitations of JS numbers.");
        }
    } else {
        if (!amount.match(/^[0-9]+$/)) {
            throw new Error("Invalid unsigned integer string format");
        }
        outAmount = amount.replace(/^0*/, "") || "0";
    }
    return {
        amount: outAmount,
        denom: denom
    };
}
function coins(amount, denom) {
    return [
        coin(amount, denom)
    ];
}
function parseCoins(input) {
    return input.replace(/\s/g, "").split(",").filter(Boolean).map((part)=>{
        // Denom regex from Stargate (https://github.com/cosmos/cosmos-sdk/blob/v0.42.7/types/coin.go#L599-L601)
        const match = part.match(/^([0-9]+)([a-zA-Z][a-zA-Z0-9/]{2,127})$/);
        if (!match) throw new Error("Got an invalid coin string");
        return {
            amount: match[1].replace(/^0+/, "") || "0",
            denom: match[2]
        };
    });
}
function addCoins(lhs, rhs) {
    if (lhs.denom !== rhs.denom) throw new Error("Trying to add two coins with different denoms");
    return {
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(lhs.amount, 0).plus(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$decimal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Decimal"].fromAtomics(rhs.amount, 0)).atomics,
        denom: lhs.denom
    };
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/multisig.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "compareArrays": (()=>compareArrays),
    "createMultisigThresholdPubkey": (()=>createMultisigThresholdPubkey)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/hex.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$addresses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/addresses.js [app-client] (ecmascript)");
;
;
;
function compareArrays(a, b) {
    const aHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toHex"])(a);
    const bHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$hex$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toHex"])(b);
    return aHex === bHex ? 0 : aHex < bHex ? -1 : 1;
}
function createMultisigThresholdPubkey(pubkeys, threshold, nosort = false) {
    const uintThreshold = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"](threshold);
    if (uintThreshold.toNumber() > pubkeys.length) {
        throw new Error(`Threshold k = ${uintThreshold.toNumber()} exceeds number of keys n = ${pubkeys.length}`);
    }
    const outPubkeys = nosort ? pubkeys : Array.from(pubkeys).sort((lhs, rhs)=>{
        // https://github.com/cosmos/cosmos-sdk/blob/v0.42.2/client/keys/add.go#L172-L174
        const addressLhs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$addresses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyToRawAddress"])(lhs);
        const addressRhs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$addresses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyToRawAddress"])(rhs);
        return compareArrays(addressLhs, addressRhs);
    });
    return {
        type: "tendermint/PubKeyMultisigThreshold",
        value: {
            threshold: uintThreshold.toString(),
            pubkeys: outPubkeys
        }
    };
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/omitdefault.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/**
 * Returns the given input. If the input is the default value
 * of protobuf, undefined is retunred. Use this when creating Amino JSON converters.
 */ __turbopack_context__.s({
    "omitDefault": (()=>omitDefault)
});
function omitDefault(input) {
    switch(typeof input){
        case "string":
            return input === "" ? undefined : input;
        case "number":
            return input === 0 ? undefined : input;
        case "bigint":
            return input === BigInt(0) ? undefined : input;
        case "boolean":
            return !input ? undefined : input;
        default:
            throw new Error(`Got unsupported type '${typeof input}'`);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/paths.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "makeCosmoshubPath": (()=>makeCosmoshubPath)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/slip10.js [app-client] (ecmascript)");
;
function makeCosmoshubPath(a) {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slip10RawIndex"].hardened(44),
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slip10RawIndex"].hardened(118),
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slip10RawIndex"].hardened(0),
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slip10RawIndex"].normal(0),
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$slip10$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slip10RawIndex"].normal(a)
    ];
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signature.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/naming-convention */ __turbopack_context__.s({
    "decodeSignature": (()=>decodeSignature),
    "encodeSecp256k1Signature": (()=>encodeSecp256k1Signature)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
;
;
;
function encodeSecp256k1Signature(pubkey, signature) {
    if (signature.length !== 64) {
        throw new Error("Signature must be 64 bytes long. Cosmos SDK uses a 2x32 byte fixed length encoding for the secp256k1 signature integers r and s.");
    }
    return {
        pub_key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeSecp256k1Pubkey"])(pubkey),
        signature: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toBase64"])(signature)
    };
}
function decodeSignature(signature) {
    switch(signature.pub_key.type){
        // Note: please don't add cases here without writing additional unit tests
        case __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["pubkeyType"].secp256k1:
            return {
                pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(signature.pub_key.value),
                signature: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(signature.signature)
            };
        default:
            throw new Error("Unsupported pubkey type");
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signdoc.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/naming-convention */ __turbopack_context__.s({
    "escapeCharacters": (()=>escapeCharacters),
    "makeSignDoc": (()=>makeSignDoc),
    "serializeSignDoc": (()=>serializeSignDoc),
    "sortedJsonStringify": (()=>sortedJsonStringify)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/utf8.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
;
;
function sortedObject(obj) {
    if (typeof obj !== "object" || obj === null) {
        return obj;
    }
    if (Array.isArray(obj)) {
        return obj.map(sortedObject);
    }
    const sortedKeys = Object.keys(obj).sort();
    const result = {};
    // NOTE: Use forEach instead of reduce for performance with large objects eg Wasm code
    sortedKeys.forEach((key)=>{
        result[key] = sortedObject(obj[key]);
    });
    return result;
}
function sortedJsonStringify(obj) {
    return JSON.stringify(sortedObject(obj));
}
function makeSignDoc(msgs, fee, chainId, memo, accountNumber, sequence, timeout_height) {
    return {
        chain_id: chainId,
        account_number: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"].fromString(accountNumber.toString()).toString(),
        sequence: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"].fromString(sequence.toString()).toString(),
        fee: fee,
        msgs: msgs,
        memo: memo || "",
        ...timeout_height && {
            timeout_height: timeout_height.toString()
        }
    };
}
function escapeCharacters(input) {
    // When we migrate to target es2021 or above, we can use replaceAll instead of global patterns.
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/replaceAll
    const amp = /&/g;
    const lt = /</g;
    const gt = />/g;
    return input.replace(amp, "\\u0026").replace(lt, "\\u003c").replace(gt, "\\u003e");
}
function serializeSignDoc(signDoc) {
    const serialized = escapeCharacters(sortedJsonStringify(signDoc));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$utf8$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toUtf8"])(serialized);
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/stdtx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "isStdTx": (()=>isStdTx),
    "makeStdTx": (()=>makeStdTx)
});
function isStdTx(txValue) {
    const { memo, msg, fee, signatures } = txValue;
    return typeof memo === "string" && Array.isArray(msg) && typeof fee === "object" && Array.isArray(signatures);
}
function makeStdTx(content, signatures) {
    return {
        msg: content.msgs,
        fee: content.fee,
        memo: content.memo,
        signatures: Array.isArray(signatures) ? signatures : [
            signatures
        ]
    };
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "cosmjsSalt": (()=>cosmjsSalt),
    "decrypt": (()=>decrypt),
    "encrypt": (()=>encrypt),
    "executeKdf": (()=>executeKdf),
    "supportedAlgorithms": (()=>supportedAlgorithms)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/libsodium.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/random.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/ascii.js [app-client] (ecmascript)");
;
;
const cosmjsSalt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$ascii$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAscii"])("The CosmJS salt.");
async function executeKdf(password, configuration) {
    switch(configuration.algorithm){
        case "argon2id":
            {
                const options = configuration.params;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isArgon2idOptions"])(options)) throw new Error("Invalid format of argon2id params");
                return __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Argon2id"].execute(password, cosmjsSalt, options);
            }
        default:
            throw new Error("Unsupported KDF algorithm");
    }
}
const supportedAlgorithms = {
    xchacha20poly1305Ietf: "xchacha20poly1305-ietf"
};
async function encrypt(plaintext, encryptionKey, config) {
    switch(config.algorithm){
        case supportedAlgorithms.xchacha20poly1305Ietf:
            {
                const nonce = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Random"].getBytes(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xchacha20NonceLength"]);
                // Prepend fixed-length nonce to ciphertext as suggested in the example from https://github.com/jedisct1/libsodium.js#api
                return new Uint8Array([
                    ...nonce,
                    ...await __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Xchacha20poly1305Ietf"].encrypt(plaintext, encryptionKey, nonce)
                ]);
            }
        default:
            throw new Error(`Unsupported encryption algorithm: '${config.algorithm}'`);
    }
}
async function decrypt(ciphertext, encryptionKey, config) {
    switch(config.algorithm){
        case supportedAlgorithms.xchacha20poly1305Ietf:
            {
                const nonce = ciphertext.slice(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xchacha20NonceLength"]);
                return __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Xchacha20poly1305Ietf"].decrypt(ciphertext.slice(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$libsodium$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xchacha20NonceLength"]), encryptionKey, nonce);
            }
        default:
            throw new Error(`Unsupported encryption algorithm: '${config.algorithm}'`);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$addresses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/addresses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$coins$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/coins.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$multisig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/multisig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$omitdefault$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/omitdefault.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$paths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/paths.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signature.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$signdoc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signdoc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$stdtx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/stdtx.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/wallet.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/amino/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$addresses$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/addresses.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$coins$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/coins.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$multisig$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/multisig.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$omitdefault$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/omitdefault.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$paths$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/paths.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$signature$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signature.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$signdoc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/signdoc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$stdtx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/stdtx.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/ed25519/keys.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PrivKey = exports.PubKey = void 0;
const binary_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/binary.js [app-client] (ecmascript)");
function createBasePubKey() {
    return {
        key: new Uint8Array()
    };
}
/**
 * PubKey is an ed25519 public key for handling Tendermint keys in SDK.
 * It's needed for Any serialization and SDK compatibility.
 * It must not be used in a non Tendermint key context because it doesn't implement
 * ADR-28. Nevertheless, you will like to use ed25519 in app user level
 * then you must create a new proto message and follow ADR-28 for Address construction.
 * @name PubKey
 * @package cosmos.crypto.ed25519
 * @see proto type: cosmos.crypto.ed25519.PubKey
 */ exports.PubKey = {
    typeUrl: "/cosmos.crypto.ed25519.PubKey",
    aminoType: "tendermint/PubKeyEd25519",
    encode (message, writer = binary_1.BinaryWriter.create()) {
        if (message.key.length !== 0) {
            writer.uint32(10).bytes(message.key);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePubKey();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.key = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePubKey();
        message.key = object.key ?? new Uint8Array();
        return message;
    }
};
function createBasePrivKey() {
    return {
        key: new Uint8Array()
    };
}
/**
 * PrivKey defines a ed25519 private key.
 * NOTE: ed25519 keys must not be used in SDK apps except in a tendermint validator context.
 * @name PrivKey
 * @package cosmos.crypto.ed25519
 * @see proto type: cosmos.crypto.ed25519.PrivKey
 */ exports.PrivKey = {
    typeUrl: "/cosmos.crypto.ed25519.PrivKey",
    aminoType: "tendermint/PrivKeyEd25519",
    encode (message, writer = binary_1.BinaryWriter.create()) {
        if (message.key.length !== 0) {
            writer.uint32(10).bytes(message.key);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePrivKey();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.key = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePrivKey();
        message.key = object.key ?? new Uint8Array();
        return message;
    }
};
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/multisig/keys.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.LegacyAminoPubKey = void 0;
const any_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/google/protobuf/any.js [app-client] (ecmascript)");
const binary_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/binary.js [app-client] (ecmascript)");
function createBaseLegacyAminoPubKey() {
    return {
        threshold: 0,
        publicKeys: []
    };
}
/**
 * LegacyAminoPubKey specifies a public key type
 * which nests multiple public keys and a threshold,
 * it uses legacy amino address rules.
 * @name LegacyAminoPubKey
 * @package cosmos.crypto.multisig
 * @see proto type: cosmos.crypto.multisig.LegacyAminoPubKey
 */ exports.LegacyAminoPubKey = {
    typeUrl: "/cosmos.crypto.multisig.LegacyAminoPubKey",
    aminoType: "tendermint/PubKeyMultisigThreshold",
    encode (message, writer = binary_1.BinaryWriter.create()) {
        if (message.threshold !== 0) {
            writer.uint32(8).uint32(message.threshold);
        }
        for (const v of message.publicKeys){
            any_1.Any.encode(v, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof binary_1.BinaryReader ? input : new binary_1.BinaryReader(input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseLegacyAminoPubKey();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.threshold = reader.uint32();
                    break;
                case 2:
                    message.publicKeys.push(any_1.Any.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseLegacyAminoPubKey();
        message.threshold = object.threshold ?? 0;
        message.publicKeys = object.publicKeys?.map((e)=>any_1.Any.fromPartial(e)) || [];
        return message;
    }
};
}}),
"[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/pubkey.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* eslint-disable @typescript-eslint/naming-convention */ __turbopack_context__.s({
    "anyToSinglePubkey": (()=>anyToSinglePubkey),
    "decodeOptionalPubkey": (()=>decodeOptionalPubkey),
    "decodePubkey": (()=>decodePubkey),
    "encodePubkey": (()=>encodePubkey)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/encoding.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/amino/esm/pubkeys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/encoding/esm/base64.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/math/esm/integers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$ed25519$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/ed25519/keys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$multisig$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/multisig/keys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$secp256k1$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/secp256k1/keys.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/google/protobuf/any.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
function encodePubkey(pubkey) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSecp256k1Pubkey"])(pubkey)) {
        const pubkeyProto = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$secp256k1$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].fromPartial({
            key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value)
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial({
            typeUrl: "/cosmos.crypto.secp256k1.PubKey",
            value: Uint8Array.from(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$secp256k1$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].encode(pubkeyProto).finish())
        });
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEd25519Pubkey"])(pubkey)) {
        const pubkeyProto = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$ed25519$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].fromPartial({
            key: (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$encoding$2f$esm$2f$base64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromBase64"])(pubkey.value)
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial({
            typeUrl: "/cosmos.crypto.ed25519.PubKey",
            value: Uint8Array.from(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$ed25519$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].encode(pubkeyProto).finish())
        });
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$pubkeys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMultisigThresholdPubkey"])(pubkey)) {
        const pubkeyProto = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$multisig$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LegacyAminoPubKey"].fromPartial({
            threshold: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$math$2f$esm$2f$integers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Uint53"].fromString(pubkey.value.threshold).toNumber(),
            publicKeys: pubkey.value.pubkeys.map(encodePubkey)
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial({
            typeUrl: "/cosmos.crypto.multisig.LegacyAminoPubKey",
            value: Uint8Array.from(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$multisig$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LegacyAminoPubKey"].encode(pubkeyProto).finish())
        });
    } else {
        throw new Error(`Pubkey type ${pubkey.type} not recognized`);
    }
}
function anyToSinglePubkey(pubkey) {
    switch(pubkey.typeUrl){
        case "/cosmos.crypto.secp256k1.PubKey":
            {
                const { key } = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$secp256k1$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].decode(pubkey.value);
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeSecp256k1Pubkey"])(key);
            }
        case "/cosmos.crypto.ed25519.PubKey":
            {
                const { key } = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$ed25519$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PubKey"].decode(pubkey.value);
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$amino$2f$esm$2f$encoding$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeEd25519Pubkey"])(key);
            }
        default:
            throw new Error(`Pubkey type_url ${pubkey.typeUrl} not recognized as single public key type`);
    }
}
function decodePubkey(pubkey) {
    switch(pubkey.typeUrl){
        case "/cosmos.crypto.secp256k1.PubKey":
        case "/cosmos.crypto.ed25519.PubKey":
            {
                return anyToSinglePubkey(pubkey);
            }
        case "/cosmos.crypto.multisig.LegacyAminoPubKey":
            {
                const { threshold, publicKeys } = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2d$types$2f$cosmos$2f$crypto$2f$multisig$2f$keys$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LegacyAminoPubKey"].decode(pubkey.value);
                const out = {
                    type: "tendermint/PubKeyMultisigThreshold",
                    value: {
                        threshold: threshold.toString(),
                        pubkeys: publicKeys.map(anyToSinglePubkey)
                    }
                };
                return out;
            }
        default:
            throw new Error(`Pubkey type URL '${pubkey.typeUrl}' not recognized`);
    }
}
function decodeOptionalPubkey(pubkey) {
    if (!pubkey) return null;
    if (pubkey.typeUrl) {
        if (pubkey.value.length) {
            // both set
            return decodePubkey(pubkey);
        } else {
            throw new Error(`Pubkey is an Any with type URL '${pubkey.typeUrl}' but an empty value`);
        }
    } else {
        if (pubkey.value.length) {
            throw new Error(`Pubkey is an Any with an empty type URL but a value set`);
        } else {
            // both unset, assuming this empty instance means null
            return null;
        }
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/pubkey.js [app-client] (ecmascript)");
;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$pubkey$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/pubkey.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$pubkey$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/pubkey/esm/index.js [app-client] (ecmascript) <locals>");
}}),
}]);

//# sourceMappingURL=1483a_%40interchainjs_b1a3c069._.js.map