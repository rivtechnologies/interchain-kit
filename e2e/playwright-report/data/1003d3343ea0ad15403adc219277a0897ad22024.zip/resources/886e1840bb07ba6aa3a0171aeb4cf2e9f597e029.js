(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'bitcannadevnet2',
    assets: [
        {
            description: 'The BCNA coin is the transactional token within the BitCanna network, serving the legal cannabis industry through its payment network, supply chain and trust network.',
            denomUnits: [
                {
                    denom: 'ubcna',
                    exponent: 0
                },
                {
                    denom: 'bcna',
                    exponent: 6
                }
            ],
            base: 'ubcna',
            display: 'bcna',
            name: 'BitCanna',
            symbol: 'BCNA',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'bitcanna',
                        baseDenom: 'ubcna'
                    },
                    provider: 'Bitcanna'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/bitcannadevnet2/images/bcna.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/bitcannadevnet2/images/bcna.svg'
            },
            coingeckoId: 'bitcanna',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/bitcannadevnet2/images/bcna.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/bitcannadevnet2/images/bcna.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'bitcannadevnet2',
    status: 'live',
    networkType: 'devnet',
    prettyName: 'BitCanna Devnet-6 SDK v0.46.x',
    chainType: 'cosmos',
    chainId: 'bitcanna-dev-6',
    bech32Prefix: 'bcna',
    daemonName: 'bcnad',
    nodeHome: '$HOME/.bcna',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'ubcna',
                fixedMinGasPrice: 0.001
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/BitCannaGlobal/bcna',
        recommendedVersion: 'v2.0.0-beta',
        compatibleVersions: [
            'v2.0.0-beta'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/BitCannaGlobal/bcna/releases/download/v2.0.0-beta/bcna_linux_amd64.tar.gz'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/BitCannaGlobal/testnet-bcna-cosmos/main/instructions/bitcanna-dev-6/genesis.json'
        }
    },
    apis: {
        rpc: [
            {
                address: 'https://rpc-devnet-6.bitcanna.io/',
                provider: 'bitcanna'
            }
        ],
        grpc: [
            {
                address: 'http://devnet-6.bitcanna.io:9090',
                provider: 'bitcanna'
            }
        ],
        rest: [
            {
                address: 'https://lcd-devnet-6.bitcanna.io/',
                provider: 'bitcanna'
            }
        ]
    },
    explorers: [
        {
            url: 'https://explorer-devnet-6.bitcanna.io',
            txPage: 'https://explorer-devnet-6.bitcanna.io/tx/${txHash}'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'celestiatestnet2',
    assets: [
        {
            denomUnits: [
                {
                    denom: 'utia',
                    exponent: 0
                },
                {
                    denom: 'tia',
                    exponent: 6
                }
            ],
            base: 'utia',
            name: 'Celestia',
            display: 'tia',
            symbol: 'TIA',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/celestiatestnet2/images/celestia.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/celestiatestnet2/images/celestia.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/celestiatestnet2/images/celestia.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/celestiatestnet2/images/celestia.png'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'celestiatestnet2',
    chainType: 'cosmos',
    chainId: 'arabica-11',
    prettyName: 'Arabica Testnet',
    status: 'live',
    networkType: 'devnet',
    bech32Prefix: 'celestia',
    daemonName: 'celestia-appd',
    nodeHome: '$HOME/.celestia-app',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'utia',
                fixedMinGasPrice: 0,
                lowGasPrice: 0.01,
                averageGasPrice: 0.02,
                highGasPrice: 0.1
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/celestiaorg/celestia-app',
        recommendedVersion: 'v3.3.1-arabica',
        compatibleVersions: [
            'v3.0.0-arabica',
            'v3.0.1-arabica',
            'v3.0.2-arabica',
            'v3.1.0-arabica',
            'v3.2.0-arabica',
            'v3.3.0-arabica',
            'v3.3.1-arabica'
        ],
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/celestiaorg/networks/master/arabica-11/genesis.json'
        }
    },
    apis: {
        rpc: [
            {
                address: 'https://validator-1.celestia-arabica-11.com/',
                provider: 'Celestia Labs'
            }
        ],
        rest: [
            {
                address: 'https://api.celestia-arabica-11.com/',
                provider: 'Celestia Labs'
            }
        ]
    },
    explorers: [
        {
            kind: 'Celenium',
            url: 'https://arabica.celenium.io/',
            txPage: 'https://arabica.celenium.io/tx/${txHash}'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'impacthubdevnet',
    assets: [
        {
            description: 'The native token of IXO Chain',
            denomUnits: [
                {
                    denom: 'uixo',
                    exponent: 0
                },
                {
                    denom: 'ixo',
                    exponent: 6
                }
            ],
            base: 'uixo',
            name: 'IXO',
            display: 'ixo',
            symbol: 'IXO',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'impacthub',
                        baseDenom: 'uixo'
                    },
                    provider: 'impacthub'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/impacthubdevnet/images/ixo.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/impacthubdevnet/images/ixo.svg'
            },
            coingeckoId: 'ixo',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/impacthubdevnet/images/ixo.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/impacthubdevnet/images/ixo.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'impacthubdevnet',
    status: 'live',
    networkType: 'devnet',
    website: 'https://www.ixo.world/',
    prettyName: 'ixo',
    chainType: 'cosmos',
    chainId: 'devnet-1',
    bech32Prefix: 'ixo',
    daemonName: 'ixod',
    nodeHome: '$HOME/.ixod',
    keyAlgos: [
        'secp256k1',
        'ed25519'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'uixo',
                fixedMinGasPrice: 0.015,
                lowGasPrice: 0.015,
                averageGasPrice: 0.025,
                highGasPrice: 0.04
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'uixo'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/ixofoundation/ixo-blockchain',
        recommendedVersion: 'v0.20.0',
        compatibleVersions: [
            'v0.20.0'
        ]
    },
    apis: {
        rpc: [
            {
                address: 'https://devnet.ixo.earth/rpc/',
                provider: 'ixoworld'
            }
        ],
        rest: [
            {
                address: 'https://devnet.ixo.earth/rest/',
                provider: 'ixoworld'
            }
        ],
        grpc: []
    },
    explorers: [
        {
            kind: 'ixoworld',
            url: 'https://blockscan.devnet.ixo.earth/ixo',
            txPage: 'https://blockscan.devnet.ixo.earth/ixo/transactions/${txHash}',
            accountPage: 'https://blockscan.devnet.ixo.earth/ixo/accounts/${accountAddress}'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'kyvedevnet',
    assets: [
        {
            description: 'The native utility token of the Korellia devnet version of KYVE.',
            denomUnits: [
                {
                    denom: 'tkyve',
                    exponent: 0
                },
                {
                    denom: 'kyve',
                    exponent: 6
                }
            ],
            base: 'tkyve',
            name: 'KYVE',
            display: 'kyve',
            symbol: 'KYVE',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'kyve',
                        baseDenom: 'ukyve'
                    },
                    provider: 'Kyve'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.svg',
                    imageSync: {
                        chainName: 'kyve',
                        baseDenom: 'ukyve'
                    },
                    theme: {
                        primaryColorHex: '#335350'
                    }
                }
            ],
            typeAsset: 'sdk.coin',
            coingeckoId: 'kyve-network'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'kyvedevnet',
    chainType: 'cosmos',
    chainId: 'korellia-2',
    prettyName: 'KYVE Korellia',
    status: 'live',
    networkType: 'devnet',
    bech32Prefix: 'kyve',
    daemonName: 'kyved',
    nodeHome: '$HOME/.kyve',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'tkyve',
                fixedMinGasPrice: 0
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/KYVENetwork/chain',
        recommendedVersion: 'v1.5.0',
        compatibleVersions: [
            'v1.5.0'
        ],
        binaries: {
            "darwin/amd64": 'https://files.kyve.network/korellia-2/v1.5.0-rc0/kyved_kaon_darwin_amd64?checksum=sha256:5f0c2e02eced4af81d15fbb46ba1f5bca45b662096b8bee3e90a20ef3cb1f54c',
            "darwin/arm64": 'https://files.kyve.network/korellia-2/v1.5.0-rc0/kyved_kaon_darwin_arm64?checksum=sha256:9c3667945a3f559d6a48f03fb61ea4045f410f1207bb9c1705a1043253877bf3',
            "linux/amd64": 'https://files.kyve.network/korellia-2/v1.5.0-rc0/kyved_kaon_linux_amd64?checksum=sha256:f165f4ca6c3831ac0d789fa5b5d6a98c0a9084b767bd048d12cca3691a861e23',
            "linux/arm64": 'https://files.kyve.network/korellia-2/v1.5.0-rc0/kyved_kaon_linux_arm64?checksum=sha256:fbd042016cd6973b301184af39df3020c69b0b35ce08d4286e974bb008ebbff0'
        },
        genesis: {
            genesisUrl: 'https://files.kyve.network/korellia-2/genesis.json'
        }
    },
    apis: {
        rpc: [
            {
                address: 'https://rpc.korellia.kyve.network',
                provider: 'kyve'
            }
        ],
        rest: [
            {
                address: 'https://api.korellia.kyve.network',
                provider: 'kyve'
            }
        ]
    },
    explorers: [
        {
            kind: 'KYVE Explorer',
            url: 'https://explorer.kyve.network/korellia',
            txPage: 'https://explorer.kyve.network/korellia/tx/${txHash}',
            accountPage: 'https://explorer.kyve.network/korellia/account/${accountAddress}'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'manifestdevnet',
    assets: [
        {
            description: 'Manifest devnet native token',
            extendedDescription: 'MFX is the foundational utility token powering the Manifest Network ecosystem - a decentralized platform bridging Web2 reliability with Web3 freedom. As the primary medium of exchange, MFX facilitates transactions across Manifest\'s privacy-first AI infrastructure, providing access to decentralized compute resources, industry-leading GPUs, blockchain-secured storage, and comprehensive deployment tools.  MFX represents more than just currency; it embodies Manifest\'s mission to democratize access to sovereign technologies and ethical AI applications, empowering developers to build scalable solutions that prioritize individual autonomy and data privacy without sacrificing performance or reliability. By holding MFX, users gain privileged access to a global network spanning multiple continents, designed for visionaries building the next generation of self-sovereign, ethical technology.',
            denomUnits: [
                {
                    denom: 'umfx',
                    exponent: 0
                },
                {
                    denom: 'mfx',
                    exponent: 6
                }
            ],
            base: 'umfx',
            name: 'Manifest Devnet Token',
            display: 'mfx',
            symbol: 'MFX',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            typeAsset: 'sdk.coin',
            socials: {
                website: 'https://manifestai.org/',
                twitter: 'https://x.com/ManifestAIs/'
            }
        },
        {
            description: 'Proof of Authority token for the Manifest devnet',
            denomUnits: [
                {
                    denom: 'upoa',
                    exponent: 0
                },
                {
                    denom: 'poa',
                    exponent: 6
                }
            ],
            base: 'upoa',
            name: 'Manifest Devnet Authority Token',
            display: 'poa',
            symbol: 'POA',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'manifestdevnet',
    status: 'live',
    networkType: 'devnet',
    website: 'https://manifestai.org/',
    prettyName: 'Manifest Devnet',
    chainId: 'manifest-ledger-qa',
    chainType: 'cosmos',
    bech32Prefix: 'manifest',
    daemonName: 'manifest',
    nodeHome: '$HOME/.manifest',
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'umfx',
                fixedMinGasPrice: 1,
                lowGasPrice: 1.05,
                averageGasPrice: 1.1,
                highGasPrice: 3
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'upoa'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/liftedinit/manifest-ledger',
        recommendedVersion: 'v1.0.3',
        compatibleVersions: [
            'v1.0.3'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/liftedinit/manifest-ledger/releases/download/v1.0.3/manifest-ledger-v1.0.3-linux-amd64.tar.gz'
        },
        genesis: {
            genesisUrl: 'https://nodes.liftedinit.tech/manifest/qa/rpc/genesis?'
        }
    },
    apis: {
        rpc: [
            {
                address: 'https://nodes.liftedinit.tech/manifest/qa/rpc',
                provider: 'The Lifted Initiative'
            }
        ],
        rest: [
            {
                address: 'https://nodes.liftedinit.tech/manifest/qa/api',
                provider: 'The Lifted Initiative'
            }
        ],
        grpc: [
            {
                address: 'https://manifest-qa-grpc.liftedinit.tech',
                provider: 'The Lifted Initiative'
            }
        ]
    },
    explorers: [
        {
            kind: 'Default Explorer',
            url: 'https://testnet.manifest.explorers.guru/',
            txPage: 'https://testnet.manifest.explorers.guru/transactions'
        }
    ],
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
    },
    images: [
        {
            imageSync: {
                chainName: 'manifestdevnet'
            },
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg',
            theme: {
                primaryColorHex: '#A087FF'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'neuradevnet',
    assets: [
        {
            description: 'ANKR: The native EVM, governance, and staking token for Neura, enabling secure transactions, and seamless GPU resourcing within the ecosystem.',
            denomUnits: [
                {
                    denom: 'atankr',
                    exponent: 0
                },
                {
                    denom: 'ankr',
                    exponent: 18
                }
            ],
            base: 'atankr',
            name: 'Neura Devnet',
            display: 'ankr',
            symbol: 'ANKR',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'neura',
                        baseDenom: 'atankr'
                    },
                    provider: 'Neura'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'neura',
                        baseDenom: 'atankr'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/ankr.svg'
                }
            ],
            typeAsset: 'sdk.coin',
            coingeckoId: 'ankr'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'neuradevnet',
    chainType: 'cosmos',
    chainId: 'neura_268-1',
    bech32Prefix: 'neura',
    prettyName: 'Neura Devnet',
    website: 'https://www.neuraprotocol.io/',
    description: 'Neura is an AI-centric, EVM-compatible Layer 1 blockchain built on the Cosmos SDK. We democratize GPU access and revolutionize AI project funding with IMO’s to advance AI development.',
    status: 'live',
    networkType: 'devnet',
    nodeHome: '$HOME/.neurad',
    daemonName: 'neurad',
    keyAlgos: [
        'ethsecp256k1'
    ],
    extraCodecs: [
        'ethermint'
    ],
    slip44: 1,
    fees: {
        feeTokens: [
            {
                denom: 'atankr'
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'atankr'
            }
        ]
    },
    codebase: {},
    images: [
        {
            imageSync: {
                chainName: 'neura'
            },
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neura/images/neura.png',
            theme: {
                primaryColorHex: '#4e5afc'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'nibirudevnet',
    assets: [
        {
            description: 'The native token of Nibiru network',
            extendedDescription: 'Nibiru hosts a variety of ecosystem partners in a wide variety of consumer sectors. From RWAs (Coded Estate) to DeFi (Constella, NOM) to Gaming (Blockchain Game Alliance, IntoTheVerse), Nibiru is advancing multiple emerging blockchain narratives that will onboard the next billion users.',
            socials: {
                website: 'https://nibiru.fi',
                twitter: 'https://twitter.com/nibiruchain'
            },
            denomUnits: [
                {
                    denom: 'unibi',
                    exponent: 0
                },
                {
                    denom: 'nibi',
                    exponent: 6
                },
                {
                    denom: 'attonibi',
                    exponent: 18
                }
            ],
            base: 'unibi',
            name: 'Nibiru',
            display: 'nibi',
            symbol: 'NIBI',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg',
                    theme: {
                        primaryColorHex: '#14c0ce'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'nibirudevnet',
    status: 'live',
    networkType: 'devnet',
    website: 'https://nibiru.fi/',
    prettyName: 'Nibiru Devnet 1',
    chainType: 'cosmos',
    chainId: 'nibiru-devnet-1',
    bech32Prefix: 'nibi',
    daemonName: 'nibid',
    nodeHome: '$HOME/.nibid',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'unibi',
                fixedMinGasPrice: 0.025,
                lowGasPrice: 0.025,
                averageGasPrice: 0.05,
                highGasPrice: 0.1
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'unibi'
            }
        ],
        lockDuration: {
            time: '1814400s'
        }
    },
    codebase: {
        gitRepo: 'https://github.com/NibiruChain/nibiru',
        recommendedVersion: 'v1.0.1',
        compatibleVersions: [
            'v1.0.1'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_amd64.tar.gz',
            "linux/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_arm64.tar.gz',
            "darwin/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_amd64.tar.gz',
            "darwin/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_arm64.tar.gz'
        },
        consensus: {
            type: 'cometbft',
            version: 'v0.37.4'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/NibiruChain/Networks/main/Testnet/nibiru-devnet-1/genesis.json'
        },
        sdk: {
            type: 'cosmos',
            version: 'v0.47.7'
        },
        ibc: {
            type: 'go',
            version: 'v7.3.1'
        },
        cosmwasm: {
            version: 'v0.44.0',
            enabled: true
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
    },
    description: 'A Web3 hub ushering in the next era of money',
    apis: {
        wss: [
            {
                address: 'wss://rpc.devnet-1.nibiru.fi/websocket',
                provider: 'Nibiru Foundation'
            }
        ],
        rpc: [
            {
                address: 'https://rpc.devnet-1.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        rest: [
            {
                address: 'https://lcd.devnet-1.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        grpc: [
            {
                address: 'grpc.devnet-1.nibiru.fi:443',
                provider: 'Nibiru Foundation'
            }
        ]
    },
    explorers: [
        {
            kind: 'Nibiru Foundation',
            url: 'https://explorer.nibiru.fi/nibiru-devnet-1',
            txPage: 'https://explorer.nibiru.fi/nibiru-devnet-1/tx/${txHash}',
            accountPage: 'https://explorer.nibiru.fi/nibiru-devnet-1/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'nibirudevnet2',
    assets: [
        {
            description: 'The native token of Nibiru network',
            extendedDescription: 'Nibiru hosts a variety of ecosystem partners in a wide variety of consumer sectors. From RWAs (Coded Estate) to DeFi (Constella, NOM) to Gaming (Blockchain Game Alliance, IntoTheVerse), Nibiru is advancing multiple emerging blockchain narratives that will onboard the next billion users.',
            socials: {
                website: 'https://nibiru.fi',
                twitter: 'https://twitter.com/nibiruchain'
            },
            denomUnits: [
                {
                    denom: 'unibi',
                    exponent: 0
                },
                {
                    denom: 'nibi',
                    exponent: 6
                },
                {
                    denom: 'attonibi',
                    exponent: 18
                }
            ],
            base: 'unibi',
            name: 'Nibiru',
            display: 'nibi',
            symbol: 'NIBI',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg',
                    theme: {
                        primaryColorHex: '#14c0ce'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'nibirudevnet2',
    status: 'live',
    networkType: 'devnet',
    website: 'https://nibiru.fi/',
    prettyName: 'Nibiru Devnet 2',
    chainType: 'cosmos',
    chainId: 'nibiru-devnet-2',
    bech32Prefix: 'nibi',
    daemonName: 'nibid',
    nodeHome: '$HOME/.nibid',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'unibi',
                fixedMinGasPrice: 0.025,
                lowGasPrice: 0.025,
                averageGasPrice: 0.05,
                highGasPrice: 0.1
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'unibi'
            }
        ],
        lockDuration: {
            time: '1814400s'
        }
    },
    codebase: {
        gitRepo: 'https://github.com/NibiruChain/nibiru',
        recommendedVersion: 'v1.0.1',
        compatibleVersions: [
            'v1.0.1'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_amd64.tar.gz',
            "linux/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_arm64.tar.gz',
            "darwin/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_amd64.tar.gz',
            "darwin/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_arm64.tar.gz'
        },
        consensus: {
            type: 'cometbft',
            version: 'v0.37.4'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/NibiruChain/Networks/main/Testnet/nibiru-devnet-2/genesis.json'
        },
        sdk: {
            type: 'cosmos',
            version: 'v0.47.7'
        },
        ibc: {
            type: 'go',
            version: 'v7.3.1'
        },
        cosmwasm: {
            version: 'v0.44.0',
            enabled: true
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
    },
    description: 'A Web3 hub ushering in the next era of money',
    apis: {
        wss: [
            {
                address: 'wss://rpc.devnet-2.nibiru.fi/websocket',
                provider: 'Nibiru Foundation'
            }
        ],
        rpc: [
            {
                address: 'https://rpc.devnet-2.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        rest: [
            {
                address: 'https://lcd.devnet-2.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        grpc: [
            {
                address: 'grpc.devnet-2.nibiru.fi:443',
                provider: 'Nibiru Foundation'
            }
        ]
    },
    explorers: [
        {
            kind: 'Nibiru Foundation',
            url: 'https://explorer.nibiru.fi/nibiru-devnet-2',
            txPage: 'https://explorer.nibiru.fi/nibiru-devnet-2/tx/${txHash}',
            accountPage: 'https://explorer.nibiru.fi/nibiru-devnet-2/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'nibirudevnet3',
    assets: [
        {
            description: 'The native token of Nibiru network',
            extendedDescription: 'Nibiru hosts a variety of ecosystem partners in a wide variety of consumer sectors. From RWAs (Coded Estate) to DeFi (Constella, NOM) to Gaming (Blockchain Game Alliance, IntoTheVerse), Nibiru is advancing multiple emerging blockchain narratives that will onboard the next billion users.',
            socials: {
                website: 'https://nibiru.fi',
                twitter: 'https://twitter.com/nibiruchain'
            },
            denomUnits: [
                {
                    denom: 'unibi',
                    exponent: 0
                },
                {
                    denom: 'nibi',
                    exponent: 6
                },
                {
                    denom: 'attonibi',
                    exponent: 18
                }
            ],
            base: 'unibi',
            name: 'Nibiru',
            display: 'nibi',
            symbol: 'NIBI',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg',
                    theme: {
                        primaryColorHex: '#14c0ce'
                    }
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'nibirudevnet3',
    status: 'live',
    networkType: 'devnet',
    website: 'https://nibiru.fi/',
    prettyName: 'Nibiru Devnet 3',
    chainType: 'cosmos',
    chainId: 'nibiru-devnet-3',
    bech32Prefix: 'nibi',
    daemonName: 'nibid',
    nodeHome: '$HOME/.nibid',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'unibi',
                fixedMinGasPrice: 0.025,
                lowGasPrice: 0.025,
                averageGasPrice: 0.05,
                highGasPrice: 0.1
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'unibi'
            }
        ],
        lockDuration: {
            time: '1814400s'
        }
    },
    codebase: {
        gitRepo: 'https://github.com/NibiruChain/nibiru',
        recommendedVersion: 'v1.0.1',
        compatibleVersions: [
            'v1.0.1'
        ],
        binaries: {
            "linux/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_amd64.tar.gz',
            "linux/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_linux_arm64.tar.gz',
            "darwin/amd64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_amd64.tar.gz',
            "darwin/arm64": 'https://github.com/NibiruChain/nibiru/releases/download/v1.0.1/nibid_1.0.1_darwin_arm64.tar.gz'
        },
        consensus: {
            type: 'cometbft',
            version: 'v0.37.4'
        },
        sdk: {
            type: 'cosmos',
            version: 'v0.47.7'
        },
        cosmwasm: {
            version: 'v0.44.0',
            path: '$HOME/.nibid/data/wasm',
            enabled: true
        },
        ibc: {
            type: 'go',
            version: 'v7.3.1'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/NibiruChain/Networks/main/Testnet/nibiru-devnet-2/genesis.json'
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
    },
    description: 'A Web3 hub ushering in the next era of money',
    apis: {
        wss: [
            {
                address: 'wss://rpc.devnet-3.nibiru.fi/websocket',
                provider: 'Nibiru Foundation'
            }
        ],
        rpc: [
            {
                address: 'https://rpc.devnet-3.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        rest: [
            {
                address: 'https://lcd.devnet-3.nibiru.fi',
                provider: 'Nibiru Foundation'
            }
        ],
        grpc: [
            {
                address: 'grpc.devnet-3.nibiru.fi:443',
                provider: 'Nibiru Foundation'
            }
        ]
    },
    explorers: [
        {
            kind: 'Nibiru Foundation',
            url: 'https://explorer.nibiru.fi/nibiru-devnet-2',
            txPage: 'https://explorer.nibiru.fi/nibiru-devnet-2/tx/${txHash}',
            accountPage: 'https://explorer.nibiru.fi/nibiru-devnet-2/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/nibiru/images/nibiru.svg'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'prysmdevnet',
    assets: [
        {
            description: 'The native token of Prysm',
            denomUnits: [
                {
                    denom: 'uprysm',
                    exponent: 0
                },
                {
                    denom: 'prysm',
                    exponent: 6
                }
            ],
            base: 'uprysm',
            display: 'prysm',
            name: 'Prysm',
            symbol: 'PRYSM',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#cf654f'
                    }
                }
            ],
            socials: {
                website: 'https://www.prysm.network/',
                twitter: 'https://twitter.com/PrysmNetwork'
            },
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'prysmdevnet',
    status: 'live',
    networkType: 'devnet',
    website: 'https://www.prysm.network/',
    prettyName: 'Prysm Devnet',
    chainType: 'cosmos',
    chainId: 'prysm-devnet-1',
    bech32Prefix: 'prysm',
    daemonName: 'prysm',
    nodeHome: '$HOME/.prysm',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'uprysm',
                fixedMinGasPrice: 0,
                lowGasPrice: 0,
                averageGasPrice: 0,
                highGasPrice: 0
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'uprysm'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/kleomedes/prysm',
        recommendedVersion: 'v0.1.0-devnet',
        compatibleVersions: [
            'v0.1.0-devnet'
        ],
        consensus: {
            type: 'cometbft',
            version: 'v0.38.10'
        },
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/kleomedes/prysm/refs/heads/main/network/prysm-devnet-1/genesis.json'
        },
        sdk: {
            type: 'cosmos',
            version: 'v0.50.8'
        },
        ibc: {
            type: 'go',
            version: 'v8.4.0'
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.svg'
    },
    description: 'Network layer blockchain providing foundational infrastructure, enhanced connectivity, and scalability.',
    apis: {
        wss: [
            {
                address: 'wss://prysm-testnet-rpc.cogwheel.zone/websocket',
                provider: 'Cogwheel ⚙️'
            },
            {
                address: 'wss://prysm-testnet-rpc.mictonode.com/websocket',
                provider: 'MictoNode'
            },
            {
                address: 'wss://prysm-testnet-rpc.itrocket.net/websocket',
                provider: 'ITRocket'
            },
            {
                address: 'wss://prysm-testnet-rpc.ibs.team/websocket',
                provider: 'Inter Blockchain Services'
            }
        ],
        rpc: [
            {
                address: 'https://prysm-rpc-devnet.kleomedes.network/',
                provider: 'Kleomedes'
            },
            {
                address: 'https://prysm-testnet-rpc.polkachu.com/',
                provider: 'Polkachu'
            },
            {
                address: 'https://prysm-testnet-rpc.synergynodes.com/',
                provider: 'Synergy Nodes'
            },
            {
                address: 'https://prysm-rpc.validatorvn.com/',
                provider: 'ValidatorVN'
            },
            {
                address: 'https://prysm-testnet-rpc.validator247.com/',
                provider: 'Validator247'
            },
            {
                address: 'https://rpc-prysm.vinjan.xyz/',
                provider: 'Vinjan.Inc'
            },
            {
                address: 'https://prysm-testnet-rpc.cogwheel.zone',
                provider: 'Cogwheel ⚙️'
            },
            {
                address: 'https://prysm-testnet-rpc.mictonode.com/',
                provider: 'MictoNode'
            },
            {
                address: 'https://rpc-prysm.josephtran.xyz/',
                provider: 'JosephTran'
            },
            {
                address: 'https://prysm-testnet-rpc.itrocket.net',
                provider: 'ITRocket'
            },
            {
                address: 'https://rpc-prysm-t.sychonix.com',
                provider: 'Sychonix'
            },
            {
                address: 'https://rpc-prysm.coha05.com/',
                provider: 'Coha05 | Spider Node'
            },
            {
                address: 'https://prysm-testnet-rpc.ibs.team',
                provider: 'Inter Blockchain Services'
            }
        ],
        rest: [
            {
                address: 'https://prysm-api-devnet.kleomedes.network/',
                provider: 'Kleomedes'
            },
            {
                address: 'https://prysm-testnet-api.polkachu.com/',
                provider: 'Polkachu'
            },
            {
                address: 'https://prysm-testnet-api.synergynodes.com/',
                provider: 'Synergy Nodes'
            },
            {
                address: 'https://prysm-api.validatorvn.com/',
                provider: 'ValidatorVN'
            },
            {
                address: 'https://api-prysm.vinjan.xyz/',
                provider: 'Vinjan.Inc'
            },
            {
                address: 'https://prysm-testnet-api.validator247.com/',
                provider: 'Validator247'
            },
            {
                address: 'https://prysm-testnet-api.cogwheel.zone',
                provider: 'Cogwheel ⚙️'
            },
            {
                address: 'https://prysm-testnet-api.mictonode.com/',
                provider: 'MictoNode'
            },
            {
                address: 'https://api-prysm.josephtran.xyz/',
                provider: 'JosephTran'
            },
            {
                address: 'https://prysm-testnet-api.itrocket.net',
                provider: 'ITRocket'
            },
            {
                address: 'https://api-prysm-t.sychonix.com',
                provider: 'Sychonix'
            },
            {
                address: 'https://api-prysm.coha05.com',
                provider: 'Coha05 | Spider Node'
            },
            {
                address: 'https://prysm-testnet-api.ibs.team',
                provider: 'Inter Blockchain Services'
            }
        ],
        grpc: [
            {
                address: 'prysm-testnet-grpc.polkachu.com:29890',
                provider: 'Polkachu'
            },
            {
                address: 'http://144.76.70.103:32090/',
                provider: 'Validator247'
            },
            {
                address: 'https://prysm-testnet-grpc.synergynodes.com/',
                provider: 'Synergy Nodes'
            },
            {
                address: 'prysm-grpc.validatorvn.com:44090',
                provider: 'ValidatorVN'
            },
            {
                address: 'prysm-testnet-grpc.cogwheel.zone:443',
                provider: 'Cogwheel ⚙️'
            },
            {
                address: 'prysm-testnet-grpc.mictonode.com:33090',
                provider: 'MictoNode'
            },
            {
                address: 'https://grpc-prysm.josephtran.xyz/',
                provider: 'JosephTran'
            },
            {
                address: 'prysm-testnet-grpc.itrocket.net:443',
                provider: 'ITRocket'
            }
        ]
    },
    explorers: [
        {
            kind: 'PingPub',
            url: 'https://explorer.kleomedes.network/prysm',
            txPage: 'https://explorer.kleomedes.network/prysm/tx/${txHash}',
            accountPage: 'https://explorer.kleomedes.network/prysm/account/${accountAddress}'
        },
        {
            kind: 'PingPub',
            url: 'https://explorer.cogwheel.zone/prysm',
            txPage: 'https://explorer.cogwheel.zone/prysm/tx/${txHash}',
            accountPage: 'https://explorer.cogwheel.zone/prysm/account/${accountAddress}'
        },
        {
            kind: 'PingPub',
            url: 'https://explorer.mictonode.com/Prysm-Testnet',
            txPage: 'https://explorer.mictonode.com/Prysm-Testnet/tx/${txHash}',
            accountPage: 'https://explorer.mictonode.com/Prysm-Testnet/account/${accountAddress}'
        },
        {
            kind: 'ITRocket',
            url: 'https://testnet.itrocket.net/prysm',
            txPage: 'https://testnet.itrocket.net/prysm/tx/${txHash}',
            accountPage: 'https://testnet.itrocket.net/prysm/account/${accountAddress}'
        },
        {
            kind: 'PingPub',
            url: 'https://explorer.sychonix.com/prysm-testnet',
            txPage: 'https://explorer.sychonix.com/prysm-testnet/tx/${txHash}',
            accountPage: 'https://explorer.sychonix.com/prysm-testnet/account/${accountAddress}'
        },
        {
            kind: 'PingPub',
            url: 'https://explorer.tech-coha05.xyz/Prysm',
            txPage: 'https://explorer.tech-coha05.xyz/Prysm/tx/${txHash}',
            accountPage: 'https://explorer.tech-coha05.xyz/Prysm/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/prysmdevnet/images/prysm.svg',
            theme: {
                primaryColorHex: '#cf654f'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'axelartestnet',
            clientId: '07-tendermint-1045',
            connectionId: 'connection-806'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-4',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-564',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'celestiatestnet3',
            clientId: '07-tendermint-615',
            connectionId: 'connection-551'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-14',
            connectionId: 'connection-8'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-138',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'composabletestnet',
            clientId: '07-tendermint-218',
            connectionId: 'connection-127'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-6',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-50',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshubtestnet',
            clientId: '07-tendermint-3805',
            connectionId: 'connection-3845'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-18',
            connectionId: 'connection-11'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4366',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-7',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'elystestnet',
            clientId: '07-tendermint-118',
            connectionId: 'connection-80'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-21',
            connectionId: 'connection-14'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-52',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-9',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'jackaltestnet2',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-17',
            connectionId: 'connection-10'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'nobletestnet',
            clientId: '07-tendermint-319',
            connectionId: 'connection-269'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-222',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet4',
            clientId: '07-tendermint-4060',
            connectionId: 'connection-3506'
        },
        chain2: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-3',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9018',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-16',
            connectionId: 'connection-9'
        },
        chain2: {
            chainName: 'quicksilvertestnet2',
            clientId: '07-tendermint-4',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'killed'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'prysmdevnet',
            clientId: '07-tendermint-29',
            connectionId: 'connection-18'
        },
        chain2: {
            chainName: 'stargazetestnet',
            clientId: '07-tendermint-961',
            connectionId: 'connection-954'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-11',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1005',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/chain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/ibc-data.js [app-client] (ecmascript)");
;
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'seidevnet3',
    assets: [
        {
            description: 'The native staking and governance token of the Atlantic testnet version of Sei.',
            denomUnits: [
                {
                    denom: 'usei',
                    exponent: 0
                },
                {
                    denom: 'sei',
                    exponent: 6
                }
            ],
            base: 'usei',
            name: 'Sei',
            display: 'sei',
            symbol: 'SEI',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/seidevnet3/images/sei.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/seidevnet3/images/sei.png'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'seidevnet3',
    chainType: 'cosmos',
    chainId: 'sei-devnet-3',
    prettyName: 'Sei Devnet 3',
    status: 'live',
    networkType: 'devnet',
    bech32Prefix: 'sei',
    daemonName: 'seid',
    nodeHome: '$HOME/.sei',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'usei',
                fixedMinGasPrice: 0
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/sei-protocol/sei-chain',
        recommendedVersion: '2.0.40beta',
        compatibleVersions: [
            '2.0.27beta',
            '2.0.29eta',
            '2.0.31beta',
            '2.0.32beta',
            '2.0.36beta',
            '2.0.37beta',
            '2.0.39beta',
            '2.0.40beta'
        ],
        genesis: {
            genesisUrl: 'https://raw.githubusercontent.com/sei-protocol/testnet/main/sei-devnet-3/genesis.json'
        }
    },
    apis: {
        rpc: [
            {
                address: 'https://rpc.sei-devnet-3.seinetwork.io',
                provider: 'Sei Foundation'
            }
        ],
        rest: [
            {
                address: 'https://rest.sei-devnet-3.seinetwork.io',
                provider: 'Sei Foundation'
            }
        ],
        grpc: [
            {
                address: 'https://grpc.sei-devnet-3.seinetwork.io',
                provider: 'Sei Foundation'
            }
        ]
    },
    explorers: [
        {
            kind: 'explorers.guru',
            url: 'https://devnet.sei.explorers.guru',
            txPage: 'https://devnet.sei.explorers.guru/transaction/${txHash}'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/chain.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const assetList = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"]
];
const __TURBOPACK__default__export__ = assetList;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/bitcannadevnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/celestiatestnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/impacthubdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/kyvedevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/manifestdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/neuradevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet2/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/nibirudevnet3/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/seidevnet3/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const chains = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$bitcannadevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$celestiatestnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$impacthubdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$kyvedevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$manifestdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$neuradevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet2$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$nibirudevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$seidevnet3$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"]
];
const __TURBOPACK__default__export__ = chains;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/prysmdevnet/index.js [app-client] (ecmascript)");
;
const ibcData = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$prysmdevnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ibcData"]
];
const __TURBOPACK__default__export__ = ibcData;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript)");
;
;
;
const __TURBOPACK__default__export__ = {
    assetLists: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    chains: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    ibcData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
;
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript) <export default as assetLists>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetLists": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript)");
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript) <export default as chains>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "chains": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript)");
}}),
"[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript) <export default as ibcData>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ibcData": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript)");
}}),
"[project]/node_modules/@chain-registry/v2/esm/asset-lists.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/asset-lists.js [app-client] (ecmascript) <export default as assetLists>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/asset-lists.js [app-client] (ecmascript) <export default as assetLists>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/asset-lists.js [app-client] (ecmascript) <export default as assetLists>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript) <export default as assetLists>");
;
;
;
;
const assetLists = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__["assetLists"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__["assetLists"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__["assetLists"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__assetLists$3e$__["assetLists"]
];
const __TURBOPACK__default__export__ = assetLists;
}}),
"[project]/node_modules/@chain-registry/v2/esm/chains.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/chains.js [app-client] (ecmascript) <export default as chains>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/chains.js [app-client] (ecmascript) <export default as chains>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/chains.js [app-client] (ecmascript) <export default as chains>");
;
;
;
const chains = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__["chains"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__["chains"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__chains$3e$__["chains"]
];
const __TURBOPACK__default__export__ = chains;
}}),
"[project]/node_modules/@chain-registry/v2/esm/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/mainnet/ibc-data.js [app-client] (ecmascript) <export default as ibcData>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/ibc-data.js [app-client] (ecmascript) <export default as ibcData>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/devnet/ibc-data.js [app-client] (ecmascript) <export default as ibcData>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript) <export default as ibcData>");
;
;
;
;
const ibcData = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$mainnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$devnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ibcData$3e$__["ibcData"]
];
const __TURBOPACK__default__export__ = ibcData;
}}),
"[project]/node_modules/@chain-registry/v2/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/chains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/ibc-data.js [app-client] (ecmascript)");
;
;
;
const __TURBOPACK__default__export__ = {
    assetLists: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    chains: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    ibcData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
;
}}),
"[project]/node_modules/@chain-registry/v2/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/chains.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/ibc-data.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/@chain-registry/v2/esm/chains.js [app-client] (ecmascript) <export default as chains>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "chains": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$chains$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/chains.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=node_modules_%40chain-registry_v2_esm_2a4cd7d5._.js.map