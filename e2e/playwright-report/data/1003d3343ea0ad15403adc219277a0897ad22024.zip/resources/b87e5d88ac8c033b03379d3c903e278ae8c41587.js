(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/solomachine/v2/solomachine.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ChannelStateData": (()=>ChannelStateData),
    "ClientState": (()=>ClientState),
    "ClientStateData": (()=>ClientStateData),
    "ConnectionStateData": (()=>ConnectionStateData),
    "ConsensusState": (()=>ConsensusState),
    "ConsensusStateData": (()=>ConsensusStateData),
    "DataType": (()=>DataType),
    "DataTypeAmino": (()=>DataTypeAmino),
    "Header": (()=>Header),
    "HeaderData": (()=>HeaderData),
    "Misbehaviour": (()=>Misbehaviour),
    "NextSequenceRecvData": (()=>NextSequenceRecvData),
    "PacketAcknowledgementData": (()=>PacketAcknowledgementData),
    "PacketCommitmentData": (()=>PacketCommitmentData),
    "PacketReceiptAbsenceData": (()=>PacketReceiptAbsenceData),
    "SignBytes": (()=>SignBytes),
    "SignatureAndData": (()=>SignatureAndData),
    "TimestampedSignatureData": (()=>TimestampedSignatureData),
    "dataTypeFromJSON": (()=>dataTypeFromJSON),
    "dataTypeToJSON": (()=>dataTypeToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/connection/v1/connection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/channel/v1/channel.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
;
;
var DataType;
(function(DataType) {
    /** DATA_TYPE_UNINITIALIZED_UNSPECIFIED - Default State */ DataType[DataType["DATA_TYPE_UNINITIALIZED_UNSPECIFIED"] = 0] = "DATA_TYPE_UNINITIALIZED_UNSPECIFIED";
    /** DATA_TYPE_CLIENT_STATE - Data type for client state verification */ DataType[DataType["DATA_TYPE_CLIENT_STATE"] = 1] = "DATA_TYPE_CLIENT_STATE";
    /** DATA_TYPE_CONSENSUS_STATE - Data type for consensus state verification */ DataType[DataType["DATA_TYPE_CONSENSUS_STATE"] = 2] = "DATA_TYPE_CONSENSUS_STATE";
    /** DATA_TYPE_CONNECTION_STATE - Data type for connection state verification */ DataType[DataType["DATA_TYPE_CONNECTION_STATE"] = 3] = "DATA_TYPE_CONNECTION_STATE";
    /** DATA_TYPE_CHANNEL_STATE - Data type for channel state verification */ DataType[DataType["DATA_TYPE_CHANNEL_STATE"] = 4] = "DATA_TYPE_CHANNEL_STATE";
    /** DATA_TYPE_PACKET_COMMITMENT - Data type for packet commitment verification */ DataType[DataType["DATA_TYPE_PACKET_COMMITMENT"] = 5] = "DATA_TYPE_PACKET_COMMITMENT";
    /** DATA_TYPE_PACKET_ACKNOWLEDGEMENT - Data type for packet acknowledgement verification */ DataType[DataType["DATA_TYPE_PACKET_ACKNOWLEDGEMENT"] = 6] = "DATA_TYPE_PACKET_ACKNOWLEDGEMENT";
    /** DATA_TYPE_PACKET_RECEIPT_ABSENCE - Data type for packet receipt absence verification */ DataType[DataType["DATA_TYPE_PACKET_RECEIPT_ABSENCE"] = 7] = "DATA_TYPE_PACKET_RECEIPT_ABSENCE";
    /** DATA_TYPE_NEXT_SEQUENCE_RECV - Data type for next sequence recv verification */ DataType[DataType["DATA_TYPE_NEXT_SEQUENCE_RECV"] = 8] = "DATA_TYPE_NEXT_SEQUENCE_RECV";
    /** DATA_TYPE_HEADER - Data type for header verification */ DataType[DataType["DATA_TYPE_HEADER"] = 9] = "DATA_TYPE_HEADER";
    DataType[DataType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(DataType || (DataType = {}));
const DataTypeAmino = DataType;
function dataTypeFromJSON(object) {
    switch(object){
        case 0:
        case "DATA_TYPE_UNINITIALIZED_UNSPECIFIED":
            return DataType.DATA_TYPE_UNINITIALIZED_UNSPECIFIED;
        case 1:
        case "DATA_TYPE_CLIENT_STATE":
            return DataType.DATA_TYPE_CLIENT_STATE;
        case 2:
        case "DATA_TYPE_CONSENSUS_STATE":
            return DataType.DATA_TYPE_CONSENSUS_STATE;
        case 3:
        case "DATA_TYPE_CONNECTION_STATE":
            return DataType.DATA_TYPE_CONNECTION_STATE;
        case 4:
        case "DATA_TYPE_CHANNEL_STATE":
            return DataType.DATA_TYPE_CHANNEL_STATE;
        case 5:
        case "DATA_TYPE_PACKET_COMMITMENT":
            return DataType.DATA_TYPE_PACKET_COMMITMENT;
        case 6:
        case "DATA_TYPE_PACKET_ACKNOWLEDGEMENT":
            return DataType.DATA_TYPE_PACKET_ACKNOWLEDGEMENT;
        case 7:
        case "DATA_TYPE_PACKET_RECEIPT_ABSENCE":
            return DataType.DATA_TYPE_PACKET_RECEIPT_ABSENCE;
        case 8:
        case "DATA_TYPE_NEXT_SEQUENCE_RECV":
            return DataType.DATA_TYPE_NEXT_SEQUENCE_RECV;
        case 9:
        case "DATA_TYPE_HEADER":
            return DataType.DATA_TYPE_HEADER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return DataType.UNRECOGNIZED;
    }
}
function dataTypeToJSON(object) {
    switch(object){
        case DataType.DATA_TYPE_UNINITIALIZED_UNSPECIFIED:
            return "DATA_TYPE_UNINITIALIZED_UNSPECIFIED";
        case DataType.DATA_TYPE_CLIENT_STATE:
            return "DATA_TYPE_CLIENT_STATE";
        case DataType.DATA_TYPE_CONSENSUS_STATE:
            return "DATA_TYPE_CONSENSUS_STATE";
        case DataType.DATA_TYPE_CONNECTION_STATE:
            return "DATA_TYPE_CONNECTION_STATE";
        case DataType.DATA_TYPE_CHANNEL_STATE:
            return "DATA_TYPE_CHANNEL_STATE";
        case DataType.DATA_TYPE_PACKET_COMMITMENT:
            return "DATA_TYPE_PACKET_COMMITMENT";
        case DataType.DATA_TYPE_PACKET_ACKNOWLEDGEMENT:
            return "DATA_TYPE_PACKET_ACKNOWLEDGEMENT";
        case DataType.DATA_TYPE_PACKET_RECEIPT_ABSENCE:
            return "DATA_TYPE_PACKET_RECEIPT_ABSENCE";
        case DataType.DATA_TYPE_NEXT_SEQUENCE_RECV:
            return "DATA_TYPE_NEXT_SEQUENCE_RECV";
        case DataType.DATA_TYPE_HEADER:
            return "DATA_TYPE_HEADER";
        case DataType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseClientState() {
    return {
        sequence: BigInt(0),
        isFrozen: false,
        consensusState: undefined,
        allowUpdateAfterProposal: false
    };
}
const ClientState = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ClientState",
    aminoType: "cosmos-sdk/ClientState",
    is (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.sequence === "bigint" && typeof o.isFrozen === "boolean" && typeof o.allowUpdateAfterProposal === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.sequence === "bigint" && typeof o.is_frozen === "boolean" && typeof o.allow_update_after_proposal === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.isFrozen === true) {
            writer.uint32(16).bool(message.isFrozen);
        }
        if (message.consensusState !== undefined) {
            ConsensusState.encode(message.consensusState, writer.uint32(26).fork()).ldelim();
        }
        if (message.allowUpdateAfterProposal === true) {
            writer.uint32(32).bool(message.allowUpdateAfterProposal);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.isFrozen = reader.bool();
                    break;
                case 3:
                    message.consensusState = ConsensusState.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.allowUpdateAfterProposal = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientState();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.isFrozen = object.isFrozen ?? false;
        message.consensusState = object.consensusState !== undefined && object.consensusState !== null ? ConsensusState.fromPartial(object.consensusState) : undefined;
        message.allowUpdateAfterProposal = object.allowUpdateAfterProposal ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientState();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.is_frozen !== undefined && object.is_frozen !== null) {
            message.isFrozen = object.is_frozen;
        }
        if (object.consensus_state !== undefined && object.consensus_state !== null) {
            message.consensusState = ConsensusState.fromAmino(object.consensus_state);
        }
        if (object.allow_update_after_proposal !== undefined && object.allow_update_after_proposal !== null) {
            message.allowUpdateAfterProposal = object.allow_update_after_proposal;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.is_frozen = message.isFrozen === false ? undefined : message.isFrozen;
        obj.consensus_state = message.consensusState ? ConsensusState.toAmino(message.consensusState) : undefined;
        obj.allow_update_after_proposal = message.allowUpdateAfterProposal === false ? undefined : message.allowUpdateAfterProposal;
        return obj;
    },
    fromAminoMsg (object) {
        return ClientState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientState",
            value: ClientState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientState.decode(message.value);
    },
    toProto (message) {
        return ClientState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ClientState",
            value: ClientState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ClientState.typeUrl)) {
            return;
        }
        ConsensusState.registerTypeUrl();
    }
};
function createBaseConsensusState() {
    return {
        publicKey: undefined,
        diversifier: "",
        timestamp: BigInt(0)
    };
}
const ConsensusState = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ConsensusState",
    aminoType: "cosmos-sdk/ConsensusState",
    is (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || typeof o.diversifier === "string" && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || typeof o.diversifier === "string" && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.publicKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.publicKey, writer.uint32(10).fork()).ldelim();
        }
        if (message.diversifier !== "") {
            writer.uint32(18).string(message.diversifier);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(24).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsensusState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.publicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.diversifier = reader.string();
                    break;
                case 3:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConsensusState();
        message.publicKey = object.publicKey !== undefined && object.publicKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.publicKey) : undefined;
        message.diversifier = object.diversifier ?? "";
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseConsensusState();
        if (object.public_key !== undefined && object.public_key !== null) {
            message.publicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.public_key);
        }
        if (object.diversifier !== undefined && object.diversifier !== null) {
            message.diversifier = object.diversifier;
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.public_key = message.publicKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.publicKey) : undefined;
        obj.diversifier = message.diversifier === "" ? undefined : message.diversifier;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConsensusState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConsensusState",
            value: ConsensusState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConsensusState.decode(message.value);
    },
    toProto (message) {
        return ConsensusState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ConsensusState",
            value: ConsensusState.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseHeader() {
    return {
        sequence: BigInt(0),
        timestamp: BigInt(0),
        signature: new Uint8Array(),
        newPublicKey: undefined,
        newDiversifier: ""
    };
}
const Header = {
    typeUrl: "/ibc.lightclients.solomachine.v2.Header",
    aminoType: "cosmos-sdk/Header",
    is (o) {
        return o && (o.$typeUrl === Header.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && (o.signature instanceof Uint8Array || typeof o.signature === "string") && typeof o.newDiversifier === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Header.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && (o.signature instanceof Uint8Array || typeof o.signature === "string") && typeof o.new_diversifier === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(16).uint64(message.timestamp);
        }
        if (message.signature.length !== 0) {
            writer.uint32(26).bytes(message.signature);
        }
        if (message.newPublicKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.newPublicKey, writer.uint32(34).fork()).ldelim();
        }
        if (message.newDiversifier !== "") {
            writer.uint32(42).string(message.newDiversifier);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHeader();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.timestamp = reader.uint64();
                    break;
                case 3:
                    message.signature = reader.bytes();
                    break;
                case 4:
                    message.newPublicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 5:
                    message.newDiversifier = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHeader();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        message.signature = object.signature ?? new Uint8Array();
        message.newPublicKey = object.newPublicKey !== undefined && object.newPublicKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.newPublicKey) : undefined;
        message.newDiversifier = object.newDiversifier ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseHeader();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        if (object.signature !== undefined && object.signature !== null) {
            message.signature = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature);
        }
        if (object.new_public_key !== undefined && object.new_public_key !== null) {
            message.newPublicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.new_public_key);
        }
        if (object.new_diversifier !== undefined && object.new_diversifier !== null) {
            message.newDiversifier = object.new_diversifier;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        obj.signature = message.signature ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signature) : undefined;
        obj.new_public_key = message.newPublicKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.newPublicKey) : undefined;
        obj.new_diversifier = message.newDiversifier === "" ? undefined : message.newDiversifier;
        return obj;
    },
    fromAminoMsg (object) {
        return Header.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Header",
            value: Header.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Header.decode(message.value);
    },
    toProto (message) {
        return Header.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.Header",
            value: Header.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMisbehaviour() {
    return {
        clientId: "",
        sequence: BigInt(0),
        signatureOne: undefined,
        signatureTwo: undefined
    };
}
const Misbehaviour = {
    typeUrl: "/ibc.lightclients.solomachine.v2.Misbehaviour",
    aminoType: "cosmos-sdk/Misbehaviour",
    is (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.clientId === "string" && typeof o.sequence === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.client_id === "string" && typeof o.sequence === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.clientId !== "") {
            writer.uint32(10).string(message.clientId);
        }
        if (message.sequence !== BigInt(0)) {
            writer.uint32(16).uint64(message.sequence);
        }
        if (message.signatureOne !== undefined) {
            SignatureAndData.encode(message.signatureOne, writer.uint32(26).fork()).ldelim();
        }
        if (message.signatureTwo !== undefined) {
            SignatureAndData.encode(message.signatureTwo, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMisbehaviour();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.clientId = reader.string();
                    break;
                case 2:
                    message.sequence = reader.uint64();
                    break;
                case 3:
                    message.signatureOne = SignatureAndData.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.signatureTwo = SignatureAndData.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMisbehaviour();
        message.clientId = object.clientId ?? "";
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.signatureOne = object.signatureOne !== undefined && object.signatureOne !== null ? SignatureAndData.fromPartial(object.signatureOne) : undefined;
        message.signatureTwo = object.signatureTwo !== undefined && object.signatureTwo !== null ? SignatureAndData.fromPartial(object.signatureTwo) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMisbehaviour();
        if (object.client_id !== undefined && object.client_id !== null) {
            message.clientId = object.client_id;
        }
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.signature_one !== undefined && object.signature_one !== null) {
            message.signatureOne = SignatureAndData.fromAmino(object.signature_one);
        }
        if (object.signature_two !== undefined && object.signature_two !== null) {
            message.signatureTwo = SignatureAndData.fromAmino(object.signature_two);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.client_id = message.clientId === "" ? undefined : message.clientId;
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.signature_one = message.signatureOne ? SignatureAndData.toAmino(message.signatureOne) : undefined;
        obj.signature_two = message.signatureTwo ? SignatureAndData.toAmino(message.signatureTwo) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Misbehaviour.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Misbehaviour",
            value: Misbehaviour.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Misbehaviour.decode(message.value);
    },
    toProto (message) {
        return Misbehaviour.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.Misbehaviour",
            value: Misbehaviour.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Misbehaviour.typeUrl)) {
            return;
        }
        SignatureAndData.registerTypeUrl();
    }
};
function createBaseSignatureAndData() {
    return {
        signature: new Uint8Array(),
        dataType: 0,
        data: new Uint8Array(),
        timestamp: BigInt(0)
    };
}
const SignatureAndData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.SignatureAndData",
    aminoType: "cosmos-sdk/SignatureAndData",
    is (o) {
        return o && (o.$typeUrl === SignatureAndData.typeUrl || (o.signature instanceof Uint8Array || typeof o.signature === "string") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.dataType) && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === SignatureAndData.typeUrl || (o.signature instanceof Uint8Array || typeof o.signature === "string") && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.data_type) && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signature.length !== 0) {
            writer.uint32(10).bytes(message.signature);
        }
        if (message.dataType !== 0) {
            writer.uint32(16).int32(message.dataType);
        }
        if (message.data.length !== 0) {
            writer.uint32(26).bytes(message.data);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(32).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSignatureAndData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signature = reader.bytes();
                    break;
                case 2:
                    message.dataType = reader.int32();
                    break;
                case 3:
                    message.data = reader.bytes();
                    break;
                case 4:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSignatureAndData();
        message.signature = object.signature ?? new Uint8Array();
        message.dataType = object.dataType ?? 0;
        message.data = object.data ?? new Uint8Array();
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseSignatureAndData();
        if (object.signature !== undefined && object.signature !== null) {
            message.signature = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature);
        }
        if (object.data_type !== undefined && object.data_type !== null) {
            message.dataType = object.data_type;
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signature = message.signature ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signature) : undefined;
        obj.data_type = message.dataType === 0 ? undefined : message.dataType;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return SignatureAndData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SignatureAndData",
            value: SignatureAndData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SignatureAndData.decode(message.value);
    },
    toProto (message) {
        return SignatureAndData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.SignatureAndData",
            value: SignatureAndData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseTimestampedSignatureData() {
    return {
        signatureData: new Uint8Array(),
        timestamp: BigInt(0)
    };
}
const TimestampedSignatureData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.TimestampedSignatureData",
    aminoType: "cosmos-sdk/TimestampedSignatureData",
    is (o) {
        return o && (o.$typeUrl === TimestampedSignatureData.typeUrl || (o.signatureData instanceof Uint8Array || typeof o.signatureData === "string") && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TimestampedSignatureData.typeUrl || (o.signature_data instanceof Uint8Array || typeof o.signature_data === "string") && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signatureData.length !== 0) {
            writer.uint32(10).bytes(message.signatureData);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(16).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTimestampedSignatureData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signatureData = reader.bytes();
                    break;
                case 2:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTimestampedSignatureData();
        message.signatureData = object.signatureData ?? new Uint8Array();
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseTimestampedSignatureData();
        if (object.signature_data !== undefined && object.signature_data !== null) {
            message.signatureData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature_data);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signature_data = message.signatureData ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signatureData) : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return TimestampedSignatureData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TimestampedSignatureData",
            value: TimestampedSignatureData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TimestampedSignatureData.decode(message.value);
    },
    toProto (message) {
        return TimestampedSignatureData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.TimestampedSignatureData",
            value: TimestampedSignatureData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseSignBytes() {
    return {
        sequence: BigInt(0),
        timestamp: BigInt(0),
        diversifier: "",
        dataType: 0,
        data: new Uint8Array()
    };
}
const SignBytes = {
    typeUrl: "/ibc.lightclients.solomachine.v2.SignBytes",
    aminoType: "cosmos-sdk/SignBytes",
    is (o) {
        return o && (o.$typeUrl === SignBytes.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && typeof o.diversifier === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.dataType) && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === SignBytes.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && typeof o.diversifier === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.data_type) && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(16).uint64(message.timestamp);
        }
        if (message.diversifier !== "") {
            writer.uint32(26).string(message.diversifier);
        }
        if (message.dataType !== 0) {
            writer.uint32(32).int32(message.dataType);
        }
        if (message.data.length !== 0) {
            writer.uint32(42).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSignBytes();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.timestamp = reader.uint64();
                    break;
                case 3:
                    message.diversifier = reader.string();
                    break;
                case 4:
                    message.dataType = reader.int32();
                    break;
                case 5:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSignBytes();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        message.diversifier = object.diversifier ?? "";
        message.dataType = object.dataType ?? 0;
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseSignBytes();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        if (object.diversifier !== undefined && object.diversifier !== null) {
            message.diversifier = object.diversifier;
        }
        if (object.data_type !== undefined && object.data_type !== null) {
            message.dataType = object.data_type;
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        obj.diversifier = message.diversifier === "" ? undefined : message.diversifier;
        obj.data_type = message.dataType === 0 ? undefined : message.dataType;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return SignBytes.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SignBytes",
            value: SignBytes.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SignBytes.decode(message.value);
    },
    toProto (message) {
        return SignBytes.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.SignBytes",
            value: SignBytes.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseHeaderData() {
    return {
        newPubKey: undefined,
        newDiversifier: ""
    };
}
const HeaderData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.HeaderData",
    aminoType: "cosmos-sdk/HeaderData",
    is (o) {
        return o && (o.$typeUrl === HeaderData.typeUrl || typeof o.newDiversifier === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === HeaderData.typeUrl || typeof o.new_diversifier === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.newPubKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.newPubKey, writer.uint32(10).fork()).ldelim();
        }
        if (message.newDiversifier !== "") {
            writer.uint32(18).string(message.newDiversifier);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHeaderData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.newPubKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.newDiversifier = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHeaderData();
        message.newPubKey = object.newPubKey !== undefined && object.newPubKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.newPubKey) : undefined;
        message.newDiversifier = object.newDiversifier ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseHeaderData();
        if (object.new_pub_key !== undefined && object.new_pub_key !== null) {
            message.newPubKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.new_pub_key);
        }
        if (object.new_diversifier !== undefined && object.new_diversifier !== null) {
            message.newDiversifier = object.new_diversifier;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.new_pub_key = message.newPubKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.newPubKey) : undefined;
        obj.new_diversifier = message.newDiversifier === "" ? undefined : message.newDiversifier;
        return obj;
    },
    fromAminoMsg (object) {
        return HeaderData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/HeaderData",
            value: HeaderData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return HeaderData.decode(message.value);
    },
    toProto (message) {
        return HeaderData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.HeaderData",
            value: HeaderData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseClientStateData() {
    return {
        path: new Uint8Array(),
        clientState: undefined
    };
}
const ClientStateData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ClientStateData",
    aminoType: "cosmos-sdk/ClientStateData",
    is (o) {
        return o && (o.$typeUrl === ClientStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.clientState !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.clientState, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientStateData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.clientState = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientStateData();
        message.path = object.path ?? new Uint8Array();
        message.clientState = object.clientState !== undefined && object.clientState !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.clientState) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientStateData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.client_state !== undefined && object.client_state !== null) {
            message.clientState = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.client_state);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.client_state = message.clientState ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.clientState) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ClientStateData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientStateData",
            value: ClientStateData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientStateData.decode(message.value);
    },
    toProto (message) {
        return ClientStateData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ClientStateData",
            value: ClientStateData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseConsensusStateData() {
    return {
        path: new Uint8Array(),
        consensusState: undefined
    };
}
const ConsensusStateData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ConsensusStateData",
    aminoType: "cosmos-sdk/ConsensusStateData",
    is (o) {
        return o && (o.$typeUrl === ConsensusStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConsensusStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.consensusState !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.consensusState, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsensusStateData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.consensusState = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConsensusStateData();
        message.path = object.path ?? new Uint8Array();
        message.consensusState = object.consensusState !== undefined && object.consensusState !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.consensusState) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseConsensusStateData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.consensus_state !== undefined && object.consensus_state !== null) {
            message.consensusState = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.consensus_state);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.consensus_state = message.consensusState ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.consensusState) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConsensusStateData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConsensusStateData",
            value: ConsensusStateData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConsensusStateData.decode(message.value);
    },
    toProto (message) {
        return ConsensusStateData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ConsensusStateData",
            value: ConsensusStateData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseConnectionStateData() {
    return {
        path: new Uint8Array(),
        connection: undefined
    };
}
const ConnectionStateData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ConnectionStateData",
    aminoType: "cosmos-sdk/ConnectionStateData",
    is (o) {
        return o && (o.$typeUrl === ConnectionStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConnectionStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.connection !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].encode(message.connection, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConnectionStateData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.connection = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConnectionStateData();
        message.path = object.path ?? new Uint8Array();
        message.connection = object.connection !== undefined && object.connection !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].fromPartial(object.connection) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseConnectionStateData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.connection !== undefined && object.connection !== null) {
            message.connection = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].fromAmino(object.connection);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.connection = message.connection ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].toAmino(message.connection) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConnectionStateData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConnectionStateData",
            value: ConnectionStateData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConnectionStateData.decode(message.value);
    },
    toProto (message) {
        return ConnectionStateData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ConnectionStateData",
            value: ConnectionStateData.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ConnectionStateData.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$connection$2f$v1$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectionEnd"].registerTypeUrl();
    }
};
function createBaseChannelStateData() {
    return {
        path: new Uint8Array(),
        channel: undefined
    };
}
const ChannelStateData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.ChannelStateData",
    aminoType: "cosmos-sdk/ChannelStateData",
    is (o) {
        return o && (o.$typeUrl === ChannelStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ChannelStateData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.channel !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].encode(message.channel, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseChannelStateData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.channel = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseChannelStateData();
        message.path = object.path ?? new Uint8Array();
        message.channel = object.channel !== undefined && object.channel !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].fromPartial(object.channel) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseChannelStateData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.channel !== undefined && object.channel !== null) {
            message.channel = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].fromAmino(object.channel);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.channel = message.channel ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].toAmino(message.channel) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ChannelStateData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ChannelStateData",
            value: ChannelStateData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ChannelStateData.decode(message.value);
    },
    toProto (message) {
        return ChannelStateData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.ChannelStateData",
            value: ChannelStateData.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ChannelStateData.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$channel$2f$v1$2f$channel$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Channel"].registerTypeUrl();
    }
};
function createBasePacketCommitmentData() {
    return {
        path: new Uint8Array(),
        commitment: new Uint8Array()
    };
}
const PacketCommitmentData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.PacketCommitmentData",
    aminoType: "cosmos-sdk/PacketCommitmentData",
    is (o) {
        return o && (o.$typeUrl === PacketCommitmentData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && (o.commitment instanceof Uint8Array || typeof o.commitment === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === PacketCommitmentData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && (o.commitment instanceof Uint8Array || typeof o.commitment === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.commitment.length !== 0) {
            writer.uint32(18).bytes(message.commitment);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePacketCommitmentData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.commitment = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePacketCommitmentData();
        message.path = object.path ?? new Uint8Array();
        message.commitment = object.commitment ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBasePacketCommitmentData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.commitment !== undefined && object.commitment !== null) {
            message.commitment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.commitment);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.commitment = message.commitment ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.commitment) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return PacketCommitmentData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/PacketCommitmentData",
            value: PacketCommitmentData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return PacketCommitmentData.decode(message.value);
    },
    toProto (message) {
        return PacketCommitmentData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.PacketCommitmentData",
            value: PacketCommitmentData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBasePacketAcknowledgementData() {
    return {
        path: new Uint8Array(),
        acknowledgement: new Uint8Array()
    };
}
const PacketAcknowledgementData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.PacketAcknowledgementData",
    aminoType: "cosmos-sdk/PacketAcknowledgementData",
    is (o) {
        return o && (o.$typeUrl === PacketAcknowledgementData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && (o.acknowledgement instanceof Uint8Array || typeof o.acknowledgement === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === PacketAcknowledgementData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && (o.acknowledgement instanceof Uint8Array || typeof o.acknowledgement === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.acknowledgement.length !== 0) {
            writer.uint32(18).bytes(message.acknowledgement);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePacketAcknowledgementData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.acknowledgement = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePacketAcknowledgementData();
        message.path = object.path ?? new Uint8Array();
        message.acknowledgement = object.acknowledgement ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBasePacketAcknowledgementData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.acknowledgement !== undefined && object.acknowledgement !== null) {
            message.acknowledgement = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.acknowledgement);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.acknowledgement = message.acknowledgement ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.acknowledgement) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return PacketAcknowledgementData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/PacketAcknowledgementData",
            value: PacketAcknowledgementData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return PacketAcknowledgementData.decode(message.value);
    },
    toProto (message) {
        return PacketAcknowledgementData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.PacketAcknowledgementData",
            value: PacketAcknowledgementData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBasePacketReceiptAbsenceData() {
    return {
        path: new Uint8Array()
    };
}
const PacketReceiptAbsenceData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.PacketReceiptAbsenceData",
    aminoType: "cosmos-sdk/PacketReceiptAbsenceData",
    is (o) {
        return o && (o.$typeUrl === PacketReceiptAbsenceData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === PacketReceiptAbsenceData.typeUrl || o.path instanceof Uint8Array || typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBasePacketReceiptAbsenceData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBasePacketReceiptAbsenceData();
        message.path = object.path ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBasePacketReceiptAbsenceData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return PacketReceiptAbsenceData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/PacketReceiptAbsenceData",
            value: PacketReceiptAbsenceData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return PacketReceiptAbsenceData.decode(message.value);
    },
    toProto (message) {
        return PacketReceiptAbsenceData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.PacketReceiptAbsenceData",
            value: PacketReceiptAbsenceData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseNextSequenceRecvData() {
    return {
        path: new Uint8Array(),
        nextSeqRecv: BigInt(0)
    };
}
const NextSequenceRecvData = {
    typeUrl: "/ibc.lightclients.solomachine.v2.NextSequenceRecvData",
    aminoType: "cosmos-sdk/NextSequenceRecvData",
    is (o) {
        return o && (o.$typeUrl === NextSequenceRecvData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && typeof o.nextSeqRecv === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === NextSequenceRecvData.typeUrl || (o.path instanceof Uint8Array || typeof o.path === "string") && typeof o.next_seq_recv === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.path.length !== 0) {
            writer.uint32(10).bytes(message.path);
        }
        if (message.nextSeqRecv !== BigInt(0)) {
            writer.uint32(16).uint64(message.nextSeqRecv);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseNextSequenceRecvData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.path = reader.bytes();
                    break;
                case 2:
                    message.nextSeqRecv = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseNextSequenceRecvData();
        message.path = object.path ?? new Uint8Array();
        message.nextSeqRecv = object.nextSeqRecv !== undefined && object.nextSeqRecv !== null ? BigInt(object.nextSeqRecv.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseNextSequenceRecvData();
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.next_seq_recv !== undefined && object.next_seq_recv !== null) {
            message.nextSeqRecv = BigInt(object.next_seq_recv);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.next_seq_recv = message.nextSeqRecv !== BigInt(0) ? message.nextSeqRecv?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return NextSequenceRecvData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/NextSequenceRecvData",
            value: NextSequenceRecvData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return NextSequenceRecvData.decode(message.value);
    },
    toProto (message) {
        return NextSequenceRecvData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v2.NextSequenceRecvData",
            value: NextSequenceRecvData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/solomachine/v3/solomachine.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ClientState": (()=>ClientState),
    "ConsensusState": (()=>ConsensusState),
    "Header": (()=>Header),
    "HeaderData": (()=>HeaderData),
    "Misbehaviour": (()=>Misbehaviour),
    "SignBytes": (()=>SignBytes),
    "SignatureAndData": (()=>SignatureAndData),
    "TimestampedSignatureData": (()=>TimestampedSignatureData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
function createBaseClientState() {
    return {
        sequence: BigInt(0),
        isFrozen: false,
        consensusState: undefined
    };
}
const ClientState = {
    typeUrl: "/ibc.lightclients.solomachine.v3.ClientState",
    aminoType: "cosmos-sdk/ClientState",
    is (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.sequence === "bigint" && typeof o.isFrozen === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.sequence === "bigint" && typeof o.is_frozen === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.isFrozen === true) {
            writer.uint32(16).bool(message.isFrozen);
        }
        if (message.consensusState !== undefined) {
            ConsensusState.encode(message.consensusState, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.isFrozen = reader.bool();
                    break;
                case 3:
                    message.consensusState = ConsensusState.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientState();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.isFrozen = object.isFrozen ?? false;
        message.consensusState = object.consensusState !== undefined && object.consensusState !== null ? ConsensusState.fromPartial(object.consensusState) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientState();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.is_frozen !== undefined && object.is_frozen !== null) {
            message.isFrozen = object.is_frozen;
        }
        if (object.consensus_state !== undefined && object.consensus_state !== null) {
            message.consensusState = ConsensusState.fromAmino(object.consensus_state);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.is_frozen = message.isFrozen === false ? undefined : message.isFrozen;
        obj.consensus_state = message.consensusState ? ConsensusState.toAmino(message.consensusState) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ClientState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientState",
            value: ClientState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientState.decode(message.value);
    },
    toProto (message) {
        return ClientState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.ClientState",
            value: ClientState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ClientState.typeUrl)) {
            return;
        }
        ConsensusState.registerTypeUrl();
    }
};
function createBaseConsensusState() {
    return {
        publicKey: undefined,
        diversifier: "",
        timestamp: BigInt(0)
    };
}
const ConsensusState = {
    typeUrl: "/ibc.lightclients.solomachine.v3.ConsensusState",
    aminoType: "cosmos-sdk/ConsensusState",
    is (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || typeof o.diversifier === "string" && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || typeof o.diversifier === "string" && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.publicKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.publicKey, writer.uint32(10).fork()).ldelim();
        }
        if (message.diversifier !== "") {
            writer.uint32(18).string(message.diversifier);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(24).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsensusState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.publicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.diversifier = reader.string();
                    break;
                case 3:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConsensusState();
        message.publicKey = object.publicKey !== undefined && object.publicKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.publicKey) : undefined;
        message.diversifier = object.diversifier ?? "";
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseConsensusState();
        if (object.public_key !== undefined && object.public_key !== null) {
            message.publicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.public_key);
        }
        if (object.diversifier !== undefined && object.diversifier !== null) {
            message.diversifier = object.diversifier;
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.public_key = message.publicKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.publicKey) : undefined;
        obj.diversifier = message.diversifier === "" ? undefined : message.diversifier;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConsensusState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConsensusState",
            value: ConsensusState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConsensusState.decode(message.value);
    },
    toProto (message) {
        return ConsensusState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.ConsensusState",
            value: ConsensusState.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseHeader() {
    return {
        timestamp: BigInt(0),
        signature: new Uint8Array(),
        newPublicKey: undefined,
        newDiversifier: ""
    };
}
const Header = {
    typeUrl: "/ibc.lightclients.solomachine.v3.Header",
    aminoType: "cosmos-sdk/Header",
    is (o) {
        return o && (o.$typeUrl === Header.typeUrl || typeof o.timestamp === "bigint" && (o.signature instanceof Uint8Array || typeof o.signature === "string") && typeof o.newDiversifier === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Header.typeUrl || typeof o.timestamp === "bigint" && (o.signature instanceof Uint8Array || typeof o.signature === "string") && typeof o.new_diversifier === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(8).uint64(message.timestamp);
        }
        if (message.signature.length !== 0) {
            writer.uint32(18).bytes(message.signature);
        }
        if (message.newPublicKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.newPublicKey, writer.uint32(26).fork()).ldelim();
        }
        if (message.newDiversifier !== "") {
            writer.uint32(34).string(message.newDiversifier);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHeader();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.timestamp = reader.uint64();
                    break;
                case 2:
                    message.signature = reader.bytes();
                    break;
                case 3:
                    message.newPublicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.newDiversifier = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHeader();
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        message.signature = object.signature ?? new Uint8Array();
        message.newPublicKey = object.newPublicKey !== undefined && object.newPublicKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.newPublicKey) : undefined;
        message.newDiversifier = object.newDiversifier ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseHeader();
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        if (object.signature !== undefined && object.signature !== null) {
            message.signature = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature);
        }
        if (object.new_public_key !== undefined && object.new_public_key !== null) {
            message.newPublicKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.new_public_key);
        }
        if (object.new_diversifier !== undefined && object.new_diversifier !== null) {
            message.newDiversifier = object.new_diversifier;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        obj.signature = message.signature ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signature) : undefined;
        obj.new_public_key = message.newPublicKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.newPublicKey) : undefined;
        obj.new_diversifier = message.newDiversifier === "" ? undefined : message.newDiversifier;
        return obj;
    },
    fromAminoMsg (object) {
        return Header.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Header",
            value: Header.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Header.decode(message.value);
    },
    toProto (message) {
        return Header.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.Header",
            value: Header.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMisbehaviour() {
    return {
        sequence: BigInt(0),
        signatureOne: undefined,
        signatureTwo: undefined
    };
}
const Misbehaviour = {
    typeUrl: "/ibc.lightclients.solomachine.v3.Misbehaviour",
    aminoType: "cosmos-sdk/Misbehaviour",
    is (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.sequence === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.sequence === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.signatureOne !== undefined) {
            SignatureAndData.encode(message.signatureOne, writer.uint32(18).fork()).ldelim();
        }
        if (message.signatureTwo !== undefined) {
            SignatureAndData.encode(message.signatureTwo, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMisbehaviour();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.signatureOne = SignatureAndData.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.signatureTwo = SignatureAndData.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMisbehaviour();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.signatureOne = object.signatureOne !== undefined && object.signatureOne !== null ? SignatureAndData.fromPartial(object.signatureOne) : undefined;
        message.signatureTwo = object.signatureTwo !== undefined && object.signatureTwo !== null ? SignatureAndData.fromPartial(object.signatureTwo) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMisbehaviour();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.signature_one !== undefined && object.signature_one !== null) {
            message.signatureOne = SignatureAndData.fromAmino(object.signature_one);
        }
        if (object.signature_two !== undefined && object.signature_two !== null) {
            message.signatureTwo = SignatureAndData.fromAmino(object.signature_two);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.signature_one = message.signatureOne ? SignatureAndData.toAmino(message.signatureOne) : undefined;
        obj.signature_two = message.signatureTwo ? SignatureAndData.toAmino(message.signatureTwo) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Misbehaviour.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Misbehaviour",
            value: Misbehaviour.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Misbehaviour.decode(message.value);
    },
    toProto (message) {
        return Misbehaviour.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.Misbehaviour",
            value: Misbehaviour.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Misbehaviour.typeUrl)) {
            return;
        }
        SignatureAndData.registerTypeUrl();
    }
};
function createBaseSignatureAndData() {
    return {
        signature: new Uint8Array(),
        path: new Uint8Array(),
        data: new Uint8Array(),
        timestamp: BigInt(0)
    };
}
const SignatureAndData = {
    typeUrl: "/ibc.lightclients.solomachine.v3.SignatureAndData",
    aminoType: "cosmos-sdk/SignatureAndData",
    is (o) {
        return o && (o.$typeUrl === SignatureAndData.typeUrl || (o.signature instanceof Uint8Array || typeof o.signature === "string") && (o.path instanceof Uint8Array || typeof o.path === "string") && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === SignatureAndData.typeUrl || (o.signature instanceof Uint8Array || typeof o.signature === "string") && (o.path instanceof Uint8Array || typeof o.path === "string") && (o.data instanceof Uint8Array || typeof o.data === "string") && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signature.length !== 0) {
            writer.uint32(10).bytes(message.signature);
        }
        if (message.path.length !== 0) {
            writer.uint32(18).bytes(message.path);
        }
        if (message.data.length !== 0) {
            writer.uint32(26).bytes(message.data);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(32).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSignatureAndData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signature = reader.bytes();
                    break;
                case 2:
                    message.path = reader.bytes();
                    break;
                case 3:
                    message.data = reader.bytes();
                    break;
                case 4:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSignatureAndData();
        message.signature = object.signature ?? new Uint8Array();
        message.path = object.path ?? new Uint8Array();
        message.data = object.data ?? new Uint8Array();
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseSignatureAndData();
        if (object.signature !== undefined && object.signature !== null) {
            message.signature = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature);
        }
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signature = message.signature ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signature) : undefined;
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return SignatureAndData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SignatureAndData",
            value: SignatureAndData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SignatureAndData.decode(message.value);
    },
    toProto (message) {
        return SignatureAndData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.SignatureAndData",
            value: SignatureAndData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseTimestampedSignatureData() {
    return {
        signatureData: new Uint8Array(),
        timestamp: BigInt(0)
    };
}
const TimestampedSignatureData = {
    typeUrl: "/ibc.lightclients.solomachine.v3.TimestampedSignatureData",
    aminoType: "cosmos-sdk/TimestampedSignatureData",
    is (o) {
        return o && (o.$typeUrl === TimestampedSignatureData.typeUrl || (o.signatureData instanceof Uint8Array || typeof o.signatureData === "string") && typeof o.timestamp === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === TimestampedSignatureData.typeUrl || (o.signature_data instanceof Uint8Array || typeof o.signature_data === "string") && typeof o.timestamp === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signatureData.length !== 0) {
            writer.uint32(10).bytes(message.signatureData);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(16).uint64(message.timestamp);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTimestampedSignatureData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signatureData = reader.bytes();
                    break;
                case 2:
                    message.timestamp = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTimestampedSignatureData();
        message.signatureData = object.signatureData ?? new Uint8Array();
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseTimestampedSignatureData();
        if (object.signature_data !== undefined && object.signature_data !== null) {
            message.signatureData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.signature_data);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signature_data = message.signatureData ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.signatureData) : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return TimestampedSignatureData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/TimestampedSignatureData",
            value: TimestampedSignatureData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return TimestampedSignatureData.decode(message.value);
    },
    toProto (message) {
        return TimestampedSignatureData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.TimestampedSignatureData",
            value: TimestampedSignatureData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseSignBytes() {
    return {
        sequence: BigInt(0),
        timestamp: BigInt(0),
        diversifier: "",
        path: new Uint8Array(),
        data: new Uint8Array()
    };
}
const SignBytes = {
    typeUrl: "/ibc.lightclients.solomachine.v3.SignBytes",
    aminoType: "cosmos-sdk/SignBytes",
    is (o) {
        return o && (o.$typeUrl === SignBytes.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && typeof o.diversifier === "string" && (o.path instanceof Uint8Array || typeof o.path === "string") && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === SignBytes.typeUrl || typeof o.sequence === "bigint" && typeof o.timestamp === "bigint" && typeof o.diversifier === "string" && (o.path instanceof Uint8Array || typeof o.path === "string") && (o.data instanceof Uint8Array || typeof o.data === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.sequence !== BigInt(0)) {
            writer.uint32(8).uint64(message.sequence);
        }
        if (message.timestamp !== BigInt(0)) {
            writer.uint32(16).uint64(message.timestamp);
        }
        if (message.diversifier !== "") {
            writer.uint32(26).string(message.diversifier);
        }
        if (message.path.length !== 0) {
            writer.uint32(34).bytes(message.path);
        }
        if (message.data.length !== 0) {
            writer.uint32(42).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSignBytes();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.sequence = reader.uint64();
                    break;
                case 2:
                    message.timestamp = reader.uint64();
                    break;
                case 3:
                    message.diversifier = reader.string();
                    break;
                case 4:
                    message.path = reader.bytes();
                    break;
                case 5:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSignBytes();
        message.sequence = object.sequence !== undefined && object.sequence !== null ? BigInt(object.sequence.toString()) : BigInt(0);
        message.timestamp = object.timestamp !== undefined && object.timestamp !== null ? BigInt(object.timestamp.toString()) : BigInt(0);
        message.diversifier = object.diversifier ?? "";
        message.path = object.path ?? new Uint8Array();
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseSignBytes();
        if (object.sequence !== undefined && object.sequence !== null) {
            message.sequence = BigInt(object.sequence);
        }
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = BigInt(object.timestamp);
        }
        if (object.diversifier !== undefined && object.diversifier !== null) {
            message.diversifier = object.diversifier;
        }
        if (object.path !== undefined && object.path !== null) {
            message.path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.path);
        }
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.sequence = message.sequence !== BigInt(0) ? message.sequence?.toString() : undefined;
        obj.timestamp = message.timestamp !== BigInt(0) ? message.timestamp?.toString() : undefined;
        obj.diversifier = message.diversifier === "" ? undefined : message.diversifier;
        obj.path = message.path ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.path) : undefined;
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return SignBytes.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/SignBytes",
            value: SignBytes.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return SignBytes.decode(message.value);
    },
    toProto (message) {
        return SignBytes.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.SignBytes",
            value: SignBytes.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseHeaderData() {
    return {
        newPubKey: undefined,
        newDiversifier: ""
    };
}
const HeaderData = {
    typeUrl: "/ibc.lightclients.solomachine.v3.HeaderData",
    aminoType: "cosmos-sdk/HeaderData",
    is (o) {
        return o && (o.$typeUrl === HeaderData.typeUrl || typeof o.newDiversifier === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === HeaderData.typeUrl || typeof o.new_diversifier === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.newPubKey !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].encode(message.newPubKey, writer.uint32(10).fork()).ldelim();
        }
        if (message.newDiversifier !== "") {
            writer.uint32(18).string(message.newDiversifier);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHeaderData();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.newPubKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.newDiversifier = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHeaderData();
        message.newPubKey = object.newPubKey !== undefined && object.newPubKey !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromPartial(object.newPubKey) : undefined;
        message.newDiversifier = object.newDiversifier ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseHeaderData();
        if (object.new_pub_key !== undefined && object.new_pub_key !== null) {
            message.newPubKey = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].fromAmino(object.new_pub_key);
        }
        if (object.new_diversifier !== undefined && object.new_diversifier !== null) {
            message.newDiversifier = object.new_diversifier;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.new_pub_key = message.newPubKey ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Any"].toAmino(message.newPubKey) : undefined;
        obj.new_diversifier = message.newDiversifier === "" ? undefined : message.newDiversifier;
        return obj;
    },
    fromAminoMsg (object) {
        return HeaderData.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/HeaderData",
            value: HeaderData.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return HeaderData.decode(message.value);
    },
    toProto (message) {
        return HeaderData.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.solomachine.v3.HeaderData",
            value: HeaderData.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/tendermint/v1/tendermint.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ClientState": (()=>ClientState),
    "ConsensusState": (()=>ConsensusState),
    "Fraction": (()=>Fraction),
    "Header": (()=>Header),
    "Misbehaviour": (()=>Misbehaviour)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/client/v1/client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/ics23/v1/proofs.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/commitment/v1/commitment.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/tendermint/types/types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/tendermint/types/validator.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
function createBaseClientState() {
    return {
        chainId: "",
        trustLevel: Fraction.fromPartial({}),
        trustingPeriod: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({}),
        unbondingPeriod: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({}),
        maxClockDrift: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial({}),
        frozenHeight: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial({}),
        latestHeight: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial({}),
        proofSpecs: [],
        upgradePath: [],
        allowUpdateAfterExpiry: false,
        allowUpdateAfterMisbehaviour: false
    };
}
const ClientState = {
    typeUrl: "/ibc.lightclients.tendermint.v1.ClientState",
    aminoType: "cosmos-sdk/ClientState",
    is (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.chainId === "string" && Fraction.is(o.trustLevel) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.trustingPeriod) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.unbondingPeriod) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].is(o.maxClockDrift) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].is(o.frozenHeight) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].is(o.latestHeight) && Array.isArray(o.proofSpecs) && (!o.proofSpecs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].is(o.proofSpecs[0])) && Array.isArray(o.upgradePath) && (!o.upgradePath.length || typeof o.upgradePath[0] === "string") && typeof o.allowUpdateAfterExpiry === "boolean" && typeof o.allowUpdateAfterMisbehaviour === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || typeof o.chain_id === "string" && Fraction.isAmino(o.trust_level) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.trusting_period) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.unbonding_period) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].isAmino(o.max_clock_drift) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].isAmino(o.frozen_height) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].isAmino(o.latest_height) && Array.isArray(o.proof_specs) && (!o.proof_specs.length || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].isAmino(o.proof_specs[0])) && Array.isArray(o.upgrade_path) && (!o.upgrade_path.length || typeof o.upgrade_path[0] === "string") && typeof o.allow_update_after_expiry === "boolean" && typeof o.allow_update_after_misbehaviour === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.chainId !== "") {
            writer.uint32(10).string(message.chainId);
        }
        if (message.trustLevel !== undefined) {
            Fraction.encode(message.trustLevel, writer.uint32(18).fork()).ldelim();
        }
        if (message.trustingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.trustingPeriod, writer.uint32(26).fork()).ldelim();
        }
        if (message.unbondingPeriod !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.unbondingPeriod, writer.uint32(34).fork()).ldelim();
        }
        if (message.maxClockDrift !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].encode(message.maxClockDrift, writer.uint32(42).fork()).ldelim();
        }
        if (message.frozenHeight !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].encode(message.frozenHeight, writer.uint32(50).fork()).ldelim();
        }
        if (message.latestHeight !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].encode(message.latestHeight, writer.uint32(58).fork()).ldelim();
        }
        for (const v of message.proofSpecs){
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].encode(v, writer.uint32(66).fork()).ldelim();
        }
        for (const v of message.upgradePath){
            writer.uint32(74).string(v);
        }
        if (message.allowUpdateAfterExpiry === true) {
            writer.uint32(80).bool(message.allowUpdateAfterExpiry);
        }
        if (message.allowUpdateAfterMisbehaviour === true) {
            writer.uint32(88).bool(message.allowUpdateAfterMisbehaviour);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.chainId = reader.string();
                    break;
                case 2:
                    message.trustLevel = Fraction.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.trustingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.unbondingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 5:
                    message.maxClockDrift = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].decode(reader, reader.uint32());
                    break;
                case 6:
                    message.frozenHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].decode(reader, reader.uint32());
                    break;
                case 7:
                    message.latestHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].decode(reader, reader.uint32());
                    break;
                case 8:
                    message.proofSpecs.push(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].decode(reader, reader.uint32()));
                    break;
                case 9:
                    message.upgradePath.push(reader.string());
                    break;
                case 10:
                    message.allowUpdateAfterExpiry = reader.bool();
                    break;
                case 11:
                    message.allowUpdateAfterMisbehaviour = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientState();
        message.chainId = object.chainId ?? "";
        message.trustLevel = object.trustLevel !== undefined && object.trustLevel !== null ? Fraction.fromPartial(object.trustLevel) : undefined;
        message.trustingPeriod = object.trustingPeriod !== undefined && object.trustingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.trustingPeriod) : undefined;
        message.unbondingPeriod = object.unbondingPeriod !== undefined && object.unbondingPeriod !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.unbondingPeriod) : undefined;
        message.maxClockDrift = object.maxClockDrift !== undefined && object.maxClockDrift !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromPartial(object.maxClockDrift) : undefined;
        message.frozenHeight = object.frozenHeight !== undefined && object.frozenHeight !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial(object.frozenHeight) : undefined;
        message.latestHeight = object.latestHeight !== undefined && object.latestHeight !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial(object.latestHeight) : undefined;
        message.proofSpecs = object.proofSpecs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].fromPartial(e)) || [];
        message.upgradePath = object.upgradePath?.map((e)=>e) || [];
        message.allowUpdateAfterExpiry = object.allowUpdateAfterExpiry ?? false;
        message.allowUpdateAfterMisbehaviour = object.allowUpdateAfterMisbehaviour ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientState();
        if (object.chain_id !== undefined && object.chain_id !== null) {
            message.chainId = object.chain_id;
        }
        if (object.trust_level !== undefined && object.trust_level !== null) {
            message.trustLevel = Fraction.fromAmino(object.trust_level);
        }
        if (object.trusting_period !== undefined && object.trusting_period !== null) {
            message.trustingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.trusting_period);
        }
        if (object.unbonding_period !== undefined && object.unbonding_period !== null) {
            message.unbondingPeriod = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.unbonding_period);
        }
        if (object.max_clock_drift !== undefined && object.max_clock_drift !== null) {
            message.maxClockDrift = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].fromAmino(object.max_clock_drift);
        }
        if (object.frozen_height !== undefined && object.frozen_height !== null) {
            message.frozenHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromAmino(object.frozen_height);
        }
        if (object.latest_height !== undefined && object.latest_height !== null) {
            message.latestHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromAmino(object.latest_height);
        }
        message.proofSpecs = object.proof_specs?.map((e)=>__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].fromAmino(e)) || [];
        message.upgradePath = object.upgrade_path?.map((e)=>e) || [];
        if (object.allow_update_after_expiry !== undefined && object.allow_update_after_expiry !== null) {
            message.allowUpdateAfterExpiry = object.allow_update_after_expiry;
        }
        if (object.allow_update_after_misbehaviour !== undefined && object.allow_update_after_misbehaviour !== null) {
            message.allowUpdateAfterMisbehaviour = object.allow_update_after_misbehaviour;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.chain_id = message.chainId === "" ? undefined : message.chainId;
        obj.trust_level = message.trustLevel ? Fraction.toAmino(message.trustLevel) : undefined;
        obj.trusting_period = message.trustingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.trustingPeriod) : undefined;
        obj.unbonding_period = message.unbondingPeriod ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.unbondingPeriod) : undefined;
        obj.max_clock_drift = message.maxClockDrift ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Duration"].toAmino(message.maxClockDrift) : undefined;
        obj.frozen_height = message.frozenHeight ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].toAmino(message.frozenHeight) : {};
        obj.latest_height = message.latestHeight ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].toAmino(message.latestHeight) : {};
        if (message.proofSpecs) {
            obj.proof_specs = message.proofSpecs.map((e)=>e ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].toAmino(e) : undefined);
        } else {
            obj.proof_specs = message.proofSpecs;
        }
        if (message.upgradePath) {
            obj.upgrade_path = message.upgradePath.map((e)=>e);
        } else {
            obj.upgrade_path = message.upgradePath;
        }
        obj.allow_update_after_expiry = message.allowUpdateAfterExpiry === false ? undefined : message.allowUpdateAfterExpiry;
        obj.allow_update_after_misbehaviour = message.allowUpdateAfterMisbehaviour === false ? undefined : message.allowUpdateAfterMisbehaviour;
        return obj;
    },
    fromAminoMsg (object) {
        return ClientState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientState",
            value: ClientState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientState.decode(message.value);
    },
    toProto (message) {
        return ClientState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.tendermint.v1.ClientState",
            value: ClientState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ClientState.typeUrl)) {
            return;
        }
        Fraction.registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$ics23$2f$v1$2f$proofs$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProofSpec"].registerTypeUrl();
    }
};
function createBaseConsensusState() {
    return {
        timestamp: new Date(),
        root: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].fromPartial({}),
        nextValidatorsHash: new Uint8Array()
    };
}
const ConsensusState = {
    typeUrl: "/ibc.lightclients.tendermint.v1.ConsensusState",
    aminoType: "cosmos-sdk/ConsensusState",
    is (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].is(o.timestamp) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].is(o.root) && (o.nextValidatorsHash instanceof Uint8Array || typeof o.nextValidatorsHash === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].isAmino(o.timestamp) && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].isAmino(o.root) && (o.next_validators_hash instanceof Uint8Array || typeof o.next_validators_hash === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.timestamp !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].encode((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.timestamp), writer.uint32(10).fork()).ldelim();
        }
        if (message.root !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].encode(message.root, writer.uint32(18).fork()).ldelim();
        }
        if (message.nextValidatorsHash.length !== 0) {
            writer.uint32(26).bytes(message.nextValidatorsHash);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsensusState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.timestamp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.root = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.nextValidatorsHash = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConsensusState();
        message.timestamp = object.timestamp ?? undefined;
        message.root = object.root !== undefined && object.root !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].fromPartial(object.root) : undefined;
        message.nextValidatorsHash = object.nextValidatorsHash ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseConsensusState();
        if (object.timestamp !== undefined && object.timestamp !== null) {
            message.timestamp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].fromAmino(object.timestamp));
        }
        if (object.root !== undefined && object.root !== null) {
            message.root = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].fromAmino(object.root);
        }
        if (object.next_validators_hash !== undefined && object.next_validators_hash !== null) {
            message.nextValidatorsHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.next_validators_hash);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.timestamp = message.timestamp ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"].toAmino((0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toTimestamp"])(message.timestamp)) : undefined;
        obj.root = message.root ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].toAmino(message.root) : undefined;
        obj.next_validators_hash = message.nextValidatorsHash ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.nextValidatorsHash) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConsensusState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConsensusState",
            value: ConsensusState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConsensusState.decode(message.value);
    },
    toProto (message) {
        return ConsensusState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.tendermint.v1.ConsensusState",
            value: ConsensusState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ConsensusState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$commitment$2f$v1$2f$commitment$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MerkleRoot"].registerTypeUrl();
    }
};
function createBaseMisbehaviour() {
    return {
        clientId: "",
        header1: undefined,
        header2: undefined
    };
}
const Misbehaviour = {
    typeUrl: "/ibc.lightclients.tendermint.v1.Misbehaviour",
    aminoType: "cosmos-sdk/Misbehaviour",
    is (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.clientId === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Misbehaviour.typeUrl || typeof o.client_id === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.clientId !== "") {
            writer.uint32(10).string(message.clientId);
        }
        if (message.header1 !== undefined) {
            Header.encode(message.header1, writer.uint32(18).fork()).ldelim();
        }
        if (message.header2 !== undefined) {
            Header.encode(message.header2, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMisbehaviour();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.clientId = reader.string();
                    break;
                case 2:
                    message.header1 = Header.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.header2 = Header.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMisbehaviour();
        message.clientId = object.clientId ?? "";
        message.header1 = object.header1 !== undefined && object.header1 !== null ? Header.fromPartial(object.header1) : undefined;
        message.header2 = object.header2 !== undefined && object.header2 !== null ? Header.fromPartial(object.header2) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMisbehaviour();
        if (object.client_id !== undefined && object.client_id !== null) {
            message.clientId = object.client_id;
        }
        if (object.header_1 !== undefined && object.header_1 !== null) {
            message.header1 = Header.fromAmino(object.header_1);
        }
        if (object.header_2 !== undefined && object.header_2 !== null) {
            message.header2 = Header.fromAmino(object.header_2);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.client_id = message.clientId === "" ? undefined : message.clientId;
        obj.header_1 = message.header1 ? Header.toAmino(message.header1) : undefined;
        obj.header_2 = message.header2 ? Header.toAmino(message.header2) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Misbehaviour.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Misbehaviour",
            value: Misbehaviour.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Misbehaviour.decode(message.value);
    },
    toProto (message) {
        return Misbehaviour.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.tendermint.v1.Misbehaviour",
            value: Misbehaviour.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Misbehaviour.typeUrl)) {
            return;
        }
        Header.registerTypeUrl();
    }
};
function createBaseHeader() {
    return {
        signedHeader: undefined,
        validatorSet: undefined,
        trustedHeight: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial({}),
        trustedValidators: undefined
    };
}
const Header = {
    typeUrl: "/ibc.lightclients.tendermint.v1.Header",
    aminoType: "cosmos-sdk/Header",
    is (o) {
        return o && (o.$typeUrl === Header.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].is(o.trustedHeight));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Header.typeUrl || __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].isAmino(o.trusted_height));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signedHeader !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].encode(message.signedHeader, writer.uint32(10).fork()).ldelim();
        }
        if (message.validatorSet !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].encode(message.validatorSet, writer.uint32(18).fork()).ldelim();
        }
        if (message.trustedHeight !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].encode(message.trustedHeight, writer.uint32(26).fork()).ldelim();
        }
        if (message.trustedValidators !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].encode(message.trustedValidators, writer.uint32(34).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHeader();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signedHeader = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].decode(reader, reader.uint32());
                    break;
                case 2:
                    message.validatorSet = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].decode(reader, reader.uint32());
                    break;
                case 3:
                    message.trustedHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].decode(reader, reader.uint32());
                    break;
                case 4:
                    message.trustedValidators = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHeader();
        message.signedHeader = object.signedHeader !== undefined && object.signedHeader !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].fromPartial(object.signedHeader) : undefined;
        message.validatorSet = object.validatorSet !== undefined && object.validatorSet !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].fromPartial(object.validatorSet) : undefined;
        message.trustedHeight = object.trustedHeight !== undefined && object.trustedHeight !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial(object.trustedHeight) : undefined;
        message.trustedValidators = object.trustedValidators !== undefined && object.trustedValidators !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].fromPartial(object.trustedValidators) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseHeader();
        if (object.signed_header !== undefined && object.signed_header !== null) {
            message.signedHeader = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].fromAmino(object.signed_header);
        }
        if (object.validator_set !== undefined && object.validator_set !== null) {
            message.validatorSet = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].fromAmino(object.validator_set);
        }
        if (object.trusted_height !== undefined && object.trusted_height !== null) {
            message.trustedHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromAmino(object.trusted_height);
        }
        if (object.trusted_validators !== undefined && object.trusted_validators !== null) {
            message.trustedValidators = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].fromAmino(object.trusted_validators);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signed_header = message.signedHeader ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].toAmino(message.signedHeader) : undefined;
        obj.validator_set = message.validatorSet ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].toAmino(message.validatorSet) : undefined;
        obj.trusted_height = message.trustedHeight ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].toAmino(message.trustedHeight) : {};
        obj.trusted_validators = message.trustedValidators ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].toAmino(message.trustedValidators) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Header.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Header",
            value: Header.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Header.decode(message.value);
    },
    toProto (message) {
        return Header.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.tendermint.v1.Header",
            value: Header.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Header.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SignedHeader"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$tendermint$2f$types$2f$validator$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ValidatorSet"].registerTypeUrl();
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].registerTypeUrl();
    }
};
function createBaseFraction() {
    return {
        numerator: BigInt(0),
        denominator: BigInt(0)
    };
}
const Fraction = {
    typeUrl: "/ibc.lightclients.tendermint.v1.Fraction",
    aminoType: "cosmos-sdk/Fraction",
    is (o) {
        return o && (o.$typeUrl === Fraction.typeUrl || typeof o.numerator === "bigint" && typeof o.denominator === "bigint");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Fraction.typeUrl || typeof o.numerator === "bigint" && typeof o.denominator === "bigint");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.numerator !== BigInt(0)) {
            writer.uint32(8).uint64(message.numerator);
        }
        if (message.denominator !== BigInt(0)) {
            writer.uint32(16).uint64(message.denominator);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFraction();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.numerator = reader.uint64();
                    break;
                case 2:
                    message.denominator = reader.uint64();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFraction();
        message.numerator = object.numerator !== undefined && object.numerator !== null ? BigInt(object.numerator.toString()) : BigInt(0);
        message.denominator = object.denominator !== undefined && object.denominator !== null ? BigInt(object.denominator.toString()) : BigInt(0);
        return message;
    },
    fromAmino (object) {
        const message = createBaseFraction();
        if (object.numerator !== undefined && object.numerator !== null) {
            message.numerator = BigInt(object.numerator);
        }
        if (object.denominator !== undefined && object.denominator !== null) {
            message.denominator = BigInt(object.denominator);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.numerator = message.numerator !== BigInt(0) ? message.numerator?.toString() : undefined;
        obj.denominator = message.denominator !== BigInt(0) ? message.denominator?.toString() : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Fraction.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Fraction",
            value: Fraction.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Fraction.decode(message.value);
    },
    toProto (message) {
        return Fraction.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.tendermint.v1.Fraction",
            value: Fraction.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/genesis.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Contract": (()=>Contract),
    "GenesisState": (()=>GenesisState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
function createBaseGenesisState() {
    return {
        contracts: []
    };
}
const GenesisState = {
    typeUrl: "/ibc.lightclients.wasm.v1.GenesisState",
    aminoType: "cosmos-sdk/GenesisState",
    is (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || Array.isArray(o.contracts) && (!o.contracts.length || Contract.is(o.contracts[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GenesisState.typeUrl || Array.isArray(o.contracts) && (!o.contracts.length || Contract.isAmino(o.contracts[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.contracts){
            Contract.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGenesisState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.contracts.push(Contract.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGenesisState();
        message.contracts = object.contracts?.map((e)=>Contract.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseGenesisState();
        message.contracts = object.contracts?.map((e)=>Contract.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.contracts) {
            obj.contracts = message.contracts.map((e)=>e ? Contract.toAmino(e) : undefined);
        } else {
            obj.contracts = message.contracts;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return GenesisState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/GenesisState",
            value: GenesisState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return GenesisState.decode(message.value);
    },
    toProto (message) {
        return GenesisState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.GenesisState",
            value: GenesisState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GenesisState.typeUrl)) {
            return;
        }
        Contract.registerTypeUrl();
    }
};
function createBaseContract() {
    return {
        codeBytes: new Uint8Array()
    };
}
const Contract = {
    typeUrl: "/ibc.lightclients.wasm.v1.Contract",
    aminoType: "cosmos-sdk/Contract",
    is (o) {
        return o && (o.$typeUrl === Contract.typeUrl || o.codeBytes instanceof Uint8Array || typeof o.codeBytes === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Contract.typeUrl || o.code_bytes instanceof Uint8Array || typeof o.code_bytes === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.codeBytes.length !== 0) {
            writer.uint32(10).bytes(message.codeBytes);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseContract();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.codeBytes = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseContract();
        message.codeBytes = object.codeBytes ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseContract();
        if (object.code_bytes !== undefined && object.code_bytes !== null) {
            message.codeBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.code_bytes);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.code_bytes = message.codeBytes ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.codeBytes) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return Contract.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Contract",
            value: Contract.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Contract.decode(message.value);
    },
    toProto (message) {
        return Contract.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.Contract",
            value: Contract.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/query.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "QueryChecksumsRequest": (()=>QueryChecksumsRequest),
    "QueryChecksumsResponse": (()=>QueryChecksumsResponse),
    "QueryCodeRequest": (()=>QueryCodeRequest),
    "QueryCodeResponse": (()=>QueryCodeResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/cosmos/base/query/v1beta1/pagination.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
function createBaseQueryChecksumsRequest() {
    return {
        pagination: undefined
    };
}
const QueryChecksumsRequest = {
    typeUrl: "/ibc.lightclients.wasm.v1.QueryChecksumsRequest",
    aminoType: "cosmos-sdk/QueryChecksumsRequest",
    is (o) {
        return o && o.$typeUrl === QueryChecksumsRequest.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === QueryChecksumsRequest.typeUrl;
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].encode(message.pagination, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryChecksumsRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryChecksumsRequest();
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryChecksumsRequest();
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryChecksumsRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryChecksumsRequest",
            value: QueryChecksumsRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryChecksumsRequest.decode(message.value);
    },
    toProto (message) {
        return QueryChecksumsRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.QueryChecksumsRequest",
            value: QueryChecksumsRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryChecksumsRequest.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageRequest"].registerTypeUrl();
    }
};
function createBaseQueryChecksumsResponse() {
    return {
        checksums: [],
        pagination: undefined
    };
}
const QueryChecksumsResponse = {
    typeUrl: "/ibc.lightclients.wasm.v1.QueryChecksumsResponse",
    aminoType: "cosmos-sdk/QueryChecksumsResponse",
    is (o) {
        return o && (o.$typeUrl === QueryChecksumsResponse.typeUrl || Array.isArray(o.checksums) && (!o.checksums.length || typeof o.checksums[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryChecksumsResponse.typeUrl || Array.isArray(o.checksums) && (!o.checksums.length || typeof o.checksums[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.checksums){
            writer.uint32(10).string(v);
        }
        if (message.pagination !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].encode(message.pagination, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryChecksumsResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.checksums.push(reader.string());
                    break;
                case 2:
                    message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryChecksumsResponse();
        message.checksums = object.checksums?.map((e)=>e) || [];
        message.pagination = object.pagination !== undefined && object.pagination !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromPartial(object.pagination) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryChecksumsResponse();
        message.checksums = object.checksums?.map((e)=>e) || [];
        if (object.pagination !== undefined && object.pagination !== null) {
            message.pagination = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].fromAmino(object.pagination);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.checksums) {
            obj.checksums = message.checksums.map((e)=>e);
        } else {
            obj.checksums = message.checksums;
        }
        obj.pagination = message.pagination ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].toAmino(message.pagination) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryChecksumsResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryChecksumsResponse",
            value: QueryChecksumsResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryChecksumsResponse.decode(message.value);
    },
    toProto (message) {
        return QueryChecksumsResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.QueryChecksumsResponse",
            value: QueryChecksumsResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(QueryChecksumsResponse.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$cosmos$2f$base$2f$query$2f$v1beta1$2f$pagination$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageResponse"].registerTypeUrl();
    }
};
function createBaseQueryCodeRequest() {
    return {
        checksum: ""
    };
}
const QueryCodeRequest = {
    typeUrl: "/ibc.lightclients.wasm.v1.QueryCodeRequest",
    aminoType: "cosmos-sdk/QueryCodeRequest",
    is (o) {
        return o && (o.$typeUrl === QueryCodeRequest.typeUrl || typeof o.checksum === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryCodeRequest.typeUrl || typeof o.checksum === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.checksum !== "") {
            writer.uint32(10).string(message.checksum);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryCodeRequest();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.checksum = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryCodeRequest();
        message.checksum = object.checksum ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryCodeRequest();
        if (object.checksum !== undefined && object.checksum !== null) {
            message.checksum = object.checksum;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.checksum = message.checksum === "" ? undefined : message.checksum;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryCodeRequest.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryCodeRequest",
            value: QueryCodeRequest.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryCodeRequest.decode(message.value);
    },
    toProto (message) {
        return QueryCodeRequest.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.QueryCodeRequest",
            value: QueryCodeRequest.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseQueryCodeResponse() {
    return {
        data: new Uint8Array()
    };
}
const QueryCodeResponse = {
    typeUrl: "/ibc.lightclients.wasm.v1.QueryCodeResponse",
    aminoType: "cosmos-sdk/QueryCodeResponse",
    is (o) {
        return o && (o.$typeUrl === QueryCodeResponse.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === QueryCodeResponse.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.data.length !== 0) {
            writer.uint32(10).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseQueryCodeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseQueryCodeResponse();
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseQueryCodeResponse();
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return QueryCodeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/QueryCodeResponse",
            value: QueryCodeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return QueryCodeResponse.decode(message.value);
    },
    toProto (message) {
        return QueryCodeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.QueryCodeResponse",
            value: QueryCodeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/tx.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MsgMigrateContract": (()=>MsgMigrateContract),
    "MsgMigrateContractResponse": (()=>MsgMigrateContractResponse),
    "MsgRemoveChecksum": (()=>MsgRemoveChecksum),
    "MsgRemoveChecksumResponse": (()=>MsgRemoveChecksumResponse),
    "MsgStoreCode": (()=>MsgStoreCode),
    "MsgStoreCodeResponse": (()=>MsgStoreCodeResponse)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
function createBaseMsgStoreCode() {
    return {
        signer: "",
        wasmByteCode: new Uint8Array()
    };
}
const MsgStoreCode = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCode",
    aminoType: "cosmos-sdk/MsgStoreCode",
    is (o) {
        return o && (o.$typeUrl === MsgStoreCode.typeUrl || typeof o.signer === "string" && (o.wasmByteCode instanceof Uint8Array || typeof o.wasmByteCode === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgStoreCode.typeUrl || typeof o.signer === "string" && (o.wasm_byte_code instanceof Uint8Array || typeof o.wasm_byte_code === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.wasmByteCode.length !== 0) {
            writer.uint32(18).bytes(message.wasmByteCode);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgStoreCode();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.wasmByteCode = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgStoreCode();
        message.signer = object.signer ?? "";
        message.wasmByteCode = object.wasmByteCode ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgStoreCode();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.wasm_byte_code !== undefined && object.wasm_byte_code !== null) {
            message.wasmByteCode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.wasm_byte_code);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.wasm_byte_code = message.wasmByteCode ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.wasmByteCode) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgStoreCode.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgStoreCode",
            value: MsgStoreCode.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgStoreCode.decode(message.value);
    },
    toProto (message) {
        return MsgStoreCode.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCode",
            value: MsgStoreCode.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgStoreCodeResponse() {
    return {
        checksum: new Uint8Array()
    };
}
const MsgStoreCodeResponse = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCodeResponse",
    aminoType: "cosmos-sdk/MsgStoreCodeResponse",
    is (o) {
        return o && (o.$typeUrl === MsgStoreCodeResponse.typeUrl || o.checksum instanceof Uint8Array || typeof o.checksum === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgStoreCodeResponse.typeUrl || o.checksum instanceof Uint8Array || typeof o.checksum === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.checksum.length !== 0) {
            writer.uint32(10).bytes(message.checksum);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgStoreCodeResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.checksum = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgStoreCodeResponse();
        message.checksum = object.checksum ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgStoreCodeResponse();
        if (object.checksum !== undefined && object.checksum !== null) {
            message.checksum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.checksum);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.checksum = message.checksum ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.checksum) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgStoreCodeResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgStoreCodeResponse",
            value: MsgStoreCodeResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgStoreCodeResponse.decode(message.value);
    },
    toProto (message) {
        return MsgStoreCodeResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCodeResponse",
            value: MsgStoreCodeResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRemoveChecksum() {
    return {
        signer: "",
        checksum: new Uint8Array()
    };
}
const MsgRemoveChecksum = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
    aminoType: "cosmos-sdk/MsgRemoveChecksum",
    is (o) {
        return o && (o.$typeUrl === MsgRemoveChecksum.typeUrl || typeof o.signer === "string" && (o.checksum instanceof Uint8Array || typeof o.checksum === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgRemoveChecksum.typeUrl || typeof o.signer === "string" && (o.checksum instanceof Uint8Array || typeof o.checksum === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.checksum.length !== 0) {
            writer.uint32(18).bytes(message.checksum);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRemoveChecksum();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.checksum = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgRemoveChecksum();
        message.signer = object.signer ?? "";
        message.checksum = object.checksum ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgRemoveChecksum();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.checksum !== undefined && object.checksum !== null) {
            message.checksum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.checksum);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.checksum = message.checksum ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.checksum) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRemoveChecksum.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRemoveChecksum",
            value: MsgRemoveChecksum.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRemoveChecksum.decode(message.value);
    },
    toProto (message) {
        return MsgRemoveChecksum.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
            value: MsgRemoveChecksum.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgRemoveChecksumResponse() {
    return {};
}
const MsgRemoveChecksumResponse = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksumResponse",
    aminoType: "cosmos-sdk/MsgRemoveChecksumResponse",
    is (o) {
        return o && o.$typeUrl === MsgRemoveChecksumResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgRemoveChecksumResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgRemoveChecksumResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgRemoveChecksumResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgRemoveChecksumResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgRemoveChecksumResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgRemoveChecksumResponse",
            value: MsgRemoveChecksumResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgRemoveChecksumResponse.decode(message.value);
    },
    toProto (message) {
        return MsgRemoveChecksumResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksumResponse",
            value: MsgRemoveChecksumResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgMigrateContract() {
    return {
        signer: "",
        clientId: "",
        checksum: new Uint8Array(),
        msg: new Uint8Array()
    };
}
const MsgMigrateContract = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContract",
    aminoType: "cosmos-sdk/MsgMigrateContract",
    is (o) {
        return o && (o.$typeUrl === MsgMigrateContract.typeUrl || typeof o.signer === "string" && typeof o.clientId === "string" && (o.checksum instanceof Uint8Array || typeof o.checksum === "string") && (o.msg instanceof Uint8Array || typeof o.msg === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MsgMigrateContract.typeUrl || typeof o.signer === "string" && typeof o.client_id === "string" && (o.checksum instanceof Uint8Array || typeof o.checksum === "string") && (o.msg instanceof Uint8Array || typeof o.msg === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.signer !== "") {
            writer.uint32(10).string(message.signer);
        }
        if (message.clientId !== "") {
            writer.uint32(18).string(message.clientId);
        }
        if (message.checksum.length !== 0) {
            writer.uint32(26).bytes(message.checksum);
        }
        if (message.msg.length !== 0) {
            writer.uint32(34).bytes(message.msg);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgMigrateContract();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.signer = reader.string();
                    break;
                case 2:
                    message.clientId = reader.string();
                    break;
                case 3:
                    message.checksum = reader.bytes();
                    break;
                case 4:
                    message.msg = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMsgMigrateContract();
        message.signer = object.signer ?? "";
        message.clientId = object.clientId ?? "";
        message.checksum = object.checksum ?? new Uint8Array();
        message.msg = object.msg ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseMsgMigrateContract();
        if (object.signer !== undefined && object.signer !== null) {
            message.signer = object.signer;
        }
        if (object.client_id !== undefined && object.client_id !== null) {
            message.clientId = object.client_id;
        }
        if (object.checksum !== undefined && object.checksum !== null) {
            message.checksum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.checksum);
        }
        if (object.msg !== undefined && object.msg !== null) {
            message.msg = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.msg);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.signer = message.signer === "" ? undefined : message.signer;
        obj.client_id = message.clientId === "" ? undefined : message.clientId;
        obj.checksum = message.checksum ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.checksum) : undefined;
        obj.msg = message.msg ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.msg) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return MsgMigrateContract.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgMigrateContract",
            value: MsgMigrateContract.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgMigrateContract.decode(message.value);
    },
    toProto (message) {
        return MsgMigrateContract.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContract",
            value: MsgMigrateContract.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseMsgMigrateContractResponse() {
    return {};
}
const MsgMigrateContractResponse = {
    typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContractResponse",
    aminoType: "cosmos-sdk/MsgMigrateContractResponse",
    is (o) {
        return o && o.$typeUrl === MsgMigrateContractResponse.typeUrl;
    },
    isAmino (o) {
        return o && o.$typeUrl === MsgMigrateContractResponse.typeUrl;
    },
    encode (_, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMsgMigrateContractResponse();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (_) {
        const message = createBaseMsgMigrateContractResponse();
        return message;
    },
    fromAmino (_) {
        const message = createBaseMsgMigrateContractResponse();
        return message;
    },
    toAmino (_) {
        const obj = {};
        return obj;
    },
    fromAminoMsg (object) {
        return MsgMigrateContractResponse.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/MsgMigrateContractResponse",
            value: MsgMigrateContractResponse.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return MsgMigrateContractResponse.decode(message.value);
    },
    toProto (message) {
        return MsgMigrateContractResponse.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContractResponse",
            value: MsgMigrateContractResponse.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/wasm.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Checksums": (()=>Checksums),
    "ClientMessage": (()=>ClientMessage),
    "ClientState": (()=>ClientState),
    "ConsensusState": (()=>ConsensusState)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/core/client/v1/client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
;
;
function createBaseClientState() {
    return {
        data: new Uint8Array(),
        checksum: new Uint8Array(),
        latestHeight: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial({})
    };
}
const ClientState = {
    typeUrl: "/ibc.lightclients.wasm.v1.ClientState",
    aminoType: "cosmos-sdk/ClientState",
    is (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || (o.data instanceof Uint8Array || typeof o.data === "string") && (o.checksum instanceof Uint8Array || typeof o.checksum === "string") && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].is(o.latestHeight));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientState.typeUrl || (o.data instanceof Uint8Array || typeof o.data === "string") && (o.checksum instanceof Uint8Array || typeof o.checksum === "string") && __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].isAmino(o.latest_height));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.data.length !== 0) {
            writer.uint32(10).bytes(message.data);
        }
        if (message.checksum.length !== 0) {
            writer.uint32(18).bytes(message.checksum);
        }
        if (message.latestHeight !== undefined) {
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].encode(message.latestHeight, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.data = reader.bytes();
                    break;
                case 2:
                    message.checksum = reader.bytes();
                    break;
                case 3:
                    message.latestHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientState();
        message.data = object.data ?? new Uint8Array();
        message.checksum = object.checksum ?? new Uint8Array();
        message.latestHeight = object.latestHeight !== undefined && object.latestHeight !== null ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromPartial(object.latestHeight) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientState();
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        if (object.checksum !== undefined && object.checksum !== null) {
            message.checksum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.checksum);
        }
        if (object.latest_height !== undefined && object.latest_height !== null) {
            message.latestHeight = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].fromAmino(object.latest_height);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        obj.checksum = message.checksum ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.checksum) : undefined;
        obj.latest_height = message.latestHeight ? __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].toAmino(message.latestHeight) : {};
        return obj;
    },
    fromAminoMsg (object) {
        return ClientState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientState",
            value: ClientState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientState.decode(message.value);
    },
    toProto (message) {
        return ClientState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.ClientState",
            value: ClientState.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ClientState.typeUrl)) {
            return;
        }
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$core$2f$client$2f$v1$2f$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Height"].registerTypeUrl();
    }
};
function createBaseConsensusState() {
    return {
        data: new Uint8Array()
    };
}
const ConsensusState = {
    typeUrl: "/ibc.lightclients.wasm.v1.ConsensusState",
    aminoType: "cosmos-sdk/ConsensusState",
    is (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ConsensusState.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.data.length !== 0) {
            writer.uint32(10).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseConsensusState();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseConsensusState();
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseConsensusState();
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ConsensusState.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ConsensusState",
            value: ConsensusState.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ConsensusState.decode(message.value);
    },
    toProto (message) {
        return ConsensusState.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.ConsensusState",
            value: ConsensusState.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseClientMessage() {
    return {
        data: new Uint8Array()
    };
}
const ClientMessage = {
    typeUrl: "/ibc.lightclients.wasm.v1.ClientMessage",
    aminoType: "cosmos-sdk/ClientMessage",
    is (o) {
        return o && (o.$typeUrl === ClientMessage.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ClientMessage.typeUrl || o.data instanceof Uint8Array || typeof o.data === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.data.length !== 0) {
            writer.uint32(10).bytes(message.data);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseClientMessage();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.data = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseClientMessage();
        message.data = object.data ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        const message = createBaseClientMessage();
        if (object.data !== undefined && object.data !== null) {
            message.data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.data);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.data = message.data ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.data) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ClientMessage.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/ClientMessage",
            value: ClientMessage.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return ClientMessage.decode(message.value);
    },
    toProto (message) {
        return ClientMessage.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.ClientMessage",
            value: ClientMessage.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseChecksums() {
    return {
        checksums: []
    };
}
const Checksums = {
    typeUrl: "/ibc.lightclients.wasm.v1.Checksums",
    aminoType: "cosmos-sdk/Checksums",
    is (o) {
        return o && (o.$typeUrl === Checksums.typeUrl || Array.isArray(o.checksums) && (!o.checksums.length || o.checksums[0] instanceof Uint8Array || typeof o.checksums[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Checksums.typeUrl || Array.isArray(o.checksums) && (!o.checksums.length || o.checksums[0] instanceof Uint8Array || typeof o.checksums[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.checksums){
            writer.uint32(10).bytes(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseChecksums();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.checksums.push(reader.bytes());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseChecksums();
        message.checksums = object.checksums?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseChecksums();
        message.checksums = object.checksums?.map((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.checksums) {
            obj.checksums = message.checksums.map((e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(e));
        } else {
            obj.checksums = message.checksums;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return Checksums.fromAmino(object.value);
    },
    toAminoMsg (message) {
        return {
            type: "cosmos-sdk/Checksums",
            value: Checksums.toAmino(message)
        };
    },
    fromProtoMsg (message) {
        return Checksums.decode(message.value);
    },
    toProto (message) {
        return Checksums.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/ibc.lightclients.wasm.v1.Checksums",
            value: Checksums.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/tx.registry.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "MessageComposer": (()=>MessageComposer),
    "registry": (()=>registry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/tx.js [app-client] (ecmascript)");
;
const registry = [
    [
        "/ibc.lightclients.wasm.v1.MsgStoreCode",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgStoreCode"]
    ],
    [
        "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRemoveChecksum"]
    ],
    [
        "/ibc.lightclients.wasm.v1.MsgMigrateContract",
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMigrateContract"]
    ]
];
const MessageComposer = {
    encoded: {
        storeCode (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCode",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgStoreCode"].encode(value).finish()
            };
        },
        removeChecksum (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRemoveChecksum"].encode(value).finish()
            };
        },
        migrateContract (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContract",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMigrateContract"].encode(value).finish()
            };
        }
    },
    withTypeUrl: {
        storeCode (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCode",
                value
            };
        },
        removeChecksum (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
                value
            };
        },
        migrateContract (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContract",
                value
            };
        }
    },
    fromPartial: {
        storeCode (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgStoreCode",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgStoreCode"].fromPartial(value)
            };
        },
        removeChecksum (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgRemoveChecksum",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRemoveChecksum"].fromPartial(value)
            };
        },
        migrateContract (value) {
            return {
                typeUrl: "/ibc.lightclients.wasm.v1.MsgMigrateContract",
                value: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMigrateContract"].fromPartial(value)
            };
        }
    }
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/query.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getChecksums": (()=>getChecksums),
    "getCode": (()=>getCode)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/query.js [app-client] (ecmascript)");
;
;
const getChecksums = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryChecksumsRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryChecksumsResponse"].decode,
    service: "ibc.lightclients.wasm.v1.Query",
    method: "Checksums",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryChecksumsRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryChecksumsResponse"]
    ]
});
const getCode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildQuery"])({
    encode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCodeRequest"].encode,
    decode: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCodeResponse"].decode,
    service: "ibc.lightclients.wasm.v1.Query",
    method: "Code",
    deps: [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCodeRequest"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$query$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryCodeResponse"]
    ]
});
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/tx.rpc.func.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "migrateContract": (()=>migrateContract),
    "removeChecksum": (()=>removeChecksum),
    "storeCode": (()=>storeCode)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helper-func-types.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/ibc/lightclients/wasm/v1/tx.js [app-client] (ecmascript)");
;
;
const storeCode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgStoreCode"]
});
const removeChecksum = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgRemoveChecksum"]
});
const migrateContract = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helper$2d$func$2d$types$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildTx"])({
    msg: __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$ibc$2f$lightclients$2f$wasm$2f$v1$2f$tx$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MsgMigrateContract"]
});
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_ibc_lightclients_b54c8a72._.js.map