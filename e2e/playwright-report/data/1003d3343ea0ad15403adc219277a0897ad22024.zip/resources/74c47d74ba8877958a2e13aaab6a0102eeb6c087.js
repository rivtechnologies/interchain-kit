(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Any": (()=>Any)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseAny() {
    return {
        typeUrl: "",
        value: new Uint8Array()
    };
}
const Any = {
    typeUrl: "/google.protobuf.Any",
    is (o) {
        return o && (o.$typeUrl === Any.typeUrl || typeof o.typeUrl === "string" && (o.value instanceof Uint8Array || typeof o.value === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === Any.typeUrl || typeof o.type === "string" && (o.value instanceof Uint8Array || typeof o.value === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.typeUrl !== "") {
            writer.uint32(10).string(message.typeUrl);
        }
        if (message.value.length !== 0) {
            writer.uint32(18).bytes(message.value);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseAny();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.typeUrl = reader.string();
                    break;
                case 2:
                    message.value = reader.bytes();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseAny();
        message.typeUrl = object.typeUrl ?? "";
        message.value = object.value ?? new Uint8Array();
        return message;
    },
    fromAmino (object) {
        return {
            typeUrl: object.type,
            value: object.value
        };
    },
    toAmino (message) {
        const obj = {};
        obj.type = message.typeUrl;
        obj.value = message.value;
        return obj;
    },
    fromAminoMsg (object) {
        return Any.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return Any.decode(message.value);
    },
    toProto (message) {
        return Any.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Any",
            value: Any.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Timestamp": (()=>Timestamp)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
;
;
function createBaseTimestamp() {
    return {
        seconds: BigInt(0),
        nanos: 0
    };
}
const Timestamp = {
    typeUrl: "/google.protobuf.Timestamp",
    is (o) {
        return o && (o.$typeUrl === Timestamp.typeUrl || typeof o.seconds === "bigint" && typeof o.nanos === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Timestamp.typeUrl || typeof o.seconds === "bigint" && typeof o.nanos === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.seconds !== BigInt(0)) {
            writer.uint32(8).int64(message.seconds);
        }
        if (message.nanos !== 0) {
            writer.uint32(16).int32(message.nanos);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseTimestamp();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.seconds = reader.int64();
                    break;
                case 2:
                    message.nanos = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseTimestamp();
        message.seconds = object.seconds !== undefined && object.seconds !== null ? BigInt(object.seconds.toString()) : BigInt(0);
        message.nanos = object.nanos ?? 0;
        return message;
    },
    fromAmino (object) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromJsonTimestamp"])(object);
    },
    toAmino (message) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromTimestamp"])(message).toISOString().replace(/\.\d+Z$/, "Z");
    },
    fromAminoMsg (object) {
        return Timestamp.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return Timestamp.decode(message.value);
    },
    toProto (message) {
        return Timestamp.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Timestamp",
            value: Timestamp.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Duration": (()=>Duration)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
;
function createBaseDuration() {
    return {
        seconds: BigInt(0),
        nanos: 0
    };
}
const Duration = {
    typeUrl: "/google.protobuf.Duration",
    is (o) {
        return o && (o.$typeUrl === Duration.typeUrl || typeof o.seconds === "bigint" && typeof o.nanos === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Duration.typeUrl || typeof o.seconds === "bigint" && typeof o.nanos === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.seconds !== BigInt(0)) {
            writer.uint32(8).int64(message.seconds);
        }
        if (message.nanos !== 0) {
            writer.uint32(16).int32(message.nanos);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDuration();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.seconds = reader.int64();
                    break;
                case 2:
                    message.nanos = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDuration();
        message.seconds = object.seconds !== undefined && object.seconds !== null ? BigInt(object.seconds.toString()) : BigInt(0);
        message.nanos = object.nanos ?? 0;
        return message;
    },
    fromAmino (object) {
        const value = BigInt(object);
        return {
            seconds: value / BigInt("1000000000"),
            nanos: Number(value % BigInt("1000000000"))
        };
    },
    toAmino (message) {
        return (message.seconds * BigInt("1000000000") + BigInt(message.nanos)).toString();
    },
    fromAminoMsg (object) {
        return Duration.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return Duration.decode(message.value);
    },
    toProto (message) {
        return Duration.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Duration",
            value: Duration.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/descriptor.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DescriptorProto": (()=>DescriptorProto),
    "DescriptorProto_ExtensionRange": (()=>DescriptorProto_ExtensionRange),
    "DescriptorProto_ReservedRange": (()=>DescriptorProto_ReservedRange),
    "Edition": (()=>Edition),
    "EditionAmino": (()=>EditionAmino),
    "EnumDescriptorProto": (()=>EnumDescriptorProto),
    "EnumDescriptorProto_EnumReservedRange": (()=>EnumDescriptorProto_EnumReservedRange),
    "EnumOptions": (()=>EnumOptions),
    "EnumValueDescriptorProto": (()=>EnumValueDescriptorProto),
    "EnumValueOptions": (()=>EnumValueOptions),
    "ExtensionRangeOptions": (()=>ExtensionRangeOptions),
    "ExtensionRangeOptions_Declaration": (()=>ExtensionRangeOptions_Declaration),
    "ExtensionRangeOptions_VerificationState": (()=>ExtensionRangeOptions_VerificationState),
    "ExtensionRangeOptions_VerificationStateAmino": (()=>ExtensionRangeOptions_VerificationStateAmino),
    "FeatureSet": (()=>FeatureSet),
    "FeatureSetDefaults": (()=>FeatureSetDefaults),
    "FeatureSetDefaults_FeatureSetEditionDefault": (()=>FeatureSetDefaults_FeatureSetEditionDefault),
    "FeatureSet_EnumType": (()=>FeatureSet_EnumType),
    "FeatureSet_EnumTypeAmino": (()=>FeatureSet_EnumTypeAmino),
    "FeatureSet_FieldPresence": (()=>FeatureSet_FieldPresence),
    "FeatureSet_FieldPresenceAmino": (()=>FeatureSet_FieldPresenceAmino),
    "FeatureSet_JsonFormat": (()=>FeatureSet_JsonFormat),
    "FeatureSet_JsonFormatAmino": (()=>FeatureSet_JsonFormatAmino),
    "FeatureSet_MessageEncoding": (()=>FeatureSet_MessageEncoding),
    "FeatureSet_MessageEncodingAmino": (()=>FeatureSet_MessageEncodingAmino),
    "FeatureSet_RepeatedFieldEncoding": (()=>FeatureSet_RepeatedFieldEncoding),
    "FeatureSet_RepeatedFieldEncodingAmino": (()=>FeatureSet_RepeatedFieldEncodingAmino),
    "FeatureSet_Utf8Validation": (()=>FeatureSet_Utf8Validation),
    "FeatureSet_Utf8ValidationAmino": (()=>FeatureSet_Utf8ValidationAmino),
    "FieldDescriptorProto": (()=>FieldDescriptorProto),
    "FieldDescriptorProto_Label": (()=>FieldDescriptorProto_Label),
    "FieldDescriptorProto_LabelAmino": (()=>FieldDescriptorProto_LabelAmino),
    "FieldDescriptorProto_Type": (()=>FieldDescriptorProto_Type),
    "FieldDescriptorProto_TypeAmino": (()=>FieldDescriptorProto_TypeAmino),
    "FieldOptions": (()=>FieldOptions),
    "FieldOptions_CType": (()=>FieldOptions_CType),
    "FieldOptions_CTypeAmino": (()=>FieldOptions_CTypeAmino),
    "FieldOptions_EditionDefault": (()=>FieldOptions_EditionDefault),
    "FieldOptions_FeatureSupport": (()=>FieldOptions_FeatureSupport),
    "FieldOptions_JSType": (()=>FieldOptions_JSType),
    "FieldOptions_JSTypeAmino": (()=>FieldOptions_JSTypeAmino),
    "FieldOptions_OptionRetention": (()=>FieldOptions_OptionRetention),
    "FieldOptions_OptionRetentionAmino": (()=>FieldOptions_OptionRetentionAmino),
    "FieldOptions_OptionTargetType": (()=>FieldOptions_OptionTargetType),
    "FieldOptions_OptionTargetTypeAmino": (()=>FieldOptions_OptionTargetTypeAmino),
    "FileDescriptorProto": (()=>FileDescriptorProto),
    "FileDescriptorSet": (()=>FileDescriptorSet),
    "FileOptions": (()=>FileOptions),
    "FileOptions_OptimizeMode": (()=>FileOptions_OptimizeMode),
    "FileOptions_OptimizeModeAmino": (()=>FileOptions_OptimizeModeAmino),
    "GeneratedCodeInfo": (()=>GeneratedCodeInfo),
    "GeneratedCodeInfo_Annotation": (()=>GeneratedCodeInfo_Annotation),
    "GeneratedCodeInfo_Annotation_Semantic": (()=>GeneratedCodeInfo_Annotation_Semantic),
    "GeneratedCodeInfo_Annotation_SemanticAmino": (()=>GeneratedCodeInfo_Annotation_SemanticAmino),
    "MessageOptions": (()=>MessageOptions),
    "MethodDescriptorProto": (()=>MethodDescriptorProto),
    "MethodOptions": (()=>MethodOptions),
    "MethodOptions_IdempotencyLevel": (()=>MethodOptions_IdempotencyLevel),
    "MethodOptions_IdempotencyLevelAmino": (()=>MethodOptions_IdempotencyLevelAmino),
    "OneofDescriptorProto": (()=>OneofDescriptorProto),
    "OneofOptions": (()=>OneofOptions),
    "ServiceDescriptorProto": (()=>ServiceDescriptorProto),
    "ServiceOptions": (()=>ServiceOptions),
    "SourceCodeInfo": (()=>SourceCodeInfo),
    "SourceCodeInfo_Location": (()=>SourceCodeInfo_Location),
    "UninterpretedOption": (()=>UninterpretedOption),
    "UninterpretedOption_NamePart": (()=>UninterpretedOption_NamePart),
    "editionFromJSON": (()=>editionFromJSON),
    "editionToJSON": (()=>editionToJSON),
    "extensionRangeOptions_VerificationStateFromJSON": (()=>extensionRangeOptions_VerificationStateFromJSON),
    "extensionRangeOptions_VerificationStateToJSON": (()=>extensionRangeOptions_VerificationStateToJSON),
    "featureSet_EnumTypeFromJSON": (()=>featureSet_EnumTypeFromJSON),
    "featureSet_EnumTypeToJSON": (()=>featureSet_EnumTypeToJSON),
    "featureSet_FieldPresenceFromJSON": (()=>featureSet_FieldPresenceFromJSON),
    "featureSet_FieldPresenceToJSON": (()=>featureSet_FieldPresenceToJSON),
    "featureSet_JsonFormatFromJSON": (()=>featureSet_JsonFormatFromJSON),
    "featureSet_JsonFormatToJSON": (()=>featureSet_JsonFormatToJSON),
    "featureSet_MessageEncodingFromJSON": (()=>featureSet_MessageEncodingFromJSON),
    "featureSet_MessageEncodingToJSON": (()=>featureSet_MessageEncodingToJSON),
    "featureSet_RepeatedFieldEncodingFromJSON": (()=>featureSet_RepeatedFieldEncodingFromJSON),
    "featureSet_RepeatedFieldEncodingToJSON": (()=>featureSet_RepeatedFieldEncodingToJSON),
    "featureSet_Utf8ValidationFromJSON": (()=>featureSet_Utf8ValidationFromJSON),
    "featureSet_Utf8ValidationToJSON": (()=>featureSet_Utf8ValidationToJSON),
    "fieldDescriptorProto_LabelFromJSON": (()=>fieldDescriptorProto_LabelFromJSON),
    "fieldDescriptorProto_LabelToJSON": (()=>fieldDescriptorProto_LabelToJSON),
    "fieldDescriptorProto_TypeFromJSON": (()=>fieldDescriptorProto_TypeFromJSON),
    "fieldDescriptorProto_TypeToJSON": (()=>fieldDescriptorProto_TypeToJSON),
    "fieldOptions_CTypeFromJSON": (()=>fieldOptions_CTypeFromJSON),
    "fieldOptions_CTypeToJSON": (()=>fieldOptions_CTypeToJSON),
    "fieldOptions_JSTypeFromJSON": (()=>fieldOptions_JSTypeFromJSON),
    "fieldOptions_JSTypeToJSON": (()=>fieldOptions_JSTypeToJSON),
    "fieldOptions_OptionRetentionFromJSON": (()=>fieldOptions_OptionRetentionFromJSON),
    "fieldOptions_OptionRetentionToJSON": (()=>fieldOptions_OptionRetentionToJSON),
    "fieldOptions_OptionTargetTypeFromJSON": (()=>fieldOptions_OptionTargetTypeFromJSON),
    "fieldOptions_OptionTargetTypeToJSON": (()=>fieldOptions_OptionTargetTypeToJSON),
    "fileOptions_OptimizeModeFromJSON": (()=>fileOptions_OptimizeModeFromJSON),
    "fileOptions_OptimizeModeToJSON": (()=>fileOptions_OptimizeModeToJSON),
    "generatedCodeInfo_Annotation_SemanticFromJSON": (()=>generatedCodeInfo_Annotation_SemanticFromJSON),
    "generatedCodeInfo_Annotation_SemanticToJSON": (()=>generatedCodeInfo_Annotation_SemanticToJSON),
    "methodOptions_IdempotencyLevelFromJSON": (()=>methodOptions_IdempotencyLevelFromJSON),
    "methodOptions_IdempotencyLevelToJSON": (()=>methodOptions_IdempotencyLevelToJSON)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
;
var Edition;
(function(Edition) {
    /** EDITION_UNKNOWN - A placeholder for an unknown edition value. */ Edition[Edition["EDITION_UNKNOWN"] = 0] = "EDITION_UNKNOWN";
    /**
     * EDITION_LEGACY - A placeholder edition for specifying default behaviors *before* a feature
     * was first introduced.  This is effectively an "infinite past".
     */ Edition[Edition["EDITION_LEGACY"] = 900] = "EDITION_LEGACY";
    /**
     * EDITION_PROTO2 - Legacy syntax "editions".  These pre-date editions, but behave much like
     * distinct editions.  These can't be used to specify the edition of proto
     * files, but feature definitions must supply proto2/proto3 defaults for
     * backwards compatibility.
     */ Edition[Edition["EDITION_PROTO2"] = 998] = "EDITION_PROTO2";
    Edition[Edition["EDITION_PROTO3"] = 999] = "EDITION_PROTO3";
    /**
     * EDITION_2023 - Editions that have been released.  The specific values are arbitrary and
     * should not be depended on, but they will always be time-ordered for easy
     * comparison.
     */ Edition[Edition["EDITION_2023"] = 1000] = "EDITION_2023";
    Edition[Edition["EDITION_2024"] = 1001] = "EDITION_2024";
    /**
     * EDITION_1_TEST_ONLY - Placeholder editions for testing feature resolution.  These should not be
     * used or relied on outside of tests.
     */ Edition[Edition["EDITION_1_TEST_ONLY"] = 1] = "EDITION_1_TEST_ONLY";
    Edition[Edition["EDITION_2_TEST_ONLY"] = 2] = "EDITION_2_TEST_ONLY";
    Edition[Edition["EDITION_99997_TEST_ONLY"] = 99997] = "EDITION_99997_TEST_ONLY";
    Edition[Edition["EDITION_99998_TEST_ONLY"] = 99998] = "EDITION_99998_TEST_ONLY";
    Edition[Edition["EDITION_99999_TEST_ONLY"] = 99999] = "EDITION_99999_TEST_ONLY";
    /**
     * EDITION_MAX - Placeholder for specifying unbounded edition support.  This should only
     * ever be used by plugins that can expect to never require any changes to
     * support a new edition.
     */ Edition[Edition["EDITION_MAX"] = 2147483647] = "EDITION_MAX";
    Edition[Edition["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(Edition || (Edition = {}));
const EditionAmino = Edition;
function editionFromJSON(object) {
    switch(object){
        case 0:
        case "EDITION_UNKNOWN":
            return Edition.EDITION_UNKNOWN;
        case 900:
        case "EDITION_LEGACY":
            return Edition.EDITION_LEGACY;
        case 998:
        case "EDITION_PROTO2":
            return Edition.EDITION_PROTO2;
        case 999:
        case "EDITION_PROTO3":
            return Edition.EDITION_PROTO3;
        case 1000:
        case "EDITION_2023":
            return Edition.EDITION_2023;
        case 1001:
        case "EDITION_2024":
            return Edition.EDITION_2024;
        case 1:
        case "EDITION_1_TEST_ONLY":
            return Edition.EDITION_1_TEST_ONLY;
        case 2:
        case "EDITION_2_TEST_ONLY":
            return Edition.EDITION_2_TEST_ONLY;
        case 99997:
        case "EDITION_99997_TEST_ONLY":
            return Edition.EDITION_99997_TEST_ONLY;
        case 99998:
        case "EDITION_99998_TEST_ONLY":
            return Edition.EDITION_99998_TEST_ONLY;
        case 99999:
        case "EDITION_99999_TEST_ONLY":
            return Edition.EDITION_99999_TEST_ONLY;
        case 2147483647:
        case "EDITION_MAX":
            return Edition.EDITION_MAX;
        case -1:
        case "UNRECOGNIZED":
        default:
            return Edition.UNRECOGNIZED;
    }
}
function editionToJSON(object) {
    switch(object){
        case Edition.EDITION_UNKNOWN:
            return "EDITION_UNKNOWN";
        case Edition.EDITION_LEGACY:
            return "EDITION_LEGACY";
        case Edition.EDITION_PROTO2:
            return "EDITION_PROTO2";
        case Edition.EDITION_PROTO3:
            return "EDITION_PROTO3";
        case Edition.EDITION_2023:
            return "EDITION_2023";
        case Edition.EDITION_2024:
            return "EDITION_2024";
        case Edition.EDITION_1_TEST_ONLY:
            return "EDITION_1_TEST_ONLY";
        case Edition.EDITION_2_TEST_ONLY:
            return "EDITION_2_TEST_ONLY";
        case Edition.EDITION_99997_TEST_ONLY:
            return "EDITION_99997_TEST_ONLY";
        case Edition.EDITION_99998_TEST_ONLY:
            return "EDITION_99998_TEST_ONLY";
        case Edition.EDITION_99999_TEST_ONLY:
            return "EDITION_99999_TEST_ONLY";
        case Edition.EDITION_MAX:
            return "EDITION_MAX";
        case Edition.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var ExtensionRangeOptions_VerificationState;
(function(ExtensionRangeOptions_VerificationState) {
    /** DECLARATION - All the extensions of the range must be declared. */ ExtensionRangeOptions_VerificationState[ExtensionRangeOptions_VerificationState["DECLARATION"] = 0] = "DECLARATION";
    ExtensionRangeOptions_VerificationState[ExtensionRangeOptions_VerificationState["UNVERIFIED"] = 1] = "UNVERIFIED";
    ExtensionRangeOptions_VerificationState[ExtensionRangeOptions_VerificationState["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(ExtensionRangeOptions_VerificationState || (ExtensionRangeOptions_VerificationState = {}));
const ExtensionRangeOptions_VerificationStateAmino = ExtensionRangeOptions_VerificationState;
function extensionRangeOptions_VerificationStateFromJSON(object) {
    switch(object){
        case 0:
        case "DECLARATION":
            return ExtensionRangeOptions_VerificationState.DECLARATION;
        case 1:
        case "UNVERIFIED":
            return ExtensionRangeOptions_VerificationState.UNVERIFIED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return ExtensionRangeOptions_VerificationState.UNRECOGNIZED;
    }
}
function extensionRangeOptions_VerificationStateToJSON(object) {
    switch(object){
        case ExtensionRangeOptions_VerificationState.DECLARATION:
            return "DECLARATION";
        case ExtensionRangeOptions_VerificationState.UNVERIFIED:
            return "UNVERIFIED";
        case ExtensionRangeOptions_VerificationState.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldDescriptorProto_Type;
(function(FieldDescriptorProto_Type) {
    /**
     * TYPE_DOUBLE - 0 is reserved for errors.
     * Order is weird for historical reasons.
     */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_DOUBLE"] = 1] = "TYPE_DOUBLE";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_FLOAT"] = 2] = "TYPE_FLOAT";
    /**
     * TYPE_INT64 - Not ZigZag encoded.  Negative numbers take 10 bytes.  Use TYPE_SINT64 if
     * negative values are likely.
     */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_INT64"] = 3] = "TYPE_INT64";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_UINT64"] = 4] = "TYPE_UINT64";
    /**
     * TYPE_INT32 - Not ZigZag encoded.  Negative numbers take 10 bytes.  Use TYPE_SINT32 if
     * negative values are likely.
     */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_INT32"] = 5] = "TYPE_INT32";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_FIXED64"] = 6] = "TYPE_FIXED64";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_FIXED32"] = 7] = "TYPE_FIXED32";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_BOOL"] = 8] = "TYPE_BOOL";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_STRING"] = 9] = "TYPE_STRING";
    /**
     * TYPE_GROUP - Tag-delimited aggregate.
     * Group type is deprecated and not supported after google.protobuf. However, Proto3
     * implementations should still be able to parse the group wire format and
     * treat group fields as unknown fields.  In Editions, the group wire format
     * can be enabled via the `message_encoding` feature.
     */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_GROUP"] = 10] = "TYPE_GROUP";
    /** TYPE_MESSAGE - Length-delimited aggregate. */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_MESSAGE"] = 11] = "TYPE_MESSAGE";
    /** TYPE_BYTES - New in version 2. */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_BYTES"] = 12] = "TYPE_BYTES";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_UINT32"] = 13] = "TYPE_UINT32";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_ENUM"] = 14] = "TYPE_ENUM";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_SFIXED32"] = 15] = "TYPE_SFIXED32";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_SFIXED64"] = 16] = "TYPE_SFIXED64";
    /** TYPE_SINT32 - Uses ZigZag encoding. */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_SINT32"] = 17] = "TYPE_SINT32";
    /** TYPE_SINT64 - Uses ZigZag encoding. */ FieldDescriptorProto_Type[FieldDescriptorProto_Type["TYPE_SINT64"] = 18] = "TYPE_SINT64";
    FieldDescriptorProto_Type[FieldDescriptorProto_Type["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldDescriptorProto_Type || (FieldDescriptorProto_Type = {}));
const FieldDescriptorProto_TypeAmino = FieldDescriptorProto_Type;
function fieldDescriptorProto_TypeFromJSON(object) {
    switch(object){
        case 1:
        case "TYPE_DOUBLE":
            return FieldDescriptorProto_Type.TYPE_DOUBLE;
        case 2:
        case "TYPE_FLOAT":
            return FieldDescriptorProto_Type.TYPE_FLOAT;
        case 3:
        case "TYPE_INT64":
            return FieldDescriptorProto_Type.TYPE_INT64;
        case 4:
        case "TYPE_UINT64":
            return FieldDescriptorProto_Type.TYPE_UINT64;
        case 5:
        case "TYPE_INT32":
            return FieldDescriptorProto_Type.TYPE_INT32;
        case 6:
        case "TYPE_FIXED64":
            return FieldDescriptorProto_Type.TYPE_FIXED64;
        case 7:
        case "TYPE_FIXED32":
            return FieldDescriptorProto_Type.TYPE_FIXED32;
        case 8:
        case "TYPE_BOOL":
            return FieldDescriptorProto_Type.TYPE_BOOL;
        case 9:
        case "TYPE_STRING":
            return FieldDescriptorProto_Type.TYPE_STRING;
        case 10:
        case "TYPE_GROUP":
            return FieldDescriptorProto_Type.TYPE_GROUP;
        case 11:
        case "TYPE_MESSAGE":
            return FieldDescriptorProto_Type.TYPE_MESSAGE;
        case 12:
        case "TYPE_BYTES":
            return FieldDescriptorProto_Type.TYPE_BYTES;
        case 13:
        case "TYPE_UINT32":
            return FieldDescriptorProto_Type.TYPE_UINT32;
        case 14:
        case "TYPE_ENUM":
            return FieldDescriptorProto_Type.TYPE_ENUM;
        case 15:
        case "TYPE_SFIXED32":
            return FieldDescriptorProto_Type.TYPE_SFIXED32;
        case 16:
        case "TYPE_SFIXED64":
            return FieldDescriptorProto_Type.TYPE_SFIXED64;
        case 17:
        case "TYPE_SINT32":
            return FieldDescriptorProto_Type.TYPE_SINT32;
        case 18:
        case "TYPE_SINT64":
            return FieldDescriptorProto_Type.TYPE_SINT64;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldDescriptorProto_Type.UNRECOGNIZED;
    }
}
function fieldDescriptorProto_TypeToJSON(object) {
    switch(object){
        case FieldDescriptorProto_Type.TYPE_DOUBLE:
            return "TYPE_DOUBLE";
        case FieldDescriptorProto_Type.TYPE_FLOAT:
            return "TYPE_FLOAT";
        case FieldDescriptorProto_Type.TYPE_INT64:
            return "TYPE_INT64";
        case FieldDescriptorProto_Type.TYPE_UINT64:
            return "TYPE_UINT64";
        case FieldDescriptorProto_Type.TYPE_INT32:
            return "TYPE_INT32";
        case FieldDescriptorProto_Type.TYPE_FIXED64:
            return "TYPE_FIXED64";
        case FieldDescriptorProto_Type.TYPE_FIXED32:
            return "TYPE_FIXED32";
        case FieldDescriptorProto_Type.TYPE_BOOL:
            return "TYPE_BOOL";
        case FieldDescriptorProto_Type.TYPE_STRING:
            return "TYPE_STRING";
        case FieldDescriptorProto_Type.TYPE_GROUP:
            return "TYPE_GROUP";
        case FieldDescriptorProto_Type.TYPE_MESSAGE:
            return "TYPE_MESSAGE";
        case FieldDescriptorProto_Type.TYPE_BYTES:
            return "TYPE_BYTES";
        case FieldDescriptorProto_Type.TYPE_UINT32:
            return "TYPE_UINT32";
        case FieldDescriptorProto_Type.TYPE_ENUM:
            return "TYPE_ENUM";
        case FieldDescriptorProto_Type.TYPE_SFIXED32:
            return "TYPE_SFIXED32";
        case FieldDescriptorProto_Type.TYPE_SFIXED64:
            return "TYPE_SFIXED64";
        case FieldDescriptorProto_Type.TYPE_SINT32:
            return "TYPE_SINT32";
        case FieldDescriptorProto_Type.TYPE_SINT64:
            return "TYPE_SINT64";
        case FieldDescriptorProto_Type.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldDescriptorProto_Label;
(function(FieldDescriptorProto_Label) {
    /** LABEL_OPTIONAL - 0 is reserved for errors */ FieldDescriptorProto_Label[FieldDescriptorProto_Label["LABEL_OPTIONAL"] = 1] = "LABEL_OPTIONAL";
    FieldDescriptorProto_Label[FieldDescriptorProto_Label["LABEL_REPEATED"] = 3] = "LABEL_REPEATED";
    /**
     * LABEL_REQUIRED - The required label is only allowed in google.protobuf.  In proto3 and Editions
     * it's explicitly prohibited.  In Editions, the `field_presence` feature
     * can be used to get this behavior.
     */ FieldDescriptorProto_Label[FieldDescriptorProto_Label["LABEL_REQUIRED"] = 2] = "LABEL_REQUIRED";
    FieldDescriptorProto_Label[FieldDescriptorProto_Label["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldDescriptorProto_Label || (FieldDescriptorProto_Label = {}));
const FieldDescriptorProto_LabelAmino = FieldDescriptorProto_Label;
function fieldDescriptorProto_LabelFromJSON(object) {
    switch(object){
        case 1:
        case "LABEL_OPTIONAL":
            return FieldDescriptorProto_Label.LABEL_OPTIONAL;
        case 3:
        case "LABEL_REPEATED":
            return FieldDescriptorProto_Label.LABEL_REPEATED;
        case 2:
        case "LABEL_REQUIRED":
            return FieldDescriptorProto_Label.LABEL_REQUIRED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldDescriptorProto_Label.UNRECOGNIZED;
    }
}
function fieldDescriptorProto_LabelToJSON(object) {
    switch(object){
        case FieldDescriptorProto_Label.LABEL_OPTIONAL:
            return "LABEL_OPTIONAL";
        case FieldDescriptorProto_Label.LABEL_REPEATED:
            return "LABEL_REPEATED";
        case FieldDescriptorProto_Label.LABEL_REQUIRED:
            return "LABEL_REQUIRED";
        case FieldDescriptorProto_Label.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FileOptions_OptimizeMode;
(function(FileOptions_OptimizeMode) {
    /** SPEED - Generate complete code for parsing, serialization, */ FileOptions_OptimizeMode[FileOptions_OptimizeMode["SPEED"] = 1] = "SPEED";
    /** CODE_SIZE - etc. */ FileOptions_OptimizeMode[FileOptions_OptimizeMode["CODE_SIZE"] = 2] = "CODE_SIZE";
    /** LITE_RUNTIME - Generate code using MessageLite and the lite runtime. */ FileOptions_OptimizeMode[FileOptions_OptimizeMode["LITE_RUNTIME"] = 3] = "LITE_RUNTIME";
    FileOptions_OptimizeMode[FileOptions_OptimizeMode["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FileOptions_OptimizeMode || (FileOptions_OptimizeMode = {}));
const FileOptions_OptimizeModeAmino = FileOptions_OptimizeMode;
function fileOptions_OptimizeModeFromJSON(object) {
    switch(object){
        case 1:
        case "SPEED":
            return FileOptions_OptimizeMode.SPEED;
        case 2:
        case "CODE_SIZE":
            return FileOptions_OptimizeMode.CODE_SIZE;
        case 3:
        case "LITE_RUNTIME":
            return FileOptions_OptimizeMode.LITE_RUNTIME;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FileOptions_OptimizeMode.UNRECOGNIZED;
    }
}
function fileOptions_OptimizeModeToJSON(object) {
    switch(object){
        case FileOptions_OptimizeMode.SPEED:
            return "SPEED";
        case FileOptions_OptimizeMode.CODE_SIZE:
            return "CODE_SIZE";
        case FileOptions_OptimizeMode.LITE_RUNTIME:
            return "LITE_RUNTIME";
        case FileOptions_OptimizeMode.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldOptions_CType;
(function(FieldOptions_CType) {
    /** STRING - Default mode. */ FieldOptions_CType[FieldOptions_CType["STRING"] = 0] = "STRING";
    /**
     * CORD - The option [ctype=CORD] may be applied to a non-repeated field of type
     * "bytes". It indicates that in C++, the data should be stored in a Cord
     * instead of a string.  For very large strings, this may reduce memory
     * fragmentation. It may also allow better performance when parsing from a
     * Cord, or when parsing with aliasing enabled, as the parsed Cord may then
     * alias the original buffer.
     */ FieldOptions_CType[FieldOptions_CType["CORD"] = 1] = "CORD";
    FieldOptions_CType[FieldOptions_CType["STRING_PIECE"] = 2] = "STRING_PIECE";
    FieldOptions_CType[FieldOptions_CType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldOptions_CType || (FieldOptions_CType = {}));
const FieldOptions_CTypeAmino = FieldOptions_CType;
function fieldOptions_CTypeFromJSON(object) {
    switch(object){
        case 0:
        case "STRING":
            return FieldOptions_CType.STRING;
        case 1:
        case "CORD":
            return FieldOptions_CType.CORD;
        case 2:
        case "STRING_PIECE":
            return FieldOptions_CType.STRING_PIECE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldOptions_CType.UNRECOGNIZED;
    }
}
function fieldOptions_CTypeToJSON(object) {
    switch(object){
        case FieldOptions_CType.STRING:
            return "STRING";
        case FieldOptions_CType.CORD:
            return "CORD";
        case FieldOptions_CType.STRING_PIECE:
            return "STRING_PIECE";
        case FieldOptions_CType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldOptions_JSType;
(function(FieldOptions_JSType) {
    /** JS_NORMAL - Use the default type. */ FieldOptions_JSType[FieldOptions_JSType["JS_NORMAL"] = 0] = "JS_NORMAL";
    /** JS_STRING - Use JavaScript strings. */ FieldOptions_JSType[FieldOptions_JSType["JS_STRING"] = 1] = "JS_STRING";
    /** JS_NUMBER - Use JavaScript numbers. */ FieldOptions_JSType[FieldOptions_JSType["JS_NUMBER"] = 2] = "JS_NUMBER";
    FieldOptions_JSType[FieldOptions_JSType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldOptions_JSType || (FieldOptions_JSType = {}));
const FieldOptions_JSTypeAmino = FieldOptions_JSType;
function fieldOptions_JSTypeFromJSON(object) {
    switch(object){
        case 0:
        case "JS_NORMAL":
            return FieldOptions_JSType.JS_NORMAL;
        case 1:
        case "JS_STRING":
            return FieldOptions_JSType.JS_STRING;
        case 2:
        case "JS_NUMBER":
            return FieldOptions_JSType.JS_NUMBER;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldOptions_JSType.UNRECOGNIZED;
    }
}
function fieldOptions_JSTypeToJSON(object) {
    switch(object){
        case FieldOptions_JSType.JS_NORMAL:
            return "JS_NORMAL";
        case FieldOptions_JSType.JS_STRING:
            return "JS_STRING";
        case FieldOptions_JSType.JS_NUMBER:
            return "JS_NUMBER";
        case FieldOptions_JSType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldOptions_OptionRetention;
(function(FieldOptions_OptionRetention) {
    FieldOptions_OptionRetention[FieldOptions_OptionRetention["RETENTION_UNKNOWN"] = 0] = "RETENTION_UNKNOWN";
    FieldOptions_OptionRetention[FieldOptions_OptionRetention["RETENTION_RUNTIME"] = 1] = "RETENTION_RUNTIME";
    FieldOptions_OptionRetention[FieldOptions_OptionRetention["RETENTION_SOURCE"] = 2] = "RETENTION_SOURCE";
    FieldOptions_OptionRetention[FieldOptions_OptionRetention["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldOptions_OptionRetention || (FieldOptions_OptionRetention = {}));
const FieldOptions_OptionRetentionAmino = FieldOptions_OptionRetention;
function fieldOptions_OptionRetentionFromJSON(object) {
    switch(object){
        case 0:
        case "RETENTION_UNKNOWN":
            return FieldOptions_OptionRetention.RETENTION_UNKNOWN;
        case 1:
        case "RETENTION_RUNTIME":
            return FieldOptions_OptionRetention.RETENTION_RUNTIME;
        case 2:
        case "RETENTION_SOURCE":
            return FieldOptions_OptionRetention.RETENTION_SOURCE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldOptions_OptionRetention.UNRECOGNIZED;
    }
}
function fieldOptions_OptionRetentionToJSON(object) {
    switch(object){
        case FieldOptions_OptionRetention.RETENTION_UNKNOWN:
            return "RETENTION_UNKNOWN";
        case FieldOptions_OptionRetention.RETENTION_RUNTIME:
            return "RETENTION_RUNTIME";
        case FieldOptions_OptionRetention.RETENTION_SOURCE:
            return "RETENTION_SOURCE";
        case FieldOptions_OptionRetention.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FieldOptions_OptionTargetType;
(function(FieldOptions_OptionTargetType) {
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_UNKNOWN"] = 0] = "TARGET_TYPE_UNKNOWN";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_FILE"] = 1] = "TARGET_TYPE_FILE";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_EXTENSION_RANGE"] = 2] = "TARGET_TYPE_EXTENSION_RANGE";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_MESSAGE"] = 3] = "TARGET_TYPE_MESSAGE";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_FIELD"] = 4] = "TARGET_TYPE_FIELD";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_ONEOF"] = 5] = "TARGET_TYPE_ONEOF";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_ENUM"] = 6] = "TARGET_TYPE_ENUM";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_ENUM_ENTRY"] = 7] = "TARGET_TYPE_ENUM_ENTRY";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_SERVICE"] = 8] = "TARGET_TYPE_SERVICE";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["TARGET_TYPE_METHOD"] = 9] = "TARGET_TYPE_METHOD";
    FieldOptions_OptionTargetType[FieldOptions_OptionTargetType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FieldOptions_OptionTargetType || (FieldOptions_OptionTargetType = {}));
const FieldOptions_OptionTargetTypeAmino = FieldOptions_OptionTargetType;
function fieldOptions_OptionTargetTypeFromJSON(object) {
    switch(object){
        case 0:
        case "TARGET_TYPE_UNKNOWN":
            return FieldOptions_OptionTargetType.TARGET_TYPE_UNKNOWN;
        case 1:
        case "TARGET_TYPE_FILE":
            return FieldOptions_OptionTargetType.TARGET_TYPE_FILE;
        case 2:
        case "TARGET_TYPE_EXTENSION_RANGE":
            return FieldOptions_OptionTargetType.TARGET_TYPE_EXTENSION_RANGE;
        case 3:
        case "TARGET_TYPE_MESSAGE":
            return FieldOptions_OptionTargetType.TARGET_TYPE_MESSAGE;
        case 4:
        case "TARGET_TYPE_FIELD":
            return FieldOptions_OptionTargetType.TARGET_TYPE_FIELD;
        case 5:
        case "TARGET_TYPE_ONEOF":
            return FieldOptions_OptionTargetType.TARGET_TYPE_ONEOF;
        case 6:
        case "TARGET_TYPE_ENUM":
            return FieldOptions_OptionTargetType.TARGET_TYPE_ENUM;
        case 7:
        case "TARGET_TYPE_ENUM_ENTRY":
            return FieldOptions_OptionTargetType.TARGET_TYPE_ENUM_ENTRY;
        case 8:
        case "TARGET_TYPE_SERVICE":
            return FieldOptions_OptionTargetType.TARGET_TYPE_SERVICE;
        case 9:
        case "TARGET_TYPE_METHOD":
            return FieldOptions_OptionTargetType.TARGET_TYPE_METHOD;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FieldOptions_OptionTargetType.UNRECOGNIZED;
    }
}
function fieldOptions_OptionTargetTypeToJSON(object) {
    switch(object){
        case FieldOptions_OptionTargetType.TARGET_TYPE_UNKNOWN:
            return "TARGET_TYPE_UNKNOWN";
        case FieldOptions_OptionTargetType.TARGET_TYPE_FILE:
            return "TARGET_TYPE_FILE";
        case FieldOptions_OptionTargetType.TARGET_TYPE_EXTENSION_RANGE:
            return "TARGET_TYPE_EXTENSION_RANGE";
        case FieldOptions_OptionTargetType.TARGET_TYPE_MESSAGE:
            return "TARGET_TYPE_MESSAGE";
        case FieldOptions_OptionTargetType.TARGET_TYPE_FIELD:
            return "TARGET_TYPE_FIELD";
        case FieldOptions_OptionTargetType.TARGET_TYPE_ONEOF:
            return "TARGET_TYPE_ONEOF";
        case FieldOptions_OptionTargetType.TARGET_TYPE_ENUM:
            return "TARGET_TYPE_ENUM";
        case FieldOptions_OptionTargetType.TARGET_TYPE_ENUM_ENTRY:
            return "TARGET_TYPE_ENUM_ENTRY";
        case FieldOptions_OptionTargetType.TARGET_TYPE_SERVICE:
            return "TARGET_TYPE_SERVICE";
        case FieldOptions_OptionTargetType.TARGET_TYPE_METHOD:
            return "TARGET_TYPE_METHOD";
        case FieldOptions_OptionTargetType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var MethodOptions_IdempotencyLevel;
(function(MethodOptions_IdempotencyLevel) {
    MethodOptions_IdempotencyLevel[MethodOptions_IdempotencyLevel["IDEMPOTENCY_UNKNOWN"] = 0] = "IDEMPOTENCY_UNKNOWN";
    /** NO_SIDE_EFFECTS - implies idempotent */ MethodOptions_IdempotencyLevel[MethodOptions_IdempotencyLevel["NO_SIDE_EFFECTS"] = 1] = "NO_SIDE_EFFECTS";
    /** IDEMPOTENT - idempotent, but may have side effects */ MethodOptions_IdempotencyLevel[MethodOptions_IdempotencyLevel["IDEMPOTENT"] = 2] = "IDEMPOTENT";
    MethodOptions_IdempotencyLevel[MethodOptions_IdempotencyLevel["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(MethodOptions_IdempotencyLevel || (MethodOptions_IdempotencyLevel = {}));
const MethodOptions_IdempotencyLevelAmino = MethodOptions_IdempotencyLevel;
function methodOptions_IdempotencyLevelFromJSON(object) {
    switch(object){
        case 0:
        case "IDEMPOTENCY_UNKNOWN":
            return MethodOptions_IdempotencyLevel.IDEMPOTENCY_UNKNOWN;
        case 1:
        case "NO_SIDE_EFFECTS":
            return MethodOptions_IdempotencyLevel.NO_SIDE_EFFECTS;
        case 2:
        case "IDEMPOTENT":
            return MethodOptions_IdempotencyLevel.IDEMPOTENT;
        case -1:
        case "UNRECOGNIZED":
        default:
            return MethodOptions_IdempotencyLevel.UNRECOGNIZED;
    }
}
function methodOptions_IdempotencyLevelToJSON(object) {
    switch(object){
        case MethodOptions_IdempotencyLevel.IDEMPOTENCY_UNKNOWN:
            return "IDEMPOTENCY_UNKNOWN";
        case MethodOptions_IdempotencyLevel.NO_SIDE_EFFECTS:
            return "NO_SIDE_EFFECTS";
        case MethodOptions_IdempotencyLevel.IDEMPOTENT:
            return "IDEMPOTENT";
        case MethodOptions_IdempotencyLevel.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_FieldPresence;
(function(FeatureSet_FieldPresence) {
    FeatureSet_FieldPresence[FeatureSet_FieldPresence["FIELD_PRESENCE_UNKNOWN"] = 0] = "FIELD_PRESENCE_UNKNOWN";
    FeatureSet_FieldPresence[FeatureSet_FieldPresence["EXPLICIT"] = 1] = "EXPLICIT";
    FeatureSet_FieldPresence[FeatureSet_FieldPresence["IMPLICIT"] = 2] = "IMPLICIT";
    FeatureSet_FieldPresence[FeatureSet_FieldPresence["LEGACY_REQUIRED"] = 3] = "LEGACY_REQUIRED";
    FeatureSet_FieldPresence[FeatureSet_FieldPresence["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_FieldPresence || (FeatureSet_FieldPresence = {}));
const FeatureSet_FieldPresenceAmino = FeatureSet_FieldPresence;
function featureSet_FieldPresenceFromJSON(object) {
    switch(object){
        case 0:
        case "FIELD_PRESENCE_UNKNOWN":
            return FeatureSet_FieldPresence.FIELD_PRESENCE_UNKNOWN;
        case 1:
        case "EXPLICIT":
            return FeatureSet_FieldPresence.EXPLICIT;
        case 2:
        case "IMPLICIT":
            return FeatureSet_FieldPresence.IMPLICIT;
        case 3:
        case "LEGACY_REQUIRED":
            return FeatureSet_FieldPresence.LEGACY_REQUIRED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_FieldPresence.UNRECOGNIZED;
    }
}
function featureSet_FieldPresenceToJSON(object) {
    switch(object){
        case FeatureSet_FieldPresence.FIELD_PRESENCE_UNKNOWN:
            return "FIELD_PRESENCE_UNKNOWN";
        case FeatureSet_FieldPresence.EXPLICIT:
            return "EXPLICIT";
        case FeatureSet_FieldPresence.IMPLICIT:
            return "IMPLICIT";
        case FeatureSet_FieldPresence.LEGACY_REQUIRED:
            return "LEGACY_REQUIRED";
        case FeatureSet_FieldPresence.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_EnumType;
(function(FeatureSet_EnumType) {
    FeatureSet_EnumType[FeatureSet_EnumType["ENUM_TYPE_UNKNOWN"] = 0] = "ENUM_TYPE_UNKNOWN";
    FeatureSet_EnumType[FeatureSet_EnumType["OPEN"] = 1] = "OPEN";
    FeatureSet_EnumType[FeatureSet_EnumType["CLOSED"] = 2] = "CLOSED";
    FeatureSet_EnumType[FeatureSet_EnumType["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_EnumType || (FeatureSet_EnumType = {}));
const FeatureSet_EnumTypeAmino = FeatureSet_EnumType;
function featureSet_EnumTypeFromJSON(object) {
    switch(object){
        case 0:
        case "ENUM_TYPE_UNKNOWN":
            return FeatureSet_EnumType.ENUM_TYPE_UNKNOWN;
        case 1:
        case "OPEN":
            return FeatureSet_EnumType.OPEN;
        case 2:
        case "CLOSED":
            return FeatureSet_EnumType.CLOSED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_EnumType.UNRECOGNIZED;
    }
}
function featureSet_EnumTypeToJSON(object) {
    switch(object){
        case FeatureSet_EnumType.ENUM_TYPE_UNKNOWN:
            return "ENUM_TYPE_UNKNOWN";
        case FeatureSet_EnumType.OPEN:
            return "OPEN";
        case FeatureSet_EnumType.CLOSED:
            return "CLOSED";
        case FeatureSet_EnumType.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_RepeatedFieldEncoding;
(function(FeatureSet_RepeatedFieldEncoding) {
    FeatureSet_RepeatedFieldEncoding[FeatureSet_RepeatedFieldEncoding["REPEATED_FIELD_ENCODING_UNKNOWN"] = 0] = "REPEATED_FIELD_ENCODING_UNKNOWN";
    FeatureSet_RepeatedFieldEncoding[FeatureSet_RepeatedFieldEncoding["PACKED"] = 1] = "PACKED";
    FeatureSet_RepeatedFieldEncoding[FeatureSet_RepeatedFieldEncoding["EXPANDED"] = 2] = "EXPANDED";
    FeatureSet_RepeatedFieldEncoding[FeatureSet_RepeatedFieldEncoding["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_RepeatedFieldEncoding || (FeatureSet_RepeatedFieldEncoding = {}));
const FeatureSet_RepeatedFieldEncodingAmino = FeatureSet_RepeatedFieldEncoding;
function featureSet_RepeatedFieldEncodingFromJSON(object) {
    switch(object){
        case 0:
        case "REPEATED_FIELD_ENCODING_UNKNOWN":
            return FeatureSet_RepeatedFieldEncoding.REPEATED_FIELD_ENCODING_UNKNOWN;
        case 1:
        case "PACKED":
            return FeatureSet_RepeatedFieldEncoding.PACKED;
        case 2:
        case "EXPANDED":
            return FeatureSet_RepeatedFieldEncoding.EXPANDED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_RepeatedFieldEncoding.UNRECOGNIZED;
    }
}
function featureSet_RepeatedFieldEncodingToJSON(object) {
    switch(object){
        case FeatureSet_RepeatedFieldEncoding.REPEATED_FIELD_ENCODING_UNKNOWN:
            return "REPEATED_FIELD_ENCODING_UNKNOWN";
        case FeatureSet_RepeatedFieldEncoding.PACKED:
            return "PACKED";
        case FeatureSet_RepeatedFieldEncoding.EXPANDED:
            return "EXPANDED";
        case FeatureSet_RepeatedFieldEncoding.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_Utf8Validation;
(function(FeatureSet_Utf8Validation) {
    FeatureSet_Utf8Validation[FeatureSet_Utf8Validation["UTF8_VALIDATION_UNKNOWN"] = 0] = "UTF8_VALIDATION_UNKNOWN";
    FeatureSet_Utf8Validation[FeatureSet_Utf8Validation["VERIFY"] = 2] = "VERIFY";
    FeatureSet_Utf8Validation[FeatureSet_Utf8Validation["NONE"] = 3] = "NONE";
    FeatureSet_Utf8Validation[FeatureSet_Utf8Validation["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_Utf8Validation || (FeatureSet_Utf8Validation = {}));
const FeatureSet_Utf8ValidationAmino = FeatureSet_Utf8Validation;
function featureSet_Utf8ValidationFromJSON(object) {
    switch(object){
        case 0:
        case "UTF8_VALIDATION_UNKNOWN":
            return FeatureSet_Utf8Validation.UTF8_VALIDATION_UNKNOWN;
        case 2:
        case "VERIFY":
            return FeatureSet_Utf8Validation.VERIFY;
        case 3:
        case "NONE":
            return FeatureSet_Utf8Validation.NONE;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_Utf8Validation.UNRECOGNIZED;
    }
}
function featureSet_Utf8ValidationToJSON(object) {
    switch(object){
        case FeatureSet_Utf8Validation.UTF8_VALIDATION_UNKNOWN:
            return "UTF8_VALIDATION_UNKNOWN";
        case FeatureSet_Utf8Validation.VERIFY:
            return "VERIFY";
        case FeatureSet_Utf8Validation.NONE:
            return "NONE";
        case FeatureSet_Utf8Validation.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_MessageEncoding;
(function(FeatureSet_MessageEncoding) {
    FeatureSet_MessageEncoding[FeatureSet_MessageEncoding["MESSAGE_ENCODING_UNKNOWN"] = 0] = "MESSAGE_ENCODING_UNKNOWN";
    FeatureSet_MessageEncoding[FeatureSet_MessageEncoding["LENGTH_PREFIXED"] = 1] = "LENGTH_PREFIXED";
    FeatureSet_MessageEncoding[FeatureSet_MessageEncoding["DELIMITED"] = 2] = "DELIMITED";
    FeatureSet_MessageEncoding[FeatureSet_MessageEncoding["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_MessageEncoding || (FeatureSet_MessageEncoding = {}));
const FeatureSet_MessageEncodingAmino = FeatureSet_MessageEncoding;
function featureSet_MessageEncodingFromJSON(object) {
    switch(object){
        case 0:
        case "MESSAGE_ENCODING_UNKNOWN":
            return FeatureSet_MessageEncoding.MESSAGE_ENCODING_UNKNOWN;
        case 1:
        case "LENGTH_PREFIXED":
            return FeatureSet_MessageEncoding.LENGTH_PREFIXED;
        case 2:
        case "DELIMITED":
            return FeatureSet_MessageEncoding.DELIMITED;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_MessageEncoding.UNRECOGNIZED;
    }
}
function featureSet_MessageEncodingToJSON(object) {
    switch(object){
        case FeatureSet_MessageEncoding.MESSAGE_ENCODING_UNKNOWN:
            return "MESSAGE_ENCODING_UNKNOWN";
        case FeatureSet_MessageEncoding.LENGTH_PREFIXED:
            return "LENGTH_PREFIXED";
        case FeatureSet_MessageEncoding.DELIMITED:
            return "DELIMITED";
        case FeatureSet_MessageEncoding.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var FeatureSet_JsonFormat;
(function(FeatureSet_JsonFormat) {
    FeatureSet_JsonFormat[FeatureSet_JsonFormat["JSON_FORMAT_UNKNOWN"] = 0] = "JSON_FORMAT_UNKNOWN";
    FeatureSet_JsonFormat[FeatureSet_JsonFormat["ALLOW"] = 1] = "ALLOW";
    FeatureSet_JsonFormat[FeatureSet_JsonFormat["LEGACY_BEST_EFFORT"] = 2] = "LEGACY_BEST_EFFORT";
    FeatureSet_JsonFormat[FeatureSet_JsonFormat["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(FeatureSet_JsonFormat || (FeatureSet_JsonFormat = {}));
const FeatureSet_JsonFormatAmino = FeatureSet_JsonFormat;
function featureSet_JsonFormatFromJSON(object) {
    switch(object){
        case 0:
        case "JSON_FORMAT_UNKNOWN":
            return FeatureSet_JsonFormat.JSON_FORMAT_UNKNOWN;
        case 1:
        case "ALLOW":
            return FeatureSet_JsonFormat.ALLOW;
        case 2:
        case "LEGACY_BEST_EFFORT":
            return FeatureSet_JsonFormat.LEGACY_BEST_EFFORT;
        case -1:
        case "UNRECOGNIZED":
        default:
            return FeatureSet_JsonFormat.UNRECOGNIZED;
    }
}
function featureSet_JsonFormatToJSON(object) {
    switch(object){
        case FeatureSet_JsonFormat.JSON_FORMAT_UNKNOWN:
            return "JSON_FORMAT_UNKNOWN";
        case FeatureSet_JsonFormat.ALLOW:
            return "ALLOW";
        case FeatureSet_JsonFormat.LEGACY_BEST_EFFORT:
            return "LEGACY_BEST_EFFORT";
        case FeatureSet_JsonFormat.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
var GeneratedCodeInfo_Annotation_Semantic;
(function(GeneratedCodeInfo_Annotation_Semantic) {
    /** NONE - There is no effect or the effect is indescribable. */ GeneratedCodeInfo_Annotation_Semantic[GeneratedCodeInfo_Annotation_Semantic["NONE"] = 0] = "NONE";
    /** SET - The element is set or otherwise mutated. */ GeneratedCodeInfo_Annotation_Semantic[GeneratedCodeInfo_Annotation_Semantic["SET"] = 1] = "SET";
    /** ALIAS - An alias to the element is returned. */ GeneratedCodeInfo_Annotation_Semantic[GeneratedCodeInfo_Annotation_Semantic["ALIAS"] = 2] = "ALIAS";
    GeneratedCodeInfo_Annotation_Semantic[GeneratedCodeInfo_Annotation_Semantic["UNRECOGNIZED"] = -1] = "UNRECOGNIZED";
})(GeneratedCodeInfo_Annotation_Semantic || (GeneratedCodeInfo_Annotation_Semantic = {}));
const GeneratedCodeInfo_Annotation_SemanticAmino = GeneratedCodeInfo_Annotation_Semantic;
function generatedCodeInfo_Annotation_SemanticFromJSON(object) {
    switch(object){
        case 0:
        case "NONE":
            return GeneratedCodeInfo_Annotation_Semantic.NONE;
        case 1:
        case "SET":
            return GeneratedCodeInfo_Annotation_Semantic.SET;
        case 2:
        case "ALIAS":
            return GeneratedCodeInfo_Annotation_Semantic.ALIAS;
        case -1:
        case "UNRECOGNIZED":
        default:
            return GeneratedCodeInfo_Annotation_Semantic.UNRECOGNIZED;
    }
}
function generatedCodeInfo_Annotation_SemanticToJSON(object) {
    switch(object){
        case GeneratedCodeInfo_Annotation_Semantic.NONE:
            return "NONE";
        case GeneratedCodeInfo_Annotation_Semantic.SET:
            return "SET";
        case GeneratedCodeInfo_Annotation_Semantic.ALIAS:
            return "ALIAS";
        case GeneratedCodeInfo_Annotation_Semantic.UNRECOGNIZED:
        default:
            return "UNRECOGNIZED";
    }
}
function createBaseFileDescriptorSet() {
    return {
        file: []
    };
}
const FileDescriptorSet = {
    typeUrl: "/google.protobuf.FileDescriptorSet",
    is (o) {
        return o && (o.$typeUrl === FileDescriptorSet.typeUrl || Array.isArray(o.file) && (!o.file.length || FileDescriptorProto.is(o.file[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FileDescriptorSet.typeUrl || Array.isArray(o.file) && (!o.file.length || FileDescriptorProto.isAmino(o.file[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.file){
            FileDescriptorProto.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFileDescriptorSet();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.file.push(FileDescriptorProto.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFileDescriptorSet();
        message.file = object.file?.map((e)=>FileDescriptorProto.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseFileDescriptorSet();
        message.file = object.file?.map((e)=>FileDescriptorProto.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.file) {
            obj.file = message.file.map((e)=>e ? FileDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.file = message.file;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return FileDescriptorSet.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FileDescriptorSet.decode(message.value);
    },
    toProto (message) {
        return FileDescriptorSet.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FileDescriptorSet",
            value: FileDescriptorSet.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FileDescriptorSet.typeUrl)) {
            return;
        }
        FileDescriptorProto.registerTypeUrl();
    }
};
function createBaseFileDescriptorProto() {
    return {
        name: "",
        package: "",
        dependency: [],
        publicDependency: [],
        weakDependency: [],
        messageType: [],
        enumType: [],
        service: [],
        extension: [],
        options: undefined,
        sourceCodeInfo: undefined,
        syntax: "",
        edition: 1
    };
}
const FileDescriptorProto = {
    typeUrl: "/google.protobuf.FileDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === FileDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.package === "string" && Array.isArray(o.dependency) && (!o.dependency.length || typeof o.dependency[0] === "string") && Array.isArray(o.publicDependency) && (!o.publicDependency.length || typeof o.publicDependency[0] === "number") && Array.isArray(o.weakDependency) && (!o.weakDependency.length || typeof o.weakDependency[0] === "number") && Array.isArray(o.messageType) && (!o.messageType.length || DescriptorProto.is(o.messageType[0])) && Array.isArray(o.enumType) && (!o.enumType.length || EnumDescriptorProto.is(o.enumType[0])) && Array.isArray(o.service) && (!o.service.length || ServiceDescriptorProto.is(o.service[0])) && Array.isArray(o.extension) && (!o.extension.length || FieldDescriptorProto.is(o.extension[0])) && typeof o.syntax === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FileDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.package === "string" && Array.isArray(o.dependency) && (!o.dependency.length || typeof o.dependency[0] === "string") && Array.isArray(o.public_dependency) && (!o.public_dependency.length || typeof o.public_dependency[0] === "number") && Array.isArray(o.weak_dependency) && (!o.weak_dependency.length || typeof o.weak_dependency[0] === "number") && Array.isArray(o.message_type) && (!o.message_type.length || DescriptorProto.isAmino(o.message_type[0])) && Array.isArray(o.enum_type) && (!o.enum_type.length || EnumDescriptorProto.isAmino(o.enum_type[0])) && Array.isArray(o.service) && (!o.service.length || ServiceDescriptorProto.isAmino(o.service[0])) && Array.isArray(o.extension) && (!o.extension.length || FieldDescriptorProto.isAmino(o.extension[0])) && typeof o.syntax === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.package !== "") {
            writer.uint32(18).string(message.package);
        }
        for (const v of message.dependency){
            writer.uint32(26).string(v);
        }
        writer.uint32(82).fork();
        for (const v of message.publicDependency){
            writer.int32(v);
        }
        writer.ldelim();
        writer.uint32(90).fork();
        for (const v of message.weakDependency){
            writer.int32(v);
        }
        writer.ldelim();
        for (const v of message.messageType){
            DescriptorProto.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.enumType){
            EnumDescriptorProto.encode(v, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.service){
            ServiceDescriptorProto.encode(v, writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.extension){
            FieldDescriptorProto.encode(v, writer.uint32(58).fork()).ldelim();
        }
        if (message.options !== undefined) {
            FileOptions.encode(message.options, writer.uint32(66).fork()).ldelim();
        }
        if (message.sourceCodeInfo !== undefined) {
            SourceCodeInfo.encode(message.sourceCodeInfo, writer.uint32(74).fork()).ldelim();
        }
        if (message.syntax !== "") {
            writer.uint32(98).string(message.syntax);
        }
        if (message.edition !== 1) {
            writer.uint32(112).int32(message.edition);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFileDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.package = reader.string();
                    break;
                case 3:
                    message.dependency.push(reader.string());
                    break;
                case 10:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.publicDependency.push(reader.int32());
                        }
                    } else {
                        message.publicDependency.push(reader.int32());
                    }
                    break;
                case 11:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.weakDependency.push(reader.int32());
                        }
                    } else {
                        message.weakDependency.push(reader.int32());
                    }
                    break;
                case 4:
                    message.messageType.push(DescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.enumType.push(EnumDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.service.push(ServiceDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.extension.push(FieldDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.options = FileOptions.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.sourceCodeInfo = SourceCodeInfo.decode(reader, reader.uint32());
                    break;
                case 12:
                    message.syntax = reader.string();
                    break;
                case 14:
                    message.edition = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFileDescriptorProto();
        message.name = object.name ?? "";
        message.package = object.package ?? "";
        message.dependency = object.dependency?.map((e)=>e) || [];
        message.publicDependency = object.publicDependency?.map((e)=>e) || [];
        message.weakDependency = object.weakDependency?.map((e)=>e) || [];
        message.messageType = object.messageType?.map((e)=>DescriptorProto.fromPartial(e)) || [];
        message.enumType = object.enumType?.map((e)=>EnumDescriptorProto.fromPartial(e)) || [];
        message.service = object.service?.map((e)=>ServiceDescriptorProto.fromPartial(e)) || [];
        message.extension = object.extension?.map((e)=>FieldDescriptorProto.fromPartial(e)) || [];
        message.options = object.options !== undefined && object.options !== null ? FileOptions.fromPartial(object.options) : undefined;
        message.sourceCodeInfo = object.sourceCodeInfo !== undefined && object.sourceCodeInfo !== null ? SourceCodeInfo.fromPartial(object.sourceCodeInfo) : undefined;
        message.syntax = object.syntax ?? "";
        message.edition = object.edition ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFileDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.package !== undefined && object.package !== null) {
            message.package = object.package;
        }
        message.dependency = object.dependency?.map((e)=>e) || [];
        message.publicDependency = object.public_dependency?.map((e)=>e) || [];
        message.weakDependency = object.weak_dependency?.map((e)=>e) || [];
        message.messageType = object.message_type?.map((e)=>DescriptorProto.fromAmino(e)) || [];
        message.enumType = object.enum_type?.map((e)=>EnumDescriptorProto.fromAmino(e)) || [];
        message.service = object.service?.map((e)=>ServiceDescriptorProto.fromAmino(e)) || [];
        message.extension = object.extension?.map((e)=>FieldDescriptorProto.fromAmino(e)) || [];
        if (object.options !== undefined && object.options !== null) {
            message.options = FileOptions.fromAmino(object.options);
        }
        if (object.source_code_info !== undefined && object.source_code_info !== null) {
            message.sourceCodeInfo = SourceCodeInfo.fromAmino(object.source_code_info);
        }
        if (object.syntax !== undefined && object.syntax !== null) {
            message.syntax = object.syntax;
        }
        if (object.edition !== undefined && object.edition !== null) {
            message.edition = object.edition;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.package = message.package === "" ? undefined : message.package;
        if (message.dependency) {
            obj.dependency = message.dependency.map((e)=>e);
        } else {
            obj.dependency = message.dependency;
        }
        if (message.publicDependency) {
            obj.public_dependency = message.publicDependency.map((e)=>e);
        } else {
            obj.public_dependency = message.publicDependency;
        }
        if (message.weakDependency) {
            obj.weak_dependency = message.weakDependency.map((e)=>e);
        } else {
            obj.weak_dependency = message.weakDependency;
        }
        if (message.messageType) {
            obj.message_type = message.messageType.map((e)=>e ? DescriptorProto.toAmino(e) : undefined);
        } else {
            obj.message_type = message.messageType;
        }
        if (message.enumType) {
            obj.enum_type = message.enumType.map((e)=>e ? EnumDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.enum_type = message.enumType;
        }
        if (message.service) {
            obj.service = message.service.map((e)=>e ? ServiceDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.service = message.service;
        }
        if (message.extension) {
            obj.extension = message.extension.map((e)=>e ? FieldDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.extension = message.extension;
        }
        obj.options = message.options ? FileOptions.toAmino(message.options) : undefined;
        obj.source_code_info = message.sourceCodeInfo ? SourceCodeInfo.toAmino(message.sourceCodeInfo) : undefined;
        obj.syntax = message.syntax === "" ? undefined : message.syntax;
        obj.edition = message.edition === 1 ? undefined : message.edition;
        return obj;
    },
    fromAminoMsg (object) {
        return FileDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FileDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return FileDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FileDescriptorProto",
            value: FileDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FileDescriptorProto.typeUrl)) {
            return;
        }
        DescriptorProto.registerTypeUrl();
        EnumDescriptorProto.registerTypeUrl();
        ServiceDescriptorProto.registerTypeUrl();
        FieldDescriptorProto.registerTypeUrl();
        FileOptions.registerTypeUrl();
        SourceCodeInfo.registerTypeUrl();
    }
};
function createBaseDescriptorProto() {
    return {
        name: "",
        field: [],
        extension: [],
        nestedType: [],
        enumType: [],
        extensionRange: [],
        oneofDecl: [],
        options: undefined,
        reservedRange: [],
        reservedName: []
    };
}
const DescriptorProto = {
    typeUrl: "/google.protobuf.DescriptorProto",
    is (o) {
        return o && (o.$typeUrl === DescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.field) && (!o.field.length || FieldDescriptorProto.is(o.field[0])) && Array.isArray(o.extension) && (!o.extension.length || FieldDescriptorProto.is(o.extension[0])) && Array.isArray(o.nestedType) && (!o.nestedType.length || DescriptorProto.is(o.nestedType[0])) && Array.isArray(o.enumType) && (!o.enumType.length || EnumDescriptorProto.is(o.enumType[0])) && Array.isArray(o.extensionRange) && (!o.extensionRange.length || DescriptorProto_ExtensionRange.is(o.extensionRange[0])) && Array.isArray(o.oneofDecl) && (!o.oneofDecl.length || OneofDescriptorProto.is(o.oneofDecl[0])) && Array.isArray(o.reservedRange) && (!o.reservedRange.length || DescriptorProto_ReservedRange.is(o.reservedRange[0])) && Array.isArray(o.reservedName) && (!o.reservedName.length || typeof o.reservedName[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === DescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.field) && (!o.field.length || FieldDescriptorProto.isAmino(o.field[0])) && Array.isArray(o.extension) && (!o.extension.length || FieldDescriptorProto.isAmino(o.extension[0])) && Array.isArray(o.nested_type) && (!o.nested_type.length || DescriptorProto.isAmino(o.nested_type[0])) && Array.isArray(o.enum_type) && (!o.enum_type.length || EnumDescriptorProto.isAmino(o.enum_type[0])) && Array.isArray(o.extension_range) && (!o.extension_range.length || DescriptorProto_ExtensionRange.isAmino(o.extension_range[0])) && Array.isArray(o.oneof_decl) && (!o.oneof_decl.length || OneofDescriptorProto.isAmino(o.oneof_decl[0])) && Array.isArray(o.reserved_range) && (!o.reserved_range.length || DescriptorProto_ReservedRange.isAmino(o.reserved_range[0])) && Array.isArray(o.reserved_name) && (!o.reserved_name.length || typeof o.reserved_name[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.field){
            FieldDescriptorProto.encode(v, writer.uint32(18).fork()).ldelim();
        }
        for (const v of message.extension){
            FieldDescriptorProto.encode(v, writer.uint32(50).fork()).ldelim();
        }
        for (const v of message.nestedType){
            DescriptorProto.encode(v, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.enumType){
            EnumDescriptorProto.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.extensionRange){
            DescriptorProto_ExtensionRange.encode(v, writer.uint32(42).fork()).ldelim();
        }
        for (const v of message.oneofDecl){
            OneofDescriptorProto.encode(v, writer.uint32(66).fork()).ldelim();
        }
        if (message.options !== undefined) {
            MessageOptions.encode(message.options, writer.uint32(58).fork()).ldelim();
        }
        for (const v of message.reservedRange){
            DescriptorProto_ReservedRange.encode(v, writer.uint32(74).fork()).ldelim();
        }
        for (const v of message.reservedName){
            writer.uint32(82).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.field.push(FieldDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 6:
                    message.extension.push(FieldDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.nestedType.push(DescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.enumType.push(EnumDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.extensionRange.push(DescriptorProto_ExtensionRange.decode(reader, reader.uint32()));
                    break;
                case 8:
                    message.oneofDecl.push(OneofDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 7:
                    message.options = MessageOptions.decode(reader, reader.uint32());
                    break;
                case 9:
                    message.reservedRange.push(DescriptorProto_ReservedRange.decode(reader, reader.uint32()));
                    break;
                case 10:
                    message.reservedName.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDescriptorProto();
        message.name = object.name ?? "";
        message.field = object.field?.map((e)=>FieldDescriptorProto.fromPartial(e)) || [];
        message.extension = object.extension?.map((e)=>FieldDescriptorProto.fromPartial(e)) || [];
        message.nestedType = object.nestedType?.map((e)=>DescriptorProto.fromPartial(e)) || [];
        message.enumType = object.enumType?.map((e)=>EnumDescriptorProto.fromPartial(e)) || [];
        message.extensionRange = object.extensionRange?.map((e)=>DescriptorProto_ExtensionRange.fromPartial(e)) || [];
        message.oneofDecl = object.oneofDecl?.map((e)=>OneofDescriptorProto.fromPartial(e)) || [];
        message.options = object.options !== undefined && object.options !== null ? MessageOptions.fromPartial(object.options) : undefined;
        message.reservedRange = object.reservedRange?.map((e)=>DescriptorProto_ReservedRange.fromPartial(e)) || [];
        message.reservedName = object.reservedName?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.field = object.field?.map((e)=>FieldDescriptorProto.fromAmino(e)) || [];
        message.extension = object.extension?.map((e)=>FieldDescriptorProto.fromAmino(e)) || [];
        message.nestedType = object.nested_type?.map((e)=>DescriptorProto.fromAmino(e)) || [];
        message.enumType = object.enum_type?.map((e)=>EnumDescriptorProto.fromAmino(e)) || [];
        message.extensionRange = object.extension_range?.map((e)=>DescriptorProto_ExtensionRange.fromAmino(e)) || [];
        message.oneofDecl = object.oneof_decl?.map((e)=>OneofDescriptorProto.fromAmino(e)) || [];
        if (object.options !== undefined && object.options !== null) {
            message.options = MessageOptions.fromAmino(object.options);
        }
        message.reservedRange = object.reserved_range?.map((e)=>DescriptorProto_ReservedRange.fromAmino(e)) || [];
        message.reservedName = object.reserved_name?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.field) {
            obj.field = message.field.map((e)=>e ? FieldDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.field = message.field;
        }
        if (message.extension) {
            obj.extension = message.extension.map((e)=>e ? FieldDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.extension = message.extension;
        }
        if (message.nestedType) {
            obj.nested_type = message.nestedType.map((e)=>e ? DescriptorProto.toAmino(e) : undefined);
        } else {
            obj.nested_type = message.nestedType;
        }
        if (message.enumType) {
            obj.enum_type = message.enumType.map((e)=>e ? EnumDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.enum_type = message.enumType;
        }
        if (message.extensionRange) {
            obj.extension_range = message.extensionRange.map((e)=>e ? DescriptorProto_ExtensionRange.toAmino(e) : undefined);
        } else {
            obj.extension_range = message.extensionRange;
        }
        if (message.oneofDecl) {
            obj.oneof_decl = message.oneofDecl.map((e)=>e ? OneofDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.oneof_decl = message.oneofDecl;
        }
        obj.options = message.options ? MessageOptions.toAmino(message.options) : undefined;
        if (message.reservedRange) {
            obj.reserved_range = message.reservedRange.map((e)=>e ? DescriptorProto_ReservedRange.toAmino(e) : undefined);
        } else {
            obj.reserved_range = message.reservedRange;
        }
        if (message.reservedName) {
            obj.reserved_name = message.reservedName.map((e)=>e);
        } else {
            obj.reserved_name = message.reservedName;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return DescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return DescriptorProto.decode(message.value);
    },
    toProto (message) {
        return DescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.DescriptorProto",
            value: DescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DescriptorProto.typeUrl)) {
            return;
        }
        FieldDescriptorProto.registerTypeUrl();
        DescriptorProto.registerTypeUrl();
        EnumDescriptorProto.registerTypeUrl();
        DescriptorProto_ExtensionRange.registerTypeUrl();
        OneofDescriptorProto.registerTypeUrl();
        MessageOptions.registerTypeUrl();
        DescriptorProto_ReservedRange.registerTypeUrl();
    }
};
function createBaseDescriptorProto_ExtensionRange() {
    return {
        start: 0,
        end: 0,
        options: undefined
    };
}
const DescriptorProto_ExtensionRange = {
    typeUrl: "/google.protobuf.ExtensionRange",
    is (o) {
        return o && (o.$typeUrl === DescriptorProto_ExtensionRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === DescriptorProto_ExtensionRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.start !== 0) {
            writer.uint32(8).int32(message.start);
        }
        if (message.end !== 0) {
            writer.uint32(16).int32(message.end);
        }
        if (message.options !== undefined) {
            ExtensionRangeOptions.encode(message.options, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDescriptorProto_ExtensionRange();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.start = reader.int32();
                    break;
                case 2:
                    message.end = reader.int32();
                    break;
                case 3:
                    message.options = ExtensionRangeOptions.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDescriptorProto_ExtensionRange();
        message.start = object.start ?? 0;
        message.end = object.end ?? 0;
        message.options = object.options !== undefined && object.options !== null ? ExtensionRangeOptions.fromPartial(object.options) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDescriptorProto_ExtensionRange();
        if (object.start !== undefined && object.start !== null) {
            message.start = object.start;
        }
        if (object.end !== undefined && object.end !== null) {
            message.end = object.end;
        }
        if (object.options !== undefined && object.options !== null) {
            message.options = ExtensionRangeOptions.fromAmino(object.options);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.start = message.start === 0 ? undefined : message.start;
        obj.end = message.end === 0 ? undefined : message.end;
        obj.options = message.options ? ExtensionRangeOptions.toAmino(message.options) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return DescriptorProto_ExtensionRange.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return DescriptorProto_ExtensionRange.decode(message.value);
    },
    toProto (message) {
        return DescriptorProto_ExtensionRange.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.ExtensionRange",
            value: DescriptorProto_ExtensionRange.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(DescriptorProto_ExtensionRange.typeUrl)) {
            return;
        }
        ExtensionRangeOptions.registerTypeUrl();
    }
};
function createBaseDescriptorProto_ReservedRange() {
    return {
        start: 0,
        end: 0
    };
}
const DescriptorProto_ReservedRange = {
    typeUrl: "/google.protobuf.ReservedRange",
    is (o) {
        return o && (o.$typeUrl === DescriptorProto_ReservedRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === DescriptorProto_ReservedRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.start !== 0) {
            writer.uint32(8).int32(message.start);
        }
        if (message.end !== 0) {
            writer.uint32(16).int32(message.end);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseDescriptorProto_ReservedRange();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.start = reader.int32();
                    break;
                case 2:
                    message.end = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseDescriptorProto_ReservedRange();
        message.start = object.start ?? 0;
        message.end = object.end ?? 0;
        return message;
    },
    fromAmino (object) {
        const message = createBaseDescriptorProto_ReservedRange();
        if (object.start !== undefined && object.start !== null) {
            message.start = object.start;
        }
        if (object.end !== undefined && object.end !== null) {
            message.end = object.end;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.start = message.start === 0 ? undefined : message.start;
        obj.end = message.end === 0 ? undefined : message.end;
        return obj;
    },
    fromAminoMsg (object) {
        return DescriptorProto_ReservedRange.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return DescriptorProto_ReservedRange.decode(message.value);
    },
    toProto (message) {
        return DescriptorProto_ReservedRange.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.ReservedRange",
            value: DescriptorProto_ReservedRange.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseExtensionRangeOptions() {
    return {
        uninterpretedOption: [],
        declaration: [],
        features: undefined,
        verification: 1
    };
}
const ExtensionRangeOptions = {
    typeUrl: "/google.protobuf.ExtensionRangeOptions",
    is (o) {
        return o && (o.$typeUrl === ExtensionRangeOptions.typeUrl || Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])) && Array.isArray(o.declaration) && (!o.declaration.length || ExtensionRangeOptions_Declaration.is(o.declaration[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.verification));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ExtensionRangeOptions.typeUrl || Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])) && Array.isArray(o.declaration) && (!o.declaration.length || ExtensionRangeOptions_Declaration.isAmino(o.declaration[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.verification));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        for (const v of message.declaration){
            ExtensionRangeOptions_Declaration.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(402).fork()).ldelim();
        }
        if (message.verification !== 1) {
            writer.uint32(24).int32(message.verification);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExtensionRangeOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.declaration.push(ExtensionRangeOptions_Declaration.decode(reader, reader.uint32()));
                    break;
                case 50:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.verification = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseExtensionRangeOptions();
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        message.declaration = object.declaration?.map((e)=>ExtensionRangeOptions_Declaration.fromPartial(e)) || [];
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.verification = object.verification ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseExtensionRangeOptions();
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        message.declaration = object.declaration?.map((e)=>ExtensionRangeOptions_Declaration.fromAmino(e)) || [];
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        if (object.verification !== undefined && object.verification !== null) {
            message.verification = object.verification;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        if (message.declaration) {
            obj.declaration = message.declaration.map((e)=>e ? ExtensionRangeOptions_Declaration.toAmino(e) : undefined);
        } else {
            obj.declaration = message.declaration;
        }
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        obj.verification = message.verification === 1 ? undefined : message.verification;
        return obj;
    },
    fromAminoMsg (object) {
        return ExtensionRangeOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return ExtensionRangeOptions.decode(message.value);
    },
    toProto (message) {
        return ExtensionRangeOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.ExtensionRangeOptions",
            value: ExtensionRangeOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ExtensionRangeOptions.typeUrl)) {
            return;
        }
        UninterpretedOption.registerTypeUrl();
        ExtensionRangeOptions_Declaration.registerTypeUrl();
        FeatureSet.registerTypeUrl();
    }
};
function createBaseExtensionRangeOptions_Declaration() {
    return {
        number: 0,
        fullName: "",
        type: "",
        reserved: false,
        repeated: false
    };
}
const ExtensionRangeOptions_Declaration = {
    typeUrl: "/google.protobuf.Declaration",
    is (o) {
        return o && (o.$typeUrl === ExtensionRangeOptions_Declaration.typeUrl || typeof o.number === "number" && typeof o.fullName === "string" && typeof o.type === "string" && typeof o.reserved === "boolean" && typeof o.repeated === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === ExtensionRangeOptions_Declaration.typeUrl || typeof o.number === "number" && typeof o.full_name === "string" && typeof o.type === "string" && typeof o.reserved === "boolean" && typeof o.repeated === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.number !== 0) {
            writer.uint32(8).int32(message.number);
        }
        if (message.fullName !== "") {
            writer.uint32(18).string(message.fullName);
        }
        if (message.type !== "") {
            writer.uint32(26).string(message.type);
        }
        if (message.reserved === true) {
            writer.uint32(40).bool(message.reserved);
        }
        if (message.repeated === true) {
            writer.uint32(48).bool(message.repeated);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseExtensionRangeOptions_Declaration();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.number = reader.int32();
                    break;
                case 2:
                    message.fullName = reader.string();
                    break;
                case 3:
                    message.type = reader.string();
                    break;
                case 5:
                    message.reserved = reader.bool();
                    break;
                case 6:
                    message.repeated = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseExtensionRangeOptions_Declaration();
        message.number = object.number ?? 0;
        message.fullName = object.fullName ?? "";
        message.type = object.type ?? "";
        message.reserved = object.reserved ?? false;
        message.repeated = object.repeated ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseExtensionRangeOptions_Declaration();
        if (object.number !== undefined && object.number !== null) {
            message.number = object.number;
        }
        if (object.full_name !== undefined && object.full_name !== null) {
            message.fullName = object.full_name;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.reserved !== undefined && object.reserved !== null) {
            message.reserved = object.reserved;
        }
        if (object.repeated !== undefined && object.repeated !== null) {
            message.repeated = object.repeated;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.number = message.number === 0 ? undefined : message.number;
        obj.full_name = message.fullName === "" ? undefined : message.fullName;
        obj.type = message.type === "" ? undefined : message.type;
        obj.reserved = message.reserved === false ? undefined : message.reserved;
        obj.repeated = message.repeated === false ? undefined : message.repeated;
        return obj;
    },
    fromAminoMsg (object) {
        return ExtensionRangeOptions_Declaration.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return ExtensionRangeOptions_Declaration.decode(message.value);
    },
    toProto (message) {
        return ExtensionRangeOptions_Declaration.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Declaration",
            value: ExtensionRangeOptions_Declaration.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseFieldDescriptorProto() {
    return {
        name: "",
        number: 0,
        label: 1,
        type: 1,
        typeName: "",
        extendee: "",
        defaultValue: "",
        oneofIndex: 0,
        jsonName: "",
        options: undefined,
        proto3Optional: false
    };
}
const FieldDescriptorProto = {
    typeUrl: "/google.protobuf.FieldDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === FieldDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.number === "number" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.label) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.type) && typeof o.typeName === "string" && typeof o.extendee === "string" && typeof o.defaultValue === "string" && typeof o.oneofIndex === "number" && typeof o.jsonName === "string" && typeof o.proto3Optional === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === FieldDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.number === "number" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.label) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.type) && typeof o.type_name === "string" && typeof o.extendee === "string" && typeof o.default_value === "string" && typeof o.oneof_index === "number" && typeof o.json_name === "string" && typeof o.proto3_optional === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.number !== 0) {
            writer.uint32(24).int32(message.number);
        }
        if (message.label !== 1) {
            writer.uint32(32).int32(message.label);
        }
        if (message.type !== 1) {
            writer.uint32(40).int32(message.type);
        }
        if (message.typeName !== "") {
            writer.uint32(50).string(message.typeName);
        }
        if (message.extendee !== "") {
            writer.uint32(18).string(message.extendee);
        }
        if (message.defaultValue !== "") {
            writer.uint32(58).string(message.defaultValue);
        }
        if (message.oneofIndex !== 0) {
            writer.uint32(72).int32(message.oneofIndex);
        }
        if (message.jsonName !== "") {
            writer.uint32(82).string(message.jsonName);
        }
        if (message.options !== undefined) {
            FieldOptions.encode(message.options, writer.uint32(66).fork()).ldelim();
        }
        if (message.proto3Optional === true) {
            writer.uint32(136).bool(message.proto3Optional);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 3:
                    message.number = reader.int32();
                    break;
                case 4:
                    message.label = reader.int32();
                    break;
                case 5:
                    message.type = reader.int32();
                    break;
                case 6:
                    message.typeName = reader.string();
                    break;
                case 2:
                    message.extendee = reader.string();
                    break;
                case 7:
                    message.defaultValue = reader.string();
                    break;
                case 9:
                    message.oneofIndex = reader.int32();
                    break;
                case 10:
                    message.jsonName = reader.string();
                    break;
                case 8:
                    message.options = FieldOptions.decode(reader, reader.uint32());
                    break;
                case 17:
                    message.proto3Optional = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFieldDescriptorProto();
        message.name = object.name ?? "";
        message.number = object.number ?? 0;
        message.label = object.label ?? 1;
        message.type = object.type ?? 1;
        message.typeName = object.typeName ?? "";
        message.extendee = object.extendee ?? "";
        message.defaultValue = object.defaultValue ?? "";
        message.oneofIndex = object.oneofIndex ?? 0;
        message.jsonName = object.jsonName ?? "";
        message.options = object.options !== undefined && object.options !== null ? FieldOptions.fromPartial(object.options) : undefined;
        message.proto3Optional = object.proto3Optional ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFieldDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.number !== undefined && object.number !== null) {
            message.number = object.number;
        }
        if (object.label !== undefined && object.label !== null) {
            message.label = object.label;
        }
        if (object.type !== undefined && object.type !== null) {
            message.type = object.type;
        }
        if (object.type_name !== undefined && object.type_name !== null) {
            message.typeName = object.type_name;
        }
        if (object.extendee !== undefined && object.extendee !== null) {
            message.extendee = object.extendee;
        }
        if (object.default_value !== undefined && object.default_value !== null) {
            message.defaultValue = object.default_value;
        }
        if (object.oneof_index !== undefined && object.oneof_index !== null) {
            message.oneofIndex = object.oneof_index;
        }
        if (object.json_name !== undefined && object.json_name !== null) {
            message.jsonName = object.json_name;
        }
        if (object.options !== undefined && object.options !== null) {
            message.options = FieldOptions.fromAmino(object.options);
        }
        if (object.proto3_optional !== undefined && object.proto3_optional !== null) {
            message.proto3Optional = object.proto3_optional;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.number = message.number === 0 ? undefined : message.number;
        obj.label = message.label === 1 ? undefined : message.label;
        obj.type = message.type === 1 ? undefined : message.type;
        obj.type_name = message.typeName === "" ? undefined : message.typeName;
        obj.extendee = message.extendee === "" ? undefined : message.extendee;
        obj.default_value = message.defaultValue === "" ? undefined : message.defaultValue;
        obj.oneof_index = message.oneofIndex === 0 ? undefined : message.oneofIndex;
        obj.json_name = message.jsonName === "" ? undefined : message.jsonName;
        obj.options = message.options ? FieldOptions.toAmino(message.options) : undefined;
        obj.proto3_optional = message.proto3Optional === false ? undefined : message.proto3Optional;
        return obj;
    },
    fromAminoMsg (object) {
        return FieldDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FieldDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return FieldDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FieldDescriptorProto",
            value: FieldDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FieldDescriptorProto.typeUrl)) {
            return;
        }
        FieldOptions.registerTypeUrl();
    }
};
function createBaseOneofDescriptorProto() {
    return {
        name: "",
        options: undefined
    };
}
const OneofDescriptorProto = {
    typeUrl: "/google.protobuf.OneofDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === OneofDescriptorProto.typeUrl || typeof o.name === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === OneofDescriptorProto.typeUrl || typeof o.name === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.options !== undefined) {
            OneofOptions.encode(message.options, writer.uint32(18).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOneofDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.options = OneofOptions.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseOneofDescriptorProto();
        message.name = object.name ?? "";
        message.options = object.options !== undefined && object.options !== null ? OneofOptions.fromPartial(object.options) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseOneofDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.options !== undefined && object.options !== null) {
            message.options = OneofOptions.fromAmino(object.options);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.options = message.options ? OneofOptions.toAmino(message.options) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return OneofDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return OneofDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return OneofDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.OneofDescriptorProto",
            value: OneofDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(OneofDescriptorProto.typeUrl)) {
            return;
        }
        OneofOptions.registerTypeUrl();
    }
};
function createBaseEnumDescriptorProto() {
    return {
        name: "",
        value: [],
        options: undefined,
        reservedRange: [],
        reservedName: []
    };
}
const EnumDescriptorProto = {
    typeUrl: "/google.protobuf.EnumDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === EnumDescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.value) && (!o.value.length || EnumValueDescriptorProto.is(o.value[0])) && Array.isArray(o.reservedRange) && (!o.reservedRange.length || EnumDescriptorProto_EnumReservedRange.is(o.reservedRange[0])) && Array.isArray(o.reservedName) && (!o.reservedName.length || typeof o.reservedName[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === EnumDescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.value) && (!o.value.length || EnumValueDescriptorProto.isAmino(o.value[0])) && Array.isArray(o.reserved_range) && (!o.reserved_range.length || EnumDescriptorProto_EnumReservedRange.isAmino(o.reserved_range[0])) && Array.isArray(o.reserved_name) && (!o.reserved_name.length || typeof o.reserved_name[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.value){
            EnumValueDescriptorProto.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.options !== undefined) {
            EnumOptions.encode(message.options, writer.uint32(26).fork()).ldelim();
        }
        for (const v of message.reservedRange){
            EnumDescriptorProto_EnumReservedRange.encode(v, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.reservedName){
            writer.uint32(42).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnumDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.value.push(EnumValueDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.options = EnumOptions.decode(reader, reader.uint32());
                    break;
                case 4:
                    message.reservedRange.push(EnumDescriptorProto_EnumReservedRange.decode(reader, reader.uint32()));
                    break;
                case 5:
                    message.reservedName.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseEnumDescriptorProto();
        message.name = object.name ?? "";
        message.value = object.value?.map((e)=>EnumValueDescriptorProto.fromPartial(e)) || [];
        message.options = object.options !== undefined && object.options !== null ? EnumOptions.fromPartial(object.options) : undefined;
        message.reservedRange = object.reservedRange?.map((e)=>EnumDescriptorProto_EnumReservedRange.fromPartial(e)) || [];
        message.reservedName = object.reservedName?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseEnumDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.value = object.value?.map((e)=>EnumValueDescriptorProto.fromAmino(e)) || [];
        if (object.options !== undefined && object.options !== null) {
            message.options = EnumOptions.fromAmino(object.options);
        }
        message.reservedRange = object.reserved_range?.map((e)=>EnumDescriptorProto_EnumReservedRange.fromAmino(e)) || [];
        message.reservedName = object.reserved_name?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.value) {
            obj.value = message.value.map((e)=>e ? EnumValueDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.value = message.value;
        }
        obj.options = message.options ? EnumOptions.toAmino(message.options) : undefined;
        if (message.reservedRange) {
            obj.reserved_range = message.reservedRange.map((e)=>e ? EnumDescriptorProto_EnumReservedRange.toAmino(e) : undefined);
        } else {
            obj.reserved_range = message.reservedRange;
        }
        if (message.reservedName) {
            obj.reserved_name = message.reservedName.map((e)=>e);
        } else {
            obj.reserved_name = message.reservedName;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return EnumDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return EnumDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return EnumDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EnumDescriptorProto",
            value: EnumDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(EnumDescriptorProto.typeUrl)) {
            return;
        }
        EnumValueDescriptorProto.registerTypeUrl();
        EnumOptions.registerTypeUrl();
        EnumDescriptorProto_EnumReservedRange.registerTypeUrl();
    }
};
function createBaseEnumDescriptorProto_EnumReservedRange() {
    return {
        start: 0,
        end: 0
    };
}
const EnumDescriptorProto_EnumReservedRange = {
    typeUrl: "/google.protobuf.EnumReservedRange",
    is (o) {
        return o && (o.$typeUrl === EnumDescriptorProto_EnumReservedRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === EnumDescriptorProto_EnumReservedRange.typeUrl || typeof o.start === "number" && typeof o.end === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.start !== 0) {
            writer.uint32(8).int32(message.start);
        }
        if (message.end !== 0) {
            writer.uint32(16).int32(message.end);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnumDescriptorProto_EnumReservedRange();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.start = reader.int32();
                    break;
                case 2:
                    message.end = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseEnumDescriptorProto_EnumReservedRange();
        message.start = object.start ?? 0;
        message.end = object.end ?? 0;
        return message;
    },
    fromAmino (object) {
        const message = createBaseEnumDescriptorProto_EnumReservedRange();
        if (object.start !== undefined && object.start !== null) {
            message.start = object.start;
        }
        if (object.end !== undefined && object.end !== null) {
            message.end = object.end;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.start = message.start === 0 ? undefined : message.start;
        obj.end = message.end === 0 ? undefined : message.end;
        return obj;
    },
    fromAminoMsg (object) {
        return EnumDescriptorProto_EnumReservedRange.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return EnumDescriptorProto_EnumReservedRange.decode(message.value);
    },
    toProto (message) {
        return EnumDescriptorProto_EnumReservedRange.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EnumReservedRange",
            value: EnumDescriptorProto_EnumReservedRange.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseEnumValueDescriptorProto() {
    return {
        name: "",
        number: 0,
        options: undefined
    };
}
const EnumValueDescriptorProto = {
    typeUrl: "/google.protobuf.EnumValueDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === EnumValueDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.number === "number");
    },
    isAmino (o) {
        return o && (o.$typeUrl === EnumValueDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.number === "number");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.number !== 0) {
            writer.uint32(16).int32(message.number);
        }
        if (message.options !== undefined) {
            EnumValueOptions.encode(message.options, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnumValueDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.number = reader.int32();
                    break;
                case 3:
                    message.options = EnumValueOptions.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseEnumValueDescriptorProto();
        message.name = object.name ?? "";
        message.number = object.number ?? 0;
        message.options = object.options !== undefined && object.options !== null ? EnumValueOptions.fromPartial(object.options) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseEnumValueDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.number !== undefined && object.number !== null) {
            message.number = object.number;
        }
        if (object.options !== undefined && object.options !== null) {
            message.options = EnumValueOptions.fromAmino(object.options);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.number = message.number === 0 ? undefined : message.number;
        obj.options = message.options ? EnumValueOptions.toAmino(message.options) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return EnumValueDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return EnumValueDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return EnumValueDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EnumValueDescriptorProto",
            value: EnumValueDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(EnumValueDescriptorProto.typeUrl)) {
            return;
        }
        EnumValueOptions.registerTypeUrl();
    }
};
function createBaseServiceDescriptorProto() {
    return {
        name: "",
        method: [],
        options: undefined
    };
}
const ServiceDescriptorProto = {
    typeUrl: "/google.protobuf.ServiceDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === ServiceDescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.method) && (!o.method.length || MethodDescriptorProto.is(o.method[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ServiceDescriptorProto.typeUrl || typeof o.name === "string" && Array.isArray(o.method) && (!o.method.length || MethodDescriptorProto.isAmino(o.method[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        for (const v of message.method){
            MethodDescriptorProto.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.options !== undefined) {
            ServiceOptions.encode(message.options, writer.uint32(26).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServiceDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.method.push(MethodDescriptorProto.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.options = ServiceOptions.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseServiceDescriptorProto();
        message.name = object.name ?? "";
        message.method = object.method?.map((e)=>MethodDescriptorProto.fromPartial(e)) || [];
        message.options = object.options !== undefined && object.options !== null ? ServiceOptions.fromPartial(object.options) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseServiceDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        message.method = object.method?.map((e)=>MethodDescriptorProto.fromAmino(e)) || [];
        if (object.options !== undefined && object.options !== null) {
            message.options = ServiceOptions.fromAmino(object.options);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        if (message.method) {
            obj.method = message.method.map((e)=>e ? MethodDescriptorProto.toAmino(e) : undefined);
        } else {
            obj.method = message.method;
        }
        obj.options = message.options ? ServiceOptions.toAmino(message.options) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return ServiceDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return ServiceDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return ServiceDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.ServiceDescriptorProto",
            value: ServiceDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ServiceDescriptorProto.typeUrl)) {
            return;
        }
        MethodDescriptorProto.registerTypeUrl();
        ServiceOptions.registerTypeUrl();
    }
};
function createBaseMethodDescriptorProto() {
    return {
        name: "",
        inputType: "",
        outputType: "",
        options: undefined,
        clientStreaming: false,
        serverStreaming: false
    };
}
const MethodDescriptorProto = {
    typeUrl: "/google.protobuf.MethodDescriptorProto",
    is (o) {
        return o && (o.$typeUrl === MethodDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.inputType === "string" && typeof o.outputType === "string" && typeof o.clientStreaming === "boolean" && typeof o.serverStreaming === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === MethodDescriptorProto.typeUrl || typeof o.name === "string" && typeof o.input_type === "string" && typeof o.output_type === "string" && typeof o.client_streaming === "boolean" && typeof o.server_streaming === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.name !== "") {
            writer.uint32(10).string(message.name);
        }
        if (message.inputType !== "") {
            writer.uint32(18).string(message.inputType);
        }
        if (message.outputType !== "") {
            writer.uint32(26).string(message.outputType);
        }
        if (message.options !== undefined) {
            MethodOptions.encode(message.options, writer.uint32(34).fork()).ldelim();
        }
        if (message.clientStreaming === true) {
            writer.uint32(40).bool(message.clientStreaming);
        }
        if (message.serverStreaming === true) {
            writer.uint32(48).bool(message.serverStreaming);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethodDescriptorProto();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.name = reader.string();
                    break;
                case 2:
                    message.inputType = reader.string();
                    break;
                case 3:
                    message.outputType = reader.string();
                    break;
                case 4:
                    message.options = MethodOptions.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.clientStreaming = reader.bool();
                    break;
                case 6:
                    message.serverStreaming = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMethodDescriptorProto();
        message.name = object.name ?? "";
        message.inputType = object.inputType ?? "";
        message.outputType = object.outputType ?? "";
        message.options = object.options !== undefined && object.options !== null ? MethodOptions.fromPartial(object.options) : undefined;
        message.clientStreaming = object.clientStreaming ?? false;
        message.serverStreaming = object.serverStreaming ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseMethodDescriptorProto();
        if (object.name !== undefined && object.name !== null) {
            message.name = object.name;
        }
        if (object.input_type !== undefined && object.input_type !== null) {
            message.inputType = object.input_type;
        }
        if (object.output_type !== undefined && object.output_type !== null) {
            message.outputType = object.output_type;
        }
        if (object.options !== undefined && object.options !== null) {
            message.options = MethodOptions.fromAmino(object.options);
        }
        if (object.client_streaming !== undefined && object.client_streaming !== null) {
            message.clientStreaming = object.client_streaming;
        }
        if (object.server_streaming !== undefined && object.server_streaming !== null) {
            message.serverStreaming = object.server_streaming;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name = message.name === "" ? undefined : message.name;
        obj.input_type = message.inputType === "" ? undefined : message.inputType;
        obj.output_type = message.outputType === "" ? undefined : message.outputType;
        obj.options = message.options ? MethodOptions.toAmino(message.options) : undefined;
        obj.client_streaming = message.clientStreaming === false ? undefined : message.clientStreaming;
        obj.server_streaming = message.serverStreaming === false ? undefined : message.serverStreaming;
        return obj;
    },
    fromAminoMsg (object) {
        return MethodDescriptorProto.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return MethodDescriptorProto.decode(message.value);
    },
    toProto (message) {
        return MethodDescriptorProto.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.MethodDescriptorProto",
            value: MethodDescriptorProto.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MethodDescriptorProto.typeUrl)) {
            return;
        }
        MethodOptions.registerTypeUrl();
    }
};
function createBaseFileOptions() {
    return {
        javaPackage: "",
        javaOuterClassname: "",
        javaMultipleFiles: false,
        javaGenerateEqualsAndHash: false,
        javaStringCheckUtf8: false,
        optimizeFor: 1,
        goPackage: "",
        ccGenericServices: false,
        javaGenericServices: false,
        pyGenericServices: false,
        deprecated: false,
        ccEnableArenas: false,
        objcClassPrefix: "",
        csharpNamespace: "",
        swiftPrefix: "",
        phpClassPrefix: "",
        phpNamespace: "",
        phpMetadataNamespace: "",
        rubyPackage: "",
        features: undefined,
        uninterpretedOption: []
    };
}
const FileOptions = {
    typeUrl: "/google.protobuf.FileOptions",
    is (o) {
        return o && (o.$typeUrl === FileOptions.typeUrl || typeof o.javaPackage === "string" && typeof o.javaOuterClassname === "string" && typeof o.javaMultipleFiles === "boolean" && typeof o.javaGenerateEqualsAndHash === "boolean" && typeof o.javaStringCheckUtf8 === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.optimizeFor) && typeof o.goPackage === "string" && typeof o.ccGenericServices === "boolean" && typeof o.javaGenericServices === "boolean" && typeof o.pyGenericServices === "boolean" && typeof o.deprecated === "boolean" && typeof o.ccEnableArenas === "boolean" && typeof o.objcClassPrefix === "string" && typeof o.csharpNamespace === "string" && typeof o.swiftPrefix === "string" && typeof o.phpClassPrefix === "string" && typeof o.phpNamespace === "string" && typeof o.phpMetadataNamespace === "string" && typeof o.rubyPackage === "string" && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FileOptions.typeUrl || typeof o.java_package === "string" && typeof o.java_outer_classname === "string" && typeof o.java_multiple_files === "boolean" && typeof o.java_generate_equals_and_hash === "boolean" && typeof o.java_string_check_utf8 === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.optimize_for) && typeof o.go_package === "string" && typeof o.cc_generic_services === "boolean" && typeof o.java_generic_services === "boolean" && typeof o.py_generic_services === "boolean" && typeof o.deprecated === "boolean" && typeof o.cc_enable_arenas === "boolean" && typeof o.objc_class_prefix === "string" && typeof o.csharp_namespace === "string" && typeof o.swift_prefix === "string" && typeof o.php_class_prefix === "string" && typeof o.php_namespace === "string" && typeof o.php_metadata_namespace === "string" && typeof o.ruby_package === "string" && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.javaPackage !== "") {
            writer.uint32(10).string(message.javaPackage);
        }
        if (message.javaOuterClassname !== "") {
            writer.uint32(66).string(message.javaOuterClassname);
        }
        if (message.javaMultipleFiles === true) {
            writer.uint32(80).bool(message.javaMultipleFiles);
        }
        if (message.javaGenerateEqualsAndHash === true) {
            writer.uint32(160).bool(message.javaGenerateEqualsAndHash);
        }
        if (message.javaStringCheckUtf8 === true) {
            writer.uint32(216).bool(message.javaStringCheckUtf8);
        }
        if (message.optimizeFor !== 1) {
            writer.uint32(72).int32(message.optimizeFor);
        }
        if (message.goPackage !== "") {
            writer.uint32(90).string(message.goPackage);
        }
        if (message.ccGenericServices === true) {
            writer.uint32(128).bool(message.ccGenericServices);
        }
        if (message.javaGenericServices === true) {
            writer.uint32(136).bool(message.javaGenericServices);
        }
        if (message.pyGenericServices === true) {
            writer.uint32(144).bool(message.pyGenericServices);
        }
        if (message.deprecated === true) {
            writer.uint32(184).bool(message.deprecated);
        }
        if (message.ccEnableArenas === true) {
            writer.uint32(248).bool(message.ccEnableArenas);
        }
        if (message.objcClassPrefix !== "") {
            writer.uint32(290).string(message.objcClassPrefix);
        }
        if (message.csharpNamespace !== "") {
            writer.uint32(298).string(message.csharpNamespace);
        }
        if (message.swiftPrefix !== "") {
            writer.uint32(314).string(message.swiftPrefix);
        }
        if (message.phpClassPrefix !== "") {
            writer.uint32(322).string(message.phpClassPrefix);
        }
        if (message.phpNamespace !== "") {
            writer.uint32(330).string(message.phpNamespace);
        }
        if (message.phpMetadataNamespace !== "") {
            writer.uint32(354).string(message.phpMetadataNamespace);
        }
        if (message.rubyPackage !== "") {
            writer.uint32(362).string(message.rubyPackage);
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(402).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFileOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.javaPackage = reader.string();
                    break;
                case 8:
                    message.javaOuterClassname = reader.string();
                    break;
                case 10:
                    message.javaMultipleFiles = reader.bool();
                    break;
                case 20:
                    message.javaGenerateEqualsAndHash = reader.bool();
                    break;
                case 27:
                    message.javaStringCheckUtf8 = reader.bool();
                    break;
                case 9:
                    message.optimizeFor = reader.int32();
                    break;
                case 11:
                    message.goPackage = reader.string();
                    break;
                case 16:
                    message.ccGenericServices = reader.bool();
                    break;
                case 17:
                    message.javaGenericServices = reader.bool();
                    break;
                case 18:
                    message.pyGenericServices = reader.bool();
                    break;
                case 23:
                    message.deprecated = reader.bool();
                    break;
                case 31:
                    message.ccEnableArenas = reader.bool();
                    break;
                case 36:
                    message.objcClassPrefix = reader.string();
                    break;
                case 37:
                    message.csharpNamespace = reader.string();
                    break;
                case 39:
                    message.swiftPrefix = reader.string();
                    break;
                case 40:
                    message.phpClassPrefix = reader.string();
                    break;
                case 41:
                    message.phpNamespace = reader.string();
                    break;
                case 44:
                    message.phpMetadataNamespace = reader.string();
                    break;
                case 45:
                    message.rubyPackage = reader.string();
                    break;
                case 50:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFileOptions();
        message.javaPackage = object.javaPackage ?? "";
        message.javaOuterClassname = object.javaOuterClassname ?? "";
        message.javaMultipleFiles = object.javaMultipleFiles ?? false;
        message.javaGenerateEqualsAndHash = object.javaGenerateEqualsAndHash ?? false;
        message.javaStringCheckUtf8 = object.javaStringCheckUtf8 ?? false;
        message.optimizeFor = object.optimizeFor ?? 1;
        message.goPackage = object.goPackage ?? "";
        message.ccGenericServices = object.ccGenericServices ?? false;
        message.javaGenericServices = object.javaGenericServices ?? false;
        message.pyGenericServices = object.pyGenericServices ?? false;
        message.deprecated = object.deprecated ?? false;
        message.ccEnableArenas = object.ccEnableArenas ?? false;
        message.objcClassPrefix = object.objcClassPrefix ?? "";
        message.csharpNamespace = object.csharpNamespace ?? "";
        message.swiftPrefix = object.swiftPrefix ?? "";
        message.phpClassPrefix = object.phpClassPrefix ?? "";
        message.phpNamespace = object.phpNamespace ?? "";
        message.phpMetadataNamespace = object.phpMetadataNamespace ?? "";
        message.rubyPackage = object.rubyPackage ?? "";
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseFileOptions();
        if (object.java_package !== undefined && object.java_package !== null) {
            message.javaPackage = object.java_package;
        }
        if (object.java_outer_classname !== undefined && object.java_outer_classname !== null) {
            message.javaOuterClassname = object.java_outer_classname;
        }
        if (object.java_multiple_files !== undefined && object.java_multiple_files !== null) {
            message.javaMultipleFiles = object.java_multiple_files;
        }
        if (object.java_generate_equals_and_hash !== undefined && object.java_generate_equals_and_hash !== null) {
            message.javaGenerateEqualsAndHash = object.java_generate_equals_and_hash;
        }
        if (object.java_string_check_utf8 !== undefined && object.java_string_check_utf8 !== null) {
            message.javaStringCheckUtf8 = object.java_string_check_utf8;
        }
        if (object.optimize_for !== undefined && object.optimize_for !== null) {
            message.optimizeFor = object.optimize_for;
        }
        if (object.go_package !== undefined && object.go_package !== null) {
            message.goPackage = object.go_package;
        }
        if (object.cc_generic_services !== undefined && object.cc_generic_services !== null) {
            message.ccGenericServices = object.cc_generic_services;
        }
        if (object.java_generic_services !== undefined && object.java_generic_services !== null) {
            message.javaGenericServices = object.java_generic_services;
        }
        if (object.py_generic_services !== undefined && object.py_generic_services !== null) {
            message.pyGenericServices = object.py_generic_services;
        }
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.cc_enable_arenas !== undefined && object.cc_enable_arenas !== null) {
            message.ccEnableArenas = object.cc_enable_arenas;
        }
        if (object.objc_class_prefix !== undefined && object.objc_class_prefix !== null) {
            message.objcClassPrefix = object.objc_class_prefix;
        }
        if (object.csharp_namespace !== undefined && object.csharp_namespace !== null) {
            message.csharpNamespace = object.csharp_namespace;
        }
        if (object.swift_prefix !== undefined && object.swift_prefix !== null) {
            message.swiftPrefix = object.swift_prefix;
        }
        if (object.php_class_prefix !== undefined && object.php_class_prefix !== null) {
            message.phpClassPrefix = object.php_class_prefix;
        }
        if (object.php_namespace !== undefined && object.php_namespace !== null) {
            message.phpNamespace = object.php_namespace;
        }
        if (object.php_metadata_namespace !== undefined && object.php_metadata_namespace !== null) {
            message.phpMetadataNamespace = object.php_metadata_namespace;
        }
        if (object.ruby_package !== undefined && object.ruby_package !== null) {
            message.rubyPackage = object.ruby_package;
        }
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.java_package = message.javaPackage === "" ? undefined : message.javaPackage;
        obj.java_outer_classname = message.javaOuterClassname === "" ? undefined : message.javaOuterClassname;
        obj.java_multiple_files = message.javaMultipleFiles === false ? undefined : message.javaMultipleFiles;
        obj.java_generate_equals_and_hash = message.javaGenerateEqualsAndHash === false ? undefined : message.javaGenerateEqualsAndHash;
        obj.java_string_check_utf8 = message.javaStringCheckUtf8 === false ? undefined : message.javaStringCheckUtf8;
        obj.optimize_for = message.optimizeFor === 1 ? undefined : message.optimizeFor;
        obj.go_package = message.goPackage === "" ? undefined : message.goPackage;
        obj.cc_generic_services = message.ccGenericServices === false ? undefined : message.ccGenericServices;
        obj.java_generic_services = message.javaGenericServices === false ? undefined : message.javaGenericServices;
        obj.py_generic_services = message.pyGenericServices === false ? undefined : message.pyGenericServices;
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.cc_enable_arenas = message.ccEnableArenas === false ? undefined : message.ccEnableArenas;
        obj.objc_class_prefix = message.objcClassPrefix === "" ? undefined : message.objcClassPrefix;
        obj.csharp_namespace = message.csharpNamespace === "" ? undefined : message.csharpNamespace;
        obj.swift_prefix = message.swiftPrefix === "" ? undefined : message.swiftPrefix;
        obj.php_class_prefix = message.phpClassPrefix === "" ? undefined : message.phpClassPrefix;
        obj.php_namespace = message.phpNamespace === "" ? undefined : message.phpNamespace;
        obj.php_metadata_namespace = message.phpMetadataNamespace === "" ? undefined : message.phpMetadataNamespace;
        obj.ruby_package = message.rubyPackage === "" ? undefined : message.rubyPackage;
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return FileOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FileOptions.decode(message.value);
    },
    toProto (message) {
        return FileOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FileOptions",
            value: FileOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FileOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseMessageOptions() {
    return {
        messageSetWireFormat: false,
        noStandardDescriptorAccessor: false,
        deprecated: false,
        mapEntry: false,
        deprecatedLegacyJsonFieldConflicts: false,
        features: undefined,
        uninterpretedOption: []
    };
}
const MessageOptions = {
    typeUrl: "/google.protobuf.MessageOptions",
    is (o) {
        return o && (o.$typeUrl === MessageOptions.typeUrl || typeof o.messageSetWireFormat === "boolean" && typeof o.noStandardDescriptorAccessor === "boolean" && typeof o.deprecated === "boolean" && typeof o.mapEntry === "boolean" && typeof o.deprecatedLegacyJsonFieldConflicts === "boolean" && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MessageOptions.typeUrl || typeof o.message_set_wire_format === "boolean" && typeof o.no_standard_descriptor_accessor === "boolean" && typeof o.deprecated === "boolean" && typeof o.map_entry === "boolean" && typeof o.deprecated_legacy_json_field_conflicts === "boolean" && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.messageSetWireFormat === true) {
            writer.uint32(8).bool(message.messageSetWireFormat);
        }
        if (message.noStandardDescriptorAccessor === true) {
            writer.uint32(16).bool(message.noStandardDescriptorAccessor);
        }
        if (message.deprecated === true) {
            writer.uint32(24).bool(message.deprecated);
        }
        if (message.mapEntry === true) {
            writer.uint32(56).bool(message.mapEntry);
        }
        if (message.deprecatedLegacyJsonFieldConflicts === true) {
            writer.uint32(88).bool(message.deprecatedLegacyJsonFieldConflicts);
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(98).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMessageOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.messageSetWireFormat = reader.bool();
                    break;
                case 2:
                    message.noStandardDescriptorAccessor = reader.bool();
                    break;
                case 3:
                    message.deprecated = reader.bool();
                    break;
                case 7:
                    message.mapEntry = reader.bool();
                    break;
                case 11:
                    message.deprecatedLegacyJsonFieldConflicts = reader.bool();
                    break;
                case 12:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMessageOptions();
        message.messageSetWireFormat = object.messageSetWireFormat ?? false;
        message.noStandardDescriptorAccessor = object.noStandardDescriptorAccessor ?? false;
        message.deprecated = object.deprecated ?? false;
        message.mapEntry = object.mapEntry ?? false;
        message.deprecatedLegacyJsonFieldConflicts = object.deprecatedLegacyJsonFieldConflicts ?? false;
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMessageOptions();
        if (object.message_set_wire_format !== undefined && object.message_set_wire_format !== null) {
            message.messageSetWireFormat = object.message_set_wire_format;
        }
        if (object.no_standard_descriptor_accessor !== undefined && object.no_standard_descriptor_accessor !== null) {
            message.noStandardDescriptorAccessor = object.no_standard_descriptor_accessor;
        }
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.map_entry !== undefined && object.map_entry !== null) {
            message.mapEntry = object.map_entry;
        }
        if (object.deprecated_legacy_json_field_conflicts !== undefined && object.deprecated_legacy_json_field_conflicts !== null) {
            message.deprecatedLegacyJsonFieldConflicts = object.deprecated_legacy_json_field_conflicts;
        }
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.message_set_wire_format = message.messageSetWireFormat === false ? undefined : message.messageSetWireFormat;
        obj.no_standard_descriptor_accessor = message.noStandardDescriptorAccessor === false ? undefined : message.noStandardDescriptorAccessor;
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.map_entry = message.mapEntry === false ? undefined : message.mapEntry;
        obj.deprecated_legacy_json_field_conflicts = message.deprecatedLegacyJsonFieldConflicts === false ? undefined : message.deprecatedLegacyJsonFieldConflicts;
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MessageOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return MessageOptions.decode(message.value);
    },
    toProto (message) {
        return MessageOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.MessageOptions",
            value: MessageOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MessageOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseFieldOptions() {
    return {
        ctype: 1,
        packed: false,
        jstype: 1,
        lazy: false,
        unverifiedLazy: false,
        deprecated: false,
        weak: false,
        debugRedact: false,
        retention: 1,
        targets: [],
        editionDefaults: [],
        features: undefined,
        featureSupport: undefined,
        uninterpretedOption: []
    };
}
const FieldOptions = {
    typeUrl: "/google.protobuf.FieldOptions",
    is (o) {
        return o && (o.$typeUrl === FieldOptions.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.ctype) && typeof o.packed === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.jstype) && typeof o.lazy === "boolean" && typeof o.unverifiedLazy === "boolean" && typeof o.deprecated === "boolean" && typeof o.weak === "boolean" && typeof o.debugRedact === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.retention) && Array.isArray(o.targets) && Array.isArray(o.editionDefaults) && (!o.editionDefaults.length || FieldOptions_EditionDefault.is(o.editionDefaults[0])) && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FieldOptions.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.ctype) && typeof o.packed === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.jstype) && typeof o.lazy === "boolean" && typeof o.unverified_lazy === "boolean" && typeof o.deprecated === "boolean" && typeof o.weak === "boolean" && typeof o.debug_redact === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.retention) && Array.isArray(o.targets) && Array.isArray(o.edition_defaults) && (!o.edition_defaults.length || FieldOptions_EditionDefault.isAmino(o.edition_defaults[0])) && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.ctype !== 1) {
            writer.uint32(8).int32(message.ctype);
        }
        if (message.packed === true) {
            writer.uint32(16).bool(message.packed);
        }
        if (message.jstype !== 1) {
            writer.uint32(48).int32(message.jstype);
        }
        if (message.lazy === true) {
            writer.uint32(40).bool(message.lazy);
        }
        if (message.unverifiedLazy === true) {
            writer.uint32(120).bool(message.unverifiedLazy);
        }
        if (message.deprecated === true) {
            writer.uint32(24).bool(message.deprecated);
        }
        if (message.weak === true) {
            writer.uint32(80).bool(message.weak);
        }
        if (message.debugRedact === true) {
            writer.uint32(128).bool(message.debugRedact);
        }
        if (message.retention !== 1) {
            writer.uint32(136).int32(message.retention);
        }
        writer.uint32(154).fork();
        for (const v of message.targets){
            writer.int32(v);
        }
        writer.ldelim();
        for (const v of message.editionDefaults){
            FieldOptions_EditionDefault.encode(v, writer.uint32(162).fork()).ldelim();
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(170).fork()).ldelim();
        }
        if (message.featureSupport !== undefined) {
            FieldOptions_FeatureSupport.encode(message.featureSupport, writer.uint32(178).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.ctype = reader.int32();
                    break;
                case 2:
                    message.packed = reader.bool();
                    break;
                case 6:
                    message.jstype = reader.int32();
                    break;
                case 5:
                    message.lazy = reader.bool();
                    break;
                case 15:
                    message.unverifiedLazy = reader.bool();
                    break;
                case 3:
                    message.deprecated = reader.bool();
                    break;
                case 10:
                    message.weak = reader.bool();
                    break;
                case 16:
                    message.debugRedact = reader.bool();
                    break;
                case 17:
                    message.retention = reader.int32();
                    break;
                case 19:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.targets.push(reader.int32());
                        }
                    } else {
                        message.targets.push(reader.int32());
                    }
                    break;
                case 20:
                    message.editionDefaults.push(FieldOptions_EditionDefault.decode(reader, reader.uint32()));
                    break;
                case 21:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 22:
                    message.featureSupport = FieldOptions_FeatureSupport.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFieldOptions();
        message.ctype = object.ctype ?? 1;
        message.packed = object.packed ?? false;
        message.jstype = object.jstype ?? 1;
        message.lazy = object.lazy ?? false;
        message.unverifiedLazy = object.unverifiedLazy ?? false;
        message.deprecated = object.deprecated ?? false;
        message.weak = object.weak ?? false;
        message.debugRedact = object.debugRedact ?? false;
        message.retention = object.retention ?? 1;
        message.targets = object.targets?.map((e)=>e) || [];
        message.editionDefaults = object.editionDefaults?.map((e)=>FieldOptions_EditionDefault.fromPartial(e)) || [];
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.featureSupport = object.featureSupport !== undefined && object.featureSupport !== null ? FieldOptions_FeatureSupport.fromPartial(object.featureSupport) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseFieldOptions();
        if (object.ctype !== undefined && object.ctype !== null) {
            message.ctype = object.ctype;
        }
        if (object.packed !== undefined && object.packed !== null) {
            message.packed = object.packed;
        }
        if (object.jstype !== undefined && object.jstype !== null) {
            message.jstype = object.jstype;
        }
        if (object.lazy !== undefined && object.lazy !== null) {
            message.lazy = object.lazy;
        }
        if (object.unverified_lazy !== undefined && object.unverified_lazy !== null) {
            message.unverifiedLazy = object.unverified_lazy;
        }
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.weak !== undefined && object.weak !== null) {
            message.weak = object.weak;
        }
        if (object.debug_redact !== undefined && object.debug_redact !== null) {
            message.debugRedact = object.debug_redact;
        }
        if (object.retention !== undefined && object.retention !== null) {
            message.retention = object.retention;
        }
        message.targets = object.targets?.map((e)=>e) || [];
        message.editionDefaults = object.edition_defaults?.map((e)=>FieldOptions_EditionDefault.fromAmino(e)) || [];
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        if (object.feature_support !== undefined && object.feature_support !== null) {
            message.featureSupport = FieldOptions_FeatureSupport.fromAmino(object.feature_support);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.ctype = message.ctype === 1 ? undefined : message.ctype;
        obj.packed = message.packed === false ? undefined : message.packed;
        obj.jstype = message.jstype === 1 ? undefined : message.jstype;
        obj.lazy = message.lazy === false ? undefined : message.lazy;
        obj.unverified_lazy = message.unverifiedLazy === false ? undefined : message.unverifiedLazy;
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.weak = message.weak === false ? undefined : message.weak;
        obj.debug_redact = message.debugRedact === false ? undefined : message.debugRedact;
        obj.retention = message.retention === 1 ? undefined : message.retention;
        if (message.targets) {
            obj.targets = message.targets.map((e)=>e);
        } else {
            obj.targets = message.targets;
        }
        if (message.editionDefaults) {
            obj.edition_defaults = message.editionDefaults.map((e)=>e ? FieldOptions_EditionDefault.toAmino(e) : undefined);
        } else {
            obj.edition_defaults = message.editionDefaults;
        }
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        obj.feature_support = message.featureSupport ? FieldOptions_FeatureSupport.toAmino(message.featureSupport) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return FieldOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FieldOptions.decode(message.value);
    },
    toProto (message) {
        return FieldOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FieldOptions",
            value: FieldOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FieldOptions.typeUrl)) {
            return;
        }
        FieldOptions_EditionDefault.registerTypeUrl();
        FeatureSet.registerTypeUrl();
        FieldOptions_FeatureSupport.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseFieldOptions_EditionDefault() {
    return {
        edition: 1,
        value: ""
    };
}
const FieldOptions_EditionDefault = {
    typeUrl: "/google.protobuf.EditionDefault",
    is (o) {
        return o && (o.$typeUrl === FieldOptions_EditionDefault.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition) && typeof o.value === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === FieldOptions_EditionDefault.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition) && typeof o.value === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.edition !== 1) {
            writer.uint32(24).int32(message.edition);
        }
        if (message.value !== "") {
            writer.uint32(18).string(message.value);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldOptions_EditionDefault();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 3:
                    message.edition = reader.int32();
                    break;
                case 2:
                    message.value = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFieldOptions_EditionDefault();
        message.edition = object.edition ?? 1;
        message.value = object.value ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseFieldOptions_EditionDefault();
        if (object.edition !== undefined && object.edition !== null) {
            message.edition = object.edition;
        }
        if (object.value !== undefined && object.value !== null) {
            message.value = object.value;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.edition = message.edition === 1 ? undefined : message.edition;
        obj.value = message.value === "" ? undefined : message.value;
        return obj;
    },
    fromAminoMsg (object) {
        return FieldOptions_EditionDefault.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FieldOptions_EditionDefault.decode(message.value);
    },
    toProto (message) {
        return FieldOptions_EditionDefault.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EditionDefault",
            value: FieldOptions_EditionDefault.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseFieldOptions_FeatureSupport() {
    return {
        editionIntroduced: 1,
        editionDeprecated: 1,
        deprecationWarning: "",
        editionRemoved: 1
    };
}
const FieldOptions_FeatureSupport = {
    typeUrl: "/google.protobuf.FeatureSupport",
    is (o) {
        return o && (o.$typeUrl === FieldOptions_FeatureSupport.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.editionIntroduced) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.editionDeprecated) && typeof o.deprecationWarning === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.editionRemoved));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FieldOptions_FeatureSupport.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition_introduced) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition_deprecated) && typeof o.deprecation_warning === "string" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition_removed));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.editionIntroduced !== 1) {
            writer.uint32(8).int32(message.editionIntroduced);
        }
        if (message.editionDeprecated !== 1) {
            writer.uint32(16).int32(message.editionDeprecated);
        }
        if (message.deprecationWarning !== "") {
            writer.uint32(26).string(message.deprecationWarning);
        }
        if (message.editionRemoved !== 1) {
            writer.uint32(32).int32(message.editionRemoved);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFieldOptions_FeatureSupport();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.editionIntroduced = reader.int32();
                    break;
                case 2:
                    message.editionDeprecated = reader.int32();
                    break;
                case 3:
                    message.deprecationWarning = reader.string();
                    break;
                case 4:
                    message.editionRemoved = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFieldOptions_FeatureSupport();
        message.editionIntroduced = object.editionIntroduced ?? 1;
        message.editionDeprecated = object.editionDeprecated ?? 1;
        message.deprecationWarning = object.deprecationWarning ?? "";
        message.editionRemoved = object.editionRemoved ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFieldOptions_FeatureSupport();
        if (object.edition_introduced !== undefined && object.edition_introduced !== null) {
            message.editionIntroduced = object.edition_introduced;
        }
        if (object.edition_deprecated !== undefined && object.edition_deprecated !== null) {
            message.editionDeprecated = object.edition_deprecated;
        }
        if (object.deprecation_warning !== undefined && object.deprecation_warning !== null) {
            message.deprecationWarning = object.deprecation_warning;
        }
        if (object.edition_removed !== undefined && object.edition_removed !== null) {
            message.editionRemoved = object.edition_removed;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.edition_introduced = message.editionIntroduced === 1 ? undefined : message.editionIntroduced;
        obj.edition_deprecated = message.editionDeprecated === 1 ? undefined : message.editionDeprecated;
        obj.deprecation_warning = message.deprecationWarning === "" ? undefined : message.deprecationWarning;
        obj.edition_removed = message.editionRemoved === 1 ? undefined : message.editionRemoved;
        return obj;
    },
    fromAminoMsg (object) {
        return FieldOptions_FeatureSupport.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FieldOptions_FeatureSupport.decode(message.value);
    },
    toProto (message) {
        return FieldOptions_FeatureSupport.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FeatureSupport",
            value: FieldOptions_FeatureSupport.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseOneofOptions() {
    return {
        features: undefined,
        uninterpretedOption: []
    };
}
const OneofOptions = {
    typeUrl: "/google.protobuf.OneofOptions",
    is (o) {
        return o && (o.$typeUrl === OneofOptions.typeUrl || Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === OneofOptions.typeUrl || Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(10).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseOneofOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseOneofOptions();
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseOneofOptions();
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return OneofOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return OneofOptions.decode(message.value);
    },
    toProto (message) {
        return OneofOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.OneofOptions",
            value: OneofOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(OneofOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseEnumOptions() {
    return {
        allowAlias: false,
        deprecated: false,
        deprecatedLegacyJsonFieldConflicts: false,
        features: undefined,
        uninterpretedOption: []
    };
}
const EnumOptions = {
    typeUrl: "/google.protobuf.EnumOptions",
    is (o) {
        return o && (o.$typeUrl === EnumOptions.typeUrl || typeof o.allowAlias === "boolean" && typeof o.deprecated === "boolean" && typeof o.deprecatedLegacyJsonFieldConflicts === "boolean" && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === EnumOptions.typeUrl || typeof o.allow_alias === "boolean" && typeof o.deprecated === "boolean" && typeof o.deprecated_legacy_json_field_conflicts === "boolean" && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.allowAlias === true) {
            writer.uint32(16).bool(message.allowAlias);
        }
        if (message.deprecated === true) {
            writer.uint32(24).bool(message.deprecated);
        }
        if (message.deprecatedLegacyJsonFieldConflicts === true) {
            writer.uint32(48).bool(message.deprecatedLegacyJsonFieldConflicts);
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(58).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnumOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 2:
                    message.allowAlias = reader.bool();
                    break;
                case 3:
                    message.deprecated = reader.bool();
                    break;
                case 6:
                    message.deprecatedLegacyJsonFieldConflicts = reader.bool();
                    break;
                case 7:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseEnumOptions();
        message.allowAlias = object.allowAlias ?? false;
        message.deprecated = object.deprecated ?? false;
        message.deprecatedLegacyJsonFieldConflicts = object.deprecatedLegacyJsonFieldConflicts ?? false;
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseEnumOptions();
        if (object.allow_alias !== undefined && object.allow_alias !== null) {
            message.allowAlias = object.allow_alias;
        }
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.deprecated_legacy_json_field_conflicts !== undefined && object.deprecated_legacy_json_field_conflicts !== null) {
            message.deprecatedLegacyJsonFieldConflicts = object.deprecated_legacy_json_field_conflicts;
        }
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.allow_alias = message.allowAlias === false ? undefined : message.allowAlias;
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.deprecated_legacy_json_field_conflicts = message.deprecatedLegacyJsonFieldConflicts === false ? undefined : message.deprecatedLegacyJsonFieldConflicts;
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return EnumOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return EnumOptions.decode(message.value);
    },
    toProto (message) {
        return EnumOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EnumOptions",
            value: EnumOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(EnumOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseEnumValueOptions() {
    return {
        deprecated: false,
        features: undefined,
        debugRedact: false,
        featureSupport: undefined,
        uninterpretedOption: []
    };
}
const EnumValueOptions = {
    typeUrl: "/google.protobuf.EnumValueOptions",
    is (o) {
        return o && (o.$typeUrl === EnumValueOptions.typeUrl || typeof o.deprecated === "boolean" && typeof o.debugRedact === "boolean" && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === EnumValueOptions.typeUrl || typeof o.deprecated === "boolean" && typeof o.debug_redact === "boolean" && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.deprecated === true) {
            writer.uint32(8).bool(message.deprecated);
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(18).fork()).ldelim();
        }
        if (message.debugRedact === true) {
            writer.uint32(24).bool(message.debugRedact);
        }
        if (message.featureSupport !== undefined) {
            FieldOptions_FeatureSupport.encode(message.featureSupport, writer.uint32(34).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseEnumValueOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.deprecated = reader.bool();
                    break;
                case 2:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 3:
                    message.debugRedact = reader.bool();
                    break;
                case 4:
                    message.featureSupport = FieldOptions_FeatureSupport.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseEnumValueOptions();
        message.deprecated = object.deprecated ?? false;
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.debugRedact = object.debugRedact ?? false;
        message.featureSupport = object.featureSupport !== undefined && object.featureSupport !== null ? FieldOptions_FeatureSupport.fromPartial(object.featureSupport) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseEnumValueOptions();
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        if (object.debug_redact !== undefined && object.debug_redact !== null) {
            message.debugRedact = object.debug_redact;
        }
        if (object.feature_support !== undefined && object.feature_support !== null) {
            message.featureSupport = FieldOptions_FeatureSupport.fromAmino(object.feature_support);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        obj.debug_redact = message.debugRedact === false ? undefined : message.debugRedact;
        obj.feature_support = message.featureSupport ? FieldOptions_FeatureSupport.toAmino(message.featureSupport) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return EnumValueOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return EnumValueOptions.decode(message.value);
    },
    toProto (message) {
        return EnumValueOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.EnumValueOptions",
            value: EnumValueOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(EnumValueOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        FieldOptions_FeatureSupport.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseServiceOptions() {
    return {
        features: undefined,
        deprecated: false,
        uninterpretedOption: []
    };
}
const ServiceOptions = {
    typeUrl: "/google.protobuf.ServiceOptions",
    is (o) {
        return o && (o.$typeUrl === ServiceOptions.typeUrl || typeof o.deprecated === "boolean" && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === ServiceOptions.typeUrl || typeof o.deprecated === "boolean" && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(274).fork()).ldelim();
        }
        if (message.deprecated === true) {
            writer.uint32(264).bool(message.deprecated);
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseServiceOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 34:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 33:
                    message.deprecated = reader.bool();
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseServiceOptions();
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.deprecated = object.deprecated ?? false;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseServiceOptions();
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return ServiceOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return ServiceOptions.decode(message.value);
    },
    toProto (message) {
        return ServiceOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.ServiceOptions",
            value: ServiceOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(ServiceOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseMethodOptions() {
    return {
        deprecated: false,
        idempotencyLevel: 1,
        features: undefined,
        uninterpretedOption: []
    };
}
const MethodOptions = {
    typeUrl: "/google.protobuf.MethodOptions",
    is (o) {
        return o && (o.$typeUrl === MethodOptions.typeUrl || typeof o.deprecated === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.idempotencyLevel) && Array.isArray(o.uninterpretedOption) && (!o.uninterpretedOption.length || UninterpretedOption.is(o.uninterpretedOption[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === MethodOptions.typeUrl || typeof o.deprecated === "boolean" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.idempotency_level) && Array.isArray(o.uninterpreted_option) && (!o.uninterpreted_option.length || UninterpretedOption.isAmino(o.uninterpreted_option[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.deprecated === true) {
            writer.uint32(264).bool(message.deprecated);
        }
        if (message.idempotencyLevel !== 1) {
            writer.uint32(272).int32(message.idempotencyLevel);
        }
        if (message.features !== undefined) {
            FeatureSet.encode(message.features, writer.uint32(282).fork()).ldelim();
        }
        for (const v of message.uninterpretedOption){
            UninterpretedOption.encode(v, writer.uint32(7994).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseMethodOptions();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 33:
                    message.deprecated = reader.bool();
                    break;
                case 34:
                    message.idempotencyLevel = reader.int32();
                    break;
                case 35:
                    message.features = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 999:
                    message.uninterpretedOption.push(UninterpretedOption.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseMethodOptions();
        message.deprecated = object.deprecated ?? false;
        message.idempotencyLevel = object.idempotencyLevel ?? 1;
        message.features = object.features !== undefined && object.features !== null ? FeatureSet.fromPartial(object.features) : undefined;
        message.uninterpretedOption = object.uninterpretedOption?.map((e)=>UninterpretedOption.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseMethodOptions();
        if (object.deprecated !== undefined && object.deprecated !== null) {
            message.deprecated = object.deprecated;
        }
        if (object.idempotency_level !== undefined && object.idempotency_level !== null) {
            message.idempotencyLevel = object.idempotency_level;
        }
        if (object.features !== undefined && object.features !== null) {
            message.features = FeatureSet.fromAmino(object.features);
        }
        message.uninterpretedOption = object.uninterpreted_option?.map((e)=>UninterpretedOption.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.deprecated = message.deprecated === false ? undefined : message.deprecated;
        obj.idempotency_level = message.idempotencyLevel === 1 ? undefined : message.idempotencyLevel;
        obj.features = message.features ? FeatureSet.toAmino(message.features) : undefined;
        if (message.uninterpretedOption) {
            obj.uninterpreted_option = message.uninterpretedOption.map((e)=>e ? UninterpretedOption.toAmino(e) : undefined);
        } else {
            obj.uninterpreted_option = message.uninterpretedOption;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return MethodOptions.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return MethodOptions.decode(message.value);
    },
    toProto (message) {
        return MethodOptions.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.MethodOptions",
            value: MethodOptions.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(MethodOptions.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
        UninterpretedOption.registerTypeUrl();
    }
};
function createBaseUninterpretedOption() {
    return {
        name: [],
        identifierValue: "",
        positiveIntValue: BigInt(0),
        negativeIntValue: BigInt(0),
        doubleValue: 0,
        stringValue: new Uint8Array(),
        aggregateValue: ""
    };
}
const UninterpretedOption = {
    typeUrl: "/google.protobuf.UninterpretedOption",
    is (o) {
        return o && (o.$typeUrl === UninterpretedOption.typeUrl || Array.isArray(o.name) && (!o.name.length || UninterpretedOption_NamePart.is(o.name[0])) && typeof o.identifierValue === "string" && typeof o.positiveIntValue === "bigint" && typeof o.negativeIntValue === "bigint" && typeof o.doubleValue === "number" && (o.stringValue instanceof Uint8Array || typeof o.stringValue === "string") && typeof o.aggregateValue === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === UninterpretedOption.typeUrl || Array.isArray(o.name) && (!o.name.length || UninterpretedOption_NamePart.isAmino(o.name[0])) && typeof o.identifier_value === "string" && typeof o.positive_int_value === "bigint" && typeof o.negative_int_value === "bigint" && typeof o.double_value === "number" && (o.string_value instanceof Uint8Array || typeof o.string_value === "string") && typeof o.aggregate_value === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.name){
            UninterpretedOption_NamePart.encode(v, writer.uint32(18).fork()).ldelim();
        }
        if (message.identifierValue !== "") {
            writer.uint32(26).string(message.identifierValue);
        }
        if (message.positiveIntValue !== BigInt(0)) {
            writer.uint32(32).uint64(message.positiveIntValue);
        }
        if (message.negativeIntValue !== BigInt(0)) {
            writer.uint32(40).int64(message.negativeIntValue);
        }
        if (message.doubleValue !== 0) {
            writer.uint32(49).double(message.doubleValue);
        }
        if (message.stringValue.length !== 0) {
            writer.uint32(58).bytes(message.stringValue);
        }
        if (message.aggregateValue !== "") {
            writer.uint32(66).string(message.aggregateValue);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUninterpretedOption();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 2:
                    message.name.push(UninterpretedOption_NamePart.decode(reader, reader.uint32()));
                    break;
                case 3:
                    message.identifierValue = reader.string();
                    break;
                case 4:
                    message.positiveIntValue = reader.uint64();
                    break;
                case 5:
                    message.negativeIntValue = reader.int64();
                    break;
                case 6:
                    message.doubleValue = reader.double();
                    break;
                case 7:
                    message.stringValue = reader.bytes();
                    break;
                case 8:
                    message.aggregateValue = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseUninterpretedOption();
        message.name = object.name?.map((e)=>UninterpretedOption_NamePart.fromPartial(e)) || [];
        message.identifierValue = object.identifierValue ?? "";
        message.positiveIntValue = object.positiveIntValue !== undefined && object.positiveIntValue !== null ? BigInt(object.positiveIntValue.toString()) : BigInt(0);
        message.negativeIntValue = object.negativeIntValue !== undefined && object.negativeIntValue !== null ? BigInt(object.negativeIntValue.toString()) : BigInt(0);
        message.doubleValue = object.doubleValue ?? 0;
        message.stringValue = object.stringValue ?? new Uint8Array();
        message.aggregateValue = object.aggregateValue ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseUninterpretedOption();
        message.name = object.name?.map((e)=>UninterpretedOption_NamePart.fromAmino(e)) || [];
        if (object.identifier_value !== undefined && object.identifier_value !== null) {
            message.identifierValue = object.identifier_value;
        }
        if (object.positive_int_value !== undefined && object.positive_int_value !== null) {
            message.positiveIntValue = BigInt(object.positive_int_value);
        }
        if (object.negative_int_value !== undefined && object.negative_int_value !== null) {
            message.negativeIntValue = BigInt(object.negative_int_value);
        }
        if (object.double_value !== undefined && object.double_value !== null) {
            message.doubleValue = object.double_value;
        }
        if (object.string_value !== undefined && object.string_value !== null) {
            message.stringValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bytesFromBase64"])(object.string_value);
        }
        if (object.aggregate_value !== undefined && object.aggregate_value !== null) {
            message.aggregateValue = object.aggregate_value;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.name) {
            obj.name = message.name.map((e)=>e ? UninterpretedOption_NamePart.toAmino(e) : undefined);
        } else {
            obj.name = message.name;
        }
        obj.identifier_value = message.identifierValue === "" ? undefined : message.identifierValue;
        obj.positive_int_value = message.positiveIntValue !== BigInt(0) ? message.positiveIntValue?.toString() : undefined;
        obj.negative_int_value = message.negativeIntValue !== BigInt(0) ? message.negativeIntValue?.toString() : undefined;
        obj.double_value = message.doubleValue === 0 ? undefined : message.doubleValue;
        obj.string_value = message.stringValue ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64FromBytes"])(message.stringValue) : undefined;
        obj.aggregate_value = message.aggregateValue === "" ? undefined : message.aggregateValue;
        return obj;
    },
    fromAminoMsg (object) {
        return UninterpretedOption.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return UninterpretedOption.decode(message.value);
    },
    toProto (message) {
        return UninterpretedOption.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.UninterpretedOption",
            value: UninterpretedOption.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(UninterpretedOption.typeUrl)) {
            return;
        }
        UninterpretedOption_NamePart.registerTypeUrl();
    }
};
function createBaseUninterpretedOption_NamePart() {
    return {
        namePart: "",
        isExtension: false
    };
}
const UninterpretedOption_NamePart = {
    typeUrl: "/google.protobuf.NamePart",
    is (o) {
        return o && (o.$typeUrl === UninterpretedOption_NamePart.typeUrl || typeof o.namePart === "string" && typeof o.isExtension === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === UninterpretedOption_NamePart.typeUrl || typeof o.name_part === "string" && typeof o.is_extension === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.namePart !== "") {
            writer.uint32(10).string(message.namePart);
        }
        if (message.isExtension === true) {
            writer.uint32(16).bool(message.isExtension);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseUninterpretedOption_NamePart();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.namePart = reader.string();
                    break;
                case 2:
                    message.isExtension = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseUninterpretedOption_NamePart();
        message.namePart = object.namePart ?? "";
        message.isExtension = object.isExtension ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseUninterpretedOption_NamePart();
        if (object.name_part !== undefined && object.name_part !== null) {
            message.namePart = object.name_part;
        }
        if (object.is_extension !== undefined && object.is_extension !== null) {
            message.isExtension = object.is_extension;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.name_part = message.namePart === "" ? undefined : message.namePart;
        obj.is_extension = message.isExtension === false ? undefined : message.isExtension;
        return obj;
    },
    fromAminoMsg (object) {
        return UninterpretedOption_NamePart.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return UninterpretedOption_NamePart.decode(message.value);
    },
    toProto (message) {
        return UninterpretedOption_NamePart.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.NamePart",
            value: UninterpretedOption_NamePart.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseFeatureSet() {
    return {
        fieldPresence: 1,
        enumType: 1,
        repeatedFieldEncoding: 1,
        utf8Validation: 0,
        messageEncoding: 1,
        jsonFormat: 1
    };
}
const FeatureSet = {
    typeUrl: "/google.protobuf.FeatureSet",
    is (o) {
        return o && (o.$typeUrl === FeatureSet.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.fieldPresence) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.enumType) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.repeatedFieldEncoding) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.utf8Validation) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.messageEncoding) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.jsonFormat));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FeatureSet.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.field_presence) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.enum_type) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.repeated_field_encoding) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.utf8_validation) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.message_encoding) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.json_format));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.fieldPresence !== 1) {
            writer.uint32(8).int32(message.fieldPresence);
        }
        if (message.enumType !== 1) {
            writer.uint32(16).int32(message.enumType);
        }
        if (message.repeatedFieldEncoding !== 1) {
            writer.uint32(24).int32(message.repeatedFieldEncoding);
        }
        if (message.utf8Validation !== 0) {
            writer.uint32(32).int32(message.utf8Validation);
        }
        if (message.messageEncoding !== 1) {
            writer.uint32(40).int32(message.messageEncoding);
        }
        if (message.jsonFormat !== 1) {
            writer.uint32(48).int32(message.jsonFormat);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFeatureSet();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.fieldPresence = reader.int32();
                    break;
                case 2:
                    message.enumType = reader.int32();
                    break;
                case 3:
                    message.repeatedFieldEncoding = reader.int32();
                    break;
                case 4:
                    message.utf8Validation = reader.int32();
                    break;
                case 5:
                    message.messageEncoding = reader.int32();
                    break;
                case 6:
                    message.jsonFormat = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFeatureSet();
        message.fieldPresence = object.fieldPresence ?? 1;
        message.enumType = object.enumType ?? 1;
        message.repeatedFieldEncoding = object.repeatedFieldEncoding ?? 1;
        message.utf8Validation = object.utf8Validation ?? 0;
        message.messageEncoding = object.messageEncoding ?? 1;
        message.jsonFormat = object.jsonFormat ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFeatureSet();
        if (object.field_presence !== undefined && object.field_presence !== null) {
            message.fieldPresence = object.field_presence;
        }
        if (object.enum_type !== undefined && object.enum_type !== null) {
            message.enumType = object.enum_type;
        }
        if (object.repeated_field_encoding !== undefined && object.repeated_field_encoding !== null) {
            message.repeatedFieldEncoding = object.repeated_field_encoding;
        }
        if (object.utf8_validation !== undefined && object.utf8_validation !== null) {
            message.utf8Validation = object.utf8_validation;
        }
        if (object.message_encoding !== undefined && object.message_encoding !== null) {
            message.messageEncoding = object.message_encoding;
        }
        if (object.json_format !== undefined && object.json_format !== null) {
            message.jsonFormat = object.json_format;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.field_presence = message.fieldPresence === 1 ? undefined : message.fieldPresence;
        obj.enum_type = message.enumType === 1 ? undefined : message.enumType;
        obj.repeated_field_encoding = message.repeatedFieldEncoding === 1 ? undefined : message.repeatedFieldEncoding;
        obj.utf8_validation = message.utf8Validation === 0 ? undefined : message.utf8Validation;
        obj.message_encoding = message.messageEncoding === 1 ? undefined : message.messageEncoding;
        obj.json_format = message.jsonFormat === 1 ? undefined : message.jsonFormat;
        return obj;
    },
    fromAminoMsg (object) {
        return FeatureSet.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FeatureSet.decode(message.value);
    },
    toProto (message) {
        return FeatureSet.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FeatureSet",
            value: FeatureSet.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseFeatureSetDefaults() {
    return {
        defaults: [],
        minimumEdition: 1,
        maximumEdition: 1
    };
}
const FeatureSetDefaults = {
    typeUrl: "/google.protobuf.FeatureSetDefaults",
    is (o) {
        return o && (o.$typeUrl === FeatureSetDefaults.typeUrl || Array.isArray(o.defaults) && (!o.defaults.length || FeatureSetDefaults_FeatureSetEditionDefault.is(o.defaults[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.minimumEdition) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.maximumEdition));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FeatureSetDefaults.typeUrl || Array.isArray(o.defaults) && (!o.defaults.length || FeatureSetDefaults_FeatureSetEditionDefault.isAmino(o.defaults[0])) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.minimum_edition) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.maximum_edition));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.defaults){
            FeatureSetDefaults_FeatureSetEditionDefault.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.minimumEdition !== 1) {
            writer.uint32(32).int32(message.minimumEdition);
        }
        if (message.maximumEdition !== 1) {
            writer.uint32(40).int32(message.maximumEdition);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFeatureSetDefaults();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.defaults.push(FeatureSetDefaults_FeatureSetEditionDefault.decode(reader, reader.uint32()));
                    break;
                case 4:
                    message.minimumEdition = reader.int32();
                    break;
                case 5:
                    message.maximumEdition = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFeatureSetDefaults();
        message.defaults = object.defaults?.map((e)=>FeatureSetDefaults_FeatureSetEditionDefault.fromPartial(e)) || [];
        message.minimumEdition = object.minimumEdition ?? 1;
        message.maximumEdition = object.maximumEdition ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFeatureSetDefaults();
        message.defaults = object.defaults?.map((e)=>FeatureSetDefaults_FeatureSetEditionDefault.fromAmino(e)) || [];
        if (object.minimum_edition !== undefined && object.minimum_edition !== null) {
            message.minimumEdition = object.minimum_edition;
        }
        if (object.maximum_edition !== undefined && object.maximum_edition !== null) {
            message.maximumEdition = object.maximum_edition;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.defaults) {
            obj.defaults = message.defaults.map((e)=>e ? FeatureSetDefaults_FeatureSetEditionDefault.toAmino(e) : undefined);
        } else {
            obj.defaults = message.defaults;
        }
        obj.minimum_edition = message.minimumEdition === 1 ? undefined : message.minimumEdition;
        obj.maximum_edition = message.maximumEdition === 1 ? undefined : message.maximumEdition;
        return obj;
    },
    fromAminoMsg (object) {
        return FeatureSetDefaults.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FeatureSetDefaults.decode(message.value);
    },
    toProto (message) {
        return FeatureSetDefaults.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FeatureSetDefaults",
            value: FeatureSetDefaults.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FeatureSetDefaults.typeUrl)) {
            return;
        }
        FeatureSetDefaults_FeatureSetEditionDefault.registerTypeUrl();
    }
};
function createBaseFeatureSetDefaults_FeatureSetEditionDefault() {
    return {
        edition: 1,
        overridableFeatures: undefined,
        fixedFeatures: undefined
    };
}
const FeatureSetDefaults_FeatureSetEditionDefault = {
    typeUrl: "/google.protobuf.FeatureSetEditionDefault",
    is (o) {
        return o && (o.$typeUrl === FeatureSetDefaults_FeatureSetEditionDefault.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition));
    },
    isAmino (o) {
        return o && (o.$typeUrl === FeatureSetDefaults_FeatureSetEditionDefault.typeUrl || (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.edition));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.edition !== 1) {
            writer.uint32(24).int32(message.edition);
        }
        if (message.overridableFeatures !== undefined) {
            FeatureSet.encode(message.overridableFeatures, writer.uint32(34).fork()).ldelim();
        }
        if (message.fixedFeatures !== undefined) {
            FeatureSet.encode(message.fixedFeatures, writer.uint32(42).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseFeatureSetDefaults_FeatureSetEditionDefault();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 3:
                    message.edition = reader.int32();
                    break;
                case 4:
                    message.overridableFeatures = FeatureSet.decode(reader, reader.uint32());
                    break;
                case 5:
                    message.fixedFeatures = FeatureSet.decode(reader, reader.uint32());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseFeatureSetDefaults_FeatureSetEditionDefault();
        message.edition = object.edition ?? 1;
        message.overridableFeatures = object.overridableFeatures !== undefined && object.overridableFeatures !== null ? FeatureSet.fromPartial(object.overridableFeatures) : undefined;
        message.fixedFeatures = object.fixedFeatures !== undefined && object.fixedFeatures !== null ? FeatureSet.fromPartial(object.fixedFeatures) : undefined;
        return message;
    },
    fromAmino (object) {
        const message = createBaseFeatureSetDefaults_FeatureSetEditionDefault();
        if (object.edition !== undefined && object.edition !== null) {
            message.edition = object.edition;
        }
        if (object.overridable_features !== undefined && object.overridable_features !== null) {
            message.overridableFeatures = FeatureSet.fromAmino(object.overridable_features);
        }
        if (object.fixed_features !== undefined && object.fixed_features !== null) {
            message.fixedFeatures = FeatureSet.fromAmino(object.fixed_features);
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.edition = message.edition === 1 ? undefined : message.edition;
        obj.overridable_features = message.overridableFeatures ? FeatureSet.toAmino(message.overridableFeatures) : undefined;
        obj.fixed_features = message.fixedFeatures ? FeatureSet.toAmino(message.fixedFeatures) : undefined;
        return obj;
    },
    fromAminoMsg (object) {
        return FeatureSetDefaults_FeatureSetEditionDefault.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return FeatureSetDefaults_FeatureSetEditionDefault.decode(message.value);
    },
    toProto (message) {
        return FeatureSetDefaults_FeatureSetEditionDefault.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.FeatureSetEditionDefault",
            value: FeatureSetDefaults_FeatureSetEditionDefault.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(FeatureSetDefaults_FeatureSetEditionDefault.typeUrl)) {
            return;
        }
        FeatureSet.registerTypeUrl();
    }
};
function createBaseSourceCodeInfo() {
    return {
        location: []
    };
}
const SourceCodeInfo = {
    typeUrl: "/google.protobuf.SourceCodeInfo",
    is (o) {
        return o && (o.$typeUrl === SourceCodeInfo.typeUrl || Array.isArray(o.location) && (!o.location.length || SourceCodeInfo_Location.is(o.location[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === SourceCodeInfo.typeUrl || Array.isArray(o.location) && (!o.location.length || SourceCodeInfo_Location.isAmino(o.location[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.location){
            SourceCodeInfo_Location.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceCodeInfo();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.location.push(SourceCodeInfo_Location.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSourceCodeInfo();
        message.location = object.location?.map((e)=>SourceCodeInfo_Location.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseSourceCodeInfo();
        message.location = object.location?.map((e)=>SourceCodeInfo_Location.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.location) {
            obj.location = message.location.map((e)=>e ? SourceCodeInfo_Location.toAmino(e) : undefined);
        } else {
            obj.location = message.location;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return SourceCodeInfo.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return SourceCodeInfo.decode(message.value);
    },
    toProto (message) {
        return SourceCodeInfo.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.SourceCodeInfo",
            value: SourceCodeInfo.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(SourceCodeInfo.typeUrl)) {
            return;
        }
        SourceCodeInfo_Location.registerTypeUrl();
    }
};
function createBaseSourceCodeInfo_Location() {
    return {
        path: [],
        span: [],
        leadingComments: "",
        trailingComments: "",
        leadingDetachedComments: []
    };
}
const SourceCodeInfo_Location = {
    typeUrl: "/google.protobuf.Location",
    is (o) {
        return o && (o.$typeUrl === SourceCodeInfo_Location.typeUrl || Array.isArray(o.path) && (!o.path.length || typeof o.path[0] === "number") && Array.isArray(o.span) && (!o.span.length || typeof o.span[0] === "number") && typeof o.leadingComments === "string" && typeof o.trailingComments === "string" && Array.isArray(o.leadingDetachedComments) && (!o.leadingDetachedComments.length || typeof o.leadingDetachedComments[0] === "string"));
    },
    isAmino (o) {
        return o && (o.$typeUrl === SourceCodeInfo_Location.typeUrl || Array.isArray(o.path) && (!o.path.length || typeof o.path[0] === "number") && Array.isArray(o.span) && (!o.span.length || typeof o.span[0] === "number") && typeof o.leading_comments === "string" && typeof o.trailing_comments === "string" && Array.isArray(o.leading_detached_comments) && (!o.leading_detached_comments.length || typeof o.leading_detached_comments[0] === "string"));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        writer.uint32(10).fork();
        for (const v of message.path){
            writer.int32(v);
        }
        writer.ldelim();
        writer.uint32(18).fork();
        for (const v of message.span){
            writer.int32(v);
        }
        writer.ldelim();
        if (message.leadingComments !== "") {
            writer.uint32(26).string(message.leadingComments);
        }
        if (message.trailingComments !== "") {
            writer.uint32(34).string(message.trailingComments);
        }
        for (const v of message.leadingDetachedComments){
            writer.uint32(50).string(v);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseSourceCodeInfo_Location();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.path.push(reader.int32());
                        }
                    } else {
                        message.path.push(reader.int32());
                    }
                    break;
                case 2:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.span.push(reader.int32());
                        }
                    } else {
                        message.span.push(reader.int32());
                    }
                    break;
                case 3:
                    message.leadingComments = reader.string();
                    break;
                case 4:
                    message.trailingComments = reader.string();
                    break;
                case 6:
                    message.leadingDetachedComments.push(reader.string());
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseSourceCodeInfo_Location();
        message.path = object.path?.map((e)=>e) || [];
        message.span = object.span?.map((e)=>e) || [];
        message.leadingComments = object.leadingComments ?? "";
        message.trailingComments = object.trailingComments ?? "";
        message.leadingDetachedComments = object.leadingDetachedComments?.map((e)=>e) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseSourceCodeInfo_Location();
        message.path = object.path?.map((e)=>e) || [];
        message.span = object.span?.map((e)=>e) || [];
        if (object.leading_comments !== undefined && object.leading_comments !== null) {
            message.leadingComments = object.leading_comments;
        }
        if (object.trailing_comments !== undefined && object.trailing_comments !== null) {
            message.trailingComments = object.trailing_comments;
        }
        message.leadingDetachedComments = object.leading_detached_comments?.map((e)=>e) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.path) {
            obj.path = message.path.map((e)=>e);
        } else {
            obj.path = message.path;
        }
        if (message.span) {
            obj.span = message.span.map((e)=>e);
        } else {
            obj.span = message.span;
        }
        obj.leading_comments = message.leadingComments === "" ? undefined : message.leadingComments;
        obj.trailing_comments = message.trailingComments === "" ? undefined : message.trailingComments;
        if (message.leadingDetachedComments) {
            obj.leading_detached_comments = message.leadingDetachedComments.map((e)=>e);
        } else {
            obj.leading_detached_comments = message.leadingDetachedComments;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return SourceCodeInfo_Location.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return SourceCodeInfo_Location.decode(message.value);
    },
    toProto (message) {
        return SourceCodeInfo_Location.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Location",
            value: SourceCodeInfo_Location.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
function createBaseGeneratedCodeInfo() {
    return {
        annotation: []
    };
}
const GeneratedCodeInfo = {
    typeUrl: "/google.protobuf.GeneratedCodeInfo",
    is (o) {
        return o && (o.$typeUrl === GeneratedCodeInfo.typeUrl || Array.isArray(o.annotation) && (!o.annotation.length || GeneratedCodeInfo_Annotation.is(o.annotation[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GeneratedCodeInfo.typeUrl || Array.isArray(o.annotation) && (!o.annotation.length || GeneratedCodeInfo_Annotation.isAmino(o.annotation[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.annotation){
            GeneratedCodeInfo_Annotation.encode(v, writer.uint32(10).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGeneratedCodeInfo();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.annotation.push(GeneratedCodeInfo_Annotation.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGeneratedCodeInfo();
        message.annotation = object.annotation?.map((e)=>GeneratedCodeInfo_Annotation.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseGeneratedCodeInfo();
        message.annotation = object.annotation?.map((e)=>GeneratedCodeInfo_Annotation.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.annotation) {
            obj.annotation = message.annotation.map((e)=>e ? GeneratedCodeInfo_Annotation.toAmino(e) : undefined);
        } else {
            obj.annotation = message.annotation;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return GeneratedCodeInfo.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return GeneratedCodeInfo.decode(message.value);
    },
    toProto (message) {
        return GeneratedCodeInfo.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.GeneratedCodeInfo",
            value: GeneratedCodeInfo.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(GeneratedCodeInfo.typeUrl)) {
            return;
        }
        GeneratedCodeInfo_Annotation.registerTypeUrl();
    }
};
function createBaseGeneratedCodeInfo_Annotation() {
    return {
        path: [],
        sourceFile: "",
        begin: 0,
        end: 0,
        semantic: 1
    };
}
const GeneratedCodeInfo_Annotation = {
    typeUrl: "/google.protobuf.Annotation",
    is (o) {
        return o && (o.$typeUrl === GeneratedCodeInfo_Annotation.typeUrl || Array.isArray(o.path) && (!o.path.length || typeof o.path[0] === "number") && typeof o.sourceFile === "string" && typeof o.begin === "number" && typeof o.end === "number" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.semantic));
    },
    isAmino (o) {
        return o && (o.$typeUrl === GeneratedCodeInfo_Annotation.typeUrl || Array.isArray(o.path) && (!o.path.length || typeof o.path[0] === "number") && typeof o.source_file === "string" && typeof o.begin === "number" && typeof o.end === "number" && (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isSet"])(o.semantic));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        writer.uint32(10).fork();
        for (const v of message.path){
            writer.int32(v);
        }
        writer.ldelim();
        if (message.sourceFile !== "") {
            writer.uint32(18).string(message.sourceFile);
        }
        if (message.begin !== 0) {
            writer.uint32(24).int32(message.begin);
        }
        if (message.end !== 0) {
            writer.uint32(32).int32(message.end);
        }
        if (message.semantic !== 1) {
            writer.uint32(40).int32(message.semantic);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseGeneratedCodeInfo_Annotation();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    if ((tag & 7) === 2) {
                        const end2 = reader.uint32() + reader.pos;
                        while(reader.pos < end2){
                            message.path.push(reader.int32());
                        }
                    } else {
                        message.path.push(reader.int32());
                    }
                    break;
                case 2:
                    message.sourceFile = reader.string();
                    break;
                case 3:
                    message.begin = reader.int32();
                    break;
                case 4:
                    message.end = reader.int32();
                    break;
                case 5:
                    message.semantic = reader.int32();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseGeneratedCodeInfo_Annotation();
        message.path = object.path?.map((e)=>e) || [];
        message.sourceFile = object.sourceFile ?? "";
        message.begin = object.begin ?? 0;
        message.end = object.end ?? 0;
        message.semantic = object.semantic ?? 1;
        return message;
    },
    fromAmino (object) {
        const message = createBaseGeneratedCodeInfo_Annotation();
        message.path = object.path?.map((e)=>e) || [];
        if (object.source_file !== undefined && object.source_file !== null) {
            message.sourceFile = object.source_file;
        }
        if (object.begin !== undefined && object.begin !== null) {
            message.begin = object.begin;
        }
        if (object.end !== undefined && object.end !== null) {
            message.end = object.end;
        }
        if (object.semantic !== undefined && object.semantic !== null) {
            message.semantic = object.semantic;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.path) {
            obj.path = message.path.map((e)=>e);
        } else {
            obj.path = message.path;
        }
        obj.source_file = message.sourceFile === "" ? undefined : message.sourceFile;
        obj.begin = message.begin === 0 ? undefined : message.begin;
        obj.end = message.end === 0 ? undefined : message.end;
        obj.semantic = message.semantic === 1 ? undefined : message.semantic;
        return obj;
    },
    fromAminoMsg (object) {
        return GeneratedCodeInfo_Annotation.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return GeneratedCodeInfo_Annotation.decode(message.value);
    },
    toProto (message) {
        return GeneratedCodeInfo_Annotation.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.protobuf.Annotation",
            value: GeneratedCodeInfo_Annotation.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/api/http.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CustomHttpPattern": (()=>CustomHttpPattern),
    "Http": (()=>Http),
    "HttpRule": (()=>HttpRule)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/binary.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/registry.js [app-client] (ecmascript)");
;
;
function createBaseHttp() {
    return {
        rules: [],
        fullyDecodeReservedExpansion: false
    };
}
const Http = {
    typeUrl: "/google.api.Http",
    is (o) {
        return o && (o.$typeUrl === Http.typeUrl || Array.isArray(o.rules) && (!o.rules.length || HttpRule.is(o.rules[0])) && typeof o.fullyDecodeReservedExpansion === "boolean");
    },
    isAmino (o) {
        return o && (o.$typeUrl === Http.typeUrl || Array.isArray(o.rules) && (!o.rules.length || HttpRule.isAmino(o.rules[0])) && typeof o.fully_decode_reserved_expansion === "boolean");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        for (const v of message.rules){
            HttpRule.encode(v, writer.uint32(10).fork()).ldelim();
        }
        if (message.fullyDecodeReservedExpansion === true) {
            writer.uint32(16).bool(message.fullyDecodeReservedExpansion);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttp();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.rules.push(HttpRule.decode(reader, reader.uint32()));
                    break;
                case 2:
                    message.fullyDecodeReservedExpansion = reader.bool();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHttp();
        message.rules = object.rules?.map((e)=>HttpRule.fromPartial(e)) || [];
        message.fullyDecodeReservedExpansion = object.fullyDecodeReservedExpansion ?? false;
        return message;
    },
    fromAmino (object) {
        const message = createBaseHttp();
        message.rules = object.rules?.map((e)=>HttpRule.fromAmino(e)) || [];
        if (object.fully_decode_reserved_expansion !== undefined && object.fully_decode_reserved_expansion !== null) {
            message.fullyDecodeReservedExpansion = object.fully_decode_reserved_expansion;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        if (message.rules) {
            obj.rules = message.rules.map((e)=>e ? HttpRule.toAmino(e) : undefined);
        } else {
            obj.rules = message.rules;
        }
        obj.fully_decode_reserved_expansion = message.fullyDecodeReservedExpansion === false ? undefined : message.fullyDecodeReservedExpansion;
        return obj;
    },
    fromAminoMsg (object) {
        return Http.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return Http.decode(message.value);
    },
    toProto (message) {
        return Http.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.api.Http",
            value: Http.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(Http.typeUrl)) {
            return;
        }
        HttpRule.registerTypeUrl();
    }
};
function createBaseHttpRule() {
    return {
        selector: "",
        get: undefined,
        put: undefined,
        post: undefined,
        delete: undefined,
        patch: undefined,
        custom: undefined,
        body: "",
        responseBody: "",
        additionalBindings: []
    };
}
const HttpRule = {
    typeUrl: "/google.api.HttpRule",
    is (o) {
        return o && (o.$typeUrl === HttpRule.typeUrl || typeof o.selector === "string" && typeof o.body === "string" && typeof o.responseBody === "string" && Array.isArray(o.additionalBindings) && (!o.additionalBindings.length || HttpRule.is(o.additionalBindings[0])));
    },
    isAmino (o) {
        return o && (o.$typeUrl === HttpRule.typeUrl || typeof o.selector === "string" && typeof o.body === "string" && typeof o.response_body === "string" && Array.isArray(o.additional_bindings) && (!o.additional_bindings.length || HttpRule.isAmino(o.additional_bindings[0])));
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.selector !== "") {
            writer.uint32(10).string(message.selector);
        }
        if (message.get !== undefined) {
            writer.uint32(18).string(message.get);
        }
        if (message.put !== undefined) {
            writer.uint32(26).string(message.put);
        }
        if (message.post !== undefined) {
            writer.uint32(34).string(message.post);
        }
        if (message.delete !== undefined) {
            writer.uint32(42).string(message.delete);
        }
        if (message.patch !== undefined) {
            writer.uint32(50).string(message.patch);
        }
        if (message.custom !== undefined) {
            CustomHttpPattern.encode(message.custom, writer.uint32(66).fork()).ldelim();
        }
        if (message.body !== "") {
            writer.uint32(58).string(message.body);
        }
        if (message.responseBody !== "") {
            writer.uint32(98).string(message.responseBody);
        }
        for (const v of message.additionalBindings){
            HttpRule.encode(v, writer.uint32(90).fork()).ldelim();
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseHttpRule();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.selector = reader.string();
                    break;
                case 2:
                    message.get = reader.string();
                    break;
                case 3:
                    message.put = reader.string();
                    break;
                case 4:
                    message.post = reader.string();
                    break;
                case 5:
                    message.delete = reader.string();
                    break;
                case 6:
                    message.patch = reader.string();
                    break;
                case 8:
                    message.custom = CustomHttpPattern.decode(reader, reader.uint32());
                    break;
                case 7:
                    message.body = reader.string();
                    break;
                case 12:
                    message.responseBody = reader.string();
                    break;
                case 11:
                    message.additionalBindings.push(HttpRule.decode(reader, reader.uint32()));
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseHttpRule();
        message.selector = object.selector ?? "";
        message.get = object.get ?? undefined;
        message.put = object.put ?? undefined;
        message.post = object.post ?? undefined;
        message.delete = object.delete ?? undefined;
        message.patch = object.patch ?? undefined;
        message.custom = object.custom !== undefined && object.custom !== null ? CustomHttpPattern.fromPartial(object.custom) : undefined;
        message.body = object.body ?? "";
        message.responseBody = object.responseBody ?? "";
        message.additionalBindings = object.additionalBindings?.map((e)=>HttpRule.fromPartial(e)) || [];
        return message;
    },
    fromAmino (object) {
        const message = createBaseHttpRule();
        if (object.selector !== undefined && object.selector !== null) {
            message.selector = object.selector;
        }
        if (object.get !== undefined && object.get !== null) {
            message.get = object.get;
        }
        if (object.put !== undefined && object.put !== null) {
            message.put = object.put;
        }
        if (object.post !== undefined && object.post !== null) {
            message.post = object.post;
        }
        if (object.delete !== undefined && object.delete !== null) {
            message.delete = object.delete;
        }
        if (object.patch !== undefined && object.patch !== null) {
            message.patch = object.patch;
        }
        if (object.custom !== undefined && object.custom !== null) {
            message.custom = CustomHttpPattern.fromAmino(object.custom);
        }
        if (object.body !== undefined && object.body !== null) {
            message.body = object.body;
        }
        if (object.response_body !== undefined && object.response_body !== null) {
            message.responseBody = object.response_body;
        }
        message.additionalBindings = object.additional_bindings?.map((e)=>HttpRule.fromAmino(e)) || [];
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.selector = message.selector === "" ? undefined : message.selector;
        obj.get = message.get === null ? undefined : message.get;
        obj.put = message.put === null ? undefined : message.put;
        obj.post = message.post === null ? undefined : message.post;
        obj.delete = message.delete === null ? undefined : message.delete;
        obj.patch = message.patch === null ? undefined : message.patch;
        obj.custom = message.custom ? CustomHttpPattern.toAmino(message.custom) : undefined;
        obj.body = message.body === "" ? undefined : message.body;
        obj.response_body = message.responseBody === "" ? undefined : message.responseBody;
        if (message.additionalBindings) {
            obj.additional_bindings = message.additionalBindings.map((e)=>e ? HttpRule.toAmino(e) : undefined);
        } else {
            obj.additional_bindings = message.additionalBindings;
        }
        return obj;
    },
    fromAminoMsg (object) {
        return HttpRule.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return HttpRule.decode(message.value);
    },
    toProto (message) {
        return HttpRule.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.api.HttpRule",
            value: HttpRule.encode(message).finish()
        };
    },
    registerTypeUrl () {
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$registry$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalDecoderRegistry"].registerExistingTypeUrl(HttpRule.typeUrl)) {
            return;
        }
        CustomHttpPattern.registerTypeUrl();
        HttpRule.registerTypeUrl();
    }
};
function createBaseCustomHttpPattern() {
    return {
        kind: "",
        path: ""
    };
}
const CustomHttpPattern = {
    typeUrl: "/google.api.CustomHttpPattern",
    is (o) {
        return o && (o.$typeUrl === CustomHttpPattern.typeUrl || typeof o.kind === "string" && typeof o.path === "string");
    },
    isAmino (o) {
        return o && (o.$typeUrl === CustomHttpPattern.typeUrl || typeof o.kind === "string" && typeof o.path === "string");
    },
    encode (message, writer = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryWriter"].create()) {
        if (message.kind !== "") {
            writer.uint32(10).string(message.kind);
        }
        if (message.path !== "") {
            writer.uint32(18).string(message.path);
        }
        return writer;
    },
    decode (input, length) {
        const reader = input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"] ? input : new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$binary$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BinaryReader"](input);
        let end = length === undefined ? reader.len : reader.pos + length;
        const message = createBaseCustomHttpPattern();
        while(reader.pos < end){
            const tag = reader.uint32();
            switch(tag >>> 3){
                case 1:
                    message.kind = reader.string();
                    break;
                case 2:
                    message.path = reader.string();
                    break;
                default:
                    reader.skipType(tag & 7);
                    break;
            }
        }
        return message;
    },
    fromPartial (object) {
        const message = createBaseCustomHttpPattern();
        message.kind = object.kind ?? "";
        message.path = object.path ?? "";
        return message;
    },
    fromAmino (object) {
        const message = createBaseCustomHttpPattern();
        if (object.kind !== undefined && object.kind !== null) {
            message.kind = object.kind;
        }
        if (object.path !== undefined && object.path !== null) {
            message.path = object.path;
        }
        return message;
    },
    toAmino (message) {
        const obj = {};
        obj.kind = message.kind === "" ? undefined : message.kind;
        obj.path = message.path === "" ? undefined : message.path;
        return obj;
    },
    fromAminoMsg (object) {
        return CustomHttpPattern.fromAmino(object.value);
    },
    fromProtoMsg (message) {
        return CustomHttpPattern.decode(message.value);
    },
    toProto (message) {
        return CustomHttpPattern.encode(message).finish();
    },
    toProtoMsg (message) {
        return {
            typeUrl: "/google.api.CustomHttpPattern",
            value: CustomHttpPattern.encode(message).finish()
        };
    },
    registerTypeUrl () {}
};
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/bundle.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$api$2f$http$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/api/http.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/descriptor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
;
;
;
;
;
}}),
"[project]/examples/e2e/node_modules/interchainjs/esm/google/bundle.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$api$2f$http$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/api/http.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$any$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/any.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$descriptor$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/descriptor.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$duration$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/duration.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$protobuf$2f$timestamp$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/protobuf/timestamp.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f$interchainjs$2f$esm$2f$google$2f$bundle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/interchainjs/esm/google/bundle.js [app-client] (ecmascript) <locals>");
}}),
}]);

//# sourceMappingURL=1483a_interchainjs_esm_google_944958ee._.js.map