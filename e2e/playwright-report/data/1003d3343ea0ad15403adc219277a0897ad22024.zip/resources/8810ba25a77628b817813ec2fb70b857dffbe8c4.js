(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BroadcastMode": (()=>BroadcastMode),
    "WalletState": (()=>WalletState),
    "WcEventTypes": (()=>WcEventTypes),
    "WcProviderEventType": (()=>WcProviderEventType)
});
var BroadcastMode;
(function(BroadcastMode) {
    /** Return after tx commit */ BroadcastMode["Block"] = "block";
    /** Return after CheckTx */ BroadcastMode["Sync"] = "sync";
    /** Return right away */ BroadcastMode["Async"] = "async";
})(BroadcastMode || (BroadcastMode = {}));
var WalletState;
(function(WalletState) {
    WalletState["Disconnected"] = "Disconnected";
    WalletState["Connecting"] = "Connecting";
    WalletState["Connected"] = "Connected";
    WalletState["Rejected"] = "Rejected";
    WalletState["NotExist"] = "NotExist";
})(WalletState || (WalletState = {}));
const WcProviderEventType = {
    chainChanged: (chainId)=>{},
    accountsChanged: (accounts)=>{}
};
const WcEventTypes = {
    display_uri: (uri)=>{},
    session_ping: (payload)=>{},
    session_event: (payload)=>{},
    session_update: (payload)=>{},
    session_delete: (payload)=>{},
    session_proposal: (payload)=>{},
    session_extend: (payload)=>{},
    session_expire: (payload)=>{},
    session_request: (payload)=>{},
    session_request_sent: (payload)=>{},
    proposal_expire: (payload)=>{}
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/types/common.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/types/manager.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WalletManagerState": (()=>WalletManagerState)
});
var WalletManagerState;
(function(WalletManagerState) {
    WalletManagerState["Initializing"] = "Initializing";
    WalletManagerState["Initialized"] = "Initialized";
})(WalletManagerState || (WalletManagerState = {}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/types/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/types/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/common.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/manager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/chain.js [app-client] (ecmascript)");
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$common$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/common.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/manager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/chain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ChainNameNotExist": (()=>ChainNameNotExist),
    "ChainNotExist": (()=>ChainNotExist),
    "NoActiveWallet": (()=>NoActiveWallet),
    "NoGasPriceFound": (()=>NoGasPriceFound),
    "NoValidRpcEndpointFound": (()=>NoValidRpcEndpointFound),
    "NoWalletConnectedYet": (()=>NoWalletConnectedYet),
    "WalletNotExist": (()=>WalletNotExist),
    "clientNotExistError": (()=>clientNotExistError)
});
const clientNotExistError = new Error('Client not exist');
class ChainNotExist extends Error {
    constructor(chainId){
        super(`Chain ${chainId} not exist, please add it first`);
    }
}
class ChainNameNotExist extends Error {
    constructor(chainName){
        super(`Chain Name ${chainName} not exist, please add it first`);
    }
}
class WalletNotExist extends Error {
    constructor(walletName){
        super(`Wallet ${walletName} not Exist, please add it first`);
    }
}
class NoWalletConnectedYet extends Error {
    constructor(){
        super('No wallet connected yet');
    }
}
class NoGasPriceFound extends Error {
    constructor(){
        super('Gas price must be set in the client options when auto gas is used.');
    }
}
class NoActiveWallet extends Error {
    constructor(){
        super('No active wallet');
    }
}
class NoValidRpcEndpointFound extends Error {
    constructor(){
        super('No valid rpc endpoint found');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getClientFromExtension": (()=>getClientFromExtension),
    "travelObject": (()=>travelObject)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
;
const travelObject = (obj, paths)=>{
    try {
        const object = paths.reduce((acc, key)=>{
            return acc[key];
        }, obj);
        return object;
    } catch (error) {
        return undefined;
    }
};
const getClientFromExtension = async (key)=>{
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    const keys = Array.isArray(key) ? key : key.split('.');
    const wallet = travelObject(window, keys);
    if (wallet) {
        return wallet;
    }
    if (document.readyState === 'complete') {
        if (wallet) {
            return wallet;
        } else {
            throw __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"];
        }
    }
    return new Promise((resolve, reject)=>{
        const documentStateChange = (event)=>{
            if (event.target && event.target.readyState === 'complete') {
                const wallet = travelObject(window, keys);
                if (wallet) {
                    resolve(wallet);
                } else {
                    reject(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"]);
                }
                document.removeEventListener('readystatechange', documentStateChange);
            }
        };
        document.addEventListener('readystatechange', documentStateChange);
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/endpoint.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getValidRpcEndpoint": (()=>getValidRpcEndpoint),
    "isValidRpcEndpoint": (()=>isValidRpcEndpoint)
});
const isValidRpcEndpoint = async (endpoint, chainType)=>{
    let requestBody;
    const rpcToCheck = typeof endpoint === 'string' ? endpoint : endpoint.url;
    if (chainType === 'cosmos') {
        requestBody = {
            jsonrpc: "2.0",
            method: "status",
            params: [],
            id: 1
        };
    } else if (chainType === 'eip155') {
        requestBody = {
            jsonrpc: "2.0",
            method: "eth_blockNumber",
            params: [],
            id: 1
        };
    } else {
        throw new Error('unsupported chain type');
    }
    try {
        const response = await fetch(rpcToCheck, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        });
        return response.status === 200;
    } catch (error) {
        return false;
    }
};
const timeoutCheck = (ms)=>new Promise((_, reject)=>setTimeout(()=>reject(new Error('timeout')), ms));
const getValidRpcEndpoint = async (endpoints)=>{
    let rpc = '';
    for (const endpoint of endpoints){
        try {
            const isValid = await Promise.race([
                isValidRpcEndpoint(endpoint.endpoint, endpoint.chainType),
                timeoutCheck(1500)
            ]);
            if (isValid) {
                rpc = endpoint.endpoint;
                break;
            }
        } catch (error) {
        // console.error(error)
        }
    }
    return rpc;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createArray": (()=>createArray),
    "delay": (()=>delay),
    "isInstanceOf": (()=>isInstanceOf),
    "waitForCondition": (()=>waitForCondition)
});
function isInstanceOf(obj, type) {
    if (!obj || typeof obj !== "object") return false;
    // Check for custom metadata
    if (obj.__class === type.name) return true;
    // Fallback to prototype chain check
    let proto = Object.getPrototypeOf(obj);
    while(proto){
        if (proto.constructor === type) return true;
        proto = Object.getPrototypeOf(proto);
    }
    return false;
}
function createArray(...items) {
    return items;
}
const delay = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
async function waitForCondition(condition, interval = 100, timeout = 5000) {
    const start = Date.now();
    return new Promise((resolve, reject)=>{
        const checkCondition = ()=>{
            if (condition()) {
                resolve();
            } else if (Date.now() - start >= timeout) {
                reject(new Error("Timeout waiting for condition"));
            } else {
                setTimeout(checkCondition, interval);
            }
        };
        checkCondition();
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/platform.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "isAndroid": (()=>isAndroid),
    "isIOS": (()=>isIOS),
    "isMobile": (()=>isMobile),
    "isServer": (()=>isServer),
    "selectWalletByPlatform": (()=>selectWalletByPlatform)
});
const isServer = ()=>"object" === 'undefined';
const isMobile = ()=>{
    if (isServer()) {
        "TURBOPACK unreachable";
    } // Avoid checking user agent on server-side
    const userAgent = navigator.userAgent || navigator.vendor;
    return /android/i.test(userAgent) || /iPad|iPhone|iPod/.test(userAgent);
};
const isAndroid = ()=>{
    if (isServer()) {
        "TURBOPACK unreachable";
    } // Avoid checking user agent on server-side
    const userAgent = navigator.userAgent || navigator.vendor;
    return /android/i.test(userAgent);
};
const isIOS = ()=>{
    if (isServer()) {
        "TURBOPACK unreachable";
    } // Avoid checking user agent on server-side
    const userAgent = navigator.userAgent || navigator.vendor;
    return /iPad|iPhone|iPod/.test(userAgent);
};
const selectWalletByPlatform = (walletPlatformMap, walletInfo)=>{
    if (isMobile()) {
        if (window[walletInfo.windowKey]) {
            return walletPlatformMap['inAppBrowser'];
        } else {
            return walletPlatformMap['mobileBrowser'];
        }
    }
    return walletPlatformMap['desktopBrowser'];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/wallet-connect.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getWCInfoByProjectId": (()=>getWCInfoByProjectId)
});
const WALLET_CONNECT_PROJECT_ID = '15a12f05b38b78014b2bb06d77eecdc3'; // Replace with your actual project ID
const WALLET_EXPLORER_API_URL = 'https://explorer-api.walletconnect.com/v3';
const getWCInfoByProjectId = async (id)=>{
    return fetch(`${WALLET_EXPLORER_API_URL}/wallets?projectId=${WALLET_CONNECT_PROJECT_ID}&ids=${id}`).then((response)=>{
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    }).then((data)=>{
        const wallets = data.listings;
        return wallets[id];
    }).catch((error)=>{
        console.error('Error fetching wallet info:', error);
        throw error;
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$endpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/endpoint.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/platform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$wallet$2d$connect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/wallet-connect.js [app-client] (ecmascript)");
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$endpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/endpoint.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/platform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$wallet$2d$connect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/wallet-connect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "BaseWallet": (()=>BaseWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$events$2f$events$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/events/events.js [app-client] (ecmascript)");
;
class BaseWallet {
    info;
    events = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$events$2f$events$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
    chainMap = new Map();
    assetLists = [];
    client;
    constructor(info){
        this.info = info;
    }
    setChainMap(chains) {
        this.chainMap = new Map(chains.map((chain)=>[
                chain.chainId,
                chain
            ]));
    }
    addChain(chain) {
        this.chainMap.set(chain.chainId, chain);
    }
    setAssetLists(assetLists) {
        this.assetLists = assetLists;
    }
    addAssetList(assetList) {
        this.assetLists.push(assetList);
    }
    getChainById(chainId) {
        const chain = this.chainMap.get(chainId);
        if (!chain) {
            throw new Error(`Chain Registry with id ${chainId} not found!`);
        }
        return chain;
    }
    getAssetListByChainId(chainId) {
        const chain = this.getChainById(chainId);
        const assetList = this.assetLists.find((assetList)=>assetList.chainName === chain.chainName);
        if (!assetList) {
            throw new Error(`Asset List with id ${chainId} not found!`);
        }
        return assetList;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/constant/icon.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WalletConnectIcon": (()=>WalletConnectIcon)
});
const WalletConnectIcon = "data:image/svg+xml;base64,PHN2ZyBoZWlnaHQ9IjUxMiIgdmlld0JveD0iMCAwIDUxMiA1MTIiIHdpZHRoPSI1MTIiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxyYWRpYWxHcmFkaWVudCBpZD0iYSIgY3g9IjAlIiBjeT0iNTAlIiByPSIxMDAlIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiM1ZDlkZjYiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwMDZmZmYiLz48L3JhZGlhbEdyYWRpZW50PjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PHBhdGggZD0ibTI1NiAwYzE0MS4zODQ4OTYgMCAyNTYgMTE0LjYxNTEwNCAyNTYgMjU2cy0xMTQuNjE1MTA0IDI1Ni0yNTYgMjU2LTI1Ni0xMTQuNjE1MTA0LTI1Ni0yNTYgMTE0LjYxNTEwNC0yNTYgMjU2LTI1NnoiIGZpbGw9InVybCgjYSkiLz48cGF0aCBkPSJtNjQuNjkxNzU1OCAzNy43MDg4Mjk4YzUxLjUzMjgwNzItNTAuMjc4NDM5NyAxMzUuMDgzOTk0Mi01MC4yNzg0Mzk3IDE4Ni42MTY3OTkyIDBsNi4yMDIwNTcgNi4wNTEwOTA2YzIuNTc2NjQgMi41MTM5MjE4IDIuNTc2NjQgNi41ODk3OTQ4IDAgOS4xMDM3MTc3bC0yMS4yMTU5OTggMjAuNjk5NTc1OWMtMS4yODgzMjEgMS4yNTY5NjE5LTMuMzc3MSAxLjI1Njk2MTktNC42NjU0MjEgMGwtOC41MzQ3NjYtOC4zMjcwMjA1Yy0zNS45NTA1NzMtMzUuMDc1NDk2Mi05NC4yMzc5NjktMzUuMDc1NDk2Mi0xMzAuMTg4NTQ0IDBsLTkuMTQwMDI4MiA4LjkxNzU1MTljLTEuMjg4MzIxNyAxLjI1Njk2MDktMy4zNzcxMDE2IDEuMjU2OTYwOS00LjY2NTQyMDggMGwtMjEuMjE1OTk3My0yMC42OTk1NzU5Yy0yLjU3NjY0MDMtMi41MTM5MjI5LTIuNTc2NjQwMy02LjU4OTc5NTggMC05LjEwMzcxNzd6bTIzMC40OTM0ODUyIDQyLjgwODkxMTcgMTguODgyMjc5IDE4LjQyMjcyNjJjMi41NzY2MjcgMi41MTM5MTAzIDIuNTc2NjQyIDYuNTg5NzU5My4wMDAwMzIgOS4xMDM2ODYzbC04NS4xNDE0OTggODMuMDcwMzU4Yy0yLjU3NjYyMyAyLjUxMzk0MS02Ljc1NDE4MiAyLjUxMzk2OS05LjMzMDg0LjAwMDA2Ni0uMDAwMDEtLjAwMDAxLS4wMDAwMjMtLjAwMDAyMy0uMDAwMDMzLS4wMDAwMzRsLTYwLjQyODI1Ni01OC45NTc0NTFjLS42NDQxNi0uNjI4NDgxLTEuNjg4NTUtLjYyODQ4MS0yLjMzMjcxIDAtLjAwMDAwNC4wMDAwMDQtLjAwMDAwOC4wMDAwMDctLjAwMDAxMi4wMDAwMTFsLTYwLjQyNjk2ODMgNTguOTU3NDA4Yy0yLjU3NjYxNDEgMi41MTM5NDctNi43NTQxNzQ2IDIuNTEzOTktOS4zMzA4NDA4LjAwMDA5Mi0uMDAwMDE1MS0uMDAwMDE0LS4wMDAwMzA5LS4wMDAwMjktLjAwMDA0NjctLjAwMDA0NmwtODUuMTQzODY3NzQtODMuMDcxNDYzYy0yLjU3NjYzOTI4LTIuNTEzOTIxLTIuNTc2NjM5MjgtNi41ODk3OTUgMC05LjEwMzcxNjNsMTguODgyMzEyNjQtMTguNDIyNjk1NWMyLjU3NjYzOTMtMi41MTM5MjIyIDYuNzU0MTk5My0yLjUxMzkyMjIgOS4zMzA4Mzk3IDBsNjAuNDI5MTM0NyA1OC45NTgyNzU4Yy42NDQxNjA4LjYyODQ4IDEuNjg4NTQ5NS42Mjg0OCAyLjMzMjcxMDMgMCAuMDAwMDA5NS0uMDAwMDA5LjAwMDAxODItLjAwMDAxOC4wMDAwMjc3LS4wMDAwMjVsNjAuNDI2MTA2NS01OC45NTgyNTA4YzIuNTc2NTgxLTIuNTEzOTggNi43NTQxNDItMi41MTQwNzQzIDkuMzMwODQtLjAwMDIxMDMuMDAwMDM3LjAwMDAzNTQuMDAwMDcyLjAwMDA3MDkuMDAwMTA3LjAwMDEwNjNsNjAuNDI5MDU2IDU4Ljk1ODM1NDhjLjY0NDE1OS42Mjg0NzkgMS42ODg1NDkuNjI4NDc5IDIuMzMyNzA5IDBsNjAuNDI4MDc5LTU4Ljk1NzE5MjVjMi41NzY2NC0yLjUxMzkyMzEgNi43NTQxOTktMi41MTM5MjMxIDkuMzMwODM5IDB6IiBmaWxsPSIjZmZmIiBmaWxsLXJ1bGU9Im5vbnplcm8iIHRyYW5zZm9ybT0idHJhbnNsYXRlKDk4IDE2MCkiLz48L2c+PC9zdmc+";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/icon.js [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WCWallet": (()=>WCWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/base64-js/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$universal$2d$provider$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/universal-provider/dist/index.es.js [app-client] (ecmascript)");
;
;
;
;
;
;
class WCWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    pairingUri;
    session;
    // signClient: InstanceType<typeof SignClient>;
    provider;
    pairingToConnect = null;
    sessionToConnect = null;
    // walletConnectOption: SignClientTypes.Options
    walletConnectOption;
    onPairingUriCreated;
    accountToRestore = null;
    setAccountToRestore(account) {
        this.accountToRestore = account;
    }
    constructor(option, walletConnectOption){
        const defaultWalletConnectOption = {
            name: 'WalletConnect',
            prettyName: 'Wallet Connect',
            mode: 'wallet-connect',
            logo: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletConnectIcon"]
        };
        super({
            ...defaultWalletConnectOption,
            ...option
        });
        this.walletConnectOption = walletConnectOption;
    }
    async init() {
        this.events.removeAllListeners();
        const defaultOption = {
            projectId: '15a12f05b38b78014b2bb06d77eecdc3',
            // optional parameters
            relayUrl: 'wss://relay.walletconnect.org',
            metadata: {
                name: 'Example Dapp',
                description: 'Example Dapp',
                url: '#',
                icons: [
                    'https://walletconnect.com/walletconnect-logo.png'
                ]
            }
        };
        const savedStringifySession = localStorage.getItem('wc-session');
        const savedSession = savedStringifySession ? JSON.parse(savedStringifySession) : undefined;
        // this.signClient = await SignClient.init({ ...defaultOption, ...this.walletConnectOption })
        this.provider = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$universal$2d$provider$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].init({
            ...defaultOption,
            ...this.walletConnectOption,
            session: savedSession
        });
        this.bindingEvent();
    }
    setOnPairingUriCreatedCallback(callback) {
        this.onPairingUriCreated = callback;
    }
    async connect(chainIds) {
        // const chainIdsWithNS = Array.isArray(chainIds) ? chainIds.map((chainId) => `cosmos:${chainId}`) : [`cosmos:${chainIds}`]
        if (this.session) {
            return;
        }
        const _chainIds = Array.from(this.chainMap).map(([chainId, chain])=>chainId);
        const cosmosChainNS = [];
        const eip155ChainNS = [];
        _chainIds.forEach((chainId)=>{
            const chain = this.getChainById(chainId);
            if (chain.chainType === 'cosmos') {
                cosmosChainNS.push(`cosmos:${chainId}`);
            }
            if (chain.chainType === 'eip155') {
                eip155ChainNS.push(`eip155:${chainId}`);
            }
        });
        const connectParam = {
            namespaces: {}
        };
        if (cosmosChainNS.length) {
            connectParam.namespaces.cosmos = {
                methods: [
                    'cosmos_signAmino',
                    'cosmos_signDirect',
                    'cosmos_getAccounts'
                ],
                chains: cosmosChainNS,
                events: [
                    "accountsChanged",
                    "chainChanged"
                ]
            };
        }
        if (eip155ChainNS.length) {
            connectParam.namespaces.eip155 = {
                methods: [
                    'eth_sendTransaction',
                    'eth_signTransaction',
                    'eth_sign',
                    'personal_sign',
                    'eth_signTypedData',
                    'trust_sendTransaction'
                ],
                chains: eip155ChainNS,
                events: []
            };
        }
        try {
            const session = await this.provider.connect(connectParam);
            this.session = session;
            this.pairingUri = null;
            this.onPairingUriCreated && this.onPairingUriCreated(null);
            localStorage.setItem('wc-session', JSON.stringify(this.session));
        } catch (error) {
            console.log('wc connect error', error);
            throw error;
        }
    }
    async disconnect() {
        // await this.provider.client.session.delete(this.provider?.session?.topic, { code: 6000, message: 'user disconnect!!' })
        this.session = null;
        await this.provider.disconnect();
        localStorage.removeItem('wc-session');
    // this.provider.client.pairing.delete(this.pairingToConnect.topic, { code: 6000, message: 'user disconnect!!' })
    // await this.provider.client.disconnect({ topic: this.sessionToConnect.topic, reason: { code: 6000, message: 'user disconnect!!' } })
    // await this.provider.client.pairing.delete(this.pairingToConnect.topic, { code: 6000, message: 'user disconnect!!' })
    // await this.removeSession()
    // this.sessionToConnect = null
    }
    async getAccounts() {
        const accounts = [];
        const namespaces = this.session.namespaces;
        Object.entries(namespaces).forEach(([namespace, session])=>{
            session.accounts.forEach((account)=>{
                const [namespace, chainId, address] = account.split(':');
                accounts.push({
                    address: address,
                    algo: 'secp256k1',
                    pubkey: null,
                    username: '',
                    isNanoLedger: null,
                    isSmartContract: null
                });
            });
        });
        return accounts;
    }
    async getAccount(chainId) {
        if (this.accountToRestore) {
            return this.accountToRestore;
        }
        const account = await this.getCosmosAccount(chainId);
        return {
            address: account.address,
            algo: 'secp256k1',
            pubkey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toByteArray"])(account.pubkey),
            username: '',
            isNanoLedger: null,
            isSmartContract: null
        };
    }
    async getCosmosAccount(chainId) {
        try {
            const accounts = await this.provider.request({
                method: 'cosmos_getAccounts',
                params: []
            }, `cosmos:${chainId}`);
            const { address, algo, pubkey } = accounts[0];
            return {
                address,
                algo: algo,
                pubkey: pubkey
            };
        } catch (error) {
            console.log('get cosmos account error', error);
            throw error;
        }
    }
    async getOfflineSigner(chainId, preferredSignType) {
        if (preferredSignType === 'amino') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AminoGenericOfflineSigner"]({
                getAccounts: async ()=>[
                        await this.getAccount(chainId)
                    ],
                signAmino: async (signer, signDoc)=>{
                    return this.signAmino(chainId, signer, signDoc);
                }
            });
        } else if (preferredSignType === 'direct') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DirectGenericOfflineSigner"]({
                getAccounts: async ()=>[
                        await this.getAccount(chainId)
                    ],
                signDirect: async (signer, signDoc)=>{
                    return this.signDirect(chainId, signer, signDoc);
                }
            });
        }
    }
    async signAmino(chainId, signer, signDoc, signOptions) {
        try {
            // const result = await this.signClient.request({
            //   topic: this.session.topic,
            //   chainId: `cosmos:${chainId}`,
            //   request: {
            //     method: 'cosmos_signAmino',
            //     params: {
            //       signerAddress: signer,
            //       signDoc,
            //     },
            //   },
            // });
            const result = await this.provider.request({
                method: 'cosmos_signAmino',
                params: {
                    signerAddress: signer,
                    signDoc
                }
            }, `cosmos:${chainId}`);
            return result;
        } catch (error) {
            console.log(error);
        }
    }
    signArbitrary(chainId, signer, data) {
        throw new Error("Method not implemented.");
    }
    verifyArbitrary(chainId, signer, data) {
        throw new Error("Method not implemented.");
    }
    signDirect(chainId, signer, signDoc, signOptions) {
        const signDocValue = {
            signerAddress: signer,
            signDoc: {
                chainId: signDoc.chainId,
                bodyBytes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromByteArray"])(signDoc.bodyBytes),
                authInfoBytes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromByteArray"])(signDoc.authInfoBytes),
                accountNumber: signDoc.accountNumber.toString()
            }
        };
        // return this.signClient.request({
        //   topic: this.session.topic,
        //   chainId: `cosmos:${chainId}`,
        //   request: {
        //     method: 'cosmos_signDirect',
        //     params: signDocValue,
        //   },
        // });
        return this.provider.request({
            method: 'cosmos_signDirect',
            params: signDocValue
        }, `cosmos:${chainId}`);
    }
    sendTx(chainId, tx, mode) {
        throw new Error("Method not implemented.");
    }
    sign(chainId, message) {
        throw new Error("Method not implemented.");
    }
    addSuggestChain(chainId) {
        throw new Error("Method not implemented.");
    }
    bindingEvent() {
        this.provider.on("disconnect", (error)=>{
            console.error("disconnect:", error);
        });
        this.provider.on("session_delete", (error)=>{
            console.log("session_delete:", event);
            localStorage.removeItem('wc-session');
        });
        this.provider.on("session_event", (error)=>{
            console.log("session_event:", event);
        });
        this.provider.on('session_request', (error)=>{
            console.log('session_request', event);
        });
        this.provider.on('display_uri', (uri)=>{
            this.pairingUri = uri;
            this.onPairingUriCreated && this.onPairingUriCreated(uri);
        });
        this.events.removeAllListeners();
        const events = [
            ...Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WcEventTypes"]),
            ...Object.keys(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WcProviderEventType"])
        ];
        // for (const event of events) {
        //   this.signClient.core.on(event, (data: never) => {
        //     this.events.emit(event, data)
        //     if (event === 'accountsChanged') {
        //       this.events.emit('keystoreChange')
        //     }
        //   })
        // }
        // this.signClient.events.on('session_event', (data: SignClientTypes.EventArguments['session_event']) => {
        //   console.log('session_event_trigger', data)
        //   this.events.emit('accountChanged', data)
        // })
        for (const event1 of events){
        // console.log(event)
        // this.provider.on(event as any, (data: any) => {
        //   console.log(event, data)
        // })
        }
    }
    unbindingEvent() {
        this.provider.events.removeAllListeners('session_event');
        this.events.removeAllListeners();
    }
    async ping() {
        if (!this.provider) {
            return;
        }
        try {
            await this.provider.client.ping({
                topic: this.session.topic
            });
            return 'success';
        } catch (error) {
            console.log(error);
            return 'failed';
        }
    }
    async getProvider() {
        return this.provider;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallet-manager.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WalletManager": (()=>WalletManager)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$signing$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/cosmos/signing-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$es5$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bowser/es5.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$endpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/endpoint.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)");
;
;
;
;
class WalletManager {
    chains = [];
    assetLists = [];
    wallets = [];
    signerOptions;
    endpointOptions;
    preferredSignTypeMap = {};
    signerOptionMap = {};
    endpointOptionsMap = {};
    constructor(chains, assetLists, wallets, signerOptions, endpointOptions){
        this.chains = chains;
        this.assetLists = assetLists;
        this.wallets = wallets;
        this.signerOptions = signerOptions;
        this.endpointOptions = endpointOptions;
        this.chains.forEach((chain)=>{
            this.signerOptionMap[chain.chainName] = signerOptions?.signing?.(chain.chainName);
            this.preferredSignTypeMap[chain.chainName] = signerOptions?.preferredSignType?.(chain.chainName);
            this.endpointOptionsMap[chain.chainName] = endpointOptions?.endpoints?.[chain.chainName];
        });
        this.wallets.forEach((wallet)=>{
            wallet.setChainMap(this.chains);
            wallet.setAssetLists(this.assetLists);
        });
    }
    async init() {
        await Promise.all(this.wallets.map(async (wallet)=>wallet.init()));
    }
    static async create(chain, assetLists, wallets, signerOptions, endpointOptions) {
        const wm = new WalletManager(chain, assetLists, wallets, signerOptions, endpointOptions);
        await wm.init();
        return wm;
    }
    async addChains(newChains, newAssetLists, signerOptions, newEndpointOptions) {
        const existChains = this.chains;
        const rpcEndpointTable = new Map();
        await Promise.all(newChains.map(async (newChain)=>{
            const rpcEndpoint = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$endpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValidRpcEndpoint"])(newChain.apis.rpc.map((url)=>({
                    chainType: newChain.chainType,
                    endpoint: url.address
                })));
            if (rpcEndpoint) {
                rpcEndpointTable.set(newChain.chainId, rpcEndpoint);
            }
        }));
        const existChainsTable = new Map(existChains.map((chain)=>[
                chain.chainId,
                chain
            ]));
        const newAssetListsTable = new Map(newAssetLists.map((assetList)=>[
                assetList.chainName,
                assetList
            ]));
        newChains.forEach((newChain)=>{
            if (!existChainsTable.has(newChain.chainId)) {
                const assetList = newAssetListsTable.get(newChain.chainName);
                this.chains.push(newChain);
                this.assetLists.push(assetList);
                this.wallets.forEach((wallet)=>{
                    wallet.addChain(newChain);
                    wallet.addAssetList(assetList);
                });
            }
            this.signerOptionMap[newChain.chainName] = signerOptions?.signing?.(newChain.chainName);
            this.endpointOptionsMap[newChain.chainName] = {
                rpc: [
                    newEndpointOptions?.endpoints?.[newChain.chainName]?.rpc?.[0] || rpcEndpointTable.get(newChain.chainId)
                ]
            };
        });
    }
    getChainLogoUrl(chainName) {
        const assetList = this.assetLists.find((assetList)=>assetList.chainName === chainName);
        return assetList?.assets?.[0].logoURIs?.png || assetList?.assets?.[0].logoURIs?.svg || undefined;
    }
    getWalletByName(walletName) {
        return this.wallets.find((w)=>w.info.name === walletName);
    }
    getChainByName(chainName) {
        const chain = this.chains.find((chain)=>chain.chainName === chainName);
        return chain;
    }
    getAssetListByName(chainName) {
        return this.assetLists.find((assetList)=>assetList.chainName === chainName);
    }
    async connect(walletName, chainName, wcQRcodeUriCallback) {
        const wallet = this.getWalletByName(walletName);
        const chain = this.getChainByName(chainName);
        if (!wallet) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletNotExist"](walletName);
        }
        if (!chain) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainNameNotExist"](chainName);
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceOf"])(wallet, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WCWallet"])) {
            wallet.setOnPairingUriCreatedCallback(wcQRcodeUriCallback);
        }
        try {
            await wallet.connect(chain.chainId);
        } catch (error) {
            throw error;
        }
    }
    async disconnect(walletName, chainName) {
        const wallet = this.getWalletByName(walletName);
        const chain = this.getChainByName(chainName);
        if (!wallet) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletNotExist"](walletName);
        }
        if (!chain) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainNameNotExist"](chainName);
        }
        return wallet.disconnect(chain.chainId);
    }
    getAccount(walletName, chainName) {
        const wallet = this.getWalletByName(walletName);
        const chain = this.getChainByName(chainName);
        if (!wallet) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletNotExist"](walletName);
        }
        if (!chain) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainNameNotExist"](chainName);
        }
        return wallet.getAccount(chain.chainId);
    }
    getRpcEndpoint = async (walletName, chainName)=>{
        const existRpcEndpoint = this.endpointOptionsMap?.[chainName]?.rpc?.[0];
        if (existRpcEndpoint) {
            return existRpcEndpoint;
        }
        const chain = this.getChainByName(chainName);
        let rpcEndpoint = '';
        const providerRpcEndpoints = this.endpointOptions?.endpoints[chain.chainName]?.rpc || [];
        // const walletRpcEndpoints = wallet?.info?.endpoints?.[chain.chainName]?.rpc || []
        const chainRpcEndpoints = chain.apis.rpc.map((url)=>url.address);
        if (providerRpcEndpoints?.[0]) {
            rpcEndpoint = providerRpcEndpoints[0];
            this.endpointOptionsMap?.[chainName]?.rpc.push(rpcEndpoint);
            return rpcEndpoint;
        }
        const rpcInfos = [
            ...providerRpcEndpoints,
            ...chainRpcEndpoints
        ].map((endpoint)=>({
                chainType: chain.chainType,
                endpoint
            }));
        const validRpcEndpoint = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$endpoint$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getValidRpcEndpoint"])(rpcInfos);
        if (validRpcEndpoint === '') {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NoValidRpcEndpointFound"]();
        }
        rpcEndpoint = validRpcEndpoint;
        this.endpointOptionsMap = {
            ...this.endpointOptionsMap,
            [chainName]: {
                rpc: [
                    rpcEndpoint
                ]
            }
        };
        return rpcEndpoint;
    };
    getPreferSignType(chainName) {
        return this.preferredSignTypeMap[chainName] || 'direct';
    }
    getSignerOptions(chainName) {
        const chain = this.getChainByName(chainName);
        const signingOptions = this.signerOptionMap[chainName];
        const options = {
            broadcast: {
                checkTx: true,
                deliverTx: true
            },
            ...signingOptions,
            signerOptions: {
                prefix: chain.bech32Prefix,
                ...signingOptions?.signerOptions
            }
        };
        return options;
    }
    async getOfflineSigner(walletName, chainName) {
        const preferredSignType = this.getPreferSignType(chainName);
        const wallet = this.getWalletByName(walletName);
        const chain = this.getChainByName(chainName);
        if (!wallet) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletNotExist"](walletName);
        }
        if (!chain) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainNotExist"](chainName);
        }
        return wallet.getOfflineSigner(chain.chainId, preferredSignType);
    }
    async getSigningClient(walletName, chainName) {
        const rpcEndpoint = await this.getRpcEndpoint(walletName, chainName);
        const offlineSigner = await this.getOfflineSigner(walletName, chainName);
        const signerOptions = await this.getSignerOptions(chainName);
        const signingClient = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$signing$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SigningClient"].connectWithSigner(rpcEndpoint, offlineSigner, signerOptions);
        return signingClient;
    }
    getEnv() {
        const parser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bowser$2f$es5$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getParser(window.navigator.userAgent);
        const env = {
            browser: parser.getBrowserName(true),
            device: parser.getPlatform().type || 'desktop',
            os: parser.getOSName(true)
        };
        return env;
    }
    getDownloadLink(walletName) {
        const env = this.getEnv();
        const wallet = this.getWalletByName(walletName);
        return wallet.info.downloads.find((d)=>{
            if (d.device === 'desktop') {
                return d.browser === env.browser;
            } else if (d.device === 'mobile') {
                return d.os === env.os;
            } else {
                return null;
            }
        });
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "CosmosWallet": (()=>CosmosWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$keplr$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/keplr/esm/index.js [app-client] (ecmascript)");
;
;
;
;
class CosmosWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    defaultSignOptions = {
        preferNoSetFee: true,
        preferNoSetMemo: true,
        disableBalanceCheck: false
    };
    setSignOptions(options) {
        this.defaultSignOptions = {
            ...this.defaultSignOptions,
            ...options
        };
    }
    async init() {
        this.client = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientFromExtension"])(this.info.cosmosKey);
    }
    async connect(chainId) {
        try {
            await this.client.enable(chainId);
        } catch (error) {
            if (!error.message.includes(`rejected`)) {
                await this.addSuggestChain(chainId);
            } else {
                throw error;
            }
        }
    }
    async disconnect(chainId) {
        this.client.disable?.(chainId);
        this.client.disconnect?.(chainId);
    }
    async getAccount(chainId) {
        const key = await this.client.getKey(chainId);
        return {
            username: key.name,
            address: key.bech32Address,
            algo: key.algo,
            pubkey: key.pubKey,
            isNanoLedger: key.isNanoLedger
        };
    }
    async getOfflineSigner(chainId, preferredSignType) {
        const account = await this.getAccount(chainId);
        if (account.isNanoLedger) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AminoGenericOfflineSigner"]({
                getAccounts: async ()=>[
                        account
                    ],
                signAmino: async (signer, signDoc)=>{
                    return this.signAmino(chainId, signer, signDoc, this.defaultSignOptions);
                }
            });
        }
        if (preferredSignType === 'amino') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AminoGenericOfflineSigner"]({
                getAccounts: async ()=>[
                        await this.getAccount(chainId)
                    ],
                signAmino: async (signer, signDoc)=>{
                    return this.signAmino(chainId, signer, signDoc, this.defaultSignOptions);
                }
            });
        } else {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DirectGenericOfflineSigner"]({
                getAccounts: async ()=>[
                        await this.getAccount(chainId)
                    ],
                signDirect: async (signer, signDoc)=>{
                    return this.signDirect(chainId, signer, signDoc, this.defaultSignOptions);
                }
            });
        }
    }
    async signAmino(chainId, signer, signDoc, signOptions) {
        return this.client.signAmino(chainId, signer, signDoc, signOptions);
    }
    async signArbitrary(chainId, signer, data) {
        return this.client.signArbitrary(chainId, signer, data);
    }
    verifyArbitrary(chainId, signer, data) {
        return this.client.verifyArbitrary(chainId, signer, data);
    }
    async signDirect(chainId, signer, signDoc, signOptions) {
        return this.client.signDirect(chainId, signer, signDoc, signOptions);
    }
    async sendTx(chainId, tx, mode) {
        return this.client.sendTx(chainId, tx, mode);
    }
    async addSuggestChain(chainId) {
        const chain = this.getChainById(chainId);
        const chainInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$keplr$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chainRegistryChainToKeplr"])(chain, this.assetLists);
        try {
            await this.client.experimentalSuggestChain(chainInfo);
        } catch (error) {
            console.log('add suggest chain error', error);
            throw error;
        }
    }
    async getProvider() {
        return this.client;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/ethereum-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "EthereumWallet": (()=>EthereumWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/base64-js/index.js [app-client] (ecmascript)");
;
;
;
class EthereumWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    ethereum;
    isSwitchingNetwork = false;
    async init() {
        this.ethereum = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientFromExtension"])(this.info.ethereumKey);
    }
    async connect(chainId) {
        let chainIdToHex = chainId.startsWith("0x") ? chainId : "0x" + parseInt(chainId, 10).toString(16);
        try {
            // const accounts = await this.ethereum.request({
            //   method: "eth_requestAccounts",
            //   params: [{ chainId }],
            // })
            // const chainIdd = await this.ethereum.request({
            //   method: "eth_chainId",
            //   params: [],
            // })
            await this.ethereum.request({
                method: "wallet_switchEthereumChain",
                params: [
                    {
                        chainId: chainIdToHex
                    }
                ]
            });
        } catch (error) {
            if (!error.message.includes("reject")) {
                await this.addSuggestChain(chainId);
            }
        }
    }
    async disconnect(chainId) {
        // throw new Error("Method not implemented.");
        console.log('eth disconnect');
        return new Promise((resolve, reject)=>{
            resolve();
        });
    }
    async switchChain(chainId) {
        if (!chainId.startsWith("0x")) {
            chainId = "0x" + parseInt(chainId, 10).toString(16);
        }
        if (this.isSwitchingNetwork) {
            while(true){
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["delay"])(10);
                if (!this.isSwitchingNetwork) {
                    break;
                }
            }
        } else {
            try {
                this.isSwitchingNetwork = true;
                await this.ethereum.request({
                    method: "wallet_switchEthereumChain",
                    params: [
                        {
                            chainId
                        }
                    ]
                });
            } catch (error) {} finally{
                this.isSwitchingNetwork = false;
            }
        }
    }
    async getAccount(chainId) {
        await this.switchChain(chainId);
        const accounts = await this.ethereum.request({
            method: 'eth_requestAccounts',
            params: [
                {
                    chainId
                }
            ]
        });
        return {
            address: accounts[0],
            pubkey: new Uint8Array(),
            algo: 'eth_secp256k1',
            isNanoLedger: false,
            isSmartContract: false,
            username: 'ethereum'
        };
    }
    async getOfflineSigner(chainId) {
        await this.switchChain(chainId);
        return {};
    }
    async addSuggestChain(chainId) {
        const chainIdToHex = chainId.startsWith("0x") ? chainId : "0x" + parseInt(chainId, 10).toString(16);
        const chain = this.getChainById(chainId);
        const assetList = this.getAssetListByChainId(chainId);
        const network = {
            chainId: chainIdToHex,
            chainName: chain.chainName,
            rpcUrls: chain.apis?.rpc.map((api)=>api.address),
            nativeCurrency: {
                name: chain.chainName,
                symbol: assetList.assets[0].symbol,
                decimals: assetList.assets[0].denomUnits.find((unit)=>unit.denom === 'eth').exponent
            },
            blockExplorerUrls: chain.explorers.map((explorer)=>explorer.url)
        };
        try {
            await this.ethereum.request({
                method: "wallet_addEthereumChain",
                params: [
                    network
                ]
            });
            console.log(`Network ${network.chainName} added successfully.`);
        } catch (error) {
            if (error.message.includes("is not a function")) {
                return;
            }
            console.error(`Failed to add network: ${error.message}`);
            throw error;
        }
    }
    async getProvider(chainId) {
        await this.switchChain(chainId);
        return this.ethereum;
    }
    async sendTransaction(transactionParameters) {
        // 发送交易请求
        const txHash = await this.ethereum.request({
            method: 'eth_sendTransaction',
            params: [
                transactionParameters
            ]
        });
        console.log('transactionHash:', txHash);
        return txHash;
    }
    async signMessage(message) {
        if (!this.ethereum) {
            throw new Error("MetaMask is not installed");
        }
        try {
            // Request account access
            const accounts = await this.ethereum.request({
                method: "eth_requestAccounts"
            });
            const account = accounts[0];
            // Encode message to Base64
            const hexMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromByteArray"])(new TextEncoder().encode(message));
            // Sign the message
            const signature = await this.ethereum.request({
                method: "personal_sign",
                params: [
                    hexMessage,
                    account
                ]
            });
            console.log("Signature:", signature);
            return signature;
        } catch (error) {
            console.error("Error signing message:", error);
            throw error;
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/multichain-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "MultiChainWallet": (()=>MultiChainWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
;
;
;
class MultiChainWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    networkWalletMap = new Map();
    constructor(info, networkWalletMap){
        super(info);
        // this.networkWalletMap.set('cosmos', new CosmosWallet(info));
        // this.networkWalletMap.set('eip155', new EthereumWallet(info));
        if (networkWalletMap) {
            networkWalletMap.forEach((wallet, key)=>{
                if (this.networkWalletMap.has(key)) {
                    this.networkWalletMap.set(key, wallet);
                }
            });
        }
    }
    setNetworkWallet(chainType, wallet) {
        this.networkWalletMap.set(chainType, wallet);
    }
    setChainMap(chains) {
        this.chainMap = new Map(chains.map((chain)=>[
                chain.chainId,
                chain
            ]));
        this.networkWalletMap.forEach((wallet)=>{
            wallet.setChainMap(chains);
        });
    }
    addChain(chain) {
        this.chainMap.set(chain.chainId, chain);
        this.networkWalletMap.forEach((wallet)=>{
            wallet.addChain(chain);
        });
    }
    setAssetLists(assetLists) {
        this.networkWalletMap.forEach((wallet)=>{
            wallet.setAssetLists(assetLists);
        });
    }
    async init() {
        const wallets = Array.from(this.networkWalletMap.values());
        await Promise.all(wallets.map(async (wallet)=>wallet.init()));
    }
    getWalletByChainType(chainType) {
        const wallet = this.networkWalletMap.get(chainType);
        if (!wallet) {
            throw new Error(`Unsupported chain type: "${chainType}"`);
        }
        return wallet;
    }
    async connect(chainId) {
        const chain = this.getChainById(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        await networkWallet.connect(chainId);
    }
    async disconnect(chainId) {
        const chain = this.getChainById(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        await networkWallet.disconnect(chainId);
    }
    async getAccount(chainId) {
        const chain = this.getChainById(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        if (!networkWallet) {
            return Promise.reject(new Error('Unsupported chain type'));
        }
        return networkWallet.getAccount(chainId);
    }
    async getOfflineSigner(chainId, preferSignType) {
        const chain = this.getChainById(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceOf"])(networkWallet, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CosmosWallet"]) && preferSignType) {
            return networkWallet.getOfflineSigner(chainId, preferSignType);
        }
        return networkWallet.getOfflineSigner(chainId);
    }
    async addSuggestChain(chainId) {
        const chain = this.chainMap.get(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        return networkWallet.addSuggestChain(chainId);
    }
    getProvider(chainId) {
        const chain = this.getChainById(chainId);
        const networkWallet = this.getWalletByChainType(chain.chainType);
        return networkWallet.getProvider(chainId);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/extension-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ExtensionWallet": (()=>ExtensionWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/extension.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/helpers.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/multichain-wallet.js [app-client] (ecmascript)");
;
;
;
class ExtensionWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MultiChainWallet"] {
    async init() {
        const walletIdentify = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$extension$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getClientFromExtension"])(this.info.windowKey);
        if (!walletIdentify) {
            throw __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"];
        }
        await super.init();
    }
    setSignOptions(options) {
        const wallet = this.getWalletByChainType('cosmos');
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$helpers$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isInstanceOf"])(wallet, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CosmosWallet"])) {
            wallet.setSignOptions(options);
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/platform-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "PlatformWallet": (()=>PlatformWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/platform.js [app-client] (ecmascript)");
;
;
class PlatformWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    currentPlatformWallet;
    platformWalletMap = new Map();
    setPlatformWallet(platform, wallet) {
        this.platformWalletMap.set(platform, wallet);
    }
    setChainMap(chains) {
        this.platformWalletMap.forEach((wallet)=>{
            wallet.setChainMap(chains);
        });
    }
    setAssetLists(assetLists) {
        this.platformWalletMap.forEach((wallet)=>{
            wallet.setAssetLists(assetLists);
        });
    }
    addAssetList(assetList) {
        this.platformWalletMap.forEach((wallet)=>{
            wallet.addAssetList(assetList);
        });
    }
    addChain(chain) {
        this.platformWalletMap.forEach((wallet)=>{
            wallet.addChain(chain);
        });
    }
    async init() {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMobile"])()) {
            this.currentPlatformWallet = this.platformWalletMap.get("mobile-web");
        } else {
            this.currentPlatformWallet = this.platformWalletMap.get("web");
        }
        if (!this.currentPlatformWallet) {
            throw new Error("No platform wallet set");
        }
        await this.currentPlatformWallet.init();
    }
    connect(chainId) {
        return this.currentPlatformWallet?.connect(chainId);
    }
    disconnect(chainId) {
        return this.currentPlatformWallet.disconnect(chainId);
    }
    getAccount(chainId) {
        return this.currentPlatformWallet?.getAccount(chainId);
    }
    getOfflineSigner(chainId, preferredSignType) {
        return this.currentPlatformWallet.getOfflineSigner(chainId, preferredSignType);
    }
    addSuggestChain(chainId) {
        return this.currentPlatformWallet?.addSuggestChain(chainId);
    }
    getProvider(chainId) {
        return this.currentPlatformWallet.getProvider(chainId);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/wc-mobile-web-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WCMobileWebWallet": (()=>WCMobileWebWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/platform.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)");
;
;
class WCMobileWebWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WCWallet"] {
    walletConnectData;
    async navigateWalletConnectLink(uri) {
        // const appUrl = this.walletConnectData.mobile.native || this.walletConnectData.mobile.universal
        let wcUrl = '';
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAndroid"])()) {
            wcUrl = this.info.walletConnectLink?.android?.replace('{wc-uri}', encodeURIComponent(uri));
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$platform$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isIOS"])()) {
            wcUrl = this.info.walletConnectLink?.ios?.replace('{wc-uri}', encodeURIComponent(uri));
        }
        if (wcUrl) {
            window.open(wcUrl, "_blank", "noopener,noreferrer");
        }
    }
    async navigateToDappBrowserLink() {
        if (!this.info.dappBrowserLink) {
            return;
        }
        const link = this.info.dappBrowserLink(window.location.href);
        window.open(link, "_blank", "noopener,noreferrer");
    }
    async init() {
        // this.walletConnectData = await getWCInfoByProjectId(this.info.walletconnect.projectId)
        await super.init();
        this.provider.on('display_uri', async (uri)=>{
            await this.navigateWalletConnectLink(uri);
            await this.navigateToDappBrowserLink();
        });
    }
    async connect() {
        await this.navigateToDappBrowserLink();
        await super.connect('');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$ethereum$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/ethereum-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/multichain-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$extension$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/extension-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$platform$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/platform-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$mobile$2d$web$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-mobile-web-wallet.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/wallets/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$ethereum$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/ethereum-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/multichain-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$extension$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/extension-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$platform$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/platform-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$mobile$2d$web$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-mobile-web-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallet$2d$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallet-manager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/index.js [app-client] (ecmascript) <module evaluation>");
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallet$2d$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallet-manager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$constant$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/constant/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/modal/views/Connecting.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ConnectingContent": (()=>ConnectingContent),
    "ConnectingHeader": (()=>ConnectingHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
;
;
const ConnectingHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet.info.prettyName,
        hasBackButton: true,
        onClose: close,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = ConnectingHeader;
const ConnectingContent = ({ wallet })=>{
    const { info: { prettyName, mode } } = wallet;
    let title = "Requesting Connection";
    let desc = mode === "wallet-connect" ? `Approve ${prettyName} connection request on your mobile.` : `Open the ${prettyName} browser extension to connect your wallet.`;
    if (!wallet) return null;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalStatus"], {
        wallet: {
            name: wallet.info.name,
            prettyName: wallet.info.prettyName,
            logo: wallet.info.logo,
            mobileDisabled: true
        },
        status: "Connecting",
        contentHeader: title,
        contentDesc: desc
    });
};
_c1 = ConnectingContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "ConnectingHeader");
__turbopack_context__.k.register(_c1, "ConnectingContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/WalletList.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WalletListContent": (()=>WalletListContent),
    "WalletListHeader": (()=>WalletListHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
;
;
const WalletListHeader = ({ close })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: "Select your wallet",
        hasBackButton: false,
        onClose: close,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = WalletListHeader;
const WalletListContent = ({ wallets, onSelectWallet })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalWalletList"], {
        wallets: wallets,
        onWalletItemClick: onSelectWallet
    });
};
_c1 = WalletListContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "WalletListHeader");
__turbopack_context__.k.register(_c1, "WalletListContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getWalletInfo": (()=>getWalletInfo),
    "transferToWalletUISchema": (()=>transferToWalletUISchema)
});
const getWalletInfo = (wallet)=>{
    return {
        name: wallet?.info?.name,
        prettyName: wallet?.info?.prettyName,
        logo: wallet?.info?.logo,
        mobileDisabled: true
    };
};
const transferToWalletUISchema = (w)=>{
    if (w.info.mode === "wallet-connect") {
        const wc = w;
        if (wc.session) {
            return {
                name: wc.session?.peer.metadata?.name,
                prettyName: `${wc.session?.peer.metadata?.name} - Mobile`,
                logo: wc.session?.peer.metadata?.icons?.[0],
                mobileDisabled: true,
                shape: "list",
                originalWallet: {
                    ...w,
                    session: wc.session
                },
                subLogo: w.info.logo
            };
        }
    }
    return {
        name: w.info.name,
        prettyName: w.info.prettyName,
        logo: w.info.logo,
        mobileDisabled: true,
        shape: "list",
        originalWallet: w
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/utils/dedupeAsync.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "dedupeAsync": (()=>dedupeAsync)
});
const pendingRequests = new Map();
async function dedupeAsync(key, asyncFn) {
    if (pendingRequests.has(key)) {
        return pendingRequests.get(key);
    }
    const promise = asyncFn().finally(()=>{
        pendingRequests.delete(key);
    });
    pendingRequests.set(key, promise);
    return promise;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/utils/restoreAccount.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "restoreAccountFromLocalStorage": (()=>restoreAccountFromLocalStorage)
});
const restoreAccountFromLocalStorage = (walletAccount)=>{
    const pubkey = walletAccount.pubkey;
    if (typeof pubkey === 'object') {
        // return from localstorage need to restructure to uinit8Array
        return {
            ...walletAccount,
            pubkey: Uint8Array.from({
                ...pubkey,
                length: Object.keys(pubkey).length
            })
        };
    }
    return walletAccount;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$dedupeAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/dedupeAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$restoreAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/restoreAccount.js [app-client] (ecmascript)");
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$dedupeAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/dedupeAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$restoreAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/restoreAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/modal/views/Astronaut.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "AstronautSvg": (()=>AstronautSvg)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
function AstronautSvg(props) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        className: "chakra-icon css-1plqj06",
        viewBox: "0 0 278 255",
        ...props,
        children: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M136.844 254.8c70.527 0 127.7-57.039 127.7-127.4S207.371 0 136.844 0 9.144 57.039 9.144 127.4s57.173 127.4 127.7 127.4Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#F6F5F3",
                d: "M85.444 22.2a2.9 2.9 0 1 0 0-5.8 2.9 2.9 0 0 0 0 5.8Zm122.7 19.9a2.9 2.9 0 1 0 0-5.801 2.9 2.9 0 0 0 0 5.8Zm18.5 68.5a2.9 2.9 0 1 0-.002-5.802 2.9 2.9 0 0 0 .002 5.802Zm-15.6 71.5a2.9 2.9 0 1 0-.002-5.802 2.9 2.9 0 0 0 .002 5.802Zm-8.8 36a2.9 2.9 0 1 0-.002-5.802 2.9 2.9 0 0 0 .002 5.802Zm-57.5 12.2a2.9 2.9 0 1 0-.002-5.802 2.9 2.9 0 0 0 .002 5.802Zm-32.9-24.2a2.9 2.9 0 1 0-.002-5.802 2.9 2.9 0 0 0 .002 5.802Zm-97.7-94a2.9 2.9 0 1 0-.001-5.8 2.9 2.9 0 0 0 0 5.8Zm34-62.1a2.9 2.9 0 1 0 0-5.8 2.9 2.9 0 0 0 0 5.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#BA536A",
                d: "M235.944 47.1c9.6 11.7 17 25.1 22 39.7-4.5 4.5-10.7 7.4-17.6 7.4-13.4 0-24.2-10.7-24.2-23.8 0-11.6 8.5-21.3 19.8-23.3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#FF6B84",
                d: "M242.544 92.9c-13 0-23.6-10.6-23.6-23.7 0-10.6 7-19.6 16.7-22.6 9.7 11.9 17.4 25.6 22.4 40.5-4.2 3.6-9.6 5.8-15.5 5.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#124899",
                d: "M144.744 246.7c0 2.8-.6 5.4-1.5 7.9-2.067.133-4.2.2-6.4.2-14.2 0-28-2.4-40.8-6.7 0-.5-.1-1-.1-1.4 0-13.1 10.9-23.8 24.4-23.8 13.5 0 24.4 10.7 24.4 23.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#4CBAB6",
                d: "M145.644 249.2c0 1.8-.2 3.567-.6 5.3-2.667.2-5.4.3-8.2.3-13.5 0-26.5-2.1-38.7-6 .2-13.4 10.8-24.3 23.7-24.3 13.1 0 23.8 11.1 23.8 24.7Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#D8DEDC",
                d: "M205.144 117.7c5.9 6.3 17.1 16.7 27.6 23.5 21.8 13.9 20.8 11.7 26.1 14l-8.8 27.9c-13.334-9.733-24.167-17.033-32.5-21.9-10.2-6.067-21.8-12.033-34.8-17.9l22.4-25.6Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#839091",
                d: "M207.344 119.9c.4.467 2.066 2.1 5 4.9-2.667 5.933-5.067 10.333-7.2 13.2-5 6.8-5.3 6.5-10 11.2l-7.9-3.8 20.1-25.5Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#9CA9A8",
                d: "M242.844 196.2c-6.934 1.333-10.367.2-10.3-3.4 0-8.4 5.1-7.8 18.6-10.2l-8.3 13.6Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#DAE0DF",
                d: "M234.844 190.9c-.267-1.6.466-3.067 2.2-4.4 1.666-1.267 4.933-1.933 9.8-2-4.534 1.4-7.334 2.533-8.4 3.4-1 .867-2.2 1.867-3.6 3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M251.844 156.9c-4.134-6.6-4.734-10.433-1.8-11.5 4.5-1.6 11.2-1 16.1 1 6.2 2.5 11.7 6.9 11.7 10.5 0 3.133-2.6 5.233-7.8 6.3 3.866 4.6 4.866 7.933 3 10-1.8 2.067-5.267 2.8-10.4 2.2 5 5.133 6.333 8.767 4 10.9-2.6 2.3-12.1 1.6-18.1-.9-5.2-2.1-14.2-12.6-11.5-15.8 1.733-2.133 5.5-3.2 11.3-3.2-5.334-3.067-7-5.567-5-7.5 2-1.867 4.833-2.533 8.5-2Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#9CA9A8",
                d: "M252.344 148.9c2.9-1.1 8.3.5 12.3 1.8 3.9 1.2 10.5 5.7 9 8-1 1.6-3.267 2.567-6.8 2.9 4.133 5.933 4.966 9.267 2.5 10-3.7 1-11.8.8-11.3 1.3s11.1 10.2 6.5 12.5c-4.5 2.3-10.9.8-15.7-1.8-5.7-3-10.4-10-8.5-12 .733-.8 4.466-1.7 11.2-2.7-5.334-4-7.8-6.533-7.4-7.6.7-1.7 3-2.6 6.4-2.6h6.5c-5.934-5.533-7.5-8.8-4.7-9.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#DAE0DF",
                d: "M256.544 155.2c-3.134-2.733-4.134-4.333-3-4.8 1.066-.4 2.9-.3 5.5.3-1.6 0-2.6.3-3 .9-.4.6-.234 1.8.5 3.6Zm-7.7 6.2c-.534 1.2-.3 2.367.7 3.5-3.2-1.4-4.434-2.666-3.7-3.8.733-1.133 3.4-1.533 8-1.2-2.8-.2-4.467.3-5 1.5Zm-4.3 12.4c-.467 1.067-.167 2.867.9 5.4-3.334-2.933-4.367-5.133-3.1-6.6 1.266-1.533 3.433-2.133 6.5-1.8-2.467.867-3.9 1.867-4.3 3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#D8DEDC",
                d: "M180.844 148.9c1.933 5.933 3.933 13.767 6 23.5 3.7 17.5 2.9 36.9-4.1 39.9-2.8 1.2-5.4 3.6-16.1 0-7.2-2.4-22.134-12.133-44.8-29.2l59-34.2Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#687476",
                d: "M182.744 155.2c-3.2 10.933-12.3 19.7-27.3 26.3-7.334 3.267-16.334 5.4-27 6.4l-10.2-7.5 46.5-25.2h18Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#D8DEDC",
                d: "M74.044 99.2c-7.467.867-13.3 1.533-17.5 2-1.934.2-4.767 1.167-8.5 2.9-3.2-4.333-5.434-8.533-6.7-12.6-1.5-4.6-3-15.4.2-21.7 2.2-4.2 14.366-9.067 36.5-14.6l-4 44Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#839091",
                d: "m82.544 53.7-3.5 43.9-23.9 3.9c-1-4.333-1.434-7.933-1.3-10.8.8-14.133 2.466-24.1 5-29.9l23.7-7.1Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "m189.144 137.5-6.4 17.7c-12.4 14.067-26.967 23.533-43.7 28.4-16.8 4.867-34.934 5.467-54.4 1.8l-68.8-32.5c.733-5.933 2.766-11.667 6.1-17.2 5-8.3 15.9-29.3 28.5-33 8.4-2.533 17.6-3.7 27.6-3.5l111.1 38.3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#D8DEDC",
                d: "M174.844 148.9c-15.334 26-42.1 37.233-80.3 33.7-16.6-1.6-41.934-12.333-76-32.2 3.666-4.733 5.833-8.467 6.5-11.2 1.1-4 2.4-7.2 6.5-9.5 4.1-2.4 9-6.9 11.7-8.8 4.8-3.5 4.6-9.7 7.2-10.4 4.266-1 12.3-1.933 24.1-2.8l100.3 41.2Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#687476",
                d: "M113.844 150.7h63.5c-4.334 6.133-11.3 12.2-20.9 18.2-9.6 6-16.4 9-20.4 9-3.334 0-8.6-2.067-15.8-6.2-9.6-5.533-15.734-10.467-18.4-14.8l12-6.2Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#839091",
                d: "m79.844 106.3 14.8 30.1-20.1 6.9c-5.8-7.667-9.534-12.967-11.2-15.9-1.667-2.933-4.267-8.867-7.8-17.8l24.3-3.3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M142.144 166.5c40.869 0 74-33.937 74-75.8s-33.131-75.8-74-75.8-74 33.937-74 75.8 33.131 75.8 74 75.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#D8DEDC",
                d: "M143.444 158.8c37.334 0 67.6-31.027 67.6-69.3 0-38.273-30.266-69.3-67.6-69.3-37.335 0-67.6 31.027-67.6 69.3 0 38.273 30.265 69.3 67.6 69.3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#fff",
                d: "M172.344 29.4c9.066 4.133 15.9 10.033 20.5 17.7-.534 1.933-7.367 4.033-20.5 6.3-4.667.8-8.934 1.4-12.8 1.8.066-5.467-.5-10.667-1.7-15.6-1.867-7.467-3.867-12.034-6-13.7 6.6-.867 13.433.3 20.5 3.5Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M85.444 50c23.133 6.6 44.366 9.566 63.7 8.9 19.333-.667 37.033-3.634 53.1-8.9 6.533 14.4 10.433 25.266 11.7 32.6 1.266 7.333.3 16.633-2.9 27.9-16.334 16.666-38.9 24.3-67.7 22.9-35.8-1.734-58.633-11.267-68.5-28.6-2.6-15.467-2.7-27.134-.3-35 2.4-7.934 6.033-14.534 10.9-19.8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#173D3E",
                d: "M96.744 75.6c5.7 1.4 15.8-.4 20.1 1.3 4.2 1.8 11.7 12.8 16.3 14.4 4.6 1.5 11.7-5.4 14-5 2.3.3 1.9 4.4 4.9 6.6 1.2.9 3.2 1.9 7.3 3 3.066.866 6.233 1.866 9.5 3-20.334 11.666-40.3 15.533-59.9 11.6-19.6-3.867-30.067-8.267-31.4-13.2-.467-4.667-.3-10.367.5-17.1.666-5.134 1.7-9.567 3.1-13.3 6.666 4.866 11.866 7.766 15.6 8.7Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#276A69",
                d: "M77.344 91.7c2.733-.6 5.166-.2 7.3 1.2 3.1 2.1 14.7 9.3 18.7 10.8s24.9-.2 26.8-1.5c1.2-.934 3.1-1.7 5.7-2.3 3.333 2.733 5.933 4 7.8 3.8 2.7-.4 6 1.2 9.9-1.3 4-2.5 6-5.6 8.8-5.6 2.7 0 5.9 1.8 8 2.1 6.5 1.1 8.2-1.5 11-.5 2.8 1 4.2 1.5 8.8 1.3 3.066-.2 9.033-.834 17.9-1.9 1.6 4.466-3.534 11.333-15.4 20.6-6.3 4.9-19.3 12-55 12-5.8 0-27.9-1.1-46-14.5-11.4-8.334-16.167-16.4-14.3-24.2Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#388688",
                d: "M122.844 103.5c4.466-.467 8.566-2.434 12.3-5.9l1.7 2.7c.133 2.266-.767 4.266-2.7 6-2.9 2.6-7.3 4.6-12.3 4.2-3.267-.2-7.934-2.334-14-6.4 5.4.133 10.4-.067 15-.6Zm27.8-.9c3.6-.6 6.7-2.7 9.2-5 1.666-1.534 3.9-1.534 6.7 0-1 .733-2 1.433-3 2.1-1.4 1-2.6 1.1-5.2 2.2s-6.6 4.4-13.8 4.4c-3 0-5.134-1.6-6.4-4.8 4.266 1.466 8.4 1.833 12.4 1.1h.1Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#fff",
                d: "m159.344 60.9 20-2.5c4.2 14.266 4.833 36.333 1.9 66.2-4.067 1.266-7.634 2.3-10.7 3.1-4.6 1.2-8.934 1.866-13 2 2.533-7.667 3.633-19.5 3.3-35.5-.2-11.867-.7-22.967-1.5-33.3Zm40-6c2.4 2.7 7.5 10.9 8.8 20 1.9 14.4 1.3 21.5-.6 27.8-2.134 4-4.634 7.1-7.5 9.3-2.867 2.266-5.434 4.466-7.7 6.6 3.2-5.067 4.466-14.734 3.8-29-.667-15.134-2.534-26.134-5.6-33l8.8-1.7Z",
                opacity: 0.4
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M74.544 142.9c15.733-15.333 28.166-21.9 37.3-19.7 15.3 3.6 14.9 13.9 11.4 24.4-2.334 6.933-15.2 12.7-38.6 17.3l-10.1-22Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#9CA9A8",
                d: "M78.144 146.2c4-4.667 11.233-8.5 21.7-11.5 15.8-4.5 18.3 4.3 18.4 7.2.2 3-1.4 7.2-6.4 8.8-3.334 1.067-11.567 3.8-24.7 8.2l-9-12.7Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#515C5C",
                d: "m78.144 144.9 4.2-2.3c3.933 4.6 6.6 6.867 8 6.8 4.2-.1 9.3.4 9.5-.5.2-.6.866-2.7 2-6.3-.134 2.8-.134 4.5 0 5.1.2.9 9.1-.2 11.3-1.3 2-1 3.7-2.5 5.1-4.5.2 3.2-.534 5.367-2.2 6.5-3.6 2.6-13.234 6.1-28.9 10.5l-9-14Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#DAE0DF",
                d: "M105.144 136.1c1-.3 6.2-.7 7.7 0 1 .467 1.633 1.5 1.9 3.1-.8-.733-1.767-1.433-2.9-2.1-.934-.533-3.167-.867-6.7-1Zm-4.5 7.8-1.5 4.2c-.267.867-2.367 1.067-6.3.6 2.466-.2 4.233-.8 5.3-1.8 1.133-.933 1.966-1.933 2.5-3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#030609",
                d: "M57.844 227.4c-.1 2.8 0 7.5-3.3 9.3-3.2 1.7-31 3.2-36.5-2.8-5.4-6-15.4-25.5-17.2-36.5-1.2-7.3-2-20.5 4-22.2 4-1.2 8.066-.833 12.2 1.1-3.934-5.933-5.9-11.4-5.9-16.4 0-3.6 1.3-9.5 5.9-10.5 3.066-.667 9.333-.167 18.8 1.5-2-7.2-2-12.2 0-15 6-8.5 22.5-7.2 27-6 4.5 1.3 39.8 37 42 46.4 1.4 5.7-2.3 21.4-6.7 24-1.867 1.133-6.1 2.1-12.7 2.9 4.2 8 4.2 13.4 0 16.2-4.267 2.867-13.467 2.867-27.6 0v8Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#9CA9A8",
                d: "M38.844 152.9c-1.2-6.867-.7-11.034 1.5-12.5 3.2-2.3 12-2.7 16.5-2.2s5.1 8 11.5 12.2c11 7.3 24 25.3 25.5 28.8s.3 6 0 8.5-12.5 6.6-16 3.7c-1.4-1.1-7.2-8.4-12-12.2-4.667-3.8-9.1-6.567-13.3-8.3 7 7.8 10.933 12.566 11.8 14.3 1.3 2.6 4.1 10.2 7 12.2 2.9 2 10.1 7.8 11.2 8.6 1.1.9 1.6 8.9 1.1 10.4-1.8 2-15.3-4.6-17.3-5-2-.3-7.2-1.2-11.7-2.5-3.067-.8-10.5-7.8-22.3-21 2.733 8.866 5.333 14.9 7.8 18.1 3.6 4.8 6 12 9.2 12 4.5 0 3.8 9.2 1.7 10.9-2.2 1.8-18.3 1.4-24.7-1.5-4.7-2.1-24.5-46.5-19-48.2 7-2.3 11.8-1 14.2 1.3 1.533 1.533 3.133 3.1 4.8 4.7-6.867-19.067-8.367-28.834-4.5-29.3 4.466-.534 9.4-.934 14.8-1.2l1.5 4.7.5-4.2 3.2 1-3-3.3Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#515C5C",
                d: "M12.244 178.1c-2 2.533-2.367 5.566-1.1 9.1 2 5.2 5.4 15 7.7 18.8 2.3 3.9 9.2 16.4 10.8 18.5 1 1.466 2.4 3.066 4.2 4.8-2.867-.267-5.367-.9-7.5-1.9-4.1-1.8-16.2-25.1-19-38.5-1.3-6.3-1.5-8.9 0-9.7 2.533-1.334 4.166-1.7 4.9-1.1Zm21.6 51.2c4.666-3 7.6-5.134 8.8-6.4a99.173 99.173 0 0 1 5.2-5.4c2.666.266 4.333.9 5 1.9 1 1.5-.4 8.9-1.8 9.5-2.4 1.1-5.1 1.3-6.9 1.4-3.867.133-7.3-.2-10.3-1Zm1.4-33c.9 3 3.7 7.6 6.1 11.6 2.533 4.266 4.233 7.033 5.1 8.3-8.2-7-12.9-12.667-14.1-17-1.2-4.334-1.2-8.1 0-11.3.533.533 1.5 3.333 2.9 8.4Zm47.3 9.7c1.6 2.9 2.3 7.7 1 10.4-.8 1.866-6.534.2-17.2-5 1.6-1.334 3-3.134 4.2-5.4 3.2-5.7 3.2-5.7 3.5-6.6 4.533 2.533 7.366 4.733 8.5 6.6Zm-20-23.4c2.533 3.533 5.033 8.066 7.5 13.6-6.334-4-11-8.534-14-13.6-2.334-4.067-4-8.634-5-13.7 5.733 6.466 9.566 11.033 11.5 13.7Zm12 5.3c3.2-.734 6.433-2.034 9.7-3.9 4.266-2.4 7.266-4.4 9-6 1.8 2.666 2 5.9.6 9.7-1.4 3.5-11.3 7.2-16 3.7-2-1.467-3.1-2.634-3.3-3.5Z"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("path", {
                fill: "#DAE0DF",
                d: "M43.344 150.7c-.867-6.6.733-10.367 4.8-11.3 4-.867 8.133.566 12.4 4.3-4.534-1.2-7.9-1.634-10.1-1.3-2.134.333-4.5 3.1-7.1 8.3Zm-17.5 11c-.667 2-.334 7.833 1 17.5-5.2-12.4-6.467-19.4-3.8-21 3.2-1.934 6.8-1.934 10.8 0-4.667.333-7.334 1.5-8 3.5Zm-10.2 20.3c-1.134.533-2 2.5-2.6 5.9-1.667-5.8-1.334-8.7 1-8.7 3.666-.067 6.3 1.533 7.9 4.8-2.134-2.334-4.267-3-6.4-2h.1Z"
            })
        ]
    });
}
_c = AstronautSvg;
var _c;
__turbopack_context__.k.register(_c, "AstronautSvg");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/Connected.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ConnectedContent": (()=>ConnectedContent),
    "ConnectedHeader": (()=>ConnectedHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Astronaut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Astronaut.js [app-client] (ecmascript)");
;
;
;
;
const ConnectedHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet?.info?.prettyName || "",
        hasBackButton: true,
        onClose: close,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = ConnectedHeader;
const ConnectedContent = ({ address, username, wallet, disconnect })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalStatus"], {
        wallet: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWalletInfo"])(wallet),
        status: "Connected",
        connectedInfo: {
            name: username || "Wallet",
            avatar: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Astronaut$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AstronautSvg"], {
                style: {
                    fontSize: "inherit",
                    width: "100%",
                    height: "100%"
                }
            }),
            address: address
        },
        onDisconnect: disconnect
    });
};
_c1 = ConnectedContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "ConnectedHeader");
__turbopack_context__.k.register(_c1, "ConnectedContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/Reject.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "RejectContent": (()=>RejectContent),
    "RejectHeader": (()=>RejectHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
;
;
;
const RejectHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet?.info?.prettyName,
        hasBackButton: true,
        onClose: close,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = RejectHeader;
const RejectContent = ({ wallet, onReconnect })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalStatus"], {
        status: "Rejected",
        wallet: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWalletInfo"])(wallet),
        contentHeader: "Request Rejected",
        contentDesc: wallet.errorMessage || "Connection permission is denied.",
        onConnect: onReconnect
    });
};
_c1 = RejectContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "RejectHeader");
__turbopack_context__.k.register(_c1, "RejectContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/QRCode.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "QRCodeContent": (()=>QRCodeContent),
    "QRCodeHeader": (()=>QRCodeHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
;
;
const QRCodeHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet?.info?.prettyName || "",
        hasBackButton: true,
        onClose: ()=>void 0,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = QRCodeHeader;
const QRCodeContent = ({ errorMessage, walletConnectQRCodeUri, onReconnect })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalQRCode"], {
        status: walletConnectQRCodeUri ? "Done" : "Pending",
        link: walletConnectQRCodeUri,
        description: "Open App to connect",
        errorTitle: "errorTitle",
        errorDesc: errorMessage || "",
        onRefresh: onReconnect
    });
};
_c1 = QRCodeContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "QRCodeHeader");
__turbopack_context__.k.register(_c1, "QRCodeContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/NotExist.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "NotExistContent": (()=>NotExistContent),
    "NotExistHeader": (()=>NotExistHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$fa$2f$FaAndroid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-icons/all-files/fa/FaAndroid.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$go$2f$GoDesktopDownload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-icons/all-files/go/GoDesktopDownload.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$gr$2f$GrFirefox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-icons/all-files/gr/GrFirefox.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$ri$2f$RiAppStoreFill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-icons/all-files/ri/RiAppStoreFill.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$ri$2f$RiChromeFill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-icons/all-files/ri/RiChromeFill.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const NotExistHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet?.info?.prettyName || "",
        hasBackButton: true,
        onClose: close,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = NotExistHeader;
const NotExistContent = ({ wallet, getDownloadLink, getEnv })=>{
    _s();
    const downloadLink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotExistContent.useMemo[downloadLink]": ()=>{
            return getDownloadLink(wallet.info.name);
        }
    }["NotExistContent.useMemo[downloadLink]"], [
        wallet?.info?.name
    ]);
    const onInstall = ()=>{
        if (downloadLink) {
            window.open(downloadLink.link, "_blank");
        }
    };
    const IconComp = getIcon(getEnv());
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalStatus"], {
        status: "NotExist",
        wallet: {
            name: wallet?.info?.prettyName,
            logo: typeof wallet?.info?.logo === "string" ? wallet?.info?.logo : "",
            mobileDisabled: true
        },
        contentHeader: `${wallet?.info?.prettyName} Not Installed`,
        contentDesc: ("TURBOPACK compile-time truthy", 1) ? `If ${wallet?.info?.prettyName.toLowerCase()} is installed on your device, please refresh this page or follow the browser instruction.` : ("TURBOPACK unreachable", undefined),
        onInstall: onInstall,
        installIcon: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(IconComp, {}),
        disableInstall: downloadLink === null
    });
};
_s(NotExistContent, "fFrYnJPRrD+Dq+IkBMkrokYm0u4=");
_c1 = NotExistContent;
function getIcon(env) {
    if (env?.browser === "chrome") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$ri$2f$RiChromeFill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiChromeFill"];
    if (env?.browser === "firefox") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$gr$2f$GrFirefox$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GrFirefox"];
    if (env?.os === "android") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$fa$2f$FaAndroid$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaAndroid"];
    if (env?.os === "ios") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$ri$2f$RiAppStoreFill$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RiAppStoreFill"];
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$icons$2f$all$2d$files$2f$go$2f$GoDesktopDownload$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GoDesktopDownload"];
}
var _c, _c1;
__turbopack_context__.k.register(_c, "NotExistHeader");
__turbopack_context__.k.register(_c1, "NotExistContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/Error.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ErrorContent": (()=>ErrorContent),
    "ErrorHeader": (()=>ErrorHeader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
;
;
;
const ErrorHeader = ({ wallet, close, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalHead"], {
        title: wallet.info.prettyName,
        hasBackButton: true,
        onClose: close,
        onBack: onBack,
        closeButtonProps: {
            onClick: close
        }
    });
};
_c = ErrorHeader;
const ErrorContent = ({ wallet, onBack })=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModalStatus"], {
        status: "Error",
        wallet: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWalletInfo"])(wallet),
        contentHeader: "Oops! Something wrong...",
        contentDesc: wallet.errorMessage,
        onChangeWallet: onBack
    });
};
_c1 = ErrorContent;
var _c, _c1;
__turbopack_context__.k.register(_c, "ErrorHeader");
__turbopack_context__.k.register(_c1, "ErrorContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connecting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connecting.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/WalletList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connected$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connected.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Reject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Reject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$QRCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/QRCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$NotExist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/NotExist.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Error.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/views/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connecting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connecting.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/WalletList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connected$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connected.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Reject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Reject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$QRCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/QRCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$NotExist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/NotExist.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useWalletManager": (()=>useWalletManager)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useWalletManager = ()=>{
    _s();
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInterchainWalletContext"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(store);
};
_s(useWalletManager, "KuiR8265kq9o2RSvOA2bOyRJHII=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInterchainWalletContext"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/useAsync.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "activeRequests": (()=>activeRequests),
    "cache": (()=>cache),
    "useAsync": (()=>useAsync)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const cache = new Map();
const activeRequests = new Map();
function useAsync({ queryKey, queryFn, enabled = true, disableCache = false }) {
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        data: null,
        isLoading: false,
        error: null
    });
    const mountedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const queryFnRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(queryFn);
    const cacheKey = Array.isArray(queryKey) ? JSON.stringify(queryKey) : queryKey;
    // Always update the current function
    queryFnRef.current = queryFn;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAsync.useEffect": ()=>{
            mountedRef.current = true;
            return ({
                "useAsync.useEffect": ()=>{
                    mountedRef.current = false;
                }
            })["useAsync.useEffect"];
        }
    }["useAsync.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAsync.useEffect": ()=>{
            if (!enabled) return;
            if (!disableCache && cache.has(cacheKey)) {
                setState({
                    "useAsync.useEffect": (prev)=>({
                            ...prev,
                            data: cache.get(cacheKey),
                            isLoading: false,
                            error: null
                        })
                }["useAsync.useEffect"]);
                return;
            }
            if (activeRequests.has(cacheKey)) {
                activeRequests.get(cacheKey).then({
                    "useAsync.useEffect": (data)=>{
                        if (mountedRef.current) {
                            setState({
                                data,
                                isLoading: false,
                                error: null
                            });
                        }
                    }
                }["useAsync.useEffect"], {
                    "useAsync.useEffect": (error)=>{
                        if (mountedRef.current) {
                            setState({
                                data: null,
                                isLoading: false,
                                error
                            });
                        }
                    }
                }["useAsync.useEffect"]);
                return;
            }
            setState({
                "useAsync.useEffect": (prev)=>({
                        ...prev,
                        isLoading: true,
                        error: null
                    })
            }["useAsync.useEffect"]);
            const requestPromise = queryFnRef.current().then({
                "useAsync.useEffect.requestPromise": (data)=>{
                    if (!disableCache) {
                        cache.set(cacheKey, data);
                    }
                    if (mountedRef.current) {
                        setState({
                            data,
                            isLoading: false,
                            error: null
                        });
                    }
                    return data;
                }
            }["useAsync.useEffect.requestPromise"]).catch({
                "useAsync.useEffect.requestPromise": (error)=>{
                    if (mountedRef.current) {
                        setState({
                            data: null,
                            isLoading: false,
                            error
                        });
                    }
                }
            }["useAsync.useEffect.requestPromise"]).finally({
                "useAsync.useEffect.requestPromise": ()=>{
                    activeRequests.delete(cacheKey);
                }
            }["useAsync.useEffect.requestPromise"]);
            activeRequests.set(cacheKey, requestPromise);
        }
    }["useAsync.useEffect"], [
        cacheKey,
        enabled,
        disableCache
    ]);
    const refetch = async ()=>{
        try {
            setState((prev)=>({
                    ...prev,
                    isLoading: true,
                    error: null
                }));
            const data = await queryFnRef.current();
            if (!disableCache) {
                cache.set(cacheKey, data);
            }
            if (mountedRef.current) {
                setState({
                    data,
                    isLoading: false,
                    error: null
                });
            }
            return data;
        } catch (error) {
            if (mountedRef.current) {
                setState({
                    data: null,
                    isLoading: false,
                    error: error
                });
            }
            throw error;
        }
    };
    return {
        data: state.data,
        isLoading: state.isLoading,
        error: state.error,
        refetch
    };
}
_s(useAsync, "7JYUcqE1xULuOd4jG78RscBb+hg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/useSigningClient.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useSigningClient": (()=>useSigningClient)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const useSigningClient = (chainName, walletName)=>{
    _s();
    const { getSigningClient, getChainWalletState, getRpcEndpoint, isReady } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    const chainWalletState = getChainWalletState(walletName, chainName);
    const { data, isLoading, error } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAsync"])({
        queryKey: `signing-client-${chainName}-${walletName}`,
        queryFn: {
            "useSigningClient.useAsync": async ()=>{
                await getRpcEndpoint(walletName, chainName);
                const currentWalletState = getChainWalletState(walletName, chainName)?.walletState;
                if (currentWalletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected) {
                    return getSigningClient(walletName, chainName);
                }
            }
        }["useSigningClient.useAsync"],
        enabled: chainWalletState?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected && isReady,
        disableCache: true
    });
    return {
        signingClient: data,
        error,
        isLoading
    };
};
_s(useSigningClient, "Lei2aRy8Oi7koUIZtEQNFzmxVtQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAsync"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/useWalletModal.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useWalletModal": (()=>useWalletModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const useWalletModal = ()=>{
    _s();
    const { modalIsOpen, openModal, closeModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    return {
        modalIsOpen,
        open: openModal,
        close: closeModal
    };
};
_s(useWalletModal, "4yaSxr7ySOhtdT2g6bx1mRfRSHM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/useChain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useChain": (()=>useChain)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useSigningClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletModal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletModal.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
const useChain = (chainName)=>{
    _s();
    const { assetLists, currentWalletName, disconnect, setCurrentChainName, getChainByName, getWalletByName, getChainWalletState, getChainLogoUrl, connect, getSigningClient, getRpcEndpoint, getAccount, getStatefulWalletByName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    const chain = getChainByName(chainName);
    if (!chain) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainNameNotExist"](chainName);
    }
    const assetList = assetLists.find((a)=>a.chainName === chainName);
    const wallet = getStatefulWalletByName(currentWalletName);
    const chainWalletStateToShow = getChainWalletState(currentWalletName, chainName);
    const { open, close } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletModal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletModal"])();
    const { signingClient, isLoading: isSigningClientLoading, error: signingClientError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSigningClient"])(chainName, currentWalletName);
    return {
        //for migration cosmos kit
        connect: ()=>{
            setCurrentChainName(chainName);
            open();
        },
        disconnect: async ()=>disconnect(currentWalletName, chainName),
        openView: ()=>{
            setCurrentChainName(chainName);
            open();
        },
        closeView: close,
        getRpcEndpoint: ()=>getRpcEndpoint(currentWalletName, chainName),
        status: chainWalletStateToShow?.walletState,
        username: chainWalletStateToShow?.account?.username,
        message: chainWalletStateToShow?.errorMessage,
        // new api
        logoUrl: getChainLogoUrl(chainName),
        chain,
        assetList,
        address: chainWalletStateToShow?.account?.address,
        wallet,
        getSigningClient: ()=>getSigningClient(currentWalletName, chainName),
        signingClient,
        isSigningClientLoading,
        signingClientError,
        rpcEndpoint: chainWalletStateToShow?.rpcEndpoint
    };
};
_s(useChain, "bg95+VZLxYBPoWeW2kgd+dZWoFM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletModal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletModal"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSigningClient"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/useChainWallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useChainWallet": (()=>useChainWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useSigningClient.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useChainWallet = (chainName, walletName)=>{
    _s();
    const { assetLists, disconnect, setCurrentChainName, setCurrentWalletName, getChainByName, getWalletByName, getChainWalletState, getChainLogoUrl, connect, getSigningClient, getRpcEndpoint, getAccount, getStatefulWalletByName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    const chain = getChainByName(chainName);
    const wallet = getStatefulWalletByName(walletName);
    const assetList = assetLists.find((a)=>a.chainName === chainName);
    const chainWalletStateToShow = getChainWalletState(walletName, chainName);
    const { signingClient, isLoading: isSigningClientLoading, error: signingClientError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSigningClient"])(chainName, walletName);
    return {
        //for migration cosmos kit
        connect: async ()=>{
            setCurrentWalletName(walletName);
            setCurrentChainName(chainName);
            await connect(walletName, chainName);
        },
        disconnect: ()=>disconnect(walletName, chainName),
        getRpcEndpoint: ()=>getRpcEndpoint(walletName, chainName),
        status: chainWalletStateToShow?.walletState,
        username: chainWalletStateToShow?.account?.username,
        message: chainWalletStateToShow?.errorMessage,
        // new api
        logoUrl: getChainLogoUrl(chainName),
        chain,
        assetList,
        address: chainWalletStateToShow?.account?.address,
        wallet,
        getSigningClient: ()=>getSigningClient(walletName, chainName),
        signingClient,
        isSigningClientLoading,
        signingClientError,
        rpcEndpoint: chainWalletStateToShow?.rpcEndpoint
    };
};
_s(useChainWallet, "JF7yuThMOnE/Cx6uVWi77fe/6dk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSigningClient"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChainWallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useSigningClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletModal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletModal.js [app-client] (ecmascript)");
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useChainWallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useChainWallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useSigningClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useSigningClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletModal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletModal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/modal/modal.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "InterchainWalletModal": (()=>InterchainWalletModal),
    "ModalRenderer": (()=>ModalRenderer),
    "WalletModalElement": (()=>WalletModalElement)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connected$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connected.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connecting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Connecting.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Error.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$NotExist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/NotExist.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$QRCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/QRCode.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Reject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/Reject.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/views/WalletList.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@interchain-ui/react/dist/interchain-ui-kit-react.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/useWalletManager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/wallet.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const InterchainWalletModal = ({ // ==== Custom modal styles
modalContainerClassName, modalContentClassName, modalChildrenClassName, modalContentStyles, modalThemeProviderProps })=>{
    _s();
    const [shouldShowList, setShouldShowList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { modalIsOpen: isOpen, walletConnectQRCodeUri, wallets: statefulWallets, getChainWalletState, currentWalletName, currentChainName, openModal: open, closeModal: close, chains, setCurrentWalletName, getDownloadLink, getEnv } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    const [walletToConnect, setWalletToConnect] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const walletsForUI = statefulWallets.map((w)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["transferToWalletUISchema"])(w));
    const chainNameToConnect = currentChainName || chains[0].chainName;
    const chainToConnect = chains.find((chain)=>chain.chainName === chainNameToConnect);
    const currentWallet = statefulWallets.find((w)=>w.info.name === currentWalletName);
    const walletToShow = walletToConnect || currentWallet;
    const { account, errorMessage } = getChainWalletState(walletToConnect?.info?.name || currentWalletName, currentChainName) || {};
    const disconnect = ()=>{
        walletToShow.disconnect(chainToConnect.chainId);
    };
    const onSelectWallet = (wallet)=>{
        setWalletToConnect(wallet);
        setShouldShowList(false);
        return wallet.connect(chainToConnect.chainId);
    };
    const onBack = ()=>setShouldShowList(true);
    const handleCloseModal = ()=>{
        close();
        setShouldShowList(false);
    };
    const onReconnect = ()=>{
        currentWallet.connect(chainToConnect.chainId);
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeProvider"], {
        ...modalThemeProviderProps,
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(WalletModalElement, {
            shouldShowList: shouldShowList,
            username: account?.username,
            address: account?.address,
            disconnect: disconnect,
            isOpen: isOpen,
            open: open,
            close: handleCloseModal,
            wallets: walletsForUI,
            walletConnectQRCodeUri: walletConnectQRCodeUri,
            currentWallet: walletToShow,
            isConnecting: walletToShow?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connecting,
            isConnected: walletToShow?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected,
            isRejected: walletToShow?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Rejected,
            isDisconnected: walletToShow?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
            isNotExist: walletToShow?.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist,
            errorMessage: errorMessage,
            onSelectWallet: (w)=>onSelectWallet(w),
            onBack: ()=>setShouldShowList(true),
            onReconnect: ()=>onSelectWallet(walletToShow),
            getDownloadLink: ()=>getDownloadLink(walletToShow?.info.name),
            getEnv: getEnv,
            modalContainerClassName: modalContainerClassName,
            modalContentClassName: modalContentClassName,
            modalChildrenClassName: modalChildrenClassName,
            modalContentStyles: modalContentStyles,
            modalThemeProviderProps: modalThemeProviderProps
        })
    });
};
_s(InterchainWalletModal, "E6FZHxOTbGFMGHJEcklvhPFkYNM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"]
    ];
});
_c = InterchainWalletModal;
const WalletModalElement = ({ shouldShowList, isOpen, walletConnectQRCodeUri, wallets, username, address, currentWallet, isConnecting, isConnected, isRejected, isDisconnected, isNotExist, errorMessage, open, close, disconnect, onSelectWallet, onBack, onReconnect, getDownloadLink, getEnv, modalThemeProviderProps, modalContainerClassName, modalContentClassName, modalChildrenClassName, modalContentStyles })=>{
    _s1();
    const { header, content } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WalletModalElement.useMemo": ()=>{
            if (shouldShowList || isDisconnected && currentWallet.errorMessage === "") {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletListHeader"], {
                        close: close
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletListContent"], {
                        onSelectWallet: onSelectWallet,
                        wallets: wallets
                    })
                };
            }
            if (currentWallet && walletConnectQRCodeUri && currentWallet.info.name === "WalletConnect") {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$QRCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QRCodeHeader"], {
                        wallet: currentWallet,
                        close: close,
                        onBack: onBack
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$QRCode$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QRCodeContent"], {
                        walletConnectQRCodeUri: walletConnectQRCodeUri,
                        errorMessage: errorMessage,
                        onReconnect: onReconnect
                    })
                };
            }
            if (currentWallet && isNotExist) {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$NotExist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotExistHeader"], {
                        wallet: currentWallet,
                        close: close,
                        onBack: onBack
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$NotExist$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NotExistContent"], {
                        wallet: currentWallet,
                        getDownloadLink: getDownloadLink,
                        getEnv: getEnv
                    })
                };
            }
            if (currentWallet && isRejected) {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Reject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RejectHeader"], {
                        wallet: currentWallet,
                        close: close,
                        onBack: onBack
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Reject$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RejectContent"], {
                        wallet: currentWallet,
                        onReconnect: onReconnect
                    })
                };
            }
            if (currentWallet && currentWallet.errorMessage) {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorHeader"], {
                        wallet: currentWallet,
                        close: close,
                        onBack: onBack
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Error$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ErrorContent"], {
                        wallet: currentWallet,
                        onBack: onBack
                    })
                };
            }
            if (currentWallet && isConnected) {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connected$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectedHeader"], {
                        wallet: currentWallet,
                        onBack: onBack,
                        close: close
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connected$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectedContent"], {
                        wallet: currentWallet,
                        username: username,
                        address: address,
                        disconnect: disconnect
                    })
                };
            }
            if (currentWallet && isConnecting) {
                return {
                    header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connecting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectingHeader"], {
                        wallet: currentWallet,
                        close: close,
                        onBack: onBack
                    }),
                    content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$Connecting$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectingContent"], {
                        wallet: currentWallet
                    })
                };
            }
            return {
                header: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletListHeader"], {
                    close: close
                }),
                content: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$views$2f$WalletList$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletListContent"], {
                    onSelectWallet: onSelectWallet,
                    wallets: wallets
                })
            };
        }
    }["WalletModalElement.useMemo"], [
        currentWallet?.info?.name,
        isConnected,
        isConnecting,
        address,
        shouldShowList,
        walletConnectQRCodeUri,
        wallets,
        isOpen
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$interchain$2d$ui$2f$react$2f$dist$2f$interchain$2d$ui$2d$kit$2d$react$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConnectModal"], {
        isOpen: isOpen,
        header: header,
        onOpen: open,
        onClose: close,
        modalContainerClassName: modalContainerClassName,
        modalContentClassName: modalContentClassName,
        modalChildrenClassName: modalChildrenClassName,
        modalContentStyles: modalContentStyles,
        children: content
    });
};
_s1(WalletModalElement, "HhDDI6MHcXOXw0QMpAfT6r5aq40=");
_c1 = WalletModalElement;
const ModalRenderer = ({ walletModal: ProvidedWalletModal })=>{
    _s2();
    if (!ProvidedWalletModal) {
        return null;
    }
    const { modalIsOpen, openModal, closeModal, wallets, currentWalletName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(ProvidedWalletModal, {
        wallets: wallets,
        isOpen: modalIsOpen,
        open: openModal,
        close: closeModal,
        currentWallet: wallets.find((w)=>w.info.name === currentWalletName)
    });
};
_s2(ModalRenderer, "uqTBaejYfvbNxJjOyu0oCNZakZM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$useWalletManager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletManager"]
    ];
});
_c2 = ModalRenderer;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "InterchainWalletModal");
__turbopack_context__.k.register(_c1, "WalletModalElement");
__turbopack_context__.k.register(_c2, "ModalRenderer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/modal.js [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/modal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/store/chain-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ChainWallet": (()=>ChainWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
;
class ChainWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    getProvider(chainId) {
        return this.originalWallet.getProvider(chainId);
    }
    originalWallet;
    connectWithState;
    disconnectWithState;
    getAccountWithState;
    constructor(originalWallet, connectWithState, disconnectWithState, getAccountWithState){
        super(originalWallet?.info);
        this.originalWallet = originalWallet;
        this.connectWithState = connectWithState;
        this.disconnectWithState = disconnectWithState;
        this.getAccountWithState = getAccountWithState;
    }
    async init(meta) {
        return this.originalWallet.init();
    }
    async connect(chainId) {
        return this.connectWithState(chainId);
    }
    async disconnect(chainId) {
        return this.disconnectWithState(chainId);
    }
    async getAccount(chainId) {
        return this.getAccountWithState(chainId);
    }
    async getOfflineSigner(chainId) {
        return this.originalWallet.getOfflineSigner(chainId);
    }
    async addSuggestChain(chainId) {
        return this.originalWallet.addSuggestChain(chainId);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/store/stateful-wallet.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "StatefulWallet": (()=>StatefulWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/base-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$ethereum$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/ethereum-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/multichain-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/wc-wallet.js [app-client] (ecmascript)");
;
class StatefulWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$base$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BaseWallet"] {
    originalWallet;
    walletName;
    get;
    constructor(wallet, get){
        super(wallet.info);
        this.originalWallet = wallet;
        this.walletName = wallet.info.name;
        this.get = get;
    }
    get store() {
        return this.get();
    }
    get walletState() {
        // 獲取此錢包在所有鏈上的狀態
        const states = (this.store.chainWalletState || []).filter((cws)=>cws.walletName === this.walletName).map((cws)=>cws.walletState);
        // If any chain is in the connected state, return connected
        if (states.includes(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected;
        }
        // 如果有任何一個鏈正在連接中，則返回連接中
        if (states.includes(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connecting)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connecting;
        }
        // 如果所有鏈都是不存在狀態，則返回不存在
        if (states.length > 0 && states.every((state)=>state === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist;
        }
        // 如果有任何一個鏈是被拒絕狀態，則返回被拒絕
        if (states.includes(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Rejected)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Rejected;
        }
        // 預設返回未連接
        return __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected;
    }
    get errorMessage() {
        // 獲取此錢包在所有鏈上的錯誤訊息
        const errors = (this.store.chainWalletState || []).filter((cws)=>cws.walletName === this.walletName).map((cws)=>cws.errorMessage).filter((error)=>error && error.trim() !== '');
        // 返回第一個非空錯誤訊息，如果沒有則返回空字串
        return errors.length > 0 ? errors[0] : '';
    }
    async init() {
        try {
            await this.originalWallet.init();
            this.store.chains.forEach((chain)=>{
                const lastChainWalletState = this.store.getChainWalletState(this.walletName, chain.chainName)?.walletState;
                if (lastChainWalletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist) {
                    this.store.updateChainWalletState(this.walletName, chain.chainName, {
                        walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
                        errorMessage: ''
                    });
                }
            });
        } catch (error) {
            if (error === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"]) {
                this.store.chains.forEach((chain)=>{
                    this.store.updateChainWalletState(this.walletName, chain.chainName, {
                        walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist,
                        errorMessage: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"].message
                    });
                });
            }
        }
    }
    async connect(chainId) {
        const { store, walletName, originalWallet } = this;
        const chainToConnect = this.getChainById(chainId);
        const state = store.getChainWalletState(walletName, chainToConnect.chainName)?.walletState;
        if (state === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].NotExist) {
            return;
        }
        if (walletName === 'WalletConnect' && state === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected) {
            return;
        }
        store.setCurrentChainName(chainToConnect.chainName);
        store.setCurrentWalletName(walletName);
        store.setWalletConnectQRCodeUri('');
        store.updateChainWalletState(walletName, chainToConnect.chainName, {
            walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connecting,
            errorMessage: ''
        });
        try {
            if (originalWallet instanceof __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WCWallet"]) {
                originalWallet.setOnPairingUriCreatedCallback((uri)=>{
                    store.setWalletConnectQRCodeUri(uri);
                });
            }
            await originalWallet.connect(chainToConnect.chainId);
            store.updateChainWalletState(walletName, chainToConnect.chainName, {
                walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected
            });
            await this.getAccount(chainToConnect.chainId);
        } catch (error) {
            if (error.message.includes('rejected')) {
                store.updateChainWalletState(walletName, chainToConnect.chainName, {
                    walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Rejected,
                    errorMessage: error.message
                });
                return;
            } else {
                store.updateChainWalletState(walletName, chainToConnect.chainName, {
                    walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
                    errorMessage: error.message
                });
            }
        }
    }
    async disconnect(chainId) {
        const { store, walletName, originalWallet } = this;
        const chainToConnect = this.getChainById(chainId);
        try {
            if (this.walletState === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Connected) {
                await originalWallet.disconnect(chainToConnect.chainId);
            }
            store.updateChainWalletState(walletName, chainToConnect.chainName, {
                walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
                account: null
            });
        } catch (error) {}
    }
    async getAccount(chainId) {
        const chainToConnect = this.getChainById(chainId);
        const { store, walletName, originalWallet } = this;
        try {
            const account = await originalWallet.getAccount(chainToConnect.chainId);
            store.updateChainWalletState(walletName, chainToConnect.chainName, {
                account
            });
            if (this.originalWallet instanceof __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$wc$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WCWallet"]) {
                this.originalWallet.setAccountToRestore(account);
            }
            return account;
        } catch (error) {
            console.log(error);
        }
    }
    getOfflineSigner(chainId) {
        return this.originalWallet.getOfflineSigner(chainId);
    }
    addSuggestChain(chainId) {
        return this.originalWallet.addSuggestChain(chainId);
    }
    getProvider(chainId) {
        return this.originalWallet.getProvider(chainId);
    }
    getChainById(chainId) {
        return this.originalWallet.getChainById(chainId);
    }
    getWalletOfType(WalletClass) {
        if (this.originalWallet instanceof WalletClass) {
            return this.originalWallet;
        }
        if (this.originalWallet instanceof __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$multichain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MultiChainWallet"]) {
            if (WalletClass === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CosmosWallet"]) {
                const cosmosWallet = this.originalWallet.getWalletByChainType('cosmos');
                if (cosmosWallet) {
                    return cosmosWallet;
                }
            }
            if (WalletClass === __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$ethereum$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EthereumWallet"]) {
                const ethereumWallet = this.originalWallet.getWalletByChainType('eip155');
                if (ethereumWallet) {
                    return ethereumWallet;
                }
            }
        }
        return undefined;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/store/store.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createInterchainStore": (()=>createInterchainStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/types/wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$dedupeAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/dedupeAsync.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$restoreAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/utils/restoreAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$stateful$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/stateful-wallet.js [app-client] (ecmascript)");
;
;
;
;
;
;
const immerSyncUp = (newWalletManager)=>{
    return (draft)=>{
        draft.chains = newWalletManager.chains;
        draft.assetLists = newWalletManager.assetLists;
        draft.wallets = newWalletManager.wallets;
        draft.signerOptions = newWalletManager.signerOptions;
        draft.endpointOptions = newWalletManager.endpointOptions;
        draft.signerOptionMap = newWalletManager.signerOptionMap;
        draft.endpointOptionsMap = newWalletManager.endpointOptionsMap;
        draft.preferredSignTypeMap = newWalletManager.preferredSignTypeMap;
    };
};
const createInterchainStore = (walletManager)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((set, get)=>({
            chainWalletState: [],
            currentWalletName: '',
            currentChainName: '',
            chains: [
                ...walletManager.chains
            ],
            assetLists: [
                ...walletManager.assetLists
            ],
            wallets: walletManager.wallets.map((wallet)=>new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$stateful$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StatefulWallet"](wallet, get)),
            signerOptions: walletManager.signerOptions,
            endpointOptions: walletManager.endpointOptions,
            preferredSignTypeMap: {
                ...walletManager.preferredSignTypeMap
            },
            signerOptionMap: {
                ...walletManager.signerOptionMap
            },
            endpointOptionsMap: {
                ...walletManager.endpointOptionsMap
            },
            walletConnectQRCodeUri: '',
            isReady: false,
            modalIsOpen: false,
            openModal: ()=>{
                set((draft)=>{
                    draft.modalIsOpen = true;
                });
            },
            closeModal: ()=>{
                set((draft)=>{
                    draft.modalIsOpen = false;
                    draft.walletConnectQRCodeUri = ''; // reset the QR code uri when modal is closed
                });
            },
            updateChainWalletState: (walletName, chainName, data)=>{
                set((draft)=>{
                    let targetIndex = draft.chainWalletState.findIndex((cws)=>cws.walletName === walletName && cws.chainName === chainName);
                    draft.chainWalletState[targetIndex] = {
                        ...draft.chainWalletState[targetIndex],
                        ...data
                    };
                });
            },
            init: async ()=>{
                const oldChainWalletStatesMap = new Map(get().chainWalletState.map((cws)=>[
                        cws.walletName + cws.chainName,
                        cws
                    ]));
                // get().createStatefulWallet()
                // should remove wallet that already disconnected ,for hydrain back from localstorage
                // const oldChainWalletStateMap = new Map()
                // get().chainWalletState.forEach(cws => {
                //   if(cws.walletState === WalletState.Connected) {
                //     oldChainWalletStateMap.set(cws.walletName + cws.chainName, cws)
                //   }
                // })
                get().wallets.forEach((wallet)=>{
                    get().chains.forEach((chain)=>{
                        set((draft)=>{
                            if (!oldChainWalletStatesMap.has(wallet.info.name + chain.chainName)) {
                                draft.chainWalletState.push({
                                    chainName: chain.chainName,
                                    walletName: wallet.info.name,
                                    walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
                                    rpcEndpoint: "",
                                    errorMessage: "",
                                    account: undefined
                                });
                            }
                        });
                    });
                });
                await Promise.all(get().wallets.map(async (wallet)=>wallet.init()));
                set((draft)=>{
                    draft.isReady = true;
                });
            },
            setCurrentChainName: (chainName)=>{
                set((draft)=>{
                    draft.currentChainName = chainName;
                });
            },
            setCurrentWalletName: (walletName)=>{
                set((draft)=>{
                    draft.currentWalletName = walletName;
                });
            },
            setWalletConnectQRCodeUri: (uri)=>{
                set((draft)=>{
                    draft.walletConnectQRCodeUri = uri;
                });
            },
            getDraftChainWalletState: (state, walletName, chainName)=>{
                const targetIndex = state.chainWalletState.findIndex((cws)=>cws.walletName === walletName && cws.chainName === chainName);
                return state.chainWalletState[targetIndex];
            },
            getChainWalletState: (walletName, chainName)=>{
                return get().chainWalletState.find((cws)=>cws.walletName === walletName && cws.chainName === chainName);
            },
            addChains: async (newChains, newAssetLists, newSignerOptions, newEndpointOptions)=>{
                await walletManager.addChains(newChains, newAssetLists, newSignerOptions, newEndpointOptions);
                // console.log(walletManager.chains, walletManager.assetLists)
                // set(immerSyncUp(walletManager))
                // set(draft => {
                //   draft.chains = walletManager.chains
                // })
                set((draft)=>{
                    const existedChainMap = new Map(get().chains.map((chain)=>[
                            chain.chainName,
                            chain
                        ]));
                    const newAssetListMap = new Map(newAssetLists.map((assetList)=>[
                            assetList.chainName,
                            assetList
                        ]));
                    newChains.forEach((newChain)=>{
                        if (!existedChainMap.has(newChain.chainName)) {
                            draft.chains.push(newChain);
                            draft.assetLists.push(newAssetListMap.get(newChain.chainName));
                        }
                        draft.signerOptionMap[newChain.chainName] = newSignerOptions?.signing(newChain.chainName);
                        draft.endpointOptionsMap[newChain.chainName] = newEndpointOptions?.endpoints?.[newChain.chainName];
                    });
                    get().chains.forEach((chain)=>{
                        draft.signerOptionMap[chain.chainName] = {
                            ...get().signerOptionMap[chain.chainName],
                            ...newSignerOptions?.signing(chain.chainName)
                        };
                        draft.endpointOptionsMap[chain.chainName] = {
                            ...get().endpointOptionsMap[chain.chainName],
                            ...newEndpointOptions?.endpoints?.[chain.chainName]
                        };
                    });
                    const existedChainWalletStatesMap = new Map(get().chainWalletState.map((cws)=>[
                            cws.walletName + cws.chainName,
                            cws
                        ]));
                    get().wallets.forEach((wallet)=>{
                        newChains.forEach((newChain)=>{
                            if (!existedChainWalletStatesMap.has(wallet.info.name + newChain.chainName)) {
                                draft.chainWalletState.push({
                                    chainName: newChain.chainName,
                                    walletName: wallet.info.name,
                                    walletState: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$types$2f$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletState"].Disconnected,
                                    rpcEndpoint: "",
                                    errorMessage: "",
                                    account: undefined
                                });
                            }
                        });
                    });
                    draft.chainWalletState = draft.chainWalletState.map((cws)=>{
                        return {
                            ...cws,
                            rpcEndpoint: newEndpointOptions?.endpoints?.[cws.chainName]?.rpc?.[0] || cws.rpcEndpoint
                        };
                    });
                });
            },
            connect: async (walletName, chainName)=>{
                const wallet = get().wallets.find((w)=>w.info.name === walletName);
                const chain = get().chains.find((c)=>c.chainName === chainName);
                if (!wallet) {
                    throw new Error(`Wallet ${walletName} not found`);
                }
                if (!chain) {
                    throw new Error(`Chain ${chainName} not found`);
                }
                return wallet.connect(chain.chainId);
            },
            disconnect: async (walletName, chainName)=>{
                const wallet = get().wallets.find((w)=>w.info.name === walletName);
                const chain = get().chains.find((c)=>c.chainName === chainName);
                if (!wallet) {
                    throw new Error(`Wallet ${walletName} not found`);
                }
                if (!chain) {
                    throw new Error(`Chain ${chainName} not found`);
                }
                return wallet.disconnect(chain.chainId);
            },
            getAccount: async (walletName, chainName)=>{
                const wallet = get().wallets.find((w)=>w.info.name === walletName);
                const chain = get().chains.find((c)=>c.chainName === chainName);
                if (!wallet) {
                    throw new Error(`Wallet ${walletName} not found`);
                }
                if (!chain) {
                    throw new Error(`Chain ${chainName} not found`);
                }
                const existedAccount = get().chainWalletState.find((cws)=>cws.walletName === walletName && cws.chainName === chainName)?.account;
                if (existedAccount) {
                    return existedAccount;
                }
                return wallet.getAccount(chain.chainId);
            },
            getRpcEndpoint: async (walletName, chainName)=>{
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$dedupeAsync$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dedupeAsync"])(`${chainName}-rpcEndpoint`, async ()=>{
                    const rpcEndpoint = await walletManager.getRpcEndpoint(walletName, chainName);
                    get().wallets.map((wallet)=>{
                        get().updateChainWalletState(wallet.info.name, chainName, {
                            rpcEndpoint
                        });
                    });
                    return rpcEndpoint;
                });
            },
            getChainLogoUrl (chainName) {
                return walletManager.getChainLogoUrl(chainName);
            },
            getChainByName (chainName) {
                return walletManager.getChainByName(chainName);
            },
            getAssetListByName (chainName) {
                return walletManager.getAssetListByName(chainName);
            },
            getDownloadLink (walletName) {
                return walletManager.getDownloadLink(walletName);
            },
            async getOfflineSigner (walletName, chainName) {
                return walletManager.getOfflineSigner(walletName, chainName);
            },
            getPreferSignType (chainName) {
                const result = walletManager.getPreferSignType(chainName);
                // set(immerSyncUp(walletManager))
                return result;
            },
            getSignerOptions (chainName) {
                const result = walletManager.getSignerOptions(chainName);
                // set(immerSyncUp(walletManager))
                return result;
            },
            getWalletByName (walletName) {
                return walletManager.getWalletByName(walletName);
            },
            getStatefulWalletByName (walletName) {
                return get().wallets.find((w)=>w.info.name === walletName);
            },
            async getSigningClient (walletName, chainName) {
                return walletManager.getSigningClient(walletName, chainName);
            },
            getEnv () {
                return walletManager.getEnv();
            }
        })), {
        name: 'interchain-kit-store',
        storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
        partialize: (state)=>({
                chainWalletState: state.chainWalletState.map((cws)=>({
                        chainName: cws.chainName,
                        walletName: cws.walletName,
                        account: cws.account,
                        walletState: cws.walletState
                    })),
                currentWalletName: state.currentWalletName,
                currentChainName: state.currentChainName
            }),
        onRehydrateStorage: (state)=>{
            // console.log('interchain-kit store hydration starts')
            // optional
            return (state, error)=>{
                if (error) {
                    console.log('an error happened during hydration', error);
                } else {
                    // console.log('interchain-kit store hydration finished')
                    state.chainWalletState = state.chainWalletState.map((cws)=>{
                        return {
                            ...cws,
                            account: cws.account ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$utils$2f$restoreAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["restoreAccountFromLocalStorage"])(cws.account) : null
                        };
                    });
                }
            };
        }
    }));
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$chain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/chain-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/store.js [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$chain$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/chain-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/store.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/provider.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ChainProvider": (()=>ChainProvider),
    "useInterchainWalletContext": (()=>useInterchainWalletContext)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallet$2d$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallet-manager.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/modal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/store.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
const InterchainWalletContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
const ChainProvider = ({ chains, assetLists, wallets, signerOptions, endpointOptions, children, walletModal: ProviderWalletModal })=>{
    _s();
    // const [_, forceRender] = useState({});
    const walletManager = new __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallet$2d$manager$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WalletManager"](chains, assetLists, wallets, signerOptions, endpointOptions);
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$store$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createInterchainStore"])(walletManager));
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChainProvider.useEffect": ()=>{
            // walletManager.init();
            store.current.getState().init();
        }
    }["ChainProvider.useEffect"], []);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(InterchainWalletContext.Provider, {
        value: store.current,
        children: [
            children,
            ProviderWalletModal && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ModalRenderer"], {
                walletModal: ProviderWalletModal
            })
        ]
    });
};
_s(ChainProvider, "qEa1HLsDxl5wLXqiMh74enKQcq0=");
_c = ChainProvider;
const useInterchainWalletContext = ()=>{
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(InterchainWalletContext);
    if (!context) {
        throw new Error("useInterChainWalletContext must be used within a InterChainProvider");
    }
    return context;
};
_s1(useInterchainWalletContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "ChainProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/types/sign-client.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/types/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$types$2f$sign$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/types/sign-client.js [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$types$2f$sign$2d$client$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/types/sign-client.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/types/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/enum/connection.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "ConnectState": (()=>ConnectState)
});
var ConnectState;
(function(ConnectState) {
    ConnectState["CONNECTING"] = "connecting";
    ConnectState["CONNECTED"] = "connected";
    ConnectState["DISCONNECTED"] = "disconnected";
})(ConnectState || (ConnectState = {}));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/enum/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$enum$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/enum/connection.js [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/enum/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$enum$2f$connection$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/enum/connection.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$enum$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/enum/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$enum$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/enum/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <module evaluation>");
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$hooks$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/hooks/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/types/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$enum$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/enum/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$store$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/store/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/examples/e2e/src/starship/config.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Config": (()=>Config),
    "ConfigContext": (()=>ConfigContext)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/hook.ts [app-client] (ecmascript)");
;
class Config {
    // keep instantiation private to enforce singletone
    constructor(){}
    registry;
    configFile;
    isConfigInitialized = false;
    isRegistryInitialized = false;
    static instance;
    setConfigFile(configFile) {
        this.configFile = configFile;
        this.isConfigInitialized = true;
    }
    setRegistry(registry) {
        this.registry = registry;
        this.isRegistryInitialized = true;
    }
    get isInitialized() {
        return this.isConfigInitialized && this.isRegistryInitialized;
    }
    // init config with a config file and an optional registry fetcher
    // if no registry fetcher is provided, it will use the default registry fetcher
    // by enforcing the use of the init method, we can ensure that the config is initialized
    static async init(configFile, registryFetcher) {
        if (Config.instance && Config.instance.isInitialized) {
            throw new Error('Config is already initialized.');
        }
        const fetcher = registryFetcher ?? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRegistry"])(configFile);
        Config.instance = new Config();
        Config.instance.setConfigFile(configFile);
        Config.instance.setRegistry(fetcher);
    }
    static getInstance() {
        if (!Config.instance || !Config.instance.isInitialized) {
            throw new Error("Config's not initialized.");
        }
        return Config.instance;
    }
    /**
     * set the config file path
     * @param configFile
     * @depracated it's not recommended to set the configFile directly. Use init instead.
     */ static setConfigFile(configFile) {
        if (!Config.instance) {
            Config.instance = new Config();
        }
        Config.instance.setConfigFile(configFile);
    }
    /**
     * set the chain registry fetcher
     * @param registry
     * @depracated it's not recommended to set the registry directly. Use init instead.
     */ static setRegistry(registry) {
        if (!Config.instance) {
            Config.instance = new Config();
        }
        Config.instance.setRegistry(registry);
    }
    static get configFile() {
        // use getInstance to ensure that the config is initialized.
        return Config.getInstance().configFile;
    }
    static get registry() {
        // use getInstance to ensure that the config is initialized.
        return Config.getInstance().registry;
    }
}
const ConfigContext = Config;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/starship/starship-config.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "starshipConfig": (()=>starshipConfig)
});
const starshipConfig = {
    "name": "interchain-kit-e2e",
    "version": "1.7.0",
    "chains": [
        {
            "id": "osmosis-1",
            "name": "osmosis",
            "numValidators": 1,
            "ports": {
                "rest": 1313,
                "rpc": 26653,
                "faucet": 9090
            }
        },
        {
            "id": "juno-1",
            "name": "juno",
            "numValidators": 1,
            "ports": {
                "rest": 1315,
                "rpc": 26655,
                "faucet": 9092
            }
        },
        {
            "id": "cosmoshub-1",
            "name": "cosmoshub",
            "numValidators": 1,
            "ports": {
                "rest": 1317,
                "rpc": 26657,
                "faucet": 9094
            }
        }
    ],
    "relayers": [
        {
            "name": "osmos-juno",
            "type": "hermes",
            "replicas": 1,
            "chains": [
                "osmosis-1",
                "juno-1"
            ]
        },
        {
            "name": "osmos-cosmos",
            "type": "hermes",
            "replicas": 1,
            "chains": [
                "osmosis-1",
                "cosmoshub-1"
            ]
        }
    ],
    "explorer": {
        "enabled": true,
        "ports": {
            "rest": 8080
        }
    },
    "registry": {
        "enabled": true,
        "ports": {
            "rest": 8081,
            "grpc": 9091
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/starship/hook.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useChain": (()=>useChain),
    "useRegistry": (()=>useRegistry)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$client$2f$main$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/client/main/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$starship$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/starship-config.ts [app-client] (ecmascript)");
;
;
;
const useRegistry = async (configFile)=>{
    const config = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$starship$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["starshipConfig"];
    const registryUrl = `http://localhost:${config.registry.ports.rest}`;
    const urls = [];
    config.chains?.forEach((chain)=>{
        urls.push(`${registryUrl}/chains/${chain.id}`, `${registryUrl}/chains/${chain.id}/assets`);
    });
    config.relayers?.forEach((relayer)=>{
        urls.push(`${registryUrl}/ibc/${relayer.chains[0]}/${relayer.chains[1]}`, `${registryUrl}/ibc/${relayer.chains[1]}/${relayer.chains[0]}`);
    });
    const options = {
        urls
    };
    const registry = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$client$2f$main$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainRegistryFetcher"](options);
    await registry.fetchUrls();
    return registry;
};
const useChain = (chainName)=>{
    const registry = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConfigContext"].registry;
    const configFile = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConfigContext"].configFile;
    const config = __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$starship$2d$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["starshipConfig"];
    const chain = registry.getChain(chainName);
    const chainInfo = registry.getChainInfo(chainName);
    const chainID = chainInfo.chain.chain_id;
    const getRpcEndpoint = async ()=>{
        return `http://localhost:${config.chains.find((chain)=>chain.id === chainID).ports.rpc}`;
    };
    const getRestEndpoint = async ()=>{
        return `http://localhost:${config.chains.find((chain)=>chain.id === chainID).ports.rest}`;
    };
    const getGenesisMnemonic = async ()=>{
        const url = `http://localhost:${config.registry.ports.rest}/chains/${chainID}/keys`;
        const response = await fetch(url, {});
        const data = await response.json();
        return data['genesis'][0]['mnemonic'];
    };
    const getCoin = async ()=>{
        return chainInfo.fetcher.getChainAssetList(chainName).assets[0];
    };
    const creditFromFaucet = async (address, denom = null)=>{
        const faucetEndpoint = `http://localhost:${config.chains.find((chain)=>chain.id === chainID).ports.faucet}/credit`;
        if (!denom) {
            denom = (await getCoin()).base;
        }
        await fetch(faucetEndpoint, {
            method: 'POST',
            body: JSON.stringify({
                address,
                denom
            }),
            headers: {
                'Content-type': 'application/json'
            }
        });
    };
    return {
        chain,
        chainInfo,
        getCoin,
        getRpcEndpoint,
        getRestEndpoint,
        getGenesisMnemonic,
        creditFromFaucet
    };
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/wallet/mock-cosmos-wallet.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "MockCosmosWallet": (()=>MockCosmosWallet),
    "MockMultiChainWallet": (()=>MockMultiChainWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/cosmos-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$extension$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/wallets/extension-wallet.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2f$wallets$2f$secp256k1hd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos/wallets/secp256k1hd.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)");
;
;
;
class MockMultiChainWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$extension$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExtensionWallet"] {
    async init() {
        await Promise.resolve();
    }
}
class MockCosmosWallet extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$wallets$2f$cosmos$2d$wallet$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CosmosWallet"] {
    directWalletMap = {};
    cosmosHdPath = "m/44'/118'/0'/0/0";
    mnemonic;
    constructor(info, mnemonic){
        super(info);
        this.mnemonic = mnemonic;
    }
    async init() {
        return super.init();
    }
    async connect(chainId) {
        if (this.client) {
            return super.connect(chainId);
        }
        const chain = this.getChainById(chainId);
        //create mock address base on chainId
        const wallet = await __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2f$wallets$2f$secp256k1hd$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Secp256k1HDWallet"].fromMnemonic(this.mnemonic, [
            {
                hdPath: this.cosmosHdPath,
                prefix: chain.bech32Prefix || 'cosmos'
            }
        ]);
        this.directWalletMap[chain.chainName] = wallet;
    }
    async disconnect(chainId) {}
    async signDirect(chainId, signer, signDoc, signOptions) {
        const chain = this.getChainById(chainId);
        const wallet = this.directWalletMap[chain.chainName];
        if (!wallet) {
            throw new Error(`Wallet not connected for chain: ${chainId}`);
        }
        const accounts = await wallet.getAccounts();
        const account = accounts.find((acc)=>acc.address === signer);
        if (!account) {
            throw new Error(`Signer address not found in wallet for chain: ${chainId}`);
        }
        return wallet.signDirect(signer, signDoc);
    }
    async getAccount(chainId) {
        if (this.client) {
            return super.getAccount(chainId);
        }
        const chain = this.getChainById(chainId);
        const wallet = this.directWalletMap[chain.chainName];
        if (!wallet) {
            throw new Error(`Wallet not connected for chain: ${chainId}`);
        }
        const accounts = await wallet.getAccounts();
        return {
            address: accounts[0].address,
            algo: 'secp256k1',
            pubkey: accounts[0].pubkey,
            username: undefined,
            isNanoLedger: false,
            isSmartContract: false
        };
    }
    async getOfflineSigner(chainId, preferredSignType) {
        const chain = this.getChainById(chainId);
        const wallet = this.directWalletMap[chain.chainName];
        if (!wallet) {
            throw new Error(`Wallet not connected for chain: ${chainId}`);
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$cosmos$2f$types$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DirectGenericOfflineSigner"]({
            getAccounts: async ()=>[
                    await this.getAccount(chainId)
                ],
            signDirect: async (signer, signDoc)=>{
                return wallet.signDirect(signer, signDoc);
            }
        });
    }
    addSuggestChain(chainId) {
        throw new Error('Method not implemented.');
    }
    getProvider(chainId) {
        throw new Error('Method not implemented.');
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/wallet/index.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "NotInstalledWallet": (()=>NotInstalledWallet),
    "mockWallet1": (()=>mockWallet1),
    "mockWallet2": (()=>mockWallet2),
    "notInstalledWallet": (()=>notInstalledWallet),
    "receiverWallet": (()=>receiverWallet),
    "senderWallet": (()=>senderWallet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$bip39$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/bip39.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/node_modules/@interchainjs/crypto/esm/random.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/wallet/mock-cosmos-wallet.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/core/dist/esm/utils/errors.js [app-client] (ecmascript)");
;
;
;
const mockWallet1Info = {
    windowKey: "mock1",
    cosmosKey: "mockcosmos1",
    name: "mockWallet1",
    prettyName: "Mock Cosmos Wallet 1",
    mode: "extension",
    downloads: [
        {
            device: 'desktop',
            browser: 'chrome',
            link: 'https://chrome.google.com/webstore/detail/keplr/dmkamcknogkgcdfhhbddcghachkejeap?hl=en'
        },
        {
            device: 'desktop',
            browser: 'firefox',
            link: 'https://addons.mozilla.org/en-US/firefox/addon/keplr/'
        },
        {
            link: 'https://www.keplr.app/download'
        }
    ]
};
const mockCosmosWallet1 = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockCosmosWallet"](mockWallet1Info, "mock1 mock1 mock1 mock1 mock1 mock1 mock1 mock1 mock1 mock1 mock1 mock1");
const mockWallet1 = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockMultiChainWallet"](mockWallet1Info);
mockWallet1.setNetworkWallet('cosmos', mockCosmosWallet1);
const mockWallet2Info = {
    windowKey: "mock2",
    cosmosKey: "mockcosmos2",
    name: "mockWallet2",
    prettyName: "Mock Cosmos Wallet 2",
    mode: "extension"
};
const mockCosmosWallet2 = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockCosmosWallet"](mockWallet2Info, "mock2 mock2 mock2 mock2 mock2 mock2 mock2 mock2 mock2 mock2 mock2 mock2");
const mockWallet2 = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockMultiChainWallet"](mockWallet2Info);
mockWallet2.setNetworkWallet('cosmos', mockCosmosWallet2);
const sendWalletInfo = {
    windowKey: "sender",
    cosmosKey: "sendercosmos",
    name: "senderWallet",
    prettyName: "Sender Wallet",
    mode: "extension"
};
const senderCosmosWallet = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockCosmosWallet"](sendWalletInfo, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$bip39$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bip39"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Random"].getBytes(16)).toString());
const senderWallet = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockMultiChainWallet"](sendWalletInfo);
senderWallet.setNetworkWallet('cosmos', senderCosmosWallet);
const receiverWalletInfo = {
    windowKey: "receiver",
    cosmosKey: "receivercosmos",
    name: "receiverWallet",
    prettyName: "Receiver Wallet",
    mode: "extension"
};
const receiverCosmosWallet = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockCosmosWallet"](receiverWalletInfo, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$bip39$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Bip39"].encode(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$node_modules$2f40$interchainjs$2f$crypto$2f$esm$2f$random$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Random"].getBytes(16)).toString());
const receiverWallet = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockMultiChainWallet"](receiverWalletInfo);
receiverWallet.setNetworkWallet('cosmos', receiverCosmosWallet);
const NotInstalledWallet = {
    name: "notInstalledWallet",
    prettyName: "Not Installed Wallet",
    mode: "extension",
    downloads: [
        {
            device: 'desktop',
            browser: 'chrome',
            link: 'http://show-not-installed-wallet.link'
        }
    ]
};
const notInstalledWallet = new __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$mock$2d$cosmos$2d$wallet$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MockMultiChainWallet"](NotInstalledWallet);
notInstalledWallet.init = ()=>{
    throw __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$core$2f$dist$2f$esm$2f$utils$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clientNotExistError"];
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/context/InterchainKit.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "InterchainKit": (()=>InterchainKit)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/provider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/react/dist/esm/modal/modal.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$osmosis$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/chain-registry/mainnet/osmosis/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$cosmoshub$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/chain-registry/mainnet/cosmoshub/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/hook.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/wallet/index.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const InterchainKit = ({ children })=>{
    _s();
    const [isRpcReady, setRpcReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [endpoint, setEndpoint] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        osmosis: "",
        cosmoshub: "",
        juno: ""
    });
    const osmosis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"])("osmosis");
    const cosmoshub = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"])("cosmoshub");
    const juno = (0, __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"])("juno");
    const initStarship = async ()=>{
        await Promise.all([
            osmosis.getRpcEndpoint(),
            cosmoshub.getRpcEndpoint(),
            juno.getRpcEndpoint()
        ]).then((result)=>{
            setEndpoint({
                osmosis: result[0],
                cosmoshub: result[1],
                juno: result[2]
            });
        });
        setRpcReady(true);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InterchainKit.useEffect": ()=>{
            initStarship();
        }
    }["InterchainKit.useEffect"], []);
    if (!isRpcReady) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/examples/e2e/src/context/InterchainKit.tsx",
            lineNumber: 61,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$provider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChainProvider"], {
        chains: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$osmosis$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$cosmoshub$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chain"]
        ],
        assetLists: [
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$osmosis$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chain$2d$registry$2f$mainnet$2f$cosmoshub$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"]
        ],
        wallets: [
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockWallet1"],
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mockWallet2"],
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["senderWallet"],
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["receiverWallet"],
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$wallet$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notInstalledWallet"]
        ],
        walletModal: ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$react$2f$dist$2f$esm$2f$modal$2f$modal$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainWalletModal"], {}, void 0, false, {
                fileName: "[project]/examples/e2e/src/context/InterchainKit.tsx",
                lineNumber: 75,
                columnNumber: 26
            }, void 0),
        signerOptions: {
            signing: (chainName)=>{
                return {
                    broadcast: {
                        deliverTx: true
                    }
                };
            }
        },
        endpointOptions: {
            endpoints: {
                osmosis: {
                    rpc: [
                        endpoint.osmosis
                    ]
                },
                cosmoshub: {
                    rpc: [
                        endpoint.cosmoshub
                    ]
                },
                juno: {
                    rpc: [
                        endpoint.juno
                    ]
                }
            }
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/examples/e2e/src/context/InterchainKit.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
};
_s(InterchainKit, "VnXB5dWQnsrT9fbk7T1HNoYt/vg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"],
        __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChain"]
    ];
});
_c = InterchainKit;
var _c;
__turbopack_context__.k.register(_c, "InterchainKit");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/context/starship.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "Starship": (()=>Starship)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/starship/config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
const Starship = ({ children })=>{
    _s();
    const [isStarshipReady, setStarshipReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Starship.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$starship$2f$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConfigContext"].init("x").then({
                "Starship.useEffect": ()=>{
                    setStarshipReady(true);
                }
            }["Starship.useEffect"]);
        }
    }["Starship.useEffect"], []);
    if (!isStarshipReady) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/examples/e2e/src/context/starship.tsx",
            lineNumber: 14,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-screen",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 overflow-y-auto",
            children: children
        }, void 0, false, {
            fileName: "[project]/examples/e2e/src/context/starship.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/examples/e2e/src/context/starship.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
};
_s(Starship, "+Pazj2jGCKLDD8CbOqEL8MqP/yE=");
_c = Starship;
var _c;
__turbopack_context__.k.register(_c, "Starship");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/examples/e2e/src/app/layout.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>RootLayout)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$context$2f$InterchainKit$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/context/InterchainKit.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$context$2f$starship$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/examples/e2e/src/context/starship.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "en",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$context$2f$starship$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Starship"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$examples$2f$e2e$2f$src$2f$context$2f$InterchainKit$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InterchainKit"], {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/examples/e2e/src/app/layout.tsx",
                    lineNumber: 14,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/examples/e2e/src/app/layout.tsx",
                lineNumber: 13,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/examples/e2e/src/app/layout.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/examples/e2e/src/app/layout.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = RootLayout;
var _c;
__turbopack_context__.k.register(_c, "RootLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=_f6ba37a0._.js.map