(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/chain-registry/mainnet/cosmoshub/asset-list.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const info = {
    $schema: '../assetlist.schema.json',
    chainName: 'cosmoshub',
    assets: [
        {
            description: 'ATOM is the native cryptocurrency of the Cosmos network, designed to facilitate interoperability between multiple blockchains through its innovative hub-and-spoke model.',
            extendedDescription: 'ATOM, the native cryptocurrency of the Cosmos network, is essential for achieving the project\'s goal of creating an \'Internet of Blockchains.\' Launched in 2019, Cosmos aims to solve the scalability, usability, and interoperability issues prevalent in existing blockchain ecosystems. The Cosmos Hub, the central blockchain of the network, uses ATOM for transaction fees, staking, and governance. By staking ATOM, users can earn rewards and participate in governance, influencing decisions on network upgrades and changes.\n\nCosmos leverages the Tendermint consensus algorithm to achieve high transaction throughput and fast finality. Its Inter-Blockchain Communication (IBC) protocol enables seamless data and value transfer between different blockchains, fostering a highly interconnected and collaborative ecosystem. The flexibility and scalability offered by Cosmos have attracted numerous projects, enhancing its utility and adoption. ATOM\'s role in securing the network and facilitating governance underscores its importance in the broader blockchain landscape.',
            denomUnits: [
                {
                    denom: 'uatom',
                    exponent: 0
                },
                {
                    denom: 'atom',
                    exponent: 6
                }
            ],
            base: 'uatom',
            name: 'Cosmos Hub Atom',
            display: 'atom',
            symbol: 'ATOM',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg'
            },
            coingeckoId: 'cosmos',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg',
                    theme: {
                        primaryColorHex: '#272d45'
                    }
                }
            ],
            socials: {
                website: 'https://cosmos.network',
                twitter: 'https://twitter.com/cosmoshub'
            },
            typeAsset: 'sdk.coin'
        },
        {
            description: 'Tether USDt on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/F04D72CF9B5D9C849BB278B691CDFA2241813327430EC9CDC83F8F4CA4CDC2B0',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/F04D72CF9B5D9C849BB278B691CDFA2241813327430EC9CDC83F8F4CA4CDC2B0',
            name: 'Tether USDt',
            display: 'usdt',
            symbol: 'USDt',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'kava',
                        baseDenom: 'erc20/tether/usdt',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: 'channel-277',
                        path: 'transfer/channel-277/erc20/tether/usdt'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'kava',
                        baseDenom: 'erc20/tether/usdt'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            },
            coingeckoId: 'tether'
        },
        {
            description: 'FX on Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/4925E6ABA571A44D2BE0286D2D29AF42A294D0FF2BB16490149A1B26EAD33729',
                    exponent: 0,
                    aliases: [
                        'FX'
                    ]
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/4925E6ABA571A44D2BE0286D2D29AF42A294D0FF2BB16490149A1B26EAD33729',
            name: 'Function X',
            display: 'FX',
            symbol: 'FX',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'fxcore',
                        baseDenom: 'FX',
                        channelId: 'channel-10'
                    },
                    chain: {
                        channelId: 'channel-585',
                        path: 'transfer/channel-585/FX'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'fxcore',
                        baseDenom: 'FX'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/fxcore/images/fx.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/fxcore/images/fx.svg',
                    theme: {
                        primaryColorHex: '#1c1c1c'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/fxcore/images/fx.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/fxcore/images/fx.svg'
            },
            coingeckoId: 'fx-coin'
        },
        {
            description: 'The token of Crowdpunk DAO',
            denomUnits: [
                {
                    denom: 'ibc/74C4FE1EC3BDD66B02C691496371DDBB86DDE512C5BC072D76262C6C9B4B20D1',
                    exponent: 0,
                    aliases: [
                        'erc20/0xfbF4318d24a93753F11d365A6dcF8b830e98Ab0F'
                    ]
                },
                {
                    denom: 'crowdp',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/74C4FE1EC3BDD66B02C691496371DDBB86DDE512C5BC072D76262C6C9B4B20D1',
            name: 'Crowdpunk DAO',
            display: 'crowdp',
            symbol: 'CROWDP',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'evmos',
                        baseDenom: 'erc20/0xfbF4318d24a93753F11d365A6dcF8b830e98Ab0F',
                        channelId: 'channel-3'
                    },
                    chain: {
                        channelId: 'channel-292',
                        path: 'transfer/channel-292/erc20/0xfbF4318d24a93753F11d365A6dcF8b830e98Ab0F'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/evmos/images/crowdp.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/evmos/images/crowdp.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'evmos',
                        baseDenom: 'erc20/0xfbF4318d24a93753F11d365A6dcF8b830e98Ab0F'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/evmos/images/crowdp.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/evmos/images/crowdp.svg',
                    theme: {
                        primaryColorHex: '#04fbfb'
                    }
                }
            ]
        },
        {
            description: 'Wrapped Bitcoin on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/D742E8566B0B8CC8F569D950051C09CF57988A88F0E45574BFB3079D41DE6462',
                    exponent: 0
                },
                {
                    denom: 'wbtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/D742E8566B0B8CC8F569D950051C09CF57988A88F0E45574BFB3079D41DE6462',
            name: 'Wrapped Bitcoin',
            display: 'wbtc',
            symbol: 'WBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x2260fac5e5542a773aa44fbcfedf7c193bc2c599',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x2260fac5e5542a773aa44fbcfedf7c193bc2c599'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0x2260fac5e5542a773aa44fbcfedf7c193bc2c599'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wbtc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wbtc.svg',
                    theme: {
                        primaryColorHex: '#f39444'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wbtc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/wbtc.svg'
            }
        },
        {
            description: 'Lombard Staked Bitcoin on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/DBD9E339E1B093A052D76BECFFDE8435EAC114CF2133346B4D691F3F2068C957',
                    exponent: 0
                },
                {
                    denom: 'lbtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/DBD9E339E1B093A052D76BECFFDE8435EAC114CF2133346B4D691F3F2068C957',
            name: 'Lombard Staked Bitcoin',
            display: 'lbtc',
            symbol: 'LBTC',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'lombardledger',
                        baseDenom: 'uclbtc',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: 'channel-1340',
                        path: 'transfer/channel-1340/uclbtc'
                    }
                }
            ],
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/lbtc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/lbtc.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/lbtc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/lbtc.svg'
            },
            coingeckoId: 'lombard-staked-btc'
        },
        {
            description: 'SolvBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/0C4417F123459B47B6933939BF6F128C362B0C1F9EDA6A6EBC08860E4672AF7E',
                    exponent: 0
                },
                {
                    denom: 'solvbtc',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/0C4417F123459B47B6933939BF6F128C362B0C1F9EDA6A6EBC08860E4672AF7E',
            name: 'SolvBTC',
            display: 'solvbtc',
            symbol: 'SolvBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x7a56e1c57c7475ccf742a1832b028f0456652f97',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x7a56e1c57c7475ccf742a1832b028f0456652f97'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'SolvBTC.BBN on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/486D45458E018B59D1F23ADD116D21A881D8DA3BC348B9E0E22354CA031C977E',
                    exponent: 0
                },
                {
                    denom: 'xsolvbtc',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/486D45458E018B59D1F23ADD116D21A881D8DA3BC348B9E0E22354CA031C977E',
            name: 'xSolvBTC',
            display: 'xsolvbtc',
            symbol: 'xSolvBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xd9d920aa40f578ab794426f5c90f6c731d159def',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xd9d920aa40f578ab794426f5c90f6c731d159def'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'PumpBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/9DA8B22BC0E6D76C2D621EF008168BC163B09A517697B14B68DE75382043152E',
                    exponent: 0
                },
                {
                    denom: 'pumpbtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9DA8B22BC0E6D76C2D621EF008168BC163B09A517697B14B68DE75382043152E',
            name: 'pumpBTC',
            display: 'pumpbtc',
            symbol: 'pumpBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xf469fbd2abcd6b9de8e169d128226c0fc90a012e',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xf469fbd2abcd6b9de8e169d128226c0fc90a012e'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'UniBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/9EE1F80BA2AE01138A40D656BBB42D11B1720000D6F64FC5988E412B6EDB4F71',
                    exponent: 0
                },
                {
                    denom: 'unibtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9EE1F80BA2AE01138A40D656BBB42D11B1720000D6F64FC5988E412B6EDB4F71',
            name: 'UniBTC',
            display: 'unibtc',
            symbol: 'uniBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x004e9c3ef86bc1ca1f0bb5c7662861ee93350568',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x004e9c3ef86bc1ca1f0bb5c7662861ee93350568'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'stBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/286A30F7F093357CE113A2E3B9A2E497F7A691CAFC624ABC615DE147DCE9FD17',
                    exponent: 0
                },
                {
                    denom: 'stbtc',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/286A30F7F093357CE113A2E3B9A2E497F7A691CAFC624ABC615DE147DCE9FD17',
            name: 'stBTC',
            display: 'stbtc',
            symbol: 'stBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xf6718b2701d4a6498ef77d7c152b2137ab28b8a3',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xf6718b2701d4a6498ef77d7c152b2137ab28b8a3'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'mBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/6583B66D1450B5A0E997C85A4048749ADCBD745562D62F3CC1CEE5D41B5814D1',
                    exponent: 0
                },
                {
                    denom: 'mbtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/6583B66D1450B5A0E997C85A4048749ADCBD745562D62F3CC1CEE5D41B5814D1',
            name: 'mBTC',
            display: 'mbtc',
            symbol: 'mBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xbdf245957992bfbc62b07e344128a1eec7b7ee3f',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xbdf245957992bfbc62b07e344128a1eec7b7ee3f'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'kBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/AE65FB498AFB35CC06301BEE6EA8063DC41CE04D80A8D167258B73D7A863DA8D',
                    exponent: 0
                },
                {
                    denom: 'kbtc',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/AE65FB498AFB35CC06301BEE6EA8063DC41CE04D80A8D167258B73D7A863DA8D',
            name: 'kBTC',
            display: 'kbtc',
            symbol: 'kBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x9356f6d95b8e109f4b7ce3e49d672967d3b48383',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x9356f6d95b8e109f4b7ce3e49d672967d3b48383'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'eBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/6F8F0E9D472BF053261F2DEBE521801B703372777F3923B48DAE55D4F1212B5F',
                    exponent: 0
                },
                {
                    denom: 'ebtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/6F8F0E9D472BF053261F2DEBE521801B703372777F3923B48DAE55D4F1212B5F',
            name: 'eBTC',
            display: 'ebtc',
            symbol: 'eBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x657e8c867d8b37dcc18fa4caead9c45eb088c642',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x657e8c867d8b37dcc18fa4caead9c45eb088c642'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'enzoBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/9CB24EF57DF00EFFCE3B52FC1225EDEDF98B31DB8C792B43C7E3D4AD9B3982CF',
                    exponent: 0
                },
                {
                    denom: 'enzobtc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9CB24EF57DF00EFFCE3B52FC1225EDEDF98B31DB8C792B43C7E3D4AD9B3982CF',
            name: 'enzoBTC',
            display: 'enzobtc',
            symbol: 'enzoBTC',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x6a9a65b84843f5fd4ac9a0471c4fc11afffbce4a',
                        channelId: 'cosmoshub-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x6a9a65b84843f5fd4ac9a0471c4fc11afffbce4a'
                    },
                    provider: 'Eureka'
                }
            ]
        },
        {
            description: 'Tether USD on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/E7E51FFF94A8B55BE84CEB0345E5CAF0A5DAEB374C6806CE908098B8996C7782',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/E7E51FFF94A8B55BE84CEB0345E5CAF0A5DAEB374C6806CE908098B8996C7782',
            name: 'Tether USD',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            }
        },
        {
            description: 'Ether ETH on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/C0B53D3D23827AE38058BED0BDCD554229278AF530A8D265FCF6DFF7C4B2ADFF',
                    exponent: 0
                },
                {
                    denom: 'eth',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/C0B53D3D23827AE38058BED0BDCD554229278AF530A8D265FCF6DFF7C4B2ADFF',
            name: 'Ethereum',
            display: 'eth',
            symbol: 'ETH',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            }
        },
        {
            description: 'sUSDS on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/B9B561EB378C9EB8C13CAA11FCBC78E6B865A3C65707972F17B1052CFC39F473',
                    exponent: 0
                },
                {
                    denom: 'susds',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/B9B561EB378C9EB8C13CAA11FCBC78E6B865A3C65707972F17B1052CFC39F473',
            name: 'Savings USDS',
            display: 'susds',
            symbol: 'sUSDS',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa3931d71877C0E7a3148CB7Eb4463524FEc27fbD',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0xa3931d71877c0e7a3148cb7eb4463524fec27fbd'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa3931d71877C0E7a3148CB7Eb4463524FEc27fbD'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/susds.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/susds.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/susds.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/susds.svg'
            }
        },
        {
            description: 'OPHIR is a Cosmos Treasury DAO',
            extendedDescription: 'The ancient city of gold',
            denomUnits: [
                {
                    denom: 'ibc/B26F762ED6D20D0D5305FE1870A476EBCB95127C10199F3CB16E69D893E9F775',
                    exponent: 0,
                    aliases: [
                        'transfer/channel-141/transfer/channel-642/factory/migaloo1t862qdu9mj5hr3j727247acypym3ej47axu22rrapm4tqlcpuseqltxwq5/ophir'
                    ]
                },
                {
                    denom: 'OPHIR',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/B26F762ED6D20D0D5305FE1870A476EBCB95127C10199F3CB16E69D893E9F775',
            name: 'Ophir DAO',
            display: 'OPHIR',
            symbol: 'OPHIR',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'migaloo',
                        baseDenom: 'factory/migaloo1t862qdu9mj5hr3j727247acypym3ej47axu22rrapm4tqlcpuseqltxwq5/ophir',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-642',
                        path: 'transfer/channel-642/factory/migaloo1t862qdu9mj5hr3j727247acypym3ej47axu22rrapm4tqlcpuseqltxwq5/ophir'
                    }
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'osmosis',
                        baseDenom: 'ibc/3AF2E322D4B54BB97EEE24760ED25B725842A9B62C759402AB8AADD75915FD14',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: 'channel-141',
                        path: 'transfer/channel-141/transfer/channel-642/factory/migaloo1t862qdu9mj5hr3j727247acypym3ej47axu22rrapm4tqlcpuseqltxwq5/ophir'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/migaloo/images/ophir.png'
            },
            socials: {
                website: 'https://www.ophirdao.com',
                twitter: 'https://x.com/OphirDAO'
            },
            keywords: [
                'dao'
            ]
        },
        {
            description: 'Midas mBTC on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/62F1A800DCE1AA0FD47B3592DEBB7A8956A383A14A4F756E4881AEA927B21671',
                    exponent: 0
                },
                {
                    denom: 'mBTC',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/62F1A800DCE1AA0FD47B3592DEBB7A8956A383A14A4F756E4881AEA927B21671',
            name: 'Midas BTC Yield Token',
            display: 'mBTC',
            symbol: 'mBTC.midas',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x007115416ab6c266329a03b09a8aa39ac2ef7d9d',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x007115416ab6c266329a03b09a8aa39ac2ef7d9d'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0x007115416ab6c266329a03b09a8aa39ac2ef7d9d'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/midas-mbtc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/midas-mbtc.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/midas-mbtc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/midas-mbtc.svg'
            }
        },
        {
            description: 'Pax Gold on the Cosmos Hub',
            denomUnits: [
                {
                    denom: 'ibc/09E95F57939E344EE36109AC41780B8A51F1FE0548A5203C5957674FF64C0F26',
                    exponent: 0
                },
                {
                    denom: 'paxg',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/09E95F57939E344EE36109AC41780B8A51F1FE0548A5203C5957674FF64C0F26',
            name: 'Pax Gold',
            display: 'paxg',
            symbol: 'PAXG',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x45804880De22913dAFE09f4980848ECE6EcbAf78',
                        channelId: 'channel-0'
                    },
                    chain: {
                        channelId: '08-wasm-1369',
                        path: 'transfer/08-wasm-1369/0x45804880de22913dafe09f4980848ece6ecbaf78'
                    },
                    provider: 'Eureka'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0x45804880De22913dAFE09f4980848ECE6EcbAf78'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/paxg.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/paxg.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#D8A24A',
                        backgroundColorHex: '#D8A24A'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/paxg.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/paxg.svg'
            }
        }
    ]
};
exports.default = info;
}}),
"[project]/node_modules/chain-registry/mainnet/cosmoshub/chain.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const info = {
    $schema: '../chain.schema.json',
    chainName: 'cosmoshub',
    chainType: 'cosmos',
    chainId: 'cosmoshub-4',
    website: 'https://cosmos.network/',
    prettyName: 'Cosmos Hub',
    status: 'live',
    networkType: 'mainnet',
    bech32Prefix: 'cosmos',
    daemonName: 'gaiad',
    nodeHome: '$HOME/.gaia',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'uatom',
                fixedMinGasPrice: 0.005,
                lowGasPrice: 0.01,
                averageGasPrice: 0.025,
                highGasPrice: 0.03
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'uatom'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/cosmos/gaia',
        recommendedVersion: 'v21.0.0',
        compatibleVersions: [
            'v21.0.0'
        ],
        consensus: {
            type: 'cometbft',
            version: 'v0.38.11'
        },
        binaries: {
            "darwin/amd64": 'https://github.com/cosmos/gaia/releases/download/v21.0.0/gaiad-v21.0.0-darwin-amd64',
            "darwin/arm64": 'https://github.com/cosmos/gaia/releases/download/v21.0.0/gaiad-v21.0.0-darwin-arm64',
            "linux/amd64": 'https://github.com/cosmos/gaia/releases/download/v21.0.0/gaiad-v21.0.0-linux-amd64'
        },
        genesis: {
            genesisUrl: 'https://github.com/cosmos/mainnet/raw/master/genesis/genesis.cosmoshub-4.json.gz'
        },
        sdk: {
            type: 'cosmos',
            version: 'v0.50.9',
            tag: 'v0.50.9-lsm'
        },
        ibc: {
            type: 'go',
            version: 'v8.5.1'
        },
        cosmwasm: {
            version: 'v0.53.0',
            repo: 'https://github.com/CosmWasm/wasmd',
            tag: 'v0.53.0'
        }
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
        svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg'
    },
    description: 'In a nutshell, Cosmos Hub bills itself as a project that solves some of the hardest problems facing the blockchain industry. It aims to offer an antidote to slow, expensive, unscalable and environmentally harmful proof-of-work protocols, like those used by Bitcoin, by offering an ecosystem of connected blockchains.\n\nThe project’s other goals include making blockchain technology less complex and difficult for developers thanks to a modular framework that demystifies decentralized apps. Last but not least, an Inter-blockchain Communication protocol makes it easier for blockchain networks to communicate with each other — preventing fragmentation in the industry.\n\nCosmos Hub\'s origins can be dated back to 2014, when Tendermint, a core contributor to the network, was founded. In 2016, a white paper for Cosmos was published — and a token sale was held the following year. ATOM tokens are earned through a hybrid proof-of-stake algorithm, and they help to keep the Cosmos Hub, the project’s flagship blockchain, secure. This cryptocurrency also has a role in the network’s governance.',
    apis: {
        rpc: [
            {
                address: 'https://cosmoshub.tendermintrpc.lava.build:443',
                provider: 'Lava'
            },
            {
                address: 'https://cosmos-rpc.quickapi.com:443',
                provider: 'Chainlayer'
            },
            {
                address: 'https://cosmos-rpc.onivalidator.com',
                provider: 'Oni Validator ⛩️'
            },
            {
                address: 'https://rpc-cosmoshub.whispernode.com:443',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'https://rpc.lavenderfive.com:443/cosmoshub',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'https://rpc-cosmoshub.ecostake.com',
                provider: 'ecostake'
            },
            {
                address: 'https://go.getblock.io/17515cb3ec0e43b7817f182e5de6066a',
                provider: 'GetBlock RPC Nodes'
            },
            {
                address: 'https://rpc-cosmoshub.pupmos.network',
                provider: 'PUPMØS'
            },
            {
                address: 'https://rpc-cosmoshub.cosmos-spaces.cloud',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'https://cosmos-rpc.polkachu.com',
                provider: 'Polkachu'
            },
            {
                address: 'https://cosmos-rpc.staketab.org:443',
                provider: 'Staketab'
            },
            {
                address: 'https://rpc-cosmoshub-ia.cosmosia.notional.ventures/',
                provider: 'Notional'
            },
            {
                address: 'https://rpc-cosmoshub.architectnodes.com',
                provider: 'Architect Nodes'
            },
            {
                address: 'https://rpc.cosmos.dragonstake.io',
                provider: 'DragonStake'
            },
            {
                address: 'https://cosmoshub.rpc.stakin-nodes.com',
                provider: 'Stakin'
            },
            {
                address: 'https://rpc.cosmos.bh.rocks',
                provider: 'BlockHunters 🎯'
            },
            {
                address: 'https://cosmos-rpc.rockrpc.net',
                provider: 'RockawayX Infra'
            },
            {
                address: 'http://rpc-cosmoshub.freshstaking.com:26657',
                provider: 'FreshSTAKING'
            },
            {
                address: 'https://cosmos-rpc.easy2stake.com/',
                provider: 'Easy 2 Stake'
            },
            {
                address: 'https://rpc.cosmos.nodestake.org',
                provider: 'NodeStake'
            },
            {
                address: 'https://cosmos.rpc.silknodes.io',
                provider: 'Silk Nodes'
            },
            {
                address: 'https://cosmos-rpc.publicnode.com:443',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'https://cosmoshub.rpc.kjnodes.com',
                provider: 'kjnodes'
            },
            {
                address: 'https://rpc.cosmoshub.goldenratiostaking.net',
                provider: 'Golden Ratio Staking'
            },
            {
                address: 'https://rpc-cosmos-hub-01.stakeflow.io',
                provider: 'Stakeflow'
            },
            {
                address: 'https://cosmos-rpc.w3coins.io',
                provider: 'w3coins'
            },
            {
                address: 'https://rpc-cosmoshub.mms.team',
                provider: 'MMS'
            },
            {
                address: 'https://cosmos-rpc.tienthuattoan.com',
                provider: 'TTT 🇻🇳'
            },
            {
                address: 'https://community.nuxian-node.ch:6797/gaia/trpc',
                provider: 'PRO Delegators'
            },
            {
                address: 'https://cosmos-rpc.highstakes.ch',
                provider: 'High Stakes 🇨🇭'
            },
            {
                address: 'https://cosmoshub-rpc.cosmosrescue.dev',
                provider: 'cosmosrescue'
            },
            {
                address: 'https://cosmos.interstellar-lounge.org',
                provider: 'Interstellar Lounge 🍸'
            },
            {
                address: 'https://public.stakewolle.com/cosmos/cosmoshub/rpc',
                provider: 'Stakewolle'
            },
            {
                address: 'https://rpc-cosmos.kewrnode.com',
                provider: 'Kewr Node'
            },
            {
                address: 'https://rpc.cosmoshub-4.citizenweb3.com',
                provider: 'Citizen Web3'
            },
            {
                address: 'https://cosmos-rpc.stakeandrelax.net',
                provider: 'Stake&Relax 🦥'
            },
            {
                address: 'https://cosmos-hub.drpc.org',
                provider: 'dRPC'
            },
            {
                address: 'https://cosmoshub-mainnet-rpc.itrocket.net',
                provider: 'ITRocket'
            },
            {
                address: 'https://cosmoshub.rpc.quasarstaking.ai',
                provider: 'Quasar'
            },
            {
                address: 'https://cosmos-rpc.ibs.team',
                provider: 'Inter Blockchain Services'
            },
            {
                address: 'https://rpc.cosmoshub-4-archive.citizenweb3.com:443',
                provider: 'Citizen Web3'
            }
        ],
        rest: [
            {
                address: 'https://cosmoshub.lava.build:443',
                provider: 'Lava'
            },
            {
                address: 'https://cosmos-lcd.quickapi.com:443',
                provider: 'Chainlayer'
            },
            {
                address: 'https://rest.cosmoshub.goldenratiostaking.net',
                provider: 'Golden Ratio Staking'
            },
            {
                address: 'https://rest.lavenderfive.com:443/cosmoshub',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'https://api-cosmoshub.pupmos.network',
                provider: 'PUPMØS'
            },
            {
                address: 'https://api-cosmoshub.cosmos-spaces.cloud',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'https://api-cosmoshub-ia.cosmosia.notional.ventures/',
                provider: 'Notional'
            },
            {
                address: 'https://cosmos-rest.staketab.org',
                provider: 'Staketab'
            },
            {
                address: 'https://lcd.cosmos.dragonstake.io',
                provider: 'DragonStake'
            },
            {
                address: 'https://cosmoshub.rest.stakin-nodes.com',
                provider: 'Stakin'
            },
            {
                address: 'https://rest-cosmoshub.architectnodes.com',
                provider: 'Architect Nodes'
            },
            {
                address: 'https://rest-cosmoshub.ecostake.com',
                provider: 'ecostake'
            },
            {
                address: 'https://lcd-cosmoshub.whispernode.com:443',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'https://cosmos-lcd.easy2stake.com',
                provider: 'Easy 2 Stake'
            },
            {
                address: 'https://api.cosmos.nodestake.org',
                provider: 'NodeStake'
            },
            {
                address: 'https://cosmos.api.silknodes.io',
                provider: 'Silk Nodes'
            },
            {
                address: 'https://cosmos-rest.publicnode.com',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'https://cosmoshub.api.kjnodes.com',
                provider: 'kjnodes'
            },
            {
                address: 'https://api-cosmos-hub-01.stakeflow.io',
                provider: 'Stakeflow'
            },
            {
                address: 'https://cosmos-api.w3coins.io',
                provider: 'w3coins'
            },
            {
                address: 'https://api-cosmoshub.mms.team',
                provider: 'MMS'
            },
            {
                address: 'https://cosmos-api.tienthuattoan.ventures',
                provider: 'TienThuatToan'
            },
            {
                address: 'https://community.nuxian-node.ch:6797/gaia/crpc',
                provider: 'PRO Delegators'
            },
            {
                address: 'https://cosmos-api.highstakes.ch',
                provider: 'High Stakes 🇨🇭'
            },
            {
                address: 'https://cosmoshub-api.cosmosrescue.dev',
                provider: 'cosmosrescue'
            },
            {
                address: 'https://cosmos-rest.interstellar-lounge.org',
                provider: 'Interstellar Lounge 🍸'
            },
            {
                address: 'https://public.stakewolle.com/cosmos/cosmoshub/rest',
                provider: 'Stakewolle'
            },
            {
                address: 'https://rest-cosmos.kewrnode.com',
                provider: 'Kewr Node'
            },
            {
                address: 'https://cosmos-api.stakeandrelax.net',
                provider: 'Stake&Relax 🦥'
            },
            {
                address: 'https://cosmoshub-mainnet-api.itrocket.net',
                provider: 'ITRocket'
            },
            {
                address: 'https://cosmoshub.api.quasarstaking.ai',
                provider: 'Quasar'
            },
            {
                address: 'https://cosmos-api.ibs.team',
                provider: 'Inter Blockchain Services'
            },
            {
                address: 'https://api.cosmoshub-4-archive.citizenweb3.com:443',
                provider: 'Citizen Web3'
            }
        ],
        grpc: [
            {
                address: 'cosmoshub.grpc.lava.build',
                provider: 'Lava'
            },
            {
                address: 'cosmoshub.lavenderfive.com:443',
                provider: 'Lavender.Five Nodes 🐝'
            },
            {
                address: 'grpc-cosmoshub-ia.cosmosia.notional.ventures:443',
                provider: 'Notional'
            },
            {
                address: 'cosmos-grpc.polkachu.com:14990',
                provider: 'Polkachu'
            },
            {
                address: 'grpc.cosmos.interbloc.org:443',
                provider: 'Interbloc'
            },
            {
                address: 'services.staketab.com:9030',
                provider: 'Staketab'
            },
            {
                address: 'grpc.cosmos.dragonstake.io:443',
                provider: 'DragonStake'
            },
            {
                address: 'cosmoshub.grpc.stakin-nodes.com:443',
                provider: 'Stakin'
            },
            {
                address: 'https://grpc.cosmos.nodestake.org',
                provider: 'NodeStake'
            },
            {
                address: 'cosmos-grpc.publicnode.com:443',
                provider: 'Allnodes ⚡️ Nodes & Staking'
            },
            {
                address: 'grpc-cosmoshub.cosmos-spaces.cloud:3910',
                provider: 'Cosmos Spaces'
            },
            {
                address: 'cosmoshub.grpc.kjnodes.com:11390',
                provider: 'kjnodes'
            },
            {
                address: 'grpc-cosmos-hub-01.stakeflow.io:9090',
                provider: 'Stakeflow'
            },
            {
                address: 'grpc-cosmoshub.whispernode.com:443',
                provider: 'WhisperNode 🤐'
            },
            {
                address: 'cosmos-grpc.w3coins.io:14990',
                provider: 'w3coins'
            },
            {
                address: 'grpc-cosmoshub.mms.team:443',
                provider: 'MMS'
            },
            {
                address: 'cosmos-grpc.tienthuattoan.ventures:9090',
                provider: 'TienThuatToan'
            },
            {
                address: 'cosmoshub-mainnet.grpc.l0vd.com:80',
                provider: 'L0vd.com ❤️'
            },
            {
                address: 'https://grpc-cosmos.nodeist.net',
                provider: 'Nodeist'
            },
            {
                address: 'cosmos-grpc.stakeandrelax.net:15090',
                provider: 'Stake&Relax 🦥'
            },
            {
                address: 'cosmoshub-mainnet-grpc.itrocket.net:443',
                provider: 'ITRocket'
            },
            {
                address: 'cosmoshub.grpc.quasarstaking.ai',
                provider: 'Quasar'
            },
            {
                address: 'grpc.cosmoshub-4-archive.citizenweb3.com',
                provider: 'Citizen Web3'
            }
        ]
    },
    explorers: [
        {
            kind: 'mintscan',
            url: 'https://www.mintscan.io/cosmos',
            txPage: 'https://www.mintscan.io/cosmos/transactions/${txHash}',
            accountPage: 'https://www.mintscan.io/cosmos/accounts/${accountAddress}',
            validatorPage: 'https://www.mintscan.io/cosmos/validators/${validatorAddress}',
            proposalPage: 'https://www.mintscan.io/cosmos/proposals/${proposalId}',
            blockPage: 'https://www.mintscan.io/cosmos/blocks/${blockHeight}'
        },
        {
            kind: 'ezstaking',
            url: 'https://ezstaking.app/cosmoshub',
            txPage: 'https://ezstaking.app/cosmoshub/txs/${txHash}',
            accountPage: 'https://ezstaking.app/cosmoshub/account/${accountAddress}',
            validatorPage: 'https://ezstaking.app/cosmoshub/validators/${validatorAddress}',
            proposalPage: 'https://ezstaking.app/cosmoshub/proposals/${proposalId}',
            blockPage: 'https://ezstaking.app/cosmoshub/blocks/${blockHeight}'
        },
        {
            kind: 'ping.pub',
            url: 'https://ping.pub/cosmos',
            txPage: 'https://ping.pub/cosmos/tx/${txHash}',
            accountPage: 'https://ping.pub/cosmos/account/${accountAddress}',
            validatorPage: 'https://ping.pub/cosmos/staking/${validatorAddress}',
            proposalPage: 'https://ping.pub/cosmos/gov/${proposalId}',
            blockPage: 'https://ping.pub/cosmos/block/${blockHeight}'
        },
        {
            kind: 'staking-explorer.com',
            url: 'https://staking-explorer.com/explorer/cosmoshub',
            txPage: 'https://staking-explorer.com/transaction.php?chain=cosmoshub&tx=${txHash}',
            accountPage: 'https://staking-explorer.com/account.php?chain=cosmoshub&addr=${accountAddress}'
        },
        {
            kind: 'atomscan',
            url: 'https://atomscan.com',
            txPage: 'https://atomscan.com/transactions/${txHash}',
            accountPage: 'https://atomscan.com/accounts/${accountAddress}',
            validatorPage: 'https://atomscan.com/validators/${validatorAddress}',
            proposalPage: 'https://atomscan.com/votes/${proposalId}',
            blockPage: 'https://atomscan.com/blocks/${blockHeight}'
        },
        {
            kind: 'unichain',
            url: 'https://unicha.in/cosmos',
            txPage: 'https://unicha.in/cosmos/transaction/${txHash}'
        },
        {
            kind: 'TC Network',
            url: 'https://explorer.tcnetwork.io/cosmoshub',
            txPage: 'https://explorer.tcnetwork.io/cosmoshub/transaction/${txHash}',
            accountPage: 'https://explorer.tcnetwork.io/cosmoshub/account/${accountAddress}',
            validatorPage: 'https://explorer.tcnetwork.io/cosmoshub/validator/${validatorAddress}',
            proposalPage: 'https://explorer.tcnetwork.io/cosmoshub/proposal/${proposalId}',
            blockPage: 'https://explorer.tcnetwork.io/cosmoshub/block/${blockHeight}'
        },
        {
            kind: 'Stakeflow',
            url: 'https://stakeflow.io/cosmos',
            accountPage: 'https://stakeflow.io/cosmos/accounts/${accountAddress}',
            validatorPage: 'https://stakeflow.io/cosmos/validators/${validatorAddress}'
        },
        {
            kind: 'Nodeist Explorer',
            url: 'https://exp.nodeist.net/cosmos'
        },
        {
            kind: 'Inbloc',
            url: 'https://inbloc.org',
            txPage: 'https://inbloc.org/transactions/${txHash}',
            accountPage: 'https://inbloc.org/account/${accountAddress}',
            validatorPage: 'https://inbloc.org/cosmos/validator/${validatorAddress}',
            proposalPage: 'https://inbloc.org/cosmos/proposal/${proposalId}',
            blockPage: 'https://inbloc.org/cosmos/blocks/${blockHeight}'
        },
        {
            kind: 'WhisperNode 🤐',
            url: 'https://mainnet.whispernode.com/cosmos',
            txPage: 'https://mainnet.whispernode.com/cosmos/tx/${txHash}',
            accountPage: 'https://mainnet.whispernode.com/cosmos/account/${accountAddress}',
            validatorPage: 'https://mainnet.whispernode.com/cosmos/staking/${validatorAddress}',
            proposalPage: 'https://mainnet.whispernode.com/cosmos/gov/${proposalId}',
            blockPage: 'https://mainnet.whispernode.com/cosmos/block/${blockHeight}'
        },
        {
            kind: 'ITRocket',
            url: 'https://mainnet.itrocket.net/cosmoshub',
            txPage: 'https://mainnet.itrocket.net/cosmoshub/tx/${txHash}',
            accountPage: 'https://mainnet.itrocket.net/cosmoshub/account/${accountAddress}',
            validatorPage: 'https://mainnet.itrocket.net/cosmoshub/staking/${validatorAddress}',
            proposalPage: 'https://mainnet.itrocket.net/cosmoshub/gov/${proposalId}',
            blockPage: 'https://mainnet.itrocket.net/cosmoshub/block/${blockHeight}'
        },
        {
            kind: 'NodeStake',
            url: 'https://explorer.nodestake.org/cosmos',
            txPage: 'https://explorer.nodestake.org/cosmos/tx/${txHash}',
            accountPage: 'https://explorer.nodestake.org/cosmos/account/${accountAddress}',
            validatorPage: 'https://explorer.nodestake.org/cosmos/staking/${validatorAddress}',
            proposalPage: 'https://explorer.nodestake.org/cosmos/gov/${proposalId}',
            blockPage: 'https://explorer.nodestake.org/cosmos/block/${blockHeight}'
        },
        {
            kind: 'Valopers',
            url: 'https://cosmos.valopers.com/',
            txPage: 'https://cosmos.valopers.com/transactions/${txHash}',
            accountPage: 'https://cosmos.valopers.com/account/${accountAddress}'
        }
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
            svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg',
            theme: {
                primaryColorHex: '#272d45'
            }
        }
    ]
};
exports.default = info;
}}),
"[project]/node_modules/chain-registry/mainnet/cosmoshub/ibc-data.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
const info = [
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'acrechain',
            clientId: '07-tendermint-9',
            connectionId: 'connection-9'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1002',
            connectionId: 'connection-701'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-457',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'agoric',
            clientId: '07-tendermint-6',
            connectionId: 'connection-8'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-927',
            connectionId: 'connection-649'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-405',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'aioz',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1121',
            connectionId: 'connection-808'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-567',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'akash',
            clientId: '07-tendermint-53',
            connectionId: 'connection-29'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-385',
            connectionId: 'connection-339'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-17',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-184',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'archway',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1152',
            connectionId: 'connection-873'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-623',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'aura',
            clientId: '07-tendermint-24',
            connectionId: 'connection-14'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1158',
            connectionId: 'connection-880'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-646',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'axelar',
            clientId: '07-tendermint-3',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-622',
            connectionId: 'connection-481'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-293',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'babylon',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1381',
            connectionId: 'connection-1104'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1341',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'bitcanna',
            clientId: '07-tendermint-4',
            connectionId: 'connection-3'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-490',
            connectionId: 'connection-399'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-232',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'bitsong',
            clientId: '07-tendermint-1',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-481',
            connectionId: 'connection-395'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-229',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'bostrom',
            clientId: '07-tendermint-15',
            connectionId: 'connection-10'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-764',
            connectionId: 'connection-553'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-341',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'canto',
            clientId: '07-tendermint-1',
            connectionId: 'connection-3'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-873',
            connectionId: 'connection-604'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-358',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'carbon',
            clientId: '07-tendermint-6',
            connectionId: 'connection-5'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-765',
            connectionId: 'connection-554'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-342',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'demex'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cifer',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1301',
            connectionId: 'connection-1035'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-831',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'composable',
            clientId: '07-tendermint-7',
            connectionId: 'connection-7'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1150',
            connectionId: 'connection-871'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-617',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'coreum',
            clientId: '07-tendermint-11',
            connectionId: 'connection-11'
        },
        chain2: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1162',
            connectionId: 'connection-884'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-660',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-724',
            connectionId: 'connection-538'
        },
        chain2: {
            chainName: 'crescent',
            clientId: '07-tendermint-3',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-326',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'crescent'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-389',
            connectionId: 'connection-342'
        },
        chain2: {
            chainName: 'cryptoorgchain',
            clientId: '07-tendermint-735',
            connectionId: 'connection-220'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-187',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-27',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1191',
            connectionId: 'connection-920'
        },
        chain2: {
            chainName: 'doravota',
            clientId: '07-tendermint-14',
            connectionId: 'connection-8'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-750',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1325',
            connectionId: 'connection-1057'
        },
        chain2: {
            chainName: 'dungeon1',
            clientId: '07-tendermint-4',
            connectionId: 'connection-9'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1213',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1205',
            connectionId: 'connection-933'
        },
        chain2: {
            chainName: 'dymension',
            clientId: '07-tendermint-1',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-794',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1339',
            connectionId: 'connection-1073'
        },
        chain2: {
            chainName: 'elys',
            clientId: '07-tendermint-0',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1265',
                    portId: 'provider'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'consumer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-1266',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-432',
            connectionId: 'connection-365'
        },
        chain2: {
            chainName: 'emoney',
            clientId: '07-tendermint-8',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-202',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1151',
            connectionId: 'connection-872'
        },
        chain2: {
            chainName: 'empowerchain',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-621',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-620',
            connectionId: 'connection-480'
        },
        chain2: {
            chainName: 'evmos',
            clientId: '07-tendermint-3',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-292',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1141',
            connectionId: 'connection-829'
        },
        chain2: {
            chainName: 'fxcore',
            clientId: '07-tendermint-13',
            connectionId: 'connection-13'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-585',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1153',
            connectionId: 'connection-874'
        },
        chain2: {
            chainName: 'haqq',
            clientId: '07-tendermint-2',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-632',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-434',
            connectionId: 'connection-368'
        },
        chain2: {
            chainName: 'impacthub',
            clientId: '07-tendermint-9',
            connectionId: 'connection-9'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-204',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-470',
            connectionId: 'connection-388'
        },
        chain2: {
            chainName: 'injective',
            clientId: '07-tendermint-5',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-220',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-384',
            connectionId: 'connection-338'
        },
        chain2: {
            chainName: 'irisnet',
            clientId: '07-tendermint-31',
            connectionId: 'connection-22'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-182',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-12',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1307',
            connectionId: 'connection-1041'
        },
        chain2: {
            chainName: 'joltify',
            clientId: '07-tendermint-3',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-866',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-439',
            connectionId: 'connection-372'
        },
        chain2: {
            chainName: 'juno',
            clientId: '07-tendermint-3',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-207',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-557',
            connectionId: 'connection-460'
        },
        chain2: {
            chainName: 'kava',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-277',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-475',
            connectionId: 'connection-392'
        },
        chain2: {
            chainName: 'kichain',
            clientId: '07-tendermint-6',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-223',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1382',
            connectionId: 'connection-1105'
        },
        chain2: {
            chainName: 'kopi',
            clientId: '07-tendermint-19',
            connectionId: 'connection-43'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1351',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-769',
            connectionId: 'connection-555'
        },
        chain2: {
            chainName: 'kujira',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-343',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1318',
            connectionId: 'connection-1050'
        },
        chain2: {
            chainName: 'lava',
            clientId: '07-tendermint-7',
            connectionId: 'connection-12'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-969',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-468',
            connectionId: 'connection-386'
        },
        chain2: {
            chainName: 'likecoin',
            clientId: '07-tendermint-24',
            connectionId: 'connection-13'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-217',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1380',
            connectionId: 'connection-1103'
        },
        chain2: {
            chainName: 'lombardledger',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1340',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1120',
            connectionId: 'connection-807'
        },
        chain2: {
            chainName: 'lumnetwork',
            clientId: '07-tendermint-21',
            connectionId: 'connection-22'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-566',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-12',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1331',
            connectionId: 'connection-1062'
        },
        chain2: {
            chainName: 'mantrachain',
            clientId: '07-tendermint-3',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1252',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-3',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1119',
            connectionId: 'connection-809'
        },
        chain2: {
            chainName: 'neutron',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-569',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1116',
            connectionId: 'connection-790'
        },
        chain2: {
            chainName: 'noble',
            clientId: '07-tendermint-4',
            connectionId: 'connection-12'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-536',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-656',
            connectionId: 'connection-501'
        },
        chain2: {
            chainName: 'omniflixhub',
            clientId: '07-tendermint-23',
            connectionId: 'connection-19'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-306',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-12',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-651',
            connectionId: 'connection-497'
        },
        chain2: {
            chainName: 'oraichain',
            clientId: '07-tendermint-47',
            connectionId: 'connection-22'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-301',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'oraidex'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-259',
            connectionId: 'connection-257'
        },
        chain2: {
            chainName: 'osmosis',
            clientId: '07-tendermint-1',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-141',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-391',
            connectionId: 'connection-344'
        },
        chain2: {
            chainName: 'persistence',
            clientId: '07-tendermint-36',
            connectionId: 'connection-30'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-190',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-24',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-994',
            connectionId: 'connection-693'
        },
        chain2: {
            chainName: 'planq',
            clientId: '07-tendermint-5',
            connectionId: 'connection-3'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-446',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-926',
            connectionId: 'connection-648'
        },
        chain2: {
            chainName: 'point',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-404',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1304',
            connectionId: 'connection-1038'
        },
        chain2: {
            chainName: 'pryzm',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-859',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-863',
                    portId: 'icahost'
                },
                chain2: {
                    channelId: 'channel-8',
                    portId: 'icacontroller-reward-uatom'
                },
                ordering: 'ordered',
                version: 'ics27-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-861',
                    portId: 'icahost'
                },
                chain2: {
                    channelId: 'channel-9',
                    portId: 'icacontroller-sweep-uatom'
                },
                ordering: 'ordered',
                version: 'ics27-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            },
            {
                chain1: {
                    channelId: 'channel-891',
                    portId: 'icahost'
                },
                chain2: {
                    channelId: 'channel-20',
                    portId: 'icacontroller-delegation-uatom'
                },
                ordering: 'ordered',
                version: 'ics27-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1018',
            connectionId: 'connection-709'
        },
        chain2: {
            chainName: 'quicksilver',
            clientId: '07-tendermint-2',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-467',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1157',
            connectionId: 'connection-879'
        },
        chain2: {
            chainName: 'realio',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-645',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-386',
            connectionId: 'connection-340'
        },
        chain2: {
            chainName: 'regen',
            clientId: '07-tendermint-27',
            connectionId: 'connection-24'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-185',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-11',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-492',
            connectionId: 'connection-401'
        },
        chain2: {
            chainName: 'secretnetwork',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-235',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    properties: 'privacy'
                }
            },
            {
                chain1: {
                    channelId: 'channel-1355',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-187',
                    portId: 'wasm.secret1tqmms5awftpuhalcv5h5mg76fa0tkdz4jv9ex4'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    properties: 'cw20'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1372',
            connectionId: 'connection-1098'
        },
        chain2: {
            chainName: 'seda',
            clientId: '07-tendermint-1',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1337',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1140',
            connectionId: 'connection-827'
        },
        chain2: {
            chainName: 'sei',
            clientId: '07-tendermint-3',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-584',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    properties: 'privacy'
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1310',
            connectionId: 'connection-1043'
        },
        chain2: {
            chainName: 'self',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-892',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-388',
            connectionId: 'connection-341'
        },
        chain2: {
            chainName: 'sentinel',
            clientId: '07-tendermint-58',
            connectionId: 'connection-33'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-186',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-12',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1383',
            connectionId: 'connection-1106'
        },
        chain2: {
            chainName: 'sidechain',
            clientId: '07-tendermint-25',
            connectionId: 'connection-11'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1352',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-395',
            connectionId: 'connection-347'
        },
        chain2: {
            chainName: 'sifchain',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-192',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-892',
            connectionId: 'connection-618'
        },
        chain2: {
            chainName: 'stafihub',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-369',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1188',
            connectionId: 'connection-918'
        },
        chain2: {
            chainName: 'stargaze',
            clientId: '07-tendermint-320',
            connectionId: 'connection-256'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-730',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-239',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-326',
            connectionId: 'connection-300'
        },
        chain2: {
            chainName: 'starname',
            clientId: '07-tendermint-6',
            connectionId: 'connection-6'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-158',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-913',
            connectionId: 'connection-635'
        },
        chain2: {
            chainName: 'stride',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-391',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-962',
            connectionId: 'connection-1710'
        },
        chain2: {
            chainName: 'teritori',
            clientId: '07-tendermint-32',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-431',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-760',
            connectionId: 'connection-551'
        },
        chain2: {
            chainName: 'terra2',
            clientId: '07-tendermint-0',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-339',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-611',
            connectionId: 'connection-473'
        },
        chain2: {
            chainName: 'umee',
            clientId: '07-tendermint-9',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-288',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {}
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshub',
            clientId: '07-tendermint-1115',
            connectionId: 'connection-788'
        },
        chain2: {
            chainName: 'uptick',
            clientId: '07-tendermint-3',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-535',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1'
            }
        ]
    }
];
exports.default = info;
}}),
"[project]/node_modules/chain-registry/mainnet/cosmoshub/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ibcData = exports.chain = exports.assetList = void 0;
const asset_list_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/chain-registry/mainnet/cosmoshub/asset-list.js [app-client] (ecmascript)"));
const chain_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/chain-registry/mainnet/cosmoshub/chain.js [app-client] (ecmascript)"));
const ibc_data_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/chain-registry/mainnet/cosmoshub/ibc-data.js [app-client] (ecmascript)"));
exports.assetList = asset_list_1.default;
exports.chain = chain_1.default;
exports.ibcData = ibc_data_1.default;
}}),
}]);

//# sourceMappingURL=node_modules_chain-registry_mainnet_cosmoshub_7b1d9c60._.js.map