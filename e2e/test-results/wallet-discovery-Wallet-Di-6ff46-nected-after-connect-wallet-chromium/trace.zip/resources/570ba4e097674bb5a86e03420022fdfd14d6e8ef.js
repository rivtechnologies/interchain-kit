(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/examples_e2e_src_app_wallet-connect_page_tsx_5adb7036._.js"
],
    source: "dynamic"
});
