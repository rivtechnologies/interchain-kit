(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@keplr-wallet/unit/build/etc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.exponentDecStringToDecString = exports.isExponentDecString = exports.isValidDecimalString = exports.isValidIntegerString = void 0;
const regexIntString = /^-?\d+$/;
const regexDecString = /^-?\d+.?\d*$/;
const regexExponentDecString = /^(-?)([\d.]+)e([-+])([\d]+)$/;
function isValidIntegerString(str) {
    return regexIntString.test(str);
}
exports.isValidIntegerString = isValidIntegerString;
function isValidDecimalString(str) {
    return regexDecString.test(str);
}
exports.isValidDecimalString = isValidDecimalString;
function isExponentDecString(str) {
    return regexExponentDecString.test(str);
}
exports.isExponentDecString = isExponentDecString;
function makeZerosStr(len) {
    let r = "";
    for(let i = 0; i < len; i++){
        r += "0";
    }
    return r;
}
function removeHeadZeros(str) {
    while(str.length > 0 && str[0] === "0"){
        str = str.slice(1);
    }
    if (str.length === 0 || str[0] === ".") {
        return "0" + str;
    }
    return str;
}
function exponentDecStringToDecString(str) {
    const split = str.split(regexExponentDecString);
    if (split.length !== 6) {
        return str;
    }
    const isNeg = split[1] === "-";
    let numStr = split[2];
    const numStrFractionIndex = numStr.indexOf(".");
    const exponentStr = split[4];
    let exponent = parseInt(exponentStr) * (split[3] === "-" ? -1 : 1);
    if (numStrFractionIndex >= 0) {
        const fractionLen = numStr.length - numStrFractionIndex - 1;
        exponent = exponent - fractionLen;
        numStr = removeHeadZeros(numStr.replace(".", ""));
    }
    const prefix = isNeg ? "-" : "";
    if (exponent < 0) {
        if (numStr.length > -exponent) {
            const fractionPosition = numStr.length + exponent;
            return prefix + (numStr.slice(0, fractionPosition) + "." + numStr.slice(fractionPosition));
        }
        return prefix + "0." + makeZerosStr(-(numStr.length + exponent)) + numStr;
    } else {
        return prefix + numStr + makeZerosStr(exponent);
    }
}
exports.exponentDecStringToDecString = exponentDecStringToDecString; //# sourceMappingURL=etc.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Uint = exports.Int = void 0;
const big_integer_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/big-integer/BigInteger.js [app-client] (ecmascript)"));
const etc_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/etc.js [app-client] (ecmascript)");
class Int {
    /**
     * @param int - Parse a number | bigInteger | string into a bigInt.
     */ constructor(int){
        if (typeof int === "number") {
            int = int.toString();
        }
        if (typeof int === "string") {
            if (!(0, etc_1.isValidIntegerString)(int)) {
                if ((0, etc_1.isExponentDecString)(int)) {
                    int = (0, etc_1.exponentDecStringToDecString)(int);
                } else {
                    throw new Error(`invalid integer: ${int}`);
                }
            }
            this.int = (0, big_integer_1.default)(int);
        } else if (typeof int === "bigint") {
            this.int = (0, big_integer_1.default)(int);
        } else {
            this.int = (0, big_integer_1.default)(int);
        }
        this.checkBitLen();
    }
    checkBitLen() {
        if (this.int.abs().gt(Int.maxInt)) {
            throw new Error(`Integer out of range ${this.int.toString()}`);
        }
    }
    toString() {
        return this.int.toString(10);
    }
    isNegative() {
        return this.int.isNegative();
    }
    isPositive() {
        return this.int.isPositive();
    }
    isZero() {
        return this.int.eq((0, big_integer_1.default)(0));
    }
    equals(i) {
        return this.int.equals(i.int);
    }
    gt(i) {
        return this.int.gt(i.int);
    }
    gte(i) {
        return this.int.greaterOrEquals(i.int);
    }
    lt(i) {
        return this.int.lt(i.int);
    }
    lte(i) {
        return this.int.lesserOrEquals(i.int);
    }
    abs() {
        return new Int(this.int.abs());
    }
    absUInt() {
        return new Uint(this.int.abs());
    }
    add(i) {
        return new Int(this.int.add(i.int));
    }
    sub(i) {
        return new Int(this.int.subtract(i.int));
    }
    mul(i) {
        return new Int(this.int.multiply(i.int));
    }
    div(i) {
        return new Int(this.int.divide(i.int));
    }
    mod(i) {
        return new Int(this.int.mod(i.int));
    }
    neg() {
        return new Int(this.int.negate());
    }
    pow(i) {
        return new Int(this.int.pow(i.toBigNumber()));
    }
    toBigNumber() {
        return this.int;
    }
}
exports.Int = Int;
// (2 ** 256) - 1
Int.maxInt = (0, big_integer_1.default)("115792089237316195423570985008687907853269984665640564039457584007913129639935");
class Uint {
    /**
     * @param uint - Parse a number | bigInteger | string into a bigUint.
     */ constructor(uint){
        if (typeof uint === "number") {
            uint = uint.toString();
        }
        if (typeof uint === "string") {
            if (!(0, etc_1.isValidIntegerString)(uint)) {
                if ((0, etc_1.isExponentDecString)(uint)) {
                    uint = (0, etc_1.exponentDecStringToDecString)(uint);
                } else {
                    throw new Error(`invalid integer: ${uint}`);
                }
            }
            this.uint = (0, big_integer_1.default)(uint);
        } else if (typeof uint === "bigint") {
            this.uint = (0, big_integer_1.default)(uint);
        } else {
            this.uint = (0, big_integer_1.default)(uint);
        }
        if (this.uint.isNegative()) {
            throw new TypeError("Uint should not be negative");
        }
        this.checkBitLen();
    }
    checkBitLen() {
        if (this.uint.abs().bitLength().gt(256)) {
            throw new Error(`Integer out of range ${this.uint.toString()}`);
        }
    }
    toString() {
        return this.uint.toString(10);
    }
    isZero() {
        return this.uint.eq((0, big_integer_1.default)(0));
    }
    equals(i) {
        return this.uint.equals(i.uint);
    }
    gt(i) {
        return this.uint.gt(i.uint);
    }
    gte(i) {
        return this.uint.greaterOrEquals(i.uint);
    }
    lt(i) {
        return this.uint.lt(i.uint);
    }
    lte(i) {
        return this.uint.lesserOrEquals(i.uint);
    }
    add(i) {
        return new Uint(this.uint.add(i.uint));
    }
    sub(i) {
        return new Uint(this.uint.subtract(i.uint));
    }
    mul(i) {
        return new Uint(this.uint.multiply(i.uint));
    }
    div(i) {
        return new Uint(this.uint.divide(i.uint));
    }
    mod(i) {
        return new Uint(this.uint.mod(i.uint));
    }
    pow(i) {
        return new Uint(this.uint.pow(i.toBigNumber()));
    }
    toBigNumber() {
        return this.uint;
    }
}
exports.Uint = Uint; //# sourceMappingURL=int.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/utils.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.integerStringToUSLocaleString = void 0;
/**
 * Change the non-locale integer string to locale string.
 * Only support en-US format.
 * This method uses the BigInt if the environment supports the BigInt.
 * @param numberStr
 */ function integerStringToUSLocaleString(numberStr) {
    if (numberStr.indexOf(".") >= 0) {
        throw new Error(`${numberStr} is not integer`);
    }
    if (typeof BigInt !== "undefined") {
        return BigInt(numberStr).toLocaleString("en-US");
    }
    const integer = numberStr;
    const chunks = [];
    for(let i = integer.length; i > 0; i -= 3){
        chunks.push(integer.slice(Math.max(0, i - 3), i));
    }
    return chunks.reverse().join(",");
}
exports.integerStringToUSLocaleString = integerStringToUSLocaleString; //# sourceMappingURL=utils.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Dec = void 0;
const big_integer_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/big-integer/BigInteger.js [app-client] (ecmascript)"));
const int_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)");
const etc_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/etc.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/utils.js [app-client] (ecmascript)");
class Dec {
    static calcPrecisionMultiplier(prec) {
        if (prec < 0) {
            throw new Error("Invalid prec");
        }
        if (prec > Dec.precision) {
            throw new Error("Too much precision");
        }
        const key = prec.toString();
        const cached = Dec.precisionMultipliers.get(key);
        if (cached) {
            return cached;
        }
        const zerosToAdd = Dec.precision - prec;
        const multiplier = (0, big_integer_1.default)(10).pow(zerosToAdd);
        Dec.precisionMultipliers.set(key, multiplier);
        return multiplier;
    }
    static reduceDecimalsFromString(str) {
        const decimalPointIndex = str.indexOf(".");
        if (decimalPointIndex < 0) {
            return {
                res: str,
                isDownToZero: false
            };
        }
        const exceededDecimals = str.length - 1 - decimalPointIndex - Dec.precision;
        if (exceededDecimals <= 0) {
            return {
                res: str,
                isDownToZero: false
            };
        }
        const res = str.slice(0, str.length - exceededDecimals);
        return {
            res,
            isDownToZero: /^[0.]*$/.test(res)
        };
    }
    /**
     * Create a new Dec from integer with decimal place at prec
     * @param int - Parse a number | bigInteger | string into a Dec.
     * If int is string and contains dot(.), prec is ignored and automatically calculated.
     * @param prec - Precision
     */ constructor(int, prec = 0){
        if (typeof int === "number") {
            int = int.toString();
        }
        if (typeof int === "string") {
            if (int.length === 0) {
                throw new Error("empty string");
            }
            if (!(0, etc_1.isValidDecimalString)(int)) {
                if ((0, etc_1.isExponentDecString)(int)) {
                    int = (0, etc_1.exponentDecStringToDecString)(int);
                } else {
                    throw new Error(`invalid decimal: ${int}`);
                }
            }
            // Even if an input with more than 18 decimals, it does not throw an error and ignores the rest.
            const reduced = Dec.reduceDecimalsFromString(int);
            if (reduced.isDownToZero) {
                // However, as a result, if the input becomes 0, a problem may occur in mul or quo. In this case, print a warning.
                console.log(`WARNING: Got ${int}. Dec can only handle up to 18 decimals. However, since the decimal point of the input exceeds 18 digits, the remainder is discarded. As a result, input becomes 0.`);
            }
            int = reduced.res;
            if (int.indexOf(".") >= 0) {
                prec = int.length - int.indexOf(".") - 1;
                int = int.replace(".", "");
            }
            this.int = (0, big_integer_1.default)(int);
        } else if (int instanceof int_1.Int) {
            this.int = (0, big_integer_1.default)(int.toString());
        } else if (int instanceof int_1.Uint) {
            this.int = (0, big_integer_1.default)(int.toString());
        } else if (typeof int === "bigint") {
            this.int = (0, big_integer_1.default)(int);
        } else {
            this.int = (0, big_integer_1.default)(int);
        }
        this.int = this.int.multiply(Dec.calcPrecisionMultiplier(prec));
        this.checkBitLen();
    }
    checkBitLen() {
        if (this.int.abs().gt(Dec.maxDec)) {
            throw new Error(`Integer out of range ${this.int.toString()}`);
        }
    }
    isZero() {
        return this.int.eq((0, big_integer_1.default)(0));
    }
    isNegative() {
        return this.int.isNegative();
    }
    isPositive() {
        return this.int.isPositive();
    }
    equals(d2) {
        return this.int.eq(d2.int);
    }
    /**
     * Alias for the greater method.
     */ gt(d2) {
        return this.int.gt(d2.int);
    }
    /**
     * Alias for the greaterOrEquals method.
     */ gte(d2) {
        return this.int.geq(d2.int);
    }
    /**
     * Alias for the lesser method.
     */ lt(d2) {
        return this.int.lt(d2.int);
    }
    /**
     * Alias for the lesserOrEquals method.
     */ lte(d2) {
        return this.int.leq(d2.int);
    }
    /**
     * reverse the decimal sign.
     */ neg() {
        return new Dec(this.int.negate(), Dec.precision);
    }
    /**
     * Returns the absolute value of a decimals.
     */ abs() {
        return new Dec(this.int.abs(), Dec.precision);
    }
    add(d2) {
        return new Dec(this.int.add(d2.int), Dec.precision);
    }
    sub(d2) {
        return new Dec(this.int.subtract(d2.int), Dec.precision);
    }
    pow(n) {
        if (n.isZero()) {
            return new Dec(1);
        }
        if (n.isNegative()) {
            return new Dec(1).quo(this.pow(n.abs()));
        }
        let base = new Dec(this.int, Dec.precision);
        let tmp = new Dec(1);
        for(let i = n; i.gt(new int_1.Int(1)); i = i.div(new int_1.Int(2))){
            if (!i.mod(new int_1.Int(2)).isZero()) {
                tmp = tmp.mul(base);
            }
            base = base.mul(base);
        }
        return base.mul(tmp);
    }
    approxSqrt() {
        return this.approxRoot(2);
    }
    approxRoot(root, maxIters = 300) {
        if (this.isNegative()) {
            return this.neg().approxRoot(root).neg();
        }
        if (root === 1 || this.isZero() || this.equals(Dec.one)) {
            return this;
        }
        if (root === 0) {
            return Dec.one;
        }
        let [guess, delta] = [
            Dec.one,
            Dec.one
        ];
        for(let i = 0; delta.abs().gt(Dec.smallestDec) && i < maxIters; i++){
            let prev = guess.pow(new int_1.Int(root - 1));
            if (prev.isZero()) {
                prev = Dec.smallestDec;
            }
            delta = this.quo(prev);
            delta = delta.sub(guess);
            delta = delta.quoTruncate(new Dec(root));
            guess = guess.add(delta);
        }
        return guess;
    }
    mul(d2) {
        return new Dec(this.mulRaw(d2).chopPrecisionAndRound(), Dec.precision);
    }
    mulTruncate(d2) {
        return new Dec(this.mulRaw(d2).chopPrecisionAndTruncate(), Dec.precision);
    }
    mulRoundUp(d2) {
        return new Dec(this.mulRaw(d2).chopPrecisionAndRoundUp(), Dec.precision);
    }
    mulRaw(d2) {
        return new Dec(this.int.multiply(d2.int), Dec.precision);
    }
    quo(d2) {
        return new Dec(this.quoRaw(d2).chopPrecisionAndRound(), Dec.precision);
    }
    quoTruncate(d2) {
        return new Dec(this.quoRaw(d2).chopPrecisionAndTruncate(), Dec.precision);
    }
    quoRoundUp(d2) {
        return new Dec(this.quoRaw(d2).chopPrecisionAndRoundUp(), Dec.precision);
    }
    quoRaw(d2) {
        const precision = Dec.calcPrecisionMultiplier(0);
        // multiply precision twice
        const mul = this.int.multiply(precision).multiply(precision);
        return new Dec(mul.divide(d2.int), Dec.precision);
    }
    isInteger() {
        const precision = Dec.calcPrecisionMultiplier(0);
        return this.int.remainder(precision).equals((0, big_integer_1.default)(0));
    }
    /**
     * Remove a Precision amount of rightmost digits and perform bankers rounding
     * on the remainder (gaussian rounding) on the digits which have been removed.
     */ chopPrecisionAndRound() {
        // Remove the negative and add it back when returning
        if (this.isNegative()) {
            const absoulteDec = this.abs();
            const choped = absoulteDec.chopPrecisionAndRound();
            return choped.negate();
        }
        const precision = Dec.calcPrecisionMultiplier(0);
        const fivePrecision = precision.divide((0, big_integer_1.default)(2));
        // Get the truncated quotient and remainder
        const { quotient, remainder } = this.int.divmod(precision);
        // If remainder is zero
        if (remainder.equals((0, big_integer_1.default)(0))) {
            return quotient;
        }
        if (remainder.lt(fivePrecision)) {
            return quotient;
        } else if (remainder.gt(fivePrecision)) {
            return quotient.add((0, big_integer_1.default)(1));
        } else {
            // always round to an even number
            if (quotient.divide((0, big_integer_1.default)(2)).equals((0, big_integer_1.default)(0))) {
                return quotient;
            } else {
                return quotient.add((0, big_integer_1.default)(1));
            }
        }
    }
    chopPrecisionAndRoundUp() {
        // Remove the negative and add it back when returning
        if (this.isNegative()) {
            const absoulteDec = this.abs();
            // truncate since d is negative...
            const choped = absoulteDec.chopPrecisionAndTruncate();
            return choped.negate();
        }
        const precision = Dec.calcPrecisionMultiplier(0);
        // Get the truncated quotient and remainder
        const { quotient, remainder } = this.int.divmod(precision);
        // If remainder is zero
        if (remainder.equals((0, big_integer_1.default)(0))) {
            return quotient;
        }
        return quotient.add((0, big_integer_1.default)(1));
    }
    /**
     * Similar to chopPrecisionAndRound, but always rounds down
     */ chopPrecisionAndTruncate() {
        const precision = Dec.calcPrecisionMultiplier(0);
        return this.int.divide(precision);
    }
    toString(prec = Dec.precision, locale = false) {
        const precision = Dec.calcPrecisionMultiplier(0);
        const int = this.int.abs();
        const { quotient: integer, remainder: fraction } = int.divmod(precision);
        let fractionStr = fraction.toString(10);
        for(let i = 0, l = fractionStr.length; i < Dec.precision - l; i++){
            fractionStr = "0" + fractionStr;
        }
        fractionStr = fractionStr.substring(0, prec);
        const isNegative = this.isNegative() && !(integer.eq((0, big_integer_1.default)(0)) && fractionStr.length === 0);
        const integerStr = locale ? (0, utils_1.integerStringToUSLocaleString)(integer.toString()) : integer.toString();
        return `${isNegative ? "-" : ""}${integerStr}${fractionStr.length > 0 ? "." + fractionStr : ""}`;
    }
    round() {
        return new int_1.Int(this.chopPrecisionAndRound());
    }
    roundUp() {
        return new int_1.Int(this.chopPrecisionAndRoundUp());
    }
    truncate() {
        return new int_1.Int(this.chopPrecisionAndTruncate());
    }
    roundDec() {
        return new Dec(this.chopPrecisionAndRound(), 0);
    }
    roundUpDec() {
        return new Dec(this.chopPrecisionAndRoundUp(), 0);
    }
    truncateDec() {
        return new Dec(this.chopPrecisionAndTruncate(), 0);
    }
}
exports.Dec = Dec;
Dec.precision = 18;
// Bytes required to represent the above precision is 18.
// Ceiling[Log2[999 999 999 999 999 999]]
Dec.decimalPrecisionBits = 60;
// Max bit length for `Dec` is 256 + 60(decimalPrecisionBits)
// The int in the `Dec` is handled as integer assuming that it has 18 precision.
// (2 ** (256 + 60) - 1)
Dec.maxDec = (0, big_integer_1.default)("133499189745056880149688856635597007162669032647290798121690100488888732861290034376435130433535");
Dec.precisionMultipliers = new Map();
Dec.zero = new Dec(0);
/** Smallest `Dec` with current precision. */ Dec.smallestDec = new Dec("1", Dec.precision);
Dec.one = new Dec(1);
int_1.Int.prototype.toDec = function() {
    return new Dec(this);
};
int_1.Uint.prototype.toDec = function() {
    return new Dec(this);
}; //# sourceMappingURL=decimal.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DecUtils = void 0;
const decimal_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)");
const int_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)");
class DecUtils {
    static trim(dec) {
        let decStr = typeof dec === "string" ? dec : dec.toString();
        if (decStr.indexOf(".") < 0) {
            return decStr;
        }
        for(let i = decStr.length - 1; i >= 0; i--){
            if (decStr[i] === "0") {
                decStr = decStr.slice(0, i);
            } else {
                break;
            }
        }
        if (decStr.length > 0) {
            if (decStr[decStr.length - 1] === ".") {
                decStr = decStr.slice(0, decStr.length - 1);
            }
        }
        return decStr;
    }
    static getTenExponentN(n) {
        if (n < -decimal_1.Dec.precision) {
            // Dec can only handle up to precision 18.
            // Anything less than 18 precision is 0, so there is a high probability of an error.
            throw new Error("Too little precision");
        }
        if (DecUtils.tenExponentNs[n.toString()]) {
            return DecUtils.tenExponentNs[n.toString()];
        }
        const dec = new decimal_1.Dec(10).pow(new int_1.Int(n));
        DecUtils.tenExponentNs[n.toString()] = dec;
        return dec;
    }
    static getTenExponentNInPrecisionRange(n) {
        if (n > decimal_1.Dec.precision) {
            throw new Error("Too much precision");
        }
        return DecUtils.getTenExponentN(n);
    }
    /**
     * @deprecated Use`getTenExponentNInPrecisionRange`
     */ static getPrecisionDec(precision) {
        return DecUtils.getTenExponentNInPrecisionRange(precision);
    }
}
exports.DecUtils = DecUtils;
DecUtils.tenExponentNs = {}; //# sourceMappingURL=dec-utils.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/coin.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Coin = void 0;
const int_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)");
class Coin {
    static parse(str) {
        const re = new RegExp("([0-9]+)[ ]*([a-zA-Z]+)$");
        const execed = re.exec(str);
        if (!execed || execed.length !== 3) {
            throw new Error("Invalid coin str");
        }
        const denom = execed[2];
        const amount = execed[1];
        return new Coin(denom, amount);
    }
    constructor(denom, amount){
        this.denom = denom;
        this.amount = amount instanceof int_1.Int ? amount : new int_1.Int(amount);
    }
    toString() {
        return `${this.amount.toString()}${this.denom}`;
    }
}
exports.Coin = Coin; //# sourceMappingURL=coin.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/coin-utils.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CoinUtils = void 0;
const coin_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/coin.js [app-client] (ecmascript)");
const int_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)");
const decimal_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)");
const dec_utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/utils.js [app-client] (ecmascript)");
class CoinUtils {
    static createCoinsFromPrimitives(coinPrimitives) {
        return coinPrimitives.map((primitive)=>{
            return new coin_1.Coin(primitive.denom, primitive.amount);
        });
    }
    static amountOf(coins, denom) {
        const coin = coins.find((coin)=>{
            return coin.denom === denom;
        });
        if (!coin) {
            return new int_1.Int(0);
        } else {
            return coin.amount;
        }
    }
    static exclude(coins, demons) {
        return coins.filter((coin)=>{
            return demons.indexOf(coin.denom) === 0;
        });
    }
    static concat(...coins) {
        if (coins.length === 0) {
            return [];
        }
        const arr = coins.slice();
        const reducer = (accumulator, coin)=>{
            // Find the duplicated denom.
            const find = accumulator.find((c)=>c.denom === coin.denom);
            // If duplicated coin exists, add the amount to duplicated one.
            if (find) {
                const newCoin = new coin_1.Coin(find.denom, find.amount.add(coin.amount));
                accumulator.push(newCoin);
            } else {
                const newCoin = new coin_1.Coin(coin.denom, coin.amount);
                accumulator.push(newCoin);
            }
            return accumulator;
        };
        return arr.reduce(reducer, []);
    }
    static getCoinFromDecimals(currencies, decAmountStr, denom) {
        const currency = currencies.find((currency)=>{
            return currency.coinDenom === denom;
        });
        if (!currency) {
            throw new Error("Invalid currency");
        }
        let precision = new decimal_1.Dec(1);
        for(let i = 0; i < currency.coinDecimals; i++){
            precision = precision.mul(new decimal_1.Dec(10));
        }
        let decAmount = new decimal_1.Dec(decAmountStr);
        decAmount = decAmount.mul(precision);
        if (!new decimal_1.Dec(decAmount.truncate()).equals(decAmount)) {
            throw new Error("Can't divide anymore");
        }
        return new coin_1.Coin(currency.coinMinimalDenom, decAmount.truncate());
    }
    static parseDecAndDenomFromCoin(currencies, coin) {
        let currency = currencies.find((currency)=>{
            return currency.coinMinimalDenom === coin.denom;
        });
        if (!currency) {
            // If the currency is unknown, just use the raw currency.
            currency = {
                coinDecimals: 0,
                coinDenom: coin.denom,
                coinMinimalDenom: coin.denom
            };
        }
        let precision = new decimal_1.Dec(1);
        for(let i = 0; i < currency.coinDecimals; i++){
            precision = precision.mul(new decimal_1.Dec(10));
        }
        const decAmount = new decimal_1.Dec(coin.amount).quoTruncate(precision);
        return {
            amount: decAmount.toString(currency.coinDecimals),
            denom: currency.coinDenom
        };
    }
    static shrinkDecimals(dec, minDecimals, maxDecimals, locale = false) {
        if (dec.equals(new decimal_1.Dec(0))) {
            return "0";
        }
        const isNeg = dec.isNegative();
        const integer = dec.abs().truncate();
        const fraction = dec.abs().sub(new decimal_1.Dec(integer));
        const decimals = Math.max(maxDecimals - integer.toString().length + 1, minDecimals);
        const fractionStr = decimals === 0 ? "" : fraction.toString(decimals).replace("0.", "");
        const integerStr = locale ? CoinUtils.integerStringToUSLocaleString(integer.toString()) : integer.toString();
        return (isNeg ? "-" : "") + integerStr + (fractionStr.length > 0 ? "." : "") + fractionStr;
    }
    static coinToTrimmedString(coin, currency, separator = " ") {
        const dec = new decimal_1.Dec(coin.amount).quoTruncate(dec_utils_1.DecUtils.getPrecisionDec(currency.coinDecimals));
        return `${dec_utils_1.DecUtils.trim(dec)}${separator}${currency.coinDenom}`;
    }
}
exports.CoinUtils = CoinUtils;
CoinUtils.integerStringToUSLocaleString = utils_1.integerStringToUSLocaleString; //# sourceMappingURL=coin-utils.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/int-pretty.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.IntPretty = void 0;
const int_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)");
const decimal_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)");
const dec_utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)");
const coin_utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/coin-utils.js [app-client] (ecmascript)");
class IntPretty {
    constructor(num){
        this.floatingDecimalPointRight = 0;
        this._options = {
            maxDecimals: 0,
            trim: false,
            shrink: false,
            ready: true,
            locale: true,
            inequalitySymbol: false,
            inequalitySymbolSeparator: " "
        };
        if (typeof num === "object" && "toDec" in num) {
            num = num.toDec();
        } else if (!(num instanceof decimal_1.Dec)) {
            num = new decimal_1.Dec(num);
        }
        if (num.isZero()) {
            this.dec = num;
            return;
        }
        let dec = num;
        let decPrecision = 0;
        for(let i = 0; i < 18; i++){
            if (!dec.truncate().equals(new int_1.Int(0)) && dec.equals(new decimal_1.Dec(dec.truncate()))) {
                break;
            }
            dec = dec.mul(new decimal_1.Dec(10));
            decPrecision++;
        }
        this.dec = num;
        this._options.maxDecimals = decPrecision;
    }
    get options() {
        return this._options;
    }
    moveDecimalPointLeft(delta) {
        const pretty = this.clone();
        pretty.floatingDecimalPointRight += -delta;
        return pretty;
    }
    moveDecimalPointRight(delta) {
        const pretty = this.clone();
        pretty.floatingDecimalPointRight += delta;
        return pretty;
    }
    /**
     * @deprecated Use`moveDecimalPointLeft`
     */ increasePrecision(delta) {
        return this.moveDecimalPointLeft(delta);
    }
    /**
     * @deprecated Use`moveDecimalPointRight`
     */ decreasePrecision(delta) {
        return this.moveDecimalPointRight(delta);
    }
    maxDecimals(max) {
        const pretty = this.clone();
        pretty._options.maxDecimals = max;
        return pretty;
    }
    inequalitySymbol(bool) {
        const pretty = this.clone();
        pretty._options.inequalitySymbol = bool;
        return pretty;
    }
    inequalitySymbolSeparator(str) {
        const pretty = this.clone();
        pretty._options.inequalitySymbolSeparator = str;
        return pretty;
    }
    trim(bool) {
        const pretty = this.clone();
        pretty._options.trim = bool;
        return pretty;
    }
    shrink(bool) {
        const pretty = this.clone();
        pretty._options.shrink = bool;
        return pretty;
    }
    locale(locale) {
        const pretty = this.clone();
        pretty._options.locale = locale;
        return pretty;
    }
    /**
     * Ready indicates the actual value is ready to show the users.
     * Even if the ready option is false, it expects that the value can be shown to users (probably as 0).
     * The method that returns prettied value may return `undefined` or `null` if the value is not ready.
     * But, alternatively, it can return the 0 value that can be shown the users anyway, but indicates that the value is not ready.
     * @param bool
     */ ready(bool) {
        const pretty = this.clone();
        pretty._options.ready = bool;
        return pretty;
    }
    get isReady() {
        return this._options.ready;
    }
    add(target) {
        if (!(target instanceof decimal_1.Dec)) {
            target = target.toDec();
        }
        const pretty = new IntPretty(this.toDec().add(target));
        pretty._options = Object.assign({}, this._options);
        return pretty;
    }
    sub(target) {
        if (!(target instanceof decimal_1.Dec)) {
            target = target.toDec();
        }
        const pretty = new IntPretty(this.toDec().sub(target));
        pretty._options = Object.assign({}, this._options);
        return pretty;
    }
    mul(target) {
        if (!(target instanceof decimal_1.Dec)) {
            target = target.toDec();
        }
        const pretty = new IntPretty(this.toDec().mul(target));
        pretty._options = Object.assign({}, this._options);
        return pretty;
    }
    quo(target) {
        if (!(target instanceof decimal_1.Dec)) {
            target = target.toDec();
        }
        const pretty = new IntPretty(this.toDec().quo(target));
        pretty._options = Object.assign({}, this._options);
        return pretty;
    }
    toDec() {
        if (this.floatingDecimalPointRight === 0) {
            return this.dec;
        } else if (this.floatingDecimalPointRight > 0) {
            return this.dec.mulTruncate(dec_utils_1.DecUtils.getTenExponentN(this.floatingDecimalPointRight));
        } else {
            // Since a decimal in Dec cannot exceed 18, it cannot be computed at once.
            let i = -this.floatingDecimalPointRight;
            let dec = this.dec;
            while(i > 0){
                if (i >= decimal_1.Dec.precision) {
                    dec = dec.mulTruncate(dec_utils_1.DecUtils.getTenExponentN(-decimal_1.Dec.precision));
                    i -= decimal_1.Dec.precision;
                } else {
                    dec = dec.mulTruncate(dec_utils_1.DecUtils.getTenExponentN(-(i % decimal_1.Dec.precision)));
                    break;
                }
            }
            return dec;
        }
    }
    toString() {
        return this.toStringWithSymbols("", "");
    }
    toStringWithSymbols(prefix, suffix) {
        const dec = this.toDec();
        if (this._options.inequalitySymbol && !dec.isZero() && dec.abs().lt(dec_utils_1.DecUtils.getTenExponentN(-this._options.maxDecimals))) {
            const isNeg = dec.isNegative();
            return `${isNeg ? ">" : "<"}${this._options.inequalitySymbolSeparator}${isNeg ? "-" : ""}${prefix}${dec_utils_1.DecUtils.getTenExponentN(-this._options.maxDecimals).toString(this._options.maxDecimals, this._options.locale)}${suffix}`;
        }
        let result;
        if (!this._options.shrink) {
            result = dec.toString(this._options.maxDecimals, this._options.locale);
        } else {
            result = coin_utils_1.CoinUtils.shrinkDecimals(dec, 0, this._options.maxDecimals, this._options.locale);
        }
        if (this._options.trim) {
            result = dec_utils_1.DecUtils.trim(result);
        }
        const isNeg = result.charAt(0) === "-";
        if (isNeg) {
            result = result.slice(1);
        }
        return `${isNeg ? "-" : ""}${prefix}${result}${suffix}`;
    }
    clone() {
        const pretty = new IntPretty(this.dec);
        pretty.dec = this.dec;
        pretty.floatingDecimalPointRight = this.floatingDecimalPointRight;
        pretty._options = Object.assign({}, this._options);
        return pretty;
    }
}
exports.IntPretty = IntPretty; //# sourceMappingURL=int-pretty.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/coin-pretty.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CoinPretty = void 0;
const int_pretty_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int-pretty.js [app-client] (ecmascript)");
const decimal_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)");
const dec_utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)");
class CoinPretty {
    constructor(_currency, amount){
        this._currency = _currency;
        this._options = {
            separator: " ",
            upperCase: false,
            lowerCase: false,
            hideDenom: false,
            hideIBCMetadata: false
        };
        if (typeof amount === "object" && "toDec" in amount) {
            amount = amount.toDec();
        } else if (!(amount instanceof decimal_1.Dec)) {
            amount = new decimal_1.Dec(amount);
        }
        this.intPretty = new int_pretty_1.IntPretty(amount.quoTruncate(dec_utils_1.DecUtils.getTenExponentNInPrecisionRange(_currency.coinDecimals))).maxDecimals(_currency.coinDecimals);
    }
    get options() {
        return Object.assign(Object.assign({}, this._options), this.intPretty.options);
    }
    get denom() {
        return this.currency.coinDenom;
    }
    get currency() {
        return this._currency;
    }
    setCurrency(currency) {
        const pretty = this.clone();
        pretty.intPretty = this.intPretty.moveDecimalPointRight(this._currency.coinDecimals - currency.coinDecimals);
        pretty._currency = currency;
        return pretty;
    }
    separator(str) {
        const pretty = this.clone();
        pretty._options.separator = str;
        return pretty;
    }
    upperCase(bool) {
        const pretty = this.clone();
        pretty._options.upperCase = bool;
        pretty._options.lowerCase = !bool;
        return pretty;
    }
    lowerCase(bool) {
        const pretty = this.clone();
        pretty._options.lowerCase = bool;
        pretty._options.upperCase = !bool;
        return pretty;
    }
    hideDenom(bool) {
        const pretty = this.clone();
        pretty._options.hideDenom = bool;
        return pretty;
    }
    hideIBCMetadata(bool) {
        const pretty = this.clone();
        pretty._options.hideIBCMetadata = bool;
        return pretty;
    }
    moveDecimalPointLeft(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointLeft(delta);
        return pretty;
    }
    moveDecimalPointRight(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointRight(delta);
        return pretty;
    }
    /**
     * @deprecated Use`moveDecimalPointLeft`
     */ increasePrecision(delta) {
        return this.moveDecimalPointLeft(delta);
    }
    /**
     * @deprecated Use`moveDecimalPointRight`
     */ decreasePrecision(delta) {
        return this.moveDecimalPointRight(delta);
    }
    maxDecimals(max) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.maxDecimals(max);
        return pretty;
    }
    inequalitySymbol(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbol(bool);
        return pretty;
    }
    inequalitySymbolSeparator(str) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbolSeparator(str);
        return pretty;
    }
    trim(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.trim(bool);
        return pretty;
    }
    shrink(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.shrink(bool);
        return pretty;
    }
    locale(locale) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.locale(locale);
        return pretty;
    }
    /**
     * Ready indicates the actual value is ready to show the users.
     * Even if the ready option is false, it expects that the value can be shown to users (probably as 0).
     * The method that returns prettied value may return `undefined` or `null` if the value is not ready.
     * But, alternatively, it can return the 0 value that can be shown the users anyway, but indicates that the value is not ready.
     * @param bool
     */ ready(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.ready(bool);
        return pretty;
    }
    get isReady() {
        return this.intPretty.isReady;
    }
    add(target) {
        const isCoinPretty = target instanceof CoinPretty;
        if (isCoinPretty) {
            // If target is `CoinPretty` and it has different denom, do nothing.
            if ("currency" in target && this.currency.coinMinimalDenom !== target.currency.coinMinimalDenom) {
                return this.clone();
            }
        }
        if ("toDec" in target) {
            target = target.toDec();
        }
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.add(isCoinPretty ? target : target.mul(dec_utils_1.DecUtils.getTenExponentNInPrecisionRange(-this._currency.coinDecimals)));
        return pretty;
    }
    sub(target) {
        const isCoinPretty = target instanceof CoinPretty;
        if (isCoinPretty) {
            // If target is `CoinPretty` and it has different denom, do nothing.
            if ("currency" in target && this.currency.coinMinimalDenom !== target.currency.coinMinimalDenom) {
                return this.clone();
            }
        }
        if ("toDec" in target) {
            target = target.toDec();
        }
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.sub(isCoinPretty ? target : target.mul(dec_utils_1.DecUtils.getTenExponentNInPrecisionRange(-this._currency.coinDecimals)));
        return pretty;
    }
    mul(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.mul(target);
        return pretty;
    }
    quo(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.quo(target);
        return pretty;
    }
    toDec() {
        return this.intPretty.toDec();
    }
    toCoin() {
        const amount = this.toDec().mulTruncate(dec_utils_1.DecUtils.getTenExponentNInPrecisionRange(this.currency.coinDecimals)).truncate();
        return {
            denom: this.currency.coinMinimalDenom,
            amount: amount.toString()
        };
    }
    toString() {
        let denom = this.denom;
        if (this._options.hideIBCMetadata && "originCurrency" in this.currency && this.currency.originCurrency) {
            denom = this.currency.originCurrency.coinDenom;
        }
        if (this._options.upperCase) {
            denom = denom.toUpperCase();
        }
        if (this._options.lowerCase) {
            denom = denom.toLowerCase();
        }
        let separator = this._options.separator;
        if (this._options.hideDenom) {
            denom = "";
            separator = "";
        }
        return this.intPretty.toStringWithSymbols("", `${separator}${denom}`);
    }
    clone() {
        const pretty = new CoinPretty(this._currency, 0);
        pretty._options = Object.assign({}, this._options);
        pretty.intPretty = this.intPretty.clone();
        return pretty;
    }
}
exports.CoinPretty = CoinPretty; //# sourceMappingURL=coin-pretty.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/price-pretty.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PricePretty = void 0;
const int_pretty_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int-pretty.js [app-client] (ecmascript)");
const dec_utils_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)");
class PricePretty {
    constructor(_fiatCurrency, amount){
        this._fiatCurrency = _fiatCurrency;
        this._options = {
            separator: "",
            upperCase: false,
            lowerCase: false,
            locale: "en-US"
        };
        this.intPretty = new int_pretty_1.IntPretty(amount).maxDecimals(_fiatCurrency.maxDecimals).shrink(true).trim(true).locale(false).inequalitySymbol(true);
        this._options.locale = _fiatCurrency.locale;
    }
    get options() {
        return Object.assign(Object.assign({}, this.intPretty.options), this._options);
    }
    get symbol() {
        return this._fiatCurrency.symbol;
    }
    get fiatCurrency() {
        return this._fiatCurrency;
    }
    separator(str) {
        const pretty = this.clone();
        pretty._options.separator = str;
        return pretty;
    }
    upperCase(bool) {
        const pretty = this.clone();
        pretty._options.upperCase = bool;
        pretty._options.lowerCase = !bool;
        return pretty;
    }
    lowerCase(bool) {
        const pretty = this.clone();
        pretty._options.lowerCase = bool;
        pretty._options.upperCase = !bool;
        return pretty;
    }
    moveDecimalPointLeft(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointLeft(delta);
        return pretty;
    }
    moveDecimalPointRight(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointRight(delta);
        return pretty;
    }
    /**
     * @deprecated Use`moveDecimalPointLeft`
     */ increasePrecision(delta) {
        return this.moveDecimalPointLeft(delta);
    }
    /**
     * @deprecated Use`moveDecimalPointRight`
     */ decreasePrecision(delta) {
        return this.moveDecimalPointRight(delta);
    }
    maxDecimals(max) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.maxDecimals(max);
        return pretty;
    }
    inequalitySymbol(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbol(bool);
        return pretty;
    }
    inequalitySymbolSeparator(str) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbolSeparator(str);
        return pretty;
    }
    trim(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.trim(bool);
        return pretty;
    }
    shrink(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.shrink(bool);
        return pretty;
    }
    locale(locale) {
        const pretty = this.clone();
        pretty._options.locale = locale;
        return pretty;
    }
    /**
     * Ready indicates the actual value is ready to show the users.
     * Even if the ready option is false, it expects that the value can be shown to users (probably as 0).
     * The method that returns prettied value may return `undefined` or `null` if the value is not ready.
     * But, alternatively, it can return the 0 value that can be shown the users anyway, but indicates that the value is not ready.
     * @param bool
     */ ready(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.ready(bool);
        return pretty;
    }
    get isReady() {
        return this.intPretty.isReady;
    }
    add(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.add(target);
        return pretty;
    }
    sub(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.sub(target);
        return pretty;
    }
    mul(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.mul(target);
        return pretty;
    }
    quo(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.quo(target);
        return pretty;
    }
    toDec() {
        return this.intPretty.toDec();
    }
    toString() {
        let symbol = this.symbol;
        if (this._options.upperCase) {
            symbol = symbol.toUpperCase();
        }
        if (this._options.lowerCase) {
            symbol = symbol.toLowerCase();
        }
        const dec = this.toDec();
        const options = this.options;
        if (options.inequalitySymbol && !dec.isZero() && dec.abs().lt(dec_utils_1.DecUtils.getTenExponentN(-options.maxDecimals))) {
            return this.intPretty.toStringWithSymbols(`${symbol}${this._options.separator}`, "");
        }
        let localeString = parseFloat(this.intPretty.toString()).toLocaleString(options.locale, {
            maximumFractionDigits: options.maxDecimals
        });
        const isNeg = localeString.charAt(0) === "-";
        if (isNeg) {
            localeString = localeString.slice(1);
        }
        return `${isNeg ? "-" : ""}${symbol}${this._options.separator}${localeString}`;
    }
    clone() {
        const pretty = new PricePretty(this._fiatCurrency, 0);
        pretty._options = Object.assign({}, this._options);
        pretty.intPretty = this.intPretty.clone();
        return pretty;
    }
}
exports.PricePretty = PricePretty; //# sourceMappingURL=price-pretty.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/rate-pretty.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RatePretty = void 0;
const int_pretty_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int-pretty.js [app-client] (ecmascript)");
/**
 * RatePretty treats `Dec` in rate form for easy calculation, and displays it as a percentage to the user by using toString().
 * By default, if the value is less than maxDeciamls, it is displayed using an inequality sign (Ex. < 0.001%)
 */ class RatePretty {
    constructor(amount){
        this._options = {
            separator: "",
            symbol: "%"
        };
        this.intPretty = new int_pretty_1.IntPretty(amount);
        this.intPretty = this.intPretty.maxDecimals(3).shrink(false).trim(true).locale(true).inequalitySymbol(true);
    }
    get options() {
        return Object.assign(Object.assign({}, this.intPretty.options), this._options);
    }
    separator(str) {
        const pretty = this.clone();
        pretty._options.separator = str;
        return pretty;
    }
    symbol(str) {
        const pretty = this.clone();
        pretty._options.symbol = str;
        return pretty;
    }
    moveDecimalPointLeft(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointLeft(delta);
        return pretty;
    }
    moveDecimalPointRight(delta) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.moveDecimalPointRight(delta);
        return pretty;
    }
    maxDecimals(max) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.maxDecimals(max);
        return pretty;
    }
    inequalitySymbol(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbol(bool);
        return pretty;
    }
    inequalitySymbolSeparator(str) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.inequalitySymbolSeparator(str);
        return pretty;
    }
    trim(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.trim(bool);
        return pretty;
    }
    shrink(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.shrink(bool);
        return pretty;
    }
    locale(locale) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.locale(locale);
        return pretty;
    }
    /**
     * Ready indicates the actual value is ready to show the users.
     * Even if the ready option is false, it expects that the value can be shown to users (probably as 0).
     * The method that returns prettied value may return `undefined` or `null` if the value is not ready.
     * But, alternatively, it can return the 0 value that can be shown the users anyway, but indicates that the value is not ready.
     * @param bool
     */ ready(bool) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.ready(bool);
        return pretty;
    }
    get isReady() {
        return this.intPretty.isReady;
    }
    add(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.add(target);
        return pretty;
    }
    sub(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.sub(target);
        return pretty;
    }
    mul(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.mul(target);
        return pretty;
    }
    quo(target) {
        const pretty = this.clone();
        pretty.intPretty = pretty.intPretty.quo(target);
        return pretty;
    }
    toDec() {
        return this.intPretty.toDec();
    }
    toString() {
        return this.intPretty.moveDecimalPointRight(2).toStringWithSymbols("", `${this._options.separator}${this._options.symbol}`);
    }
    clone() {
        const pretty = new RatePretty(0);
        pretty._options = Object.assign({}, this._options);
        pretty.intPretty = this.intPretty.clone();
        return pretty;
    }
}
exports.RatePretty = RatePretty; //# sourceMappingURL=rate-pretty.js.map
}}),
"[project]/node_modules/@keplr-wallet/unit/build/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int-pretty.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/coin-pretty.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/coin.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/int.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/decimal.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/coin-utils.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/dec-utils.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/price-pretty.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/rate-pretty.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/simple-fetch/build/error.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isSimpleFetchError = exports.SimpleFetchError = void 0;
class SimpleFetchError extends Error {
    constructor(baseURL, url, response){
        super(`Failed to get response from ${new URL(url, baseURL).toString()}`);
        this.baseURL = baseURL;
        this.url = url;
        this.response = response;
        // Set the prototype explicitly.
        Object.setPrototypeOf(this, SimpleFetchError.prototype);
    }
}
exports.SimpleFetchError = SimpleFetchError;
function isSimpleFetchError(payload) {
    return payload instanceof SimpleFetchError;
}
exports.isSimpleFetchError = isSimpleFetchError; //# sourceMappingURL=error.js.map
}}),
"[project]/node_modules/@keplr-wallet/simple-fetch/build/fetch.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = this && this.__rest || function(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.simpleFetch = exports.makeURL = void 0;
const error_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/simple-fetch/build/error.js [app-client] (ecmascript)");
function makeURL(baseURL, url) {
    const baseURLInstance = new URL(baseURL);
    baseURL = removeLastSlashIfIs(baseURLInstance.origin);
    url = removeLastSlashIfIs(baseURLInstance.pathname) + "/" + removeFirstSlashIfIs(url);
    return removeLastSlashIfIs(baseURL + "/" + removeFirstSlashIfIs(url));
}
exports.makeURL = makeURL;
function removeFirstSlashIfIs(str) {
    if (str.length > 0 && str[0] === "/") {
        return str.slice(1);
    }
    return str;
}
function removeLastSlashIfIs(str) {
    if (str.length > 0 && str[str.length - 1] === "/") {
        return str.slice(0, str.length - 1);
    }
    return str;
}
function simpleFetch(baseURL, url, options) {
    return __awaiter(this, void 0, void 0, function*() {
        if (typeof url !== "string") {
            if (url) {
                options = url;
            }
            url = "";
        }
        if (url === "/") {
            // If url is "/", probably its mean should be to use only base url.
            // However, `URL` with "/" url generate the root url with removing trailing url from base url.
            // To prevent this invalid case, just handle "/" as "".
            url = "";
        }
        const actualURL = makeURL(baseURL, url);
        const _a = options || {}, { headers: optionHeaders } = _a, otherOptions = __rest(_a, [
            "headers"
        ]);
        const fetched = yield fetch(actualURL, Object.assign({
            headers: Object.assign({
                accept: "application/json, text/plain, */*"
            }, optionHeaders)
        }, otherOptions));
        let data;
        const contentType = fetched.headers.get("content-type") || "";
        if (contentType.startsWith("application/json")) {
            data = yield fetched.json();
        } else {
            const r = yield fetched.text();
            const trim = r.trim();
            if (trim.startsWith("{") && trim.endsWith("}")) {
                data = JSON.parse(trim);
            } else {
                data = r;
            }
        }
        const res = {
            url: actualURL,
            data,
            headers: fetched.headers,
            status: fetched.status,
            statusText: fetched.statusText
        };
        const validateStatusFn = (options === null || options === void 0 ? void 0 : options.validateStatus) || defaultValidateStatusFn;
        if (!validateStatusFn(fetched.status)) {
            throw new error_1.SimpleFetchError(baseURL, url, res);
        }
        return res;
    });
}
exports.simpleFetch = simpleFetch;
function defaultValidateStatusFn(status) {
    return status === 200;
} //# sourceMappingURL=fetch.js.map
}}),
"[project]/node_modules/@keplr-wallet/simple-fetch/build/types.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=types.js.map
}}),
"[project]/node_modules/@keplr-wallet/simple-fetch/build/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/simple-fetch/build/fetch.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/simple-fetch/build/error.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/simple-fetch/build/types.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/account/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseAccount = void 0;
const unit_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/unit/build/index.js [app-client] (ecmascript)");
const simple_fetch_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/simple-fetch/build/index.js [app-client] (ecmascript)");
class BaseAccount {
    static fetchFromRest(rest, address, // If the account doesn't exist, the result from `auth/accounts` would not have the address.
    // In this case, if `defaultBech32Address` param is provided, this will use it instead of the result from rest.
    defaultBech32Address = false) {
        return __awaiter(this, void 0, void 0, function*() {
            const result = yield (0, simple_fetch_1.simpleFetch)(rest, `/cosmos/auth/v1beta1/accounts/${address}`, {
                validateStatus: function(status) {
                    // Permit 404 not found to handle the case of account not exists
                    return status >= 200 && status < 300 || status === 404;
                }
            });
            return BaseAccount.fromProtoJSON(result.data, defaultBech32Address ? address : "");
        });
    }
    static fromProtoJSON(obj, // If the account doesn't exist, the result from `auth/accounts` would not have the address.
    // In this case, if `defaultBech32Address` param is provided, this will use it instead of the result from rest.
    defaultBech32Address = "") {
        if (!obj.account) {
            // Case of not existing account.
            // {
            //   "code": 5,
            //   "message": "rpc error: code = NotFound desc = account {address} not found: key not found",
            //   "details": [
            //   ]
            // }
            if (!defaultBech32Address) {
                throw new Error(`Account's address is unknown: ${JSON.stringify(obj)}`);
            }
            return new BaseAccount("", defaultBech32Address, new unit_1.Int(0), new unit_1.Int(0));
        }
        let value = obj.account;
        const type = value["@type"] || "";
        // If the chain modifies the account type, handle the case where the account type embeds the base account.
        // (Actually, the only existent case is ethermint, and this is the line for handling ethermint)
        const baseAccount = value.BaseAccount || value.baseAccount || value.base_account;
        if (baseAccount) {
            value = baseAccount;
        }
        // If the chain modifies the account type, handle the case where the account type embeds the account.
        // (Actually, the only existent case is desmos, and this is the line for handling desmos)
        const embedAccount = value.account;
        if (embedAccount) {
            value = embedAccount;
        }
        // If the account is the vesting account that embeds the base vesting account,
        // the actual base account exists under the base vesting account.
        // But, this can be different according to the version of cosmos-sdk.
        // So, anyway, try to parse it by some ways...
        const baseVestingAccount = value.BaseVestingAccount || value.baseVestingAccount || value.base_vesting_account;
        if (baseVestingAccount) {
            value = baseVestingAccount;
            const baseAccount = value.BaseAccount || value.baseAccount || value.base_account;
            if (baseAccount) {
                value = baseAccount;
            }
        }
        let address = value.address;
        if (!address) {
            if (!defaultBech32Address) {
                throw new Error(`Account's address is unknown: ${JSON.stringify(obj)}`);
            }
            address = defaultBech32Address;
        }
        const accountNumber = value.account_number;
        const sequence = value.sequence;
        return new BaseAccount(type, address, new unit_1.Int(accountNumber || "0"), new unit_1.Int(sequence || "0"));
    }
    constructor(type, address, accountNumber, sequence){
        this.type = type;
        this.address = address;
        this.accountNumber = accountNumber;
        this.sequence = sequence;
    }
    getType() {
        return this.type;
    }
    getAddress() {
        return this.address;
    }
    getAccountNumber() {
        return this.accountNumber;
    }
    getSequence() {
        return this.sequence;
    }
}
exports.BaseAccount = BaseAccount; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/bech32/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __setModuleDefault = this && this.__setModuleDefault || (Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
});
var __importStar = this && this.__importStar || function(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k in mod)if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    }
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Bech32Address = void 0;
const bech32_1 = __importStar(__turbopack_context__.r("[project]/node_modules/bech32/index.js [app-client] (ecmascript)"));
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
const address_1 = __turbopack_context__.r("[project]/node_modules/@ethersproject/address/lib.esm/index.js [app-client] (ecmascript)");
class Bech32Address {
    static shortenAddress(bech32, maxCharacters) {
        if (maxCharacters >= bech32.length) {
            return bech32;
        }
        const i = bech32.indexOf("1");
        const prefix = bech32.slice(0, i);
        const address = bech32.slice(i + 1);
        maxCharacters -= prefix.length;
        maxCharacters -= 3; // For "..."
        maxCharacters -= 1; // For "1"
        if (maxCharacters <= 0) {
            return "";
        }
        const mid = Math.floor(address.length / 2);
        let former = address.slice(0, mid);
        let latter = address.slice(mid);
        while(maxCharacters < former.length + latter.length){
            if ((former.length + latter.length) % 2 === 1 && former.length > 0) {
                former = former.slice(0, former.length - 1);
            } else {
                latter = latter.slice(1);
            }
        }
        return prefix + "1" + former + "..." + latter;
    }
    static fromBech32(bech32Address, prefix) {
        const decoded = bech32_1.default.decode(bech32Address);
        if (prefix && decoded.prefix !== prefix) {
            throw new Error("Unmatched prefix");
        }
        return new Bech32Address(new Uint8Array((0, bech32_1.fromWords)(decoded.words)));
    }
    static validate(bech32Address, prefix) {
        const { prefix: decodedPrefix } = bech32_1.default.decode(bech32Address);
        if (prefix && prefix !== decodedPrefix) {
            throw new Error(`Unexpected prefix (expected: ${prefix}, actual: ${decodedPrefix})`);
        }
    }
    static defaultBech32Config(mainPrefix, validatorPrefix = "val", consensusPrefix = "cons", publicPrefix = "pub", operatorPrefix = "oper") {
        return {
            bech32PrefixAccAddr: mainPrefix,
            bech32PrefixAccPub: mainPrefix + publicPrefix,
            bech32PrefixValAddr: mainPrefix + validatorPrefix + operatorPrefix,
            bech32PrefixValPub: mainPrefix + validatorPrefix + operatorPrefix + publicPrefix,
            bech32PrefixConsAddr: mainPrefix + validatorPrefix + consensusPrefix,
            bech32PrefixConsPub: mainPrefix + validatorPrefix + consensusPrefix + publicPrefix
        };
    }
    constructor(address){
        this.address = address;
    }
    toBech32(prefix) {
        const words = bech32_1.default.toWords(this.address);
        return bech32_1.default.encode(prefix, words);
    }
    toHex(mixedCaseChecksum = true) {
        const hex = buffer_1.Buffer.from(this.address).toString("hex");
        if (hex.length === 0) {
            throw new Error("Empty address");
        }
        if (mixedCaseChecksum) {
            return (0, address_1.getAddress)("0x" + hex);
        } else {
            return "0x" + hex;
        }
    }
}
exports.Bech32Address = Bech32Address; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/cosmos.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ChainIdHelper = void 0;
class ChainIdHelper {
    static parse(chainId) {
        // In the case of injective dev/testnet, there is a difficult problem to deal with keplr's chain identifier system...
        // Fundamentally, keplr's chain identifier system started when the app was created, so too mnay logic depends on chain identifier.
        // Temporarily deal with it in the way below.
        // There is a possibility of some kind of problem...
        // But anyway, it's not a big problem because it's dev/testnet...
        if (chainId === "injective-777" || chainId === "injective-888") {
            return {
                identifier: chainId,
                version: 0
            };
        }
        const split = chainId.split(ChainIdHelper.VersionFormatRegExp).filter(Boolean);
        if (split.length !== 2) {
            return {
                identifier: chainId,
                version: 0
            };
        } else {
            return {
                identifier: split[0],
                version: parseInt(split[1])
            };
        }
    }
    static hasChainVersion(chainId) {
        const version = ChainIdHelper.parse(chainId);
        return version.identifier !== chainId;
    }
}
exports.ChainIdHelper = ChainIdHelper;
// VersionFormatRegExp checks if a chainID is in the format required for parsing versions
// The chainID should be in the form: `{identifier}-{version}`
ChainIdHelper.VersionFormatRegExp = /(.+)-([\d]+)/; //# sourceMappingURL=cosmos.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/ethermint.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.EthermintChainIdHelper = void 0;
const cosmos_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/cosmos.js [app-client] (ecmascript)");
class EthermintChainIdHelper {
    static parse(chainId) {
        const cosmosChainId = cosmos_1.ChainIdHelper.parse(chainId);
        if (chainId.startsWith("injective")) {
            const injectiveTestnetChainIds = [
                "injective-777",
                "injective-888"
            ];
            if (injectiveTestnetChainIds.includes(chainId)) {
                return Object.assign({
                    ethChainId: 5
                }, cosmosChainId);
            }
            return Object.assign({
                ethChainId: 1
            }, cosmosChainId);
        }
        const matches = chainId.match("^([a-z]{1,})_{1}([1-9][0-9]*)-{1}([1-9][0-9]*)$");
        if (!matches || matches.length !== 4 || matches[1] === "" || Number.isNaN(parseFloat(matches[2])) || !Number.isInteger(parseFloat(matches[2]))) {
            throw new Error(`Invalid chainId for ethermint: ${chainId}`);
        }
        return Object.assign(Object.assign({}, cosmosChainId), {
            ethChainId: parseFloat(matches[2])
        });
    }
}
exports.EthermintChainIdHelper = EthermintChainIdHelper; //# sourceMappingURL=ethermint.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/cosmos.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/ethermint.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/tx-tracer/types.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WsReadyState = void 0;
var WsReadyState;
(function(WsReadyState) {
    WsReadyState[WsReadyState["CONNECTING"] = 0] = "CONNECTING";
    WsReadyState[WsReadyState["OPEN"] = 1] = "OPEN";
    WsReadyState[WsReadyState["CLOSING"] = 2] = "CLOSING";
    WsReadyState[WsReadyState["CLOSED"] = 3] = "CLOSED";
    // WS is not initialized or the ready state of WS is unknown
    WsReadyState[WsReadyState["NONE"] = 4] = "NONE";
})(WsReadyState = exports.WsReadyState || (exports.WsReadyState = {})); //# sourceMappingURL=types.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/tx-tracer/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TendermintTxTracer = void 0;
const types_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/tx-tracer/types.js [app-client] (ecmascript)");
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
class TendermintTxTracer {
    constructor(url, wsEndpoint, options = {}){
        this.url = url;
        this.wsEndpoint = wsEndpoint;
        this.options = options;
        this.newBlockSubscribes = [];
        // Key is "id" for jsonrpc
        this.txSubscribes = new Map();
        // Key is "id" for jsonrpc
        this.pendingQueries = new Map();
        this.listeners = {};
        this.onOpen = (e)=>{
            var _a;
            if (this.newBlockSubscribes.length > 0) {
                this.sendSubscribeBlockRpc();
            }
            for (const [id, tx] of this.txSubscribes){
                this.sendSubscribeTxRpc(id, tx.params);
            }
            for (const [id, query] of this.pendingQueries){
                this.sendQueryRpc(id, query.method, query.params);
            }
            for (const listener of (_a = this.listeners.open) !== null && _a !== void 0 ? _a : []){
                listener(e);
            }
        };
        this.onMessage = (e)=>{
            var _a, _b, _c, _d, _e, _f;
            for (const listener of (_a = this.listeners.message) !== null && _a !== void 0 ? _a : []){
                listener(e);
            }
            if (e.data) {
                try {
                    const obj = JSON.parse(e.data);
                    if (obj === null || obj === void 0 ? void 0 : obj.id) {
                        if (this.pendingQueries.has(obj.id)) {
                            if (obj.error) {
                                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                this.pendingQueries.get(obj.id).rejector(new Error(obj.error.data || obj.error.message));
                            } else {
                                // XXX: I'm not sure why this happens, but somtimes the form of tx id delivered under the "tx_result" field.
                                if ((_b = obj.result) === null || _b === void 0 ? void 0 : _b.tx_result) {
                                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                    this.pendingQueries.get(obj.id).resolver(obj.result.tx_result);
                                } else {
                                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                    this.pendingQueries.get(obj.id).resolver(obj.result);
                                }
                            }
                            this.pendingQueries.delete(obj.id);
                        }
                    }
                    if (((_d = (_c = obj === null || obj === void 0 ? void 0 : obj.result) === null || _c === void 0 ? void 0 : _c.data) === null || _d === void 0 ? void 0 : _d.type) === "tendermint/event/NewBlock") {
                        for (const handler of this.newBlockSubscribes){
                            handler.handler(obj.result.data.value);
                        }
                    }
                    if (((_f = (_e = obj === null || obj === void 0 ? void 0 : obj.result) === null || _e === void 0 ? void 0 : _e.data) === null || _f === void 0 ? void 0 : _f.type) === "tendermint/event/Tx") {
                        if (obj === null || obj === void 0 ? void 0 : obj.id) {
                            if (this.txSubscribes.has(obj.id)) {
                                if (obj.error) {
                                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                    this.txSubscribes.get(obj.id).rejector(new Error(obj.error.data || obj.error.message));
                                } else {
                                    // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                                    this.txSubscribes.get(obj.id).resolver(obj.result.data.value.TxResult.result);
                                }
                                this.txSubscribes.delete(obj.id);
                            }
                        }
                    }
                } catch (e) {
                    console.log(`Tendermint websocket jsonrpc response is not JSON: ${e.message || e.toString()}`);
                }
            }
        };
        this.onClose = (e)=>{
            var _a;
            for (const listener of (_a = this.listeners.close) !== null && _a !== void 0 ? _a : []){
                listener(e);
            }
        };
        this.ws = this.options.wsObject ? new this.options.wsObject(this.getWsEndpoint()) : new WebSocket(this.getWsEndpoint());
        this.ws.onopen = this.onOpen;
        this.ws.onmessage = this.onMessage;
        this.ws.onclose = this.onClose;
    }
    getWsEndpoint() {
        let url = this.url;
        if (url.startsWith("http")) {
            url = url.replace("http", "ws");
        }
        if (!url.endsWith(this.wsEndpoint)) {
            const wsEndpoint = this.wsEndpoint.startsWith("/") ? this.wsEndpoint : "/" + this.wsEndpoint;
            url = url.endsWith("/") ? url + wsEndpoint.slice(1) : url + wsEndpoint;
        }
        return url;
    }
    close() {
        this.ws.close();
    }
    get readyState() {
        switch(this.ws.readyState){
            case 0:
                return types_1.WsReadyState.CONNECTING;
            case 1:
                return types_1.WsReadyState.OPEN;
            case 2:
                return types_1.WsReadyState.CLOSING;
            case 3:
                return types_1.WsReadyState.CLOSED;
            default:
                return types_1.WsReadyState.NONE;
        }
    }
    addEventListener(type, listener) {
        if (!this.listeners[type]) {
            this.listeners[type] = [];
        }
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-ignore
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        this.listeners[type].push(listener);
    }
    /**
     * SubscribeBlock receives the handler for the block.
     * The handelrs shares the subscription of block.
     * @param handler
     * @return unsubscriber
     */ subscribeBlock(handler) {
        this.newBlockSubscribes.push({
            handler
        });
        if (this.newBlockSubscribes.length === 1) {
            this.sendSubscribeBlockRpc();
        }
        return ()=>{
            this.newBlockSubscribes = this.newBlockSubscribes.filter((s)=>s.handler !== handler);
        };
    }
    sendSubscribeBlockRpc() {
        if (this.readyState === types_1.WsReadyState.OPEN) {
            this.ws.send(JSON.stringify({
                jsonrpc: "2.0",
                method: "subscribe",
                params: [
                    "tm.event='NewBlock'"
                ],
                id: 1
            }));
        }
    }
    // Query the tx and subscribe the tx.
    traceTx(query) {
        return new Promise((resolve)=>{
            // At first, try to query the tx at the same time of subscribing the tx.
            // But, the querying's error will be ignored.
            this.queryTx(query).then((result)=>{
                if (query instanceof Uint8Array) {
                    resolve(result);
                    return;
                }
                if ((result === null || result === void 0 ? void 0 : result.total_count) !== "0") {
                    resolve(result);
                    return;
                }
            }).catch(()=>{
            // noop
            });
            this.subscribeTx(query).then(resolve);
        }).then((tx)=>{
            // Occasionally, even if the subscribe tx event occurs, the state through query is not changed yet.
            // Perhaps it is because the block has not been committed yet even though the result of deliverTx in tendermint is complete.
            // This method is usually used to reflect the state change through query when tx is completed.
            // The simplest solution is to just add a little delay.
            return new Promise((resolve)=>{
                setTimeout(()=>resolve(tx), 100);
            });
        });
    }
    subscribeTx(query) {
        if (query instanceof Uint8Array) {
            const id = this.createRandomId();
            const params = {
                query: `tm.event='Tx' AND tx.hash='${buffer_1.Buffer.from(query).toString("hex").toUpperCase()}'`
            };
            return new Promise((resolve, reject)=>{
                this.txSubscribes.set(id, {
                    params,
                    resolver: resolve,
                    rejector: reject
                });
                this.sendSubscribeTxRpc(id, params);
            });
        } else {
            const id = this.createRandomId();
            const params = {
                query: `tm.event='Tx' and ` + Object.keys(query).map((key)=>{
                    return {
                        key,
                        value: query[key]
                    };
                }).map((obj)=>{
                    return `${obj.key}=${typeof obj.value === "string" ? `'${obj.value}'` : obj.value}`;
                }).join(" and "),
                page: "1",
                per_page: "1",
                order_by: "desc"
            };
            return new Promise((resolve, reject)=>{
                this.txSubscribes.set(id, {
                    params,
                    resolver: resolve,
                    rejector: reject
                });
                this.sendSubscribeTxRpc(id, params);
            });
        }
    }
    sendSubscribeTxRpc(id, params) {
        if (this.readyState === types_1.WsReadyState.OPEN) {
            this.ws.send(JSON.stringify({
                jsonrpc: "2.0",
                method: "subscribe",
                params: params,
                id
            }));
        }
    }
    queryTx(query) {
        if (query instanceof Uint8Array) {
            return this.query("tx", {
                hash: buffer_1.Buffer.from(query).toString("base64"),
                prove: false
            });
        } else {
            const params = {
                query: Object.keys(query).map((key)=>{
                    return {
                        key,
                        value: query[key]
                    };
                }).map((obj)=>{
                    return `${obj.key}=${typeof obj.value === "string" ? `'${obj.value}'` : obj.value}`;
                }).join(" and "),
                page: "1",
                per_page: "1",
                order_by: "desc"
            };
            return this.query("tx_search", params);
        }
    }
    query(method, params) {
        const id = this.createRandomId();
        return new Promise((resolve, reject)=>{
            this.pendingQueries.set(id, {
                method,
                params,
                resolver: resolve,
                rejector: reject
            });
            this.sendQueryRpc(id, method, params);
        });
    }
    sendQueryRpc(id, method, params) {
        if (this.readyState === types_1.WsReadyState.OPEN) {
            this.ws.send(JSON.stringify({
                jsonrpc: "2.0",
                method,
                params,
                id
            }));
        }
    }
    createRandomId() {
        return parseInt(Array.from({
            length: 6
        }).map(()=>Math.floor(Math.random() * 100)).join(""));
    }
}
exports.TendermintTxTracer = TendermintTxTracer; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/unknown.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.UnknownMessage = void 0;
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
class UnknownMessage {
    constructor(/** Any type_url. */ _typeUrl, /** Any value. */ _value){
        this._typeUrl = _typeUrl;
        this._value = _value;
    }
    get typeUrl() {
        return this._typeUrl;
    }
    get value() {
        return this._value;
    }
    toJSON() {
        return {
            typeUrl: this._typeUrl,
            value: buffer_1.Buffer.from(this._value).toString("base64")
        };
    }
}
exports.UnknownMessage = UnknownMessage; //# sourceMappingURL=unknown.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.defaultProtoCodec = exports.ProtoCodec = void 0;
const msgs_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/agoric/swingset/msgs.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/bank/v1beta1/tx.js [app-client] (ecmascript)");
const tx_2 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/staking/v1beta1/tx.js [app-client] (ecmascript)");
const tx_3 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/authz/v1beta1/tx.js [app-client] (ecmascript)");
const tx_4 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/gov/v1beta1/tx.js [app-client] (ecmascript)");
const tx_5 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/distribution/v1beta1/tx.js [app-client] (ecmascript)");
const tx_6 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmwasm/wasm/v1/tx.js [app-client] (ecmascript)");
const tx_7 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/ibc/applications/transfer/v1/tx.js [app-client] (ecmascript)");
const unknown_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/unknown.js [app-client] (ecmascript)");
const authz_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/authz/v1beta1/authz.js [app-client] (ecmascript)");
const authz_2 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/staking/v1beta1/authz.js [app-client] (ecmascript)");
const authz_3 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/bank/v1beta1/authz.js [app-client] (ecmascript)");
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/unknown.js [app-client] (ecmascript)"), exports);
class ProtoCodec {
    constructor(){
        this.typeUrlMap = new Map();
    }
    unpackAnyFactory(typeUrl) {
        if (!this.typeUrlMap.has(typeUrl)) {
            return undefined;
        }
        return this.typeUrlMap.get(typeUrl);
    }
    /**
     * Unpack the any to the registered message.
     * NOTE: If there is no matched message, it will not throw an error but return the `UnknownMessage` class.
     * @param any
     */ unpackAny(any) {
        const factory = this.unpackAnyFactory(any.typeUrl);
        if (!factory) {
            return new unknown_1.UnknownMessage(any.typeUrl, any.value);
        }
        const unpacked = factory.decode(any.value);
        return Object.assign(Object.assign({}, any), {
            unpacked
        });
    }
    unpackedAnyToJSONRecursive(unpacked) {
        if (unpacked instanceof unknown_1.UnknownMessage) {
            return unpacked.toJSON();
        }
        const factory = this.unpackAnyFactory(unpacked.typeUrl);
        if (factory && "unpacked" in unpacked && unpacked.unpacked) {
            const isJSONEncodedAny = (any)=>{
                const r = typeof any === "object" && !(any instanceof unknown_1.UnknownMessage) && "typeUrl" in any && any.typeUrl && typeof any.typeUrl === "string" && "value" in any && any.value && typeof any.value === "string";
                if (r) {
                    try {
                        buffer_1.Buffer.from(any.value, "base64");
                    } catch (_a) {
                        return false;
                    }
                }
                return r;
            };
            const unpackJSONEncodedAnyInner = (jsonEncodedAny)=>{
                const factory = this.unpackAnyFactory(jsonEncodedAny.typeUrl);
                const bz = buffer_1.Buffer.from(jsonEncodedAny.value, "base64");
                if (!factory) {
                    return new unknown_1.UnknownMessage(jsonEncodedAny.typeUrl, bz).toJSON();
                }
                const unpacked = factory.decode(bz);
                return {
                    typeUrl: jsonEncodedAny.typeUrl,
                    value: factory.toJSON(unpacked)
                };
            };
            const unpackedJSONEncodedAnyRecursive = (obj)=>{
                if (Array.isArray(obj)) {
                    for(let i = 0; i < obj.length; i++){
                        const value = obj[i];
                        if (isJSONEncodedAny(value)) {
                            obj[i] = unpackJSONEncodedAnyInner(value);
                        } else if (typeof value === "object") {
                            obj[i] = unpackedJSONEncodedAnyRecursive(value);
                        }
                    }
                } else {
                    for(const key in obj){
                        const value = obj[key];
                        if (isJSONEncodedAny(value)) {
                            obj[key] = unpackJSONEncodedAnyInner(value);
                        } else if (typeof value === "object") {
                            obj[key] = unpackedJSONEncodedAnyRecursive(value);
                        }
                    }
                }
                return obj;
            };
            // This is mutated by logic.
            let mutObj = factory.toJSON(unpacked.unpacked);
            if (mutObj && typeof mutObj === "object") {
                mutObj = unpackedJSONEncodedAnyRecursive(mutObj);
                return {
                    typeUrl: unpacked.typeUrl,
                    value: mutObj
                };
            }
        }
        return new unknown_1.UnknownMessage(unpacked.typeUrl, unpacked.value).toJSON();
    }
    registerAny(typeUrl, message) {
        this.typeUrlMap.set(typeUrl, message);
    }
}
exports.ProtoCodec = ProtoCodec;
exports.defaultProtoCodec = new ProtoCodec();
exports.defaultProtoCodec.registerAny("/agoric.swingset.MsgWalletSpendAction", msgs_1.MsgWalletSpendAction);
exports.defaultProtoCodec.registerAny("/agoric.swingset.MsgProvision", msgs_1.MsgProvision);
exports.defaultProtoCodec.registerAny("/cosmos.bank.v1beta1.MsgSend", tx_1.MsgSend);
exports.defaultProtoCodec.registerAny("/cosmos.bank.v1beta1.MsgMultiSend", tx_1.MsgMultiSend);
exports.defaultProtoCodec.registerAny("/cosmos.staking.v1beta1.MsgDelegate", tx_2.MsgDelegate);
exports.defaultProtoCodec.registerAny("/cosmos.staking.v1beta1.MsgUndelegate", tx_2.MsgUndelegate);
exports.defaultProtoCodec.registerAny("/cosmos.staking.v1beta1.MsgBeginRedelegate", tx_2.MsgBeginRedelegate);
exports.defaultProtoCodec.registerAny("/cosmwasm.wasm.v1.MsgExecuteContract", tx_6.MsgExecuteContract);
exports.defaultProtoCodec.registerAny("/cosmwasm.wasm.v1.MsgInstantiateContract", tx_6.MsgInstantiateContract);
exports.defaultProtoCodec.registerAny("/cosmos.distribution.v1beta1.MsgWithdrawDelegatorReward", tx_5.MsgWithdrawDelegatorReward);
exports.defaultProtoCodec.registerAny("/cosmos.distribution.v1beta1.MsgSetWithdrawAddress", tx_5.MsgSetWithdrawAddress);
exports.defaultProtoCodec.registerAny("/ibc.applications.transfer.v1.MsgTransfer", tx_7.MsgTransfer);
exports.defaultProtoCodec.registerAny("/cosmos.gov.v1beta1.MsgVote", tx_4.MsgVote);
exports.defaultProtoCodec.registerAny("/cosmos.authz.v1beta1.MsgGrant", tx_3.MsgGrant);
// ----- Authz grants -----
exports.defaultProtoCodec.registerAny("/cosmos.authz.v1beta1.GenericAuthorization", authz_1.GenericAuthorization);
exports.defaultProtoCodec.registerAny("/cosmos.staking.v1beta1.StakeAuthorization", authz_2.StakeAuthorization);
exports.defaultProtoCodec.registerAny("/cosmos.bank.v1beta1.SendAuthorization", authz_3.SendAuthorization);
// ----- Authz grants -----
exports.defaultProtoCodec.registerAny("/cosmos.authz.v1beta1.MsgRevoke", tx_3.MsgRevoke);
exports.defaultProtoCodec.registerAny("/cosmos.authz.v1beta1.MsgExec", tx_3.MsgExec); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/stargate/decoder/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ProtoSignDocDecoder = void 0;
const tx_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const codec_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/index.js [app-client] (ecmascript)");
class ProtoSignDocDecoder {
    static decode(bytes) {
        return new ProtoSignDocDecoder(tx_1.SignDoc.decode(bytes));
    }
    constructor(signDoc, protoCodec = codec_1.defaultProtoCodec){
        this.signDoc = signDoc;
        this.protoCodec = protoCodec;
    }
    get txBody() {
        if (!this._txBody) {
            this._txBody = tx_1.TxBody.decode(this.signDoc.bodyBytes);
        }
        return this._txBody;
    }
    get txMsgs() {
        const msgs = [];
        for (const msg of this.txBody.messages){
            msgs.push(this.protoCodec.unpackAny(msg));
        }
        return msgs;
    }
    get authInfo() {
        if (!this._authInfo) {
            this._authInfo = tx_1.AuthInfo.decode(this.signDoc.authInfoBytes);
        }
        return this._authInfo;
    }
    get chainId() {
        return this.signDoc.chainId;
    }
    get accountNumber() {
        return this.signDoc.accountNumber.toString();
    }
    toBytes() {
        return tx_1.SignDoc.encode(this.signDoc).finish();
    }
    toJSON() {
        return {
            txBody: Object.assign(Object.assign({}, tx_1.TxBody.toJSON(this.txBody)), {
                messages: this.txMsgs.map((msg)=>{
                    return this.protoCodec.unpackedAnyToJSONRecursive(msg);
                })
            }),
            authInfo: tx_1.AuthInfo.toJSON(this.authInfo),
            chainId: this.chainId,
            accountNumber: this.accountNumber
        };
    }
}
exports.ProtoSignDocDecoder = ProtoSignDocDecoder; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/signing/encode.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.serializeSignDoc = exports.encodeSecp256k1Signature = exports.encodeSecp256k1Pubkey = void 0;
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
const common_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/index.js [app-client] (ecmascript)");
function encodeSecp256k1Pubkey(pubkey) {
    if (pubkey.length !== 33 || pubkey[0] !== 0x02 && pubkey[0] !== 0x03) {
        throw new Error("Public key must be compressed secp256k1, i.e. 33 bytes starting with 0x02 or 0x03");
    }
    return {
        type: "tendermint/PubKeySecp256k1",
        value: buffer_1.Buffer.from(pubkey).toString("base64")
    };
}
exports.encodeSecp256k1Pubkey = encodeSecp256k1Pubkey;
function encodeSecp256k1Signature(pubkey, signature) {
    if (signature.length !== 64) {
        throw new Error("Signature must be 64 bytes long. Cosmos SDK uses a 2x32 byte fixed length encoding for the secp256k1 signature integers r and s.");
    }
    return {
        pub_key: encodeSecp256k1Pubkey(pubkey),
        signature: buffer_1.Buffer.from(signature).toString("base64")
    };
}
exports.encodeSecp256k1Signature = encodeSecp256k1Signature;
function serializeSignDoc(signDoc) {
    return buffer_1.Buffer.from((0, common_1.escapeHTML)((0, common_1.sortedJsonByKeyStringify)(signDoc)));
}
exports.serializeSignDoc = serializeSignDoc; //# sourceMappingURL=encode.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/signing/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/signing/encode.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/adr-36/amino.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.verifyADR36Amino = exports.verifyADR36AminoSignDoc = exports.makeADR36AminoSignDoc = exports.checkAndValidateADR36AminoSignDoc = void 0;
const signing_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/signing/index.js [app-client] (ecmascript)");
const bech32_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/bech32/index.js [app-client] (ecmascript)");
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
const crypto_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/index.js [app-client] (ecmascript)");
/**
 * Check the sign doc is for ADR-36.
 * If the sign doc is expected to be ADR-36, validate the sign doc and throw an error if the sign doc is valid ADR-36.
 * @param signDoc
 * @param bech32PrefixAccAddr If this argument is provided, validate the signer in the `MsgSignData` with this prefix.
 *                            If not, validate the signer in the `MsgSignData` without considering the bech32 prefix.
 */ function checkAndValidateADR36AminoSignDoc(signDoc, bech32PrefixAccAddr) {
    const hasOnlyMsgSignData = (()=>{
        if (signDoc && signDoc.msgs && Array.isArray(signDoc.msgs) && signDoc.msgs.length === 1) {
            const msg = signDoc.msgs[0];
            return msg.type === "sign/MsgSignData";
        } else {
            return false;
        }
    })();
    if (!hasOnlyMsgSignData) {
        return false;
    }
    if (signDoc.chain_id !== "") {
        throw new Error("Chain id should be empty string for ADR-36 signing");
    }
    if (signDoc.memo !== "") {
        throw new Error("Memo should be empty string for ADR-36 signing");
    }
    if (signDoc.account_number !== "0") {
        throw new Error('Account number should be "0" for ADR-36 signing');
    }
    if (signDoc.sequence !== "0") {
        throw new Error('Sequence should be "0" for ADR-36 signing');
    }
    if (signDoc.fee.gas !== "0") {
        throw new Error('Gas should be "0" for ADR-36 signing');
    }
    if (signDoc.fee.amount.length !== 0) {
        throw new Error("Fee amount should be empty array for ADR-36 signing");
    }
    const msg = signDoc.msgs[0];
    if (msg.type !== "sign/MsgSignData") {
        throw new Error(`Invalid type of ADR-36 sign msg: ${msg.type}`);
    }
    if (!msg.value) {
        throw new Error("Empty value in the msg");
    }
    const signer = msg.value.signer;
    if (!signer) {
        throw new Error("Empty signer in the ADR-36 msg");
    }
    bech32_1.Bech32Address.validate(signer, bech32PrefixAccAddr);
    const data = msg.value.data;
    if (!data) {
        throw new Error("Empty data in the ADR-36 msg");
    }
    const rawData = buffer_1.Buffer.from(data, "base64");
    // Validate the data is encoded as base64.
    if (rawData.toString("base64") !== data) {
        throw new Error("Data is not encoded by base64");
    }
    if (rawData.length === 0) {
        throw new Error("Empty data in the ADR-36 msg");
    }
    return true;
}
exports.checkAndValidateADR36AminoSignDoc = checkAndValidateADR36AminoSignDoc;
function makeADR36AminoSignDoc(signer, data) {
    if (typeof data === "string") {
        data = buffer_1.Buffer.from(data).toString("base64");
    } else {
        data = buffer_1.Buffer.from(data).toString("base64");
    }
    return {
        chain_id: "",
        account_number: "0",
        sequence: "0",
        fee: {
            gas: "0",
            amount: []
        },
        msgs: [
            {
                type: "sign/MsgSignData",
                value: {
                    signer,
                    data
                }
            }
        ],
        memo: ""
    };
}
exports.makeADR36AminoSignDoc = makeADR36AminoSignDoc;
function verifyADR36AminoSignDoc(bech32PrefixAccAddr, signDoc, pubKey, signature, algo = "secp256k1") {
    if (!checkAndValidateADR36AminoSignDoc(signDoc, bech32PrefixAccAddr)) {
        throw new Error("Invalid sign doc for ADR-36");
    }
    const cryptoPubKey = new crypto_1.PubKeySecp256k1(pubKey);
    const expectedSigner = (()=>{
        if (algo === "ethsecp256k1") {
            return new bech32_1.Bech32Address(cryptoPubKey.getEthAddress()).toBech32(bech32PrefixAccAddr);
        }
        return new bech32_1.Bech32Address(cryptoPubKey.getCosmosAddress()).toBech32(bech32PrefixAccAddr);
    })();
    const signer = signDoc.msgs[0].value.signer;
    if (expectedSigner !== signer) {
        throw new Error("Unmatched signer");
    }
    const msg = (0, signing_1.serializeSignDoc)(signDoc);
    return cryptoPubKey.verifyDigest32((()=>{
        if (algo === "ethsecp256k1") {
            return crypto_1.Hash.keccak256(msg);
        }
        return crypto_1.Hash.sha256(msg);
    })(), signature);
}
exports.verifyADR36AminoSignDoc = verifyADR36AminoSignDoc;
function verifyADR36Amino(bech32PrefixAccAddr, signer, data, pubKey, signature, algo = "secp256k1") {
    const signDoc = makeADR36AminoSignDoc(signer, data);
    return verifyADR36AminoSignDoc(bech32PrefixAccAddr, signDoc, pubKey, signature, algo);
}
exports.verifyADR36Amino = verifyADR36Amino; //# sourceMappingURL=amino.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/adr-36/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/adr-36/amino.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/stargate/wrapper/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SignDocWrapper = void 0;
const decoder_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/decoder/index.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/proto-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const adr_36_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/adr-36/index.js [app-client] (ecmascript)");
class SignDocWrapper {
    constructor(signDoc){
        this.signDoc = signDoc;
        if ("msgs" in signDoc) {
            this.mode = "amino";
        } else {
            this.mode = "direct";
        }
        if (this.mode === "amino") {
            // Check that the sign doc is for ADR-36.
            // The validation should be performed on the background process.
            // So, here, we check once more, but the validation related to bech32 is considered to be done in the background process.
            this.isADR36SignDoc = (0, adr_36_1.checkAndValidateADR36AminoSignDoc)(this.aminoSignDoc);
        } else {
            // Currently, only support amino sign doc for ADR-36
            this.isADR36SignDoc = false;
        }
    }
    static fromAminoSignDoc(signDoc) {
        return new SignDocWrapper(signDoc);
    }
    static fromDirectSignDoc(signDoc) {
        return new SignDocWrapper(signDoc);
    }
    static fromDirectSignDocBytes(signDocBytes) {
        return new SignDocWrapper(tx_1.SignDoc.decode(signDocBytes));
    }
    clone() {
        return new SignDocWrapper(this.signDoc);
    }
    get protoSignDoc() {
        if (this.mode === "amino") {
            throw new Error("Sign doc is encoded as Amino Json");
        }
        if ("msgs" in this.signDoc) {
            throw new Error("Unexpected error");
        }
        if (!this._protoSignDoc) {
            this._protoSignDoc = new decoder_1.ProtoSignDocDecoder(this.signDoc);
        }
        return this._protoSignDoc;
    }
    get aminoSignDoc() {
        if (this.mode === "direct") {
            throw new Error("Sign doc is encoded as Protobuf");
        }
        if (!("msgs" in this.signDoc)) {
            throw new Error("Unexpected error");
        }
        return this.signDoc;
    }
    get chainId() {
        if (this.mode === "direct") {
            return this.protoSignDoc.chainId;
        }
        return this.aminoSignDoc.chain_id;
    }
    get memo() {
        if (this.mode === "direct") {
            return this.protoSignDoc.txBody.memo;
        }
        return this.aminoSignDoc.memo;
    }
    get fees() {
        var _a, _b;
        if (this.mode === "direct") {
            const fees = [];
            for (const coinObj of (_b = (_a = this.protoSignDoc.authInfo.fee) === null || _a === void 0 ? void 0 : _a.amount) !== null && _b !== void 0 ? _b : []){
                if (coinObj.denom == null || coinObj.amount == null) {
                    throw new Error("Invalid fee");
                }
                fees.push({
                    denom: coinObj.denom,
                    amount: coinObj.amount
                });
            }
            return fees;
        }
        return this.aminoSignDoc.fee.amount;
    }
    get payer() {
        var _a;
        if (this.mode === "direct") {
            return (_a = this.protoSignDoc.authInfo.fee) === null || _a === void 0 ? void 0 : _a.payer;
        }
        return this.aminoSignDoc.fee.payer;
    }
    get granter() {
        var _a;
        if (this.mode === "direct") {
            return (_a = this.protoSignDoc.authInfo.fee) === null || _a === void 0 ? void 0 : _a.granter;
        }
        return this.aminoSignDoc.fee.granter;
    }
    get gas() {
        var _a;
        if (this.mode === "direct") {
            if ((_a = this.protoSignDoc.authInfo.fee) === null || _a === void 0 ? void 0 : _a.gasLimit) {
                return parseInt(this.protoSignDoc.authInfo.fee.gasLimit);
            } else {
                return 0;
            }
        }
        return parseInt(this.aminoSignDoc.fee.gas);
    }
}
exports.SignDocWrapper = SignDocWrapper; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/stargate/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/codec/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/decoder/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/wrapper/index.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/cosmos/build/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/account/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/bech32/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/chain-id/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/tx-tracer/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/stargate/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/adr-36/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/cosmos/build/signing/index.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/interface.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
}); //# sourceMappingURL=interface.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/base.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseKVStore = void 0;
class BaseKVStore {
    constructor(provider, _prefix){
        this.provider = provider;
        this._prefix = _prefix;
    }
    get(key) {
        return __awaiter(this, void 0, void 0, function*() {
            const k = this.prefix() + "/" + key;
            const data = yield this.provider.get();
            return data[k];
        });
    }
    set(key, data) {
        const k = this.prefix() + "/" + key;
        return this.provider.set({
            [k]: data
        });
    }
    prefix() {
        return this._prefix;
    }
}
exports.BaseKVStore = BaseKVStore; //# sourceMappingURL=base.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/extension.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.ExtensionKVStore = void 0;
const base_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/base.js [app-client] (ecmascript)");
class ExtensionKVStore extends base_1.BaseKVStore {
    constructor(prefix){
        if (!ExtensionKVStore.KVStoreProvider) {
            if (typeof browser === "undefined") {
                console.log("You should use ExtensionKVStore on the extension environment.");
            } else if (!browser.storage || !browser.storage.local) {
                console.log("The 'browser' exists, but it doesn't seem to be an extension environment. This can happen in Safari browser.");
            } else {
                ExtensionKVStore.KVStoreProvider = {
                    get: browser.storage.local.get,
                    set: browser.storage.local.set,
                    multiGet: browser.storage.local.get
                };
            }
        }
        if (!ExtensionKVStore.KVStoreProvider) {
            throw new Error("Can't initialize kv store for browser extension");
        }
        super(ExtensionKVStore.KVStoreProvider, prefix);
    }
    multiGet(keys) {
        var _a;
        return __awaiter(this, void 0, void 0, function*() {
            // Remove duplications
            keys = Array.from(new Set(keys));
            const res = (_a = yield ExtensionKVStore.KVStoreProvider.multiGet(keys.map((k)=>this.prefix() + "/" + k))) !== null && _a !== void 0 ? _a : {};
            const prefixedKeys = Object.keys(res);
            for (const prefixedKey of prefixedKeys){
                const key = prefixedKey.slice(this.prefix().length + 1);
                res[key] = res[prefixedKey];
                delete res[prefixedKey];
            }
            return res;
        });
    }
}
exports.ExtensionKVStore = ExtensionKVStore; //# sourceMappingURL=extension.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/memory.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.MemoryKVStore = void 0;
const base_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/base.js [app-client] (ecmascript)");
class MemoryKVStoreProvider {
    constructor(){
        this.store = {};
    }
    get() {
        return Promise.resolve(this.store);
    }
    set(items) {
        // Generally, memory kv store is used for testing, and mocking.
        // However, we can store non-primitive type to memory even though local storage generally can't do that.
        // To mitigate the risk, we check the type of value to be stored if env is for testing.
        if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] !== "undefined" && (("TURBOPACK compile-time value", "development") === "test" || ("TURBOPACK compile-time value", "development") === "development")) {
            this.checkNotPrimitiveField(items);
        }
        this.store = Object.assign(Object.assign({}, this.store), items);
        return Promise.resolve();
    }
    checkNotPrimitiveField(items) {
        Object.keys(items).forEach((key)=>{
            const value = items[key];
            if (value != null && typeof value === "object") {
                if (value.constructor !== Object && value.constructor !== Array) {
                    throw new Error(`${key} may not be serializable: ${value.constructor.name}`);
                }
                this.checkNotPrimitiveField(value);
            }
        });
    }
}
class MemoryKVStore extends base_1.BaseKVStore {
    constructor(prefix){
        super(new MemoryKVStoreProvider(), prefix);
    }
}
exports.MemoryKVStore = MemoryKVStore; //# sourceMappingURL=memory.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/local.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.LocalKVStore = void 0;
class LocalKVStore {
    constructor(_prefix){
        this._prefix = _prefix;
    }
    get(key) {
        const k = this.prefix() + "/" + key;
        const data = localStorage.getItem(k);
        if (data === null) {
            return Promise.resolve(undefined);
        }
        return Promise.resolve(JSON.parse(data));
    }
    set(key, data) {
        const k = this.prefix() + "/" + key;
        if (data === null) {
            return Promise.resolve(localStorage.removeItem(k));
        }
        return Promise.resolve(localStorage.setItem(k, JSON.stringify(data)));
    }
    prefix() {
        return this._prefix;
    }
}
exports.LocalKVStore = LocalKVStore; //# sourceMappingURL=local.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/indexed-db.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.IndexedDBKVStore = void 0;
class IndexedDBKVStore {
    constructor(_prefix){
        this._prefix = _prefix;
    }
    get(key) {
        return __awaiter(this, void 0, void 0, function*() {
            const tx = (yield this.getDB()).transaction([
                this.prefix()
            ], "readonly");
            const store = tx.objectStore(this.prefix());
            return new Promise((resolve, reject)=>{
                const request = store.get(key);
                request.onerror = (event)=>{
                    event.stopPropagation();
                    reject(event.target);
                };
                request.onsuccess = ()=>{
                    if (!request.result) {
                        resolve(undefined);
                    } else {
                        resolve(request.result.data);
                    }
                };
            });
        });
    }
    set(key, data) {
        return __awaiter(this, void 0, void 0, function*() {
            if (data === null) {
                const tx = (yield this.getDB()).transaction([
                    this.prefix()
                ], "readwrite");
                const store = tx.objectStore(this.prefix());
                return new Promise((resolve, reject)=>{
                    const request = store.delete(key);
                    request.onerror = (event)=>{
                        event.stopPropagation();
                        reject(event.target);
                    };
                    request.onsuccess = ()=>{
                        resolve();
                    };
                });
            } else {
                const tx = (yield this.getDB()).transaction([
                    this.prefix()
                ], "readwrite");
                const store = tx.objectStore(this.prefix());
                return new Promise((resolve, reject)=>{
                    const request = store.put({
                        key,
                        data
                    });
                    request.onerror = (event)=>{
                        event.stopPropagation();
                        reject(event.target);
                    };
                    request.onsuccess = ()=>{
                        resolve();
                    };
                });
            }
        });
    }
    prefix() {
        return this._prefix;
    }
    getDB() {
        return __awaiter(this, void 0, void 0, function*() {
            if (this.cachedDB) {
                return this.cachedDB;
            }
            return new Promise((resolve, reject)=>{
                const request = window.indexedDB.open(this.prefix());
                request.onerror = (event)=>{
                    event.stopPropagation();
                    reject(event.target);
                };
                request.onupgradeneeded = (event)=>{
                    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
                    // @ts-ignore
                    const db = event.target.result;
                    db.createObjectStore(this.prefix(), {
                        keyPath: "key"
                    });
                };
                request.onsuccess = ()=>{
                    this.cachedDB = request.result;
                    resolve(request.result);
                };
            });
        });
    }
}
exports.IndexedDBKVStore = IndexedDBKVStore; //# sourceMappingURL=indexed-db.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/prefix.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PrefixKVStore = void 0;
class PrefixKVStore {
    constructor(kvStore, _prefix){
        this.kvStore = kvStore;
        this._prefix = _prefix;
    }
    prefix() {
        return this._prefix;
    }
    get(key) {
        return __awaiter(this, void 0, void 0, function*() {
            const k = this.prefix() + "/" + key;
            return yield this.kvStore.get(k);
        });
    }
    set(key, data) {
        return __awaiter(this, void 0, void 0, function*() {
            const k = this.prefix() + "/" + key;
            return yield this.kvStore.set(k, data);
        });
    }
}
exports.PrefixKVStore = PrefixKVStore; //# sourceMappingURL=prefix.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/multi-get.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.WrapMultiGetKVStore = void 0;
class WrapMultiGetKVStore {
    constructor(kvStore){
        this.kvStore = kvStore;
    }
    multiGet(keys) {
        return __awaiter(this, void 0, void 0, function*() {
            // Remove duplications
            keys = Array.from(new Set(keys));
            const res = {};
            const promises = [];
            for (const key of keys){
                promises.push((()=>__awaiter(this, void 0, void 0, function*() {
                        res[key] = yield this.kvStore.get(key);
                    }))());
            }
            yield Promise.all(promises);
            return res;
        });
    }
}
exports.WrapMultiGetKVStore = WrapMultiGetKVStore; //# sourceMappingURL=multi-get.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/kv-store/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/interface.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/extension.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/base.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/memory.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/local.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/indexed-db.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/prefix.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/multi-get.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/denom/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DenomHelper = void 0;
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
const crypto_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/index.js [app-client] (ecmascript)");
class DenomHelper {
    static ibcDenom(paths, coinMinimalDenom) {
        const prefixes = [];
        for (const path of paths){
            prefixes.push(`${path.portId}/${path.channelId}`);
        }
        const prefix = prefixes.join("/");
        const denom = `${prefix}/${coinMinimalDenom}`;
        return "ibc/" + buffer_1.Buffer.from(crypto_1.Hash.sha256(buffer_1.Buffer.from(denom))).toString("hex").toUpperCase();
    }
    constructor(_denom){
        this._denom = _denom;
        // Remember that the coin's actual denom should start with "type:contractAddress:denom" if it is for the token based on contract.
        const split = this.denom.split(/(\w+):(\w+):(.+)/).filter(Boolean);
        if (split.length !== 1 && split.length !== 3) {
            throw new Error(`Invalid denom: ${this.denom}`);
        }
        this._type = split.length === 3 ? split[0] : "";
        this._contractAddress = split.length === 3 ? split[1] : "";
    }
    get denom() {
        return this._denom;
    }
    get type() {
        return this._type || "native";
    }
    get contractAddress() {
        return this._contractAddress;
    }
}
exports.DenomHelper = DenomHelper; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/mobx/etc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.toGenerator = void 0;
// Copied from the mobx-state-tree repository.
/**
 * @experimental
 * experimental api - might change on minor/patch releases
 *
 * Convert a promise to a generator yielding that promise
 * This is intended to allow for usage of `yield*` in async actions to
 * retain the promise return type.
 *
 * Example:
 * ```ts
 * function getDataAsync(input: string): Promise<number> { ... }
 *
 * const someModel.actions(self => ({
 *   someAction: flow(function*() {
 *     // value is typed as number
 *     const value = yield* toGenerator(getDataAsync("input value"));
 *     ...
 *   })
 * }))
 * ```
 */ function* toGenerator(p) {
    return yield p;
}
exports.toGenerator = toGenerator; //# sourceMappingURL=etc.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/mobx/debounce.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DebounceActionTimer = void 0;
const mobx_1 = __turbopack_context__.r("[project]/node_modules/mobx/dist/mobx.esm.js [app-client] (ecmascript)");
class DebounceActionTimer {
    constructor(debounceMs, handler){
        this.debounceMs = debounceMs;
        this.handler = handler;
        this.requests = [];
        this.startTime = 0;
        this.tick = ()=>{
            let shouldExec = this.debounceMs <= 0;
            if (this.debounceMs > 0) {
                const now = Date.now();
                if (now - this.startTime >= this.debounceMs) {
                    shouldExec = true;
                }
            }
            if (shouldExec) {
                // Should use sliced (copied) array
                const requests = this.requests.slice();
                const responses = this.handler(requests);
                if (typeof responses === "object" && "then" in responses) {
                    Promise.resolve(responses).then((responses)=>{
                        this.handleResponses(requests, responses);
                    });
                } else {
                    this.handleResponses(requests, responses);
                }
                this.requests = [];
            } else {
                this.nextTick(this.tick);
            }
        };
        this.handleResponses = (requests, responses)=>{
            (0, mobx_1.runInAction)(()=>{
                for(let i = 0; i < requests.length; i++){
                    const req = requests[i];
                    const res = responses[i];
                    req.action(res);
                }
            });
            for (const req of requests){
                req.resolver();
            }
        };
    }
    call(args, action) {
        return new Promise((resolve)=>{
            const newStart = this.requests.length === 0;
            this.requests.push({
                args,
                action,
                resolver: resolve
            });
            if (newStart) {
                this.startTimer();
            }
        });
    }
    startTimer() {
        this.startTime = Date.now();
        this.nextTick(this.tick);
    }
    nextTick(fn) {
        if (this.debounceMs <= 0) {
            Promise.resolve().then(fn);
            return;
        }
        if (typeof window !== "undefined" && window.requestAnimationFrame) {
            window.requestAnimationFrame(fn);
        } else {
            setTimeout(fn, this.debounceMs);
        }
    }
}
exports.DebounceActionTimer = DebounceActionTimer; //# sourceMappingURL=debounce.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/mobx/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/mobx/etc.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/mobx/debounce.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/utils/debouncer.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Debouncer = void 0;
class Debouncer {
    static promise(fn) {
        let currentPromise;
        return (...arguments_)=>__awaiter(this, void 0, void 0, function*() {
                if (currentPromise) {
                    return currentPromise;
                }
                try {
                    currentPromise = fn.apply(this, arguments_);
                    return yield currentPromise;
                } finally{
                    currentPromise = undefined;
                }
            });
    }
}
exports.Debouncer = Debouncer; //# sourceMappingURL=debouncer.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/utils/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/utils/debouncer.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/escape/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.unescapeHTML = exports.escapeHTML = void 0;
/**
 * Escapes <,>,& in string.
 * Golang's json marshaller escapes <,>,& by default.
 * However, because JS doesn't do that by default, to match the sign doc with cosmos-sdk,
 * we should escape <,>,& in string manually.
 * @param str
 */ function escapeHTML(str) {
    return str.replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026");
}
exports.escapeHTML = escapeHTML;
/**
 * Unescapes \u003c/(<),\u003e(>),\u0026(&) in string.
 * Golang's json marshaller escapes <,>,& by default, whilst for most of the users, such escape characters are unfamiliar.
 * This function can be used to show the escaped characters with more familiar characters.
 * @param str
 */ function unescapeHTML(str) {
    return str.replace(/\\u003c/g, "<").replace(/\\u003e/g, ">").replace(/\\u0026/g, "&");
}
exports.unescapeHTML = unescapeHTML; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/json/sort.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.sortedJsonByKeyStringify = exports.sortObjectByKey = void 0;
function sortObjectByKey(obj) {
    if (typeof obj !== "object" || obj === null) {
        return obj;
    }
    if (Array.isArray(obj)) {
        return obj.map(sortObjectByKey);
    }
    const sortedKeys = Object.keys(obj).sort();
    const result = {};
    sortedKeys.forEach((key)=>{
        result[key] = sortObjectByKey(obj[key]);
    });
    return result;
}
exports.sortObjectByKey = sortObjectByKey;
function sortedJsonByKeyStringify(obj) {
    return JSON.stringify(sortObjectByKey(obj));
}
exports.sortedJsonByKeyStringify = sortedJsonByKeyStringify; //# sourceMappingURL=sort.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/json/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/json/sort.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/icns/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.validateICNSName = exports.parseICNSName = void 0;
function parseICNSName(name) {
    const split = name.split(".");
    if (split.length === 2) {
        if (split[0].length > 0 && split[1].length > 0) {
            return [
                split[0],
                split[1]
            ];
        }
    }
    return undefined;
}
exports.parseICNSName = parseICNSName;
function validateICNSName(name, bech32Prefix) {
    const parsed = parseICNSName(name);
    if (!parsed) {
        return false;
    }
    return parsed[1] === bech32Prefix;
}
exports.validateICNSName = validateICNSName; //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/common/build/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/kv-store/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/denom/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/mobx/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/utils/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/escape/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/json/index.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/common/build/icns/index.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
"[project]/node_modules/@keplr-wallet/crypto/build/mnemonic.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __awaiter = this && this.__awaiter || function(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Mnemonic = void 0;
// eslint-disable-next-line @typescript-eslint/no-var-requires
const bip39 = __turbopack_context__.r("[project]/node_modules/bip39/src/index.js [app-client] (ecmascript)");
// eslint-disable-next-line @typescript-eslint/no-var-requires
const bip32 = __turbopack_context__.r("[project]/node_modules/bip32/src/index.js [app-client] (ecmascript)");
// eslint-disable-next-line @typescript-eslint/no-var-requires
const bs58check = __turbopack_context__.r("[project]/node_modules/bs58check/index.js [app-client] (ecmascript)");
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
class Mnemonic {
    static generateWallet(rng, path = `m/44'/118'/0'/0/0`, password = "", strength = 256) {
        return __awaiter(this, void 0, void 0, function*() {
            const mnemonic = yield Mnemonic.generateSeed(rng, strength);
            const privKey = Mnemonic.generateWalletFromMnemonic(mnemonic, path, password);
            return {
                privKey,
                mnemonic
            };
        });
    }
    static validateMnemonic(mnemonic) {
        return bip39.validateMnemonic(mnemonic);
    }
    static generateSeed(rng, strength = 128) {
        return __awaiter(this, void 0, void 0, function*() {
            if (strength % 32 !== 0) {
                throw new TypeError("invalid entropy");
            }
            let bytes = new Uint8Array(strength / 8);
            bytes = yield rng(bytes);
            return bip39.entropyToMnemonic(buffer_1.Buffer.from(bytes).toString("hex"));
        });
    }
    static generateWalletFromMnemonic(mnemonic, path = `m/44'/118'/0'/0/0`, password = "") {
        const seed = bip39.mnemonicToSeedSync(mnemonic, password);
        const masterSeed = bip32.fromSeed(seed);
        const hd = masterSeed.derivePath(path);
        const privateKey = hd.privateKey;
        if (!privateKey) {
            throw new Error("null hd key");
        }
        return privateKey;
    }
    static generateMasterSeedFromMnemonic(mnemonic, password = "") {
        const seed = bip39.mnemonicToSeedSync(mnemonic, password);
        const masterKey = bip32.fromSeed(seed);
        return buffer_1.Buffer.from(bs58check.decode(masterKey.toBase58()));
    }
    static generatePrivateKeyFromMasterSeed(seed, path = `m/44'/118'/0'/0/0`) {
        const masterSeed = bip32.fromBase58(bs58check.encode(seed));
        const hd = masterSeed.derivePath(path);
        const privateKey = hd.privateKey;
        if (!privateKey) {
            throw new Error("null hd key");
        }
        return privateKey;
    }
}
exports.Mnemonic = Mnemonic; //# sourceMappingURL=mnemonic.js.map
}}),
"[project]/node_modules/@keplr-wallet/crypto/build/hash.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Hash = void 0;
const sha_js_1 = __turbopack_context__.r("[project]/node_modules/sha.js/index.js [app-client] (ecmascript)");
const keccak256_1 = __turbopack_context__.r("[project]/node_modules/@ethersproject/keccak256/lib.esm/index.js [app-client] (ecmascript)");
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
class Hash {
    static sha256(data) {
        return new Uint8Array(new sha_js_1.sha256().update(data).digest());
    }
    static keccak256(data) {
        return buffer_1.Buffer.from((0, keccak256_1.keccak256)(data).replace("0x", ""), "hex");
    }
    static truncHashPortion(str, firstCharCount = str.length, endCharCount = 0) {
        return str.substring(0, firstCharCount) + "…" + str.substring(str.length - endCharCount, str.length);
    }
}
exports.Hash = Hash; //# sourceMappingURL=hash.js.map
}}),
"[project]/node_modules/@keplr-wallet/crypto/build/key.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.PubKeySecp256k1 = exports.PrivKeySecp256k1 = void 0;
const elliptic_1 = __turbopack_context__.r("[project]/node_modules/elliptic/lib/elliptic.js [app-client] (ecmascript)");
const crypto_js_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/crypto-js/index.js [app-client] (ecmascript)"));
const buffer_1 = __turbopack_context__.f({
    "buffer": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    },
    "buffer/": {
        id: ()=>"[project]/node_modules/buffer/index.js [app-client] (ecmascript)",
        module: ()=>__turbopack_context__.r("[project]/node_modules/buffer/index.js [app-client] (ecmascript)")
    }
})("buffer/");
const hash_1 = __turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/hash.js [app-client] (ecmascript)");
class PrivKeySecp256k1 {
    static generateRandomKey() {
        const secp256k1 = new elliptic_1.ec("secp256k1");
        return new PrivKeySecp256k1(buffer_1.Buffer.from(secp256k1.genKeyPair().getPrivate().toArray()));
    }
    constructor(privKey){
        this.privKey = privKey;
    }
    toBytes() {
        return new Uint8Array(this.privKey);
    }
    getPubKey() {
        const secp256k1 = new elliptic_1.ec("secp256k1");
        const key = secp256k1.keyFromPrivate(this.privKey);
        return new PubKeySecp256k1(new Uint8Array(key.getPublic().encodeCompressed("array")));
    }
    signDigest32(digest) {
        if (digest.length !== 32) {
            throw new Error(`Invalid length of digest to sign: ${digest.length}`);
        }
        const secp256k1 = new elliptic_1.ec("secp256k1");
        const key = secp256k1.keyFromPrivate(this.privKey);
        const signature = key.sign(digest, {
            canonical: true
        });
        return {
            r: new Uint8Array(signature.r.toArray("be", 32)),
            s: new Uint8Array(signature.s.toArray("be", 32)),
            v: signature.recoveryParam
        };
    }
}
exports.PrivKeySecp256k1 = PrivKeySecp256k1;
class PubKeySecp256k1 {
    constructor(pubKey){
        this.pubKey = pubKey;
        if (pubKey.length !== 33 && pubKey.length !== 65) {
            throw new Error(`Invalid length of public key: ${pubKey.length}`);
        }
    }
    toBytes(uncompressed) {
        if (uncompressed && this.pubKey.length === 65) {
            return this.pubKey;
        }
        if (!uncompressed && this.pubKey.length === 33) {
            return this.pubKey;
        }
        const keyPair = this.toKeyPair();
        if (uncompressed) {
            return new Uint8Array(buffer_1.Buffer.from(keyPair.getPublic().encode("hex", false), "hex"));
        } else {
            return new Uint8Array(buffer_1.Buffer.from(keyPair.getPublic().encodeCompressed("hex"), "hex"));
        }
    }
    /**
     * @deprecated Use `getCosmosAddress()` instead.
     */ getAddress() {
        return this.getCosmosAddress();
    }
    getCosmosAddress() {
        let hash = crypto_js_1.default.SHA256(crypto_js_1.default.lib.WordArray.create(this.toBytes(false))).toString();
        hash = crypto_js_1.default.RIPEMD160(crypto_js_1.default.enc.Hex.parse(hash)).toString();
        return new Uint8Array(buffer_1.Buffer.from(hash, "hex"));
    }
    getEthAddress() {
        // Should be uncompressed.
        // And remove prefix byte.
        // And hash by keccak256.
        // Use last 20 bytes.
        return hash_1.Hash.keccak256(this.toBytes(true).slice(1)).slice(-20);
    }
    toKeyPair() {
        const secp256k1 = new elliptic_1.ec("secp256k1");
        return secp256k1.keyFromPublic(buffer_1.Buffer.from(this.pubKey).toString("hex"), "hex");
    }
    verifyDigest32(digest, signature) {
        if (digest.length !== 32) {
            throw new Error(`Invalid length of digest to verify: ${digest.length}`);
        }
        if (signature.length !== 64) {
            throw new Error(`Invalid length of signature: ${signature.length}`);
        }
        const secp256k1 = new elliptic_1.ec("secp256k1");
        const r = signature.slice(0, 32);
        const s = signature.slice(32);
        return secp256k1.verify(digest, {
            r: buffer_1.Buffer.from(r).toString("hex"),
            s: buffer_1.Buffer.from(s).toString("hex")
        }, this.toKeyPair());
    }
}
exports.PubKeySecp256k1 = PubKeySecp256k1; //# sourceMappingURL=key.js.map
}}),
"[project]/node_modules/@keplr-wallet/crypto/build/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/mnemonic.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/key.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@keplr-wallet/crypto/build/hash.js [app-client] (ecmascript)"), exports); //# sourceMappingURL=index.js.map
}}),
}]);

//# sourceMappingURL=node_modules_%40keplr-wallet_fc4d99c2._.js.map