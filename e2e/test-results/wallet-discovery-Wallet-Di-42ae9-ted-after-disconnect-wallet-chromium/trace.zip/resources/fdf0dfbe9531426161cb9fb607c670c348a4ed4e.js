(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectGenericOfflineSigner = exports.AminoGenericOfflineSigner = void 0;
exports.isOfflineAminoSigner = isOfflineAminoSigner;
exports.isOfflineDirectSigner = isOfflineDirectSigner;
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
/**
 * Check if signer is offline amino signer
 */ function isOfflineAminoSigner(signer) {
    return 'signAmino' in signer;
}
/**
 * Check if signer is offline direct signer
 */ function isOfflineDirectSigner(signer) {
    return 'signDirect' in signer;
}
/**
 * Amino general offline signer.
 * This is a wrapper for offline amino signer.
 */ class AminoGenericOfflineSigner {
    offlineSigner;
    constructor(offlineSigner){
        this.offlineSigner = offlineSigner;
    }
    signMode = types_1.SIGN_MODE.AMINO;
    getAccounts() {
        return this.offlineSigner.getAccounts();
    }
    sign({ signerAddress, signDoc }) {
        return this.offlineSigner.signAmino(signerAddress, signDoc);
    }
}
exports.AminoGenericOfflineSigner = AminoGenericOfflineSigner;
/**
 * Direct general offline signer.
 * This is a wrapper for offline direct signer.
 */ class DirectGenericOfflineSigner {
    offlineSigner;
    constructor(offlineSigner){
        this.offlineSigner = offlineSigner;
    }
    signMode = types_1.SIGN_MODE.DIRECT;
    getAccounts() {
        return this.offlineSigner.getAccounts();
    }
    sign({ signerAddress, signDoc }) {
        return this.offlineSigner.signDirect(signerAddress, signDoc);
    }
}
exports.DirectGenericOfflineSigner = DirectGenericOfflineSigner;
}}),
"[project]/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectDocAuth = exports.AminoDocAuth = void 0;
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
/**
 * a helper class to sign the StdSignDoc with Amino encoding using offline signer.
 */ class AminoDocAuth extends types_1.BaseDocAuth {
    getPublicKey() {
        return utils_1.Key.from(this.pubkey);
    }
    async signDoc(doc) {
        let resp;
        if ((0, wallet_1.isOfflineAminoSigner)(this.offlineSigner)) {
            resp = await this.offlineSigner.signAmino(this.address, doc);
        } else {
            resp = await this.offlineSigner.sign({
                signerAddress: this.address,
                signDoc: doc
            });
        }
        return {
            signature: utils_1.Key.fromBase64(resp.signature.signature),
            signDoc: resp.signed
        };
    }
    static async fromOfflineSigner(offlineSigner) {
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new AminoDocAuth(offlineSigner, account.address, account.algo, account.pubkey);
        });
    }
    static async fromGenericOfflineSigner(offlineSigner) {
        if (offlineSigner.signMode !== types_1.SIGN_MODE.AMINO) {
            throw new Error('not an amino general offline signer');
        }
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new AminoDocAuth({
                getAccounts: offlineSigner.getAccounts,
                signAmino (signerAddress, signDoc) {
                    return offlineSigner.sign({
                        signerAddress,
                        signDoc
                    });
                }
            }, account.address, account.algo, account.pubkey);
        });
    }
}
exports.AminoDocAuth = AminoDocAuth;
/**
 * a helper class to sign the SignDoc with Direct encoding using offline signer.
 */ class DirectDocAuth extends types_1.BaseDocAuth {
    getPublicKey() {
        return utils_1.Key.from(this.pubkey);
    }
    async signDoc(doc) {
        // let resp = await this.offlineSigner.signDirect(this.address, doc);
        let resp;
        if ((0, wallet_1.isOfflineDirectSigner)(this.offlineSigner)) {
            resp = await this.offlineSigner.signDirect(this.address, doc);
        } else {
            resp = await this.offlineSigner.sign({
                signerAddress: this.address,
                signDoc: doc
            });
        }
        return {
            signature: utils_1.Key.fromBase64(resp.signature.signature),
            signDoc: resp.signed
        };
    }
    static async fromOfflineSigner(offlineSigner) {
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new DirectDocAuth(offlineSigner, account.address, account.algo, account.pubkey);
        });
    }
    static async fromGenericOfflineSigner(offlineSigner) {
        if (offlineSigner.signMode !== types_1.SIGN_MODE.DIRECT) {
            throw new Error('not a direct general offline signer');
        }
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new DirectDocAuth({
                getAccounts: offlineSigner.getAccounts,
                signDirect (signerAddress, signDoc) {
                    return offlineSigner.sign({
                        signerAddress,
                        signDoc
                    });
                }
            }, account.address, account.algo, account.pubkey);
        });
    }
}
exports.DirectDocAuth = DirectDocAuth;
}}),
"[project]/node_modules/@interchainjs/cosmos/types/query.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isSearchTxQueryObj = isSearchTxQueryObj;
exports.isSearchBlockQueryObj = isSearchBlockQueryObj;
function isSearchTxQueryObj(query) {
    return typeof query === 'object' && 'query' in query;
}
function isSearchBlockQueryObj(query) {
    return typeof query === 'object' && 'query' in query;
}
}}),
"[project]/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TimeoutError = void 0;
class TimeoutError extends Error {
    txId;
    constructor(message, txId){
        super(message);
        this.txId = txId;
    }
}
exports.TimeoutError = TimeoutError;
}}),
"[project]/node_modules/@interchainjs/cosmos/types/signer.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CosmosAccount = void 0;
exports.isICosmosAccount = isICosmosAccount;
const account_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/account.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const ripemd160_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/ripemd160.js [app-client] (ecmascript)");
const sha256_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/sha256.js [app-client] (ecmascript)");
/**
 * Check if instance is cosmos account
 */ function isICosmosAccount(instance) {
    return instance.toAccountData !== undefined;
}
/**
 * Cosmos account implementation
 */ class CosmosAccount extends account_1.AccountBase {
    getAddressByPubKey() {
        return utils_1.Key.from((0, ripemd160_1.ripemd160)((0, sha256_1.sha256)(this.publicKey.value))).toBech32(this.prefix);
    }
}
exports.CosmosAccount = CosmosAccount;
}}),
"[project]/node_modules/@interchainjs/cosmos/types/signing-client.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isISigningClient = isISigningClient;
function isISigningClient(client) {
    return client !== null && client !== undefined && typeof client.signAndBroadcast === 'function' && (!client.addConverters || typeof client.addConverters === 'function') && (!client.addEncoders || typeof client.addEncoders === 'function');
}
}}),
"[project]/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/query.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/signer.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/signing-client.js [app-client] (ecmascript)"), exports);
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/accounts.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isBaseAccount = isBaseAccount;
const auth_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/auth.js [app-client] (ecmascript)");
function isBaseAccount(o) {
    return o && (o.$typeUrl === auth_1.BaseAccount.typeUrl || typeof o.address === "string" && typeof o.accountNumber === "bigint" && typeof o.sequence === "bigint");
}
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/amino.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.encodeStdSignDoc = encodeStdSignDoc;
exports.toMessages = toMessages;
exports.toAminoMsgs = toAminoMsgs;
exports.toFee = toFee;
exports.toStdFee = toStdFee;
exports.toConverter = toConverter;
exports.toConverters = toConverters;
const coin_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
function sortKey(target) {
    if (target === null || typeof target !== 'object') {
        return target;
    }
    if (Array.isArray(target)) {
        return target.map(sortKey);
    }
    const sortedObj = {};
    Object.keys(target).sort().forEach((key)=>{
        sortedObj[key] = sortKey(target[key]);
    });
    return sortedObj;
}
/**
 * Encode the StdSignDoc to bytes for amino signing
 */ function encodeStdSignDoc(doc) {
    const sorted = sortKey(doc);
    const str = JSON.stringify(sorted);
    const serialized = str.replaceAll('&', '\\u0026').replaceAll('<', '\\u003c').replaceAll('>', '\\u003e');
    return (0, utils_1.fromUtf8)(serialized);
}
/**
 * from Amino messages to protobuf messages
 */ function toMessages(aminoMsgs, getConverter) {
    return aminoMsgs.map(({ type, value })=>{
        const { fromAmino, typeUrl } = getConverter(type);
        return {
            typeUrl,
            value: fromAmino(value)
        };
    });
}
/**
 * from protobuf messages to Amino messages
 */ function toAminoMsgs(messages, getConverter) {
    return messages.map(({ typeUrl, value })=>{
        const { toAmino, aminoType } = getConverter(typeUrl);
        return {
            type: aminoType,
            value: toAmino(value)
        };
    });
}
/**
 * Convert StdFee to Fee
 */ function toFee(fee) {
    return tx_1.Fee.fromPartial({
        amount: fee.amount.map((coin)=>coin_1.Coin.fromPartial(coin)),
        gasLimit: BigInt(fee.gas),
        payer: fee.payer,
        granter: fee.granter
    });
}
/**
 * Convert Fee to StdFee
 */ function toStdFee(fee) {
    return {
        amount: fee.amount,
        gas: fee.gasLimit.toString(),
        granter: fee.granter === '' ? void 0 : fee.granter,
        payer: fee.payer === '' ? void 0 : fee.payer
    };
}
/**
 * from telescope generated codec to AminoConverter
 */ function toConverter(generated) {
    (0, utils_1.assertEmpty)(generated.aminoType);
    return {
        aminoType: generated.aminoType,
        typeUrl: generated.typeUrl,
        fromAmino: (data)=>{
            (0, utils_1.assertEmpty)(generated.fromAmino);
            return generated.fromAmino(data);
        },
        toAmino: (data)=>{
            (0, utils_1.assertEmpty)(generated.toAmino);
            return generated.toAmino(data);
        }
    };
}
/**
 * from telescope generated codecs to AminoConverters
 */ function toConverters(...generatedArray) {
    return generatedArray.map((generated)=>toConverter(generated));
}
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/asserts.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isDeliverTxFailure = isDeliverTxFailure;
exports.isDeliverTxSuccess = isDeliverTxSuccess;
exports.assertIsDeliverTxSuccess = assertIsDeliverTxSuccess;
exports.assertIsDeliverTxFailure = assertIsDeliverTxFailure;
function isDeliverTxFailure(resp) {
    return resp.code !== 0;
}
function isDeliverTxSuccess(resp) {
    return !isDeliverTxFailure(resp);
}
function assertIsDeliverTxSuccess(resp) {
    if (isDeliverTxFailure(resp)) {
        throw new Error(`Error when broadcasting tx ${resp.transactionHash} at height ${resp.height}. Code: ${resp.code}; Raw log: ${resp.rawLog}`);
    }
}
function assertIsDeliverTxFailure(resp) {
    if (isDeliverTxSuccess(resp)) {
        throw new Error(`Transaction ${resp.transactionHash} did not fail at height ${resp.height}. Code: ${resp.code}; Raw log: ${resp.rawLog}`);
    }
}
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAvgGasPrice = getAvgGasPrice;
exports.getHighGasPrice = getHighGasPrice;
exports.getLowGasPrice = getLowGasPrice;
exports.calculateFee = calculateFee;
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/decimal.js/decimal.js [app-client] (ecmascript)"));
const defaults_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
/**
 * get the average gas price of the chain
 */ function getAvgGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.averageGasPrice === 'undefined') {
        throw new Error(`No averageGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.averageGasPrice),
        denom: feeToken.denom
    };
}
function getHighGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.highGasPrice === 'undefined') {
        throw new Error(`No highGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.highGasPrice),
        denom: feeToken.denom
    };
}
function getLowGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.lowGasPrice === 'undefined') {
        throw new Error(`No lowGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.lowGasPrice),
        denom: feeToken.denom
    };
}
/**
 * calculate fee based on gas info
 */ async function calculateFee(gasInfo, options, getChainId) {
    const gasLimit = new decimal_js_1.default(gasInfo.gasUsed.toString()).mul(options?.multiplier || defaults_1.defaultFeeOptions.multiplier).ceil();
    let price;
    switch(options?.gasPrice ?? defaults_1.defaultFeeOptions.gasPrice){
        case 'average':
            price = getAvgGasPrice(await getChainId());
            break;
        case 'high':
            price = getHighGasPrice(await getChainId());
            break;
        case 'low':
            price = getLowGasPrice(await getChainId());
            break;
        default:
            price = (0, utils_1.toPrice)(options?.gasPrice);
            break;
    }
    if (price.denom.length < 3 || price.denom.length > 128) {
        throw new Error('Denom must be between 3 and 128 characters');
    }
    return {
        amount: [
            {
                amount: gasLimit.mul(price.amount).ceil().toString(),
                denom: price.denom
            }
        ],
        gas: gasLimit.toString()
    };
}
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.constructAuthInfo = constructAuthInfo;
exports.toEncoder = toEncoder;
exports.toEncoders = toEncoders;
exports.toDecoder = toDecoder;
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
function constructAuthInfo(signerInfos, fee) {
    const authInfo = tx_1.AuthInfo.fromPartial({
        signerInfos,
        fee
    });
    return {
        authInfo,
        encode: ()=>tx_1.AuthInfo.encode(authInfo).finish()
    };
}
/**
 * from telescope generated codec to encoder
 */ function toEncoder(generated) {
    return {
        typeUrl: generated.typeUrl,
        fromPartial: generated.fromPartial,
        encode: (data)=>{
            (0, utils_1.assertEmpty)(generated.encode);
            const encoded = generated.encode(generated.fromPartial(data));
            return encoded.finish ? encoded.finish() : encoded;
        }
    };
}
/**
 * from telescope generated codecs to encoders
 */ function toEncoders(...generatedArray) {
    return generatedArray.map((generated)=>toEncoder(generated));
}
/**
 * from telescope generated codec to decoder
 */ function toDecoder(generated) {
    return {
        typeUrl: generated.typeUrl,
        fromPartial: generated.fromPartial,
        decode: (data)=>{
            (0, utils_1.assertEmpty)(generated.decode);
            return generated.decode(data);
        }
    };
}
}}),
"[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/accounts.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/amino.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/asserts.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)"), exports);
}}),
"[project]/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.defaultWalletOptions = exports.defaultSignerOptions = exports.defaultAccountParser = exports.defaultPublicKeyEncoder = exports.defaultSignerConfig = exports.defaultFeeOptions = exports.defaultBroadcastOptions = void 0;
const auth_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/auth.js [app-client] (ecmascript)");
const keys_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/crypto/secp256k1/keys.js [app-client] (ecmascript)");
const vesting_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/vesting/v1beta1/vesting.js [app-client] (ecmascript)");
const account_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/injective/types/v1beta1/account.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/utils.js [app-client] (ecmascript)");
const ripemd160_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/ripemd160.js [app-client] (ecmascript)");
const sha256_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/sha256.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)");
const utils_3 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
const secp256k1_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/auth/secp256k1.js [app-client] (ecmascript)");
exports.defaultBroadcastOptions = {
    checkTx: true,
    deliverTx: false,
    timeoutMs: 60_000,
    pollIntervalMs: 3_000
};
exports.defaultFeeOptions = {
    multiplier: 1.6,
    gasPrice: 'average'
};
/**
 * Default signer configuration for Cosmos chains.
 */ exports.defaultSignerConfig = {
    publicKey: {
        isCompressed: true,
        hash: (publicKey)=>utils_1.Key.from((0, ripemd160_1.ripemd160)((0, sha256_1.sha256)(publicKey.value)))
    },
    message: {
        hash: (message)=>{
            const hashed = (0, sha256_1.sha256)(message);
            (0, utils_2.bytesToHex)(hashed);
            return hashed;
        }
    }
};
const defaultPublicKeyEncoder = (key)=>{
    return {
        typeUrl: keys_1.PubKey.typeUrl,
        value: keys_1.PubKey.encode(keys_1.PubKey.fromPartial({
            key: key.value
        })).finish()
    };
};
exports.defaultPublicKeyEncoder = defaultPublicKeyEncoder;
const accountCodecs = [
    auth_1.BaseAccount,
    auth_1.ModuleAccount,
    vesting_1.BaseVestingAccount,
    vesting_1.ContinuousVestingAccount,
    vesting_1.DelayedVestingAccount,
    vesting_1.PeriodicVestingAccount,
    account_1.EthAccount
];
const defaultAccountParser = (encodedAccount)=>{
    const codec = accountCodecs.find((codec)=>codec.typeUrl === encodedAccount.typeUrl);
    if (!codec) {
        throw new Error(`No corresponding account found for account type ${encodedAccount.typeUrl}.`);
    }
    const decoder = (0, utils_3.toDecoder)(codec);
    const account = decoder.fromPartial(decoder.decode(encodedAccount.value));
    const baseAccount = account.baseVestingAccount?.baseAccount || account.baseAccount || account;
    return baseAccount;
};
exports.defaultAccountParser = defaultAccountParser;
exports.defaultSignerOptions = {
    ...exports.defaultSignerConfig,
    parseAccount: exports.defaultAccountParser,
    createAccount: types_1.CosmosAccount,
    encodePublicKey: exports.defaultPublicKeyEncoder,
    prefix: undefined
};
exports.defaultWalletOptions = {
    bip39Password: undefined,
    createAuthsFromMnemonic: secp256k1_1.Secp256k1Auth.fromMnemonic,
    signerConfig: exports.defaultSignerOptions
};
}}),
"[project]/node_modules/@interchainjs/cosmos/query/rpc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RpcClient = void 0;
const signing_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const query_rpc_func_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/query.rpc.func.js [app-client] (ecmascript)");
const service_rpc_func_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/service.rpc.func.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
const rpc_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)");
const direct_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const utils_3 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
const abci_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/base/abci/v1beta1/abci.js [app-client] (ecmascript)");
/**
 * client for cosmos rpc
 */ class RpcClient {
    endpoint;
    chainId;
    accountNumber;
    getAccount;
    getSimulate;
    parseAccount = defaults_1.defaultAccountParser;
    _prefix;
    txRpc;
    constructor(endpoint, prefix){
        this.endpoint = (0, utils_1.toHttpEndpoint)(endpoint);
        this.txRpc = (0, utils_2.createQueryRpc)(this.endpoint);
        this._prefix = prefix;
    }
    setAccountParser(parseBaseAccount) {
        this.parseAccount = parseBaseAccount;
    }
    async getPrefix() {
        return this._prefix ?? (0, utils_2.getPrefix)(await this.getChainId());
    }
    /**
     * get basic account info by address
     */ async getBaseAccount(address) {
        const accountResp = await (0, query_rpc_func_1.getAccount)(this.txRpc, {
            address
        });
        if (!accountResp || !accountResp.account) {
            throw new Error(`Account is undefined.`);
        }
        // if the account is a BaseAccount, return it
        if ((0, utils_3.isBaseAccount)(accountResp.account)) {
            return accountResp.account;
        }
        // if there's a baseAccount in the account, and it's a BaseAccount, return it
        if ('baseAccount' in accountResp.account && accountResp.account.baseAccount && (0, utils_3.isBaseAccount)(accountResp.account.baseAccount)) {
            return accountResp.account.baseAccount;
        }
        // otherwise, parse the account from Any type.
        return this.parseAccount(accountResp.account);
    }
    /**
     * get status of the chain
     */ async getStatus() {
        const data = await fetch(`${this.endpoint.url}/status`);
        const json = await data.json();
        return json['result'] ?? json;
    }
    /**
     * get chain id
     */ getChainId = async ()=>{
        if ((0, utils_1.isEmpty)(this.chainId)) {
            const status = await this.getStatus();
            this.chainId = status.node_info.network;
        }
        return this.chainId;
    };
    /**
     * get the latest block height
     */ async getLatestBlockHeight() {
        const status = await this.getStatus();
        return BigInt(status.sync_info.latest_block_height);
    }
    /**
     * get account number by address
     */ async getAccountNumber(address) {
        if ((0, utils_1.isEmpty)(this.accountNumber)) {
            const account = await this.getBaseAccount(address);
            this.accountNumber = account.accountNumber;
        }
        return this.accountNumber;
    }
    /**
     * get sequence by address
     */ async getSequence(address) {
        const account = await this.getBaseAccount(address);
        return account.sequence;
    }
    /**
     * get the account of the current signer
     */ async simulate(txBody, signerInfos) {
        const tx = tx_1.Tx.fromPartial({
            body: txBody,
            authInfo: (0, direct_1.constructAuthInfo)(signerInfos.map((signerInfo)=>{
                return {
                    ...signerInfo,
                    modeInfo: {
                        single: {
                            mode: signing_1.SignMode.SIGN_MODE_UNSPECIFIED
                        }
                    }
                };
            }), tx_1.Fee.fromPartial({})).authInfo,
            signatures: [
                new Uint8Array()
            ]
        });
        return await (0, service_rpc_func_1.getSimulate)(this.txRpc, {
            tx: void 0,
            txBytes: tx_1.Tx.encode(tx).finish()
        });
    }
    /**
     * Decode TxMsgData from base64-encoded data
     */ decodeTxMsgData(data) {
        return abci_1.TxMsgData.decode(data ? (0, utils_1.fromBase64)(data) : new Uint8Array());
    }
    /**
     * get the transaction by hash(id)
     */ async getTx(id) {
        const data = await fetch(`${this.endpoint.url}/tx?hash=0x${id}`);
        const json = await data.json();
        const tx = json['result'];
        if (!tx) return null;
        const txMsgData = this.decodeTxMsgData(tx.tx_result.data);
        return {
            height: tx.height,
            txIndex: tx.index,
            hash: tx.hash,
            code: tx.tx_result.code,
            events: tx.tx_result.events,
            rawLog: tx.tx_result.log,
            tx: (0, utils_1.fromBase64)(tx.tx),
            msgResponses: txMsgData.msgResponses,
            gasUsed: BigInt(tx.tx_result.gas_used),
            gasWanted: BigInt(tx.tx_result.gas_wanted),
            data: tx.tx_result.data,
            log: tx.tx_result.log,
            info: tx.tx_result.info
        };
    }
    /**
     * broadcast a transaction.
     * there're three modes:
     * - 'broadcast_tx_async': broadcast the transaction and return immediately.
     * - 'broadcast_tx_sync': broadcast the transaction and wait for the response.
     * - 'broadcast_tx_commit': broadcast the transaction and wait for the response and the transaction to be included in a block.
     */ async broadcast(txBytes, options) {
        const { checkTx, deliverTx, timeoutMs, pollIntervalMs, useLegacyBroadcastTxCommit } = {
            ...defaults_1.defaultBroadcastOptions,
            ...options
        };
        const mode = checkTx && deliverTx ? 'broadcast_tx_commit' : checkTx ? 'broadcast_tx_sync' : 'broadcast_tx_async';
        const resp = await (0, utils_2.broadcast)(this.endpoint, mode === 'broadcast_tx_commit' && !useLegacyBroadcastTxCommit ? 'broadcast_tx_async' : mode, txBytes);
        switch(mode){
            case 'broadcast_tx_async':
                return {
                    transactionHash: resp.hash,
                    hash: resp.hash,
                    code: resp.code,
                    height: 0,
                    txIndex: 0,
                    events: [],
                    msgResponses: [],
                    gasUsed: 0n,
                    gasWanted: 0n,
                    rawLog: resp.log || "",
                    data: [],
                    origin: resp
                };
            case 'broadcast_tx_sync':
                return {
                    transactionHash: resp.hash,
                    hash: resp.hash,
                    code: resp.code,
                    height: 0,
                    txIndex: 0,
                    events: [],
                    msgResponses: [],
                    gasUsed: 0n,
                    gasWanted: 0n,
                    rawLog: resp.log || "",
                    data: [],
                    origin: resp
                };
            case 'broadcast_tx_commit':
                if (useLegacyBroadcastTxCommit) {
                    const msgResponses = this.decodeTxMsgData(resp.deliver_tx.data).msgResponses;
                    const data = msgResponses.map((res)=>{
                        return {
                            msgType: res.typeUrl,
                            data: res.value
                        };
                    });
                    return {
                        transactionHash: resp.hash,
                        hash: resp.hash,
                        code: resp.deliver_tx.code,
                        height: resp.height,
                        txIndex: 0,
                        events: resp.deliver_tx.events,
                        msgResponses,
                        data,
                        gasUsed: BigInt(resp.deliver_tx.gas_used),
                        gasWanted: BigInt(resp.deliver_tx.gas_wanted),
                        rawLog: resp.deliver_tx.log || "",
                        origin: resp
                    };
                } else {
                    let timedOut = false;
                    const txPollTimeout = setTimeout(()=>{
                        timedOut = true;
                    }, timeoutMs);
                    const pollForTx = async (txId)=>{
                        if (timedOut) {
                            throw new rpc_1.TimeoutError(`Transaction with ID ${txId} was submitted but was not yet found on the chain. You might want to check later. There was a wait of ${timeoutMs / 1000} seconds.`, txId);
                        }
                        await (0, utils_2.sleep)(pollIntervalMs);
                        const result = await this.getTx(txId);
                        return result ? {
                            transactionHash: result.hash,
                            hash: result.hash,
                            code: result.code,
                            height: result.height,
                            txIndex: result.txIndex,
                            events: result.events,
                            msgResponses: result.msgResponses,
                            gasUsed: result.gasUsed,
                            gasWanted: result.gasWanted,
                            rawLog: result.rawLog,
                            data: result.msgResponses.map((res)=>{
                                return {
                                    msgType: res.typeUrl,
                                    data: res.value
                                };
                            }),
                            origin: result
                        } : pollForTx(txId);
                    };
                    const transactionId = resp.hash.toUpperCase();
                    return new Promise((resolve, reject)=>pollForTx(transactionId).then((value)=>{
                            clearTimeout(txPollTimeout);
                            resolve(value);
                        }, (error)=>{
                            clearTimeout(txPollTimeout);
                            reject(error);
                        }));
                }
            default:
                throw new Error(`Wrong method: ${mode}`);
        }
    }
}
exports.RpcClient = RpcClient;
}}),
"[project]/node_modules/@interchainjs/cosmos/base/base-signer.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CosmosBaseSigner = exports.CosmosDocSigner = void 0;
const signing_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
const rpc_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/query/rpc.js [app-client] (ecmascript)");
const chain_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * Base class for Cosmos Doc Signer.
 * It provides the basic methods for signing a document.
 * @template TDoc - The type of the document to be signed.
 *  * @template TArgs The type of the args.
 */ class CosmosDocSigner extends types_1.BaseSigner {
    constructor(auth, config){
        super(auth, config);
        this.txBuilder = this.getTxBuilder();
    }
    /**
     * signature builder
     */ txBuilder;
    /**
     * Sign a document.
     */ async signDoc(doc) {
        if ((0, types_1.isDocAuth)(this.auth)) {
            return await this.auth.signDoc(doc);
        } else {
            const sig = await this.txBuilder.buildSignature(doc);
            return {
                signature: sig,
                signDoc: doc
            };
        }
    }
}
exports.CosmosDocSigner = CosmosDocSigner;
/**
 * Base class for Cosmos Signer.
 */ class CosmosBaseSigner extends CosmosDocSigner {
    /**
     * QueryClient for querying chain data.
     */ _queryClient;
    /**
     * registered encoders
     */ encoders;
    /**
     * encode public key to EncodedMessage
     * the method is provided by the config
     */ _encodePublicKey;
    /**
     * parse account from EncodedMessage
     * the method is provided by the config
     */ parseAccount;
    /**
     * prefix of the chain.
     * will get from queryClient if not set.
     */ prefix;
    /**
     * account info of the current signer.
     */ account;
    /**
     * broadcast options
     */ broadcastOptions;
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, {
            ...defaults_1.defaultSignerOptions,
            ...options
        });
        this.encoders = encoders;
        this.parseAccount = options?.parseAccount ?? defaults_1.defaultSignerOptions.parseAccount;
        this._encodePublicKey = options?.encodePublicKey ?? defaults_1.defaultSignerOptions.encodePublicKey;
        this.prefix = options?.prefix;
        this.broadcastOptions = broadcastOptions;
        if (!(0, utils_1.isEmpty)(endpoint)) {
            this.setEndpoint(endpoint);
        }
        this.txBuilder = this.getTxBuilder();
    }
    get encodedPublicKey() {
        return this._encodePublicKey(this.publicKey);
    }
    /**
     * register encoders
     */ addEncoders = (encoders)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.encoders.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newEncoders = encoders.filter((encoder)=>!existingTypeUrls.has(encoder.typeUrl));
        // Add only the unique converters
        this.encoders.push(...newEncoders.map(utils_2.toEncoder));
    };
    /**
     * get prefix of the chain
     * @returns prefix of the chain
     */ getPrefix = async ()=>{
        if (this.prefix) {
            return this.prefix;
        }
        if (this.queryClient) {
            return this.queryClient.getPrefix();
        }
        throw new Error("Can't get prefix because no queryClient is set");
    };
    /**
     * get encoder by typeUrl
     */ getEncoder = (typeUrl)=>{
        const encoder = this.encoders.find((encoder)=>encoder.typeUrl === typeUrl);
        if (!encoder) {
            throw new Error(`No such Encoder for typeUrl ${typeUrl}, please add corresponding Encoder with method \`addEncoder\``);
        }
        return encoder;
    };
    /**
     * get the address of the current signer
     * @returns the address of the current signer
     */ async getAddress() {
        if (!this.account) {
            this.account = await this.getAccount();
        }
        return this.account.address;
    }
    /**
     * get account by account creator
     */ async getAccount() {
        const opts = this.config;
        if (opts.createAccount) {
            return new opts.createAccount(await this.getPrefix(), this.auth, this.config.publicKey.isCompressed);
        } else {
            throw new Error('No account creator is provided, or you can try to override the method `getAccount`');
        }
    }
    /**
     * set the endpoint of the queryClient
     */ setEndpoint(endpoint) {
        this._queryClient = new rpc_1.RpcClient(endpoint, this.prefix);
        this._queryClient.setAccountParser(this.parseAccount);
    }
    /**
     * get the queryClient
     */ get queryClient() {
        (0, utils_1.assertEmpty)(this._queryClient);
        return this._queryClient;
    }
    /**
     * convert relative timeoutHeight to absolute timeoutHeight
     */ async toAbsoluteTimeoutHeight(timeoutHeight) {
        return (0, utils_1.isEmpty)(timeoutHeight) ? void 0 : {
            type: 'absolute',
            value: timeoutHeight.type === 'absolute' ? timeoutHeight.value : await this.queryClient.getLatestBlockHeight() + timeoutHeight.value
        };
    }
    /**
     * sign tx messages with fee, memo, etc.
     * @param args - arguments for signing, e.g. messages, fee, memo, etc.
     * @returns a response object with the signed document and a broadcast method
     */ async sign(args) {
        const signed = await this.txBuilder.buildSignedTxDoc(args);
        return {
            ...signed,
            broadcast: async (options)=>{
                return this.broadcast(signed.tx, options);
            }
        };
    }
    /**
     * broadcast a signed document
     * @param txRaw - the signed document
     * @param options - options for broadcasting
     * @returns a broadcast response
     */ async broadcast(txRaw, options) {
        return this.broadcastArbitrary(tx_1.TxRaw.encode(tx_1.TxRaw.fromPartial(txRaw)).finish(), options);
    }
    /**
     * broadcast an arbitrary message in bytes
     */ async broadcastArbitrary(message, options) {
        const result = await this.queryClient.broadcast(message, options);
        return result;
    }
    /**
     * sign and broadcast tx messages
     */ async signAndBroadcast(args, messageOrOptions, fee, memo, options) {
        if (typeof args === 'string') {
            if (args !== await this.getAddress()) {
                throw new Error('signerAddress is not match');
            }
            return this._signAndBroadcast({
                messages: messageOrOptions,
                fee: fee === 'auto' ? undefined : fee,
                memo: memo,
                options: options
            }, this.broadcastOptions);
        }
        return this._signAndBroadcast(args, messageOrOptions ? messageOrOptions : this.broadcastOptions);
    }
    /**
     * sign and broadcast tx messages
     */ async _signAndBroadcast({ messages, fee, memo, options: signOptions }, options) {
        const { broadcast } = await this.sign({
            messages,
            fee,
            memo,
            options: signOptions
        });
        return await broadcast(options);
    }
    /**
     * simulate broadcasting tx messages.
     */ async simulate({ messages, memo, options }) {
        const { txBody } = await this.txBuilder.buildTxBody({
            messages,
            memo,
            options
        });
        const { signerInfo } = await this.txBuilder.buildSignerInfo(this.encodedPublicKey, options?.sequence ?? await this.queryClient.getSequence(await this.getAddress()), options?.signMode ?? signing_1.SignMode.SIGN_MODE_DIRECT);
        return await this.simulateByTxBody(txBody, [
            signerInfo
        ]);
    }
    /**
     * simulate broadcasting txBody.
     */ async simulateByTxBody(txBody, signerInfos) {
        return await this.queryClient.simulate(txBody, signerInfos);
    }
    /**
     * estimate fee for tx messages.
     */ async estimateFee({ messages, memo, options }) {
        const { gasInfo } = await this.simulate({
            messages,
            memo,
            options
        });
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, chain_1.calculateFee)(gasInfo, options, this.queryClient.getChainId);
    }
    /**
     * estimate fee by txBody.
     */ async estimateFeeByTxBody(txBody, signerInfos, options) {
        const { gasInfo } = await this.simulateByTxBody(txBody, signerInfos);
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, chain_1.calculateFee)(gasInfo, options, this.queryClient.getChainId);
    }
}
exports.CosmosBaseSigner = CosmosBaseSigner;
}}),
"[project]/node_modules/@interchainjs/cosmos/base/base-wallet.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosWallet = void 0;
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
/**
 * Cosmos HD Wallet for secp256k1
 */ class BaseCosmosWallet {
    accounts;
    options;
    constructor(accounts, options){
        this.options = {
            ...defaults_1.defaultSignerConfig,
            ...options
        };
        this.accounts = accounts;
    }
    /**
     * Get account data
     * @returns account data
     */ async getAccounts() {
        return this.accounts.map((acct)=>{
            return acct.toAccountData();
        });
    }
    /**
     * Get one of the accounts using the address.
     * @param address
     * @returns
     */ getAcctFromBech32Addr(address) {
        const id = this.accounts.findIndex((acct)=>acct.address === address);
        if (id === -1) {
            throw new Error('No such signerAddress been authed.');
        }
        return this.accounts[id];
    }
    /**
     * Sign direct doc for signerAddress
     */ async signDirect(signerAddress, signDoc) {
        const account = this.getAcctFromBech32Addr(signerAddress);
        const docSigner = this.getDirectDocSigner(account.auth, this.options);
        const resp = await docSigner.signDoc(signDoc);
        return {
            signed: resp.signDoc,
            signature: {
                pub_key: {
                    type: 'tendermint/PubKeySecp256k1',
                    value: {
                        key: account.publicKey.toBase64()
                    }
                },
                signature: resp.signature.toBase64()
            }
        };
    }
    /**
     * sign amino doc for signerAddress
     */ async signAmino(signerAddress, signDoc) {
        const account = this.getAcctFromBech32Addr(signerAddress);
        const docSigner = this.getAminoDocSigner(account.auth, this.options);
        const resp = await docSigner.signDoc(signDoc);
        return {
            signed: resp.signDoc,
            signature: {
                pub_key: {
                    type: 'tendermint/PubKeySecp256k1',
                    value: {
                        key: account.publicKey.toBase64()
                    }
                },
                signature: resp.signature.toBase64()
            }
        };
    }
    /**
     * Convert this to offline direct signer for hiding the private key.
     */ toOfflineDirectSigner() {
        return {
            getAccounts: async ()=>this.getAccounts(),
            signDirect: async (signerAddress, signDoc)=>this.signDirect(signerAddress, signDoc)
        };
    }
    /**
     * Convert this to offline amino signer for hiding the private key.
     */ toOfflineAminoSigner() {
        return {
            getAccounts: async ()=>this.getAccounts(),
            signAmino: async (signerAddress, signDoc)=>this.signAmino(signerAddress, signDoc)
        };
    }
    /**
     * Convert this to general offline signer for hiding the private key.
     * @param signMode sign mode. (direct or amino)
     * @returns general offline signer for direct or amino
     */ toGenericOfflineSigner(signMode) {
        switch(signMode){
            case types_1.SIGN_MODE.DIRECT:
                return {
                    signMode: signMode,
                    getAccounts: async ()=>this.getAccounts(),
                    sign: async ({ signerAddress, signDoc })=>this.signDirect(signerAddress, signDoc)
                };
            case types_1.SIGN_MODE.AMINO:
                return {
                    signMode: signMode,
                    getAccounts: async ()=>this.getAccounts(),
                    sign: async ({ signerAddress, signDoc })=>this.signAmino(signerAddress, signDoc)
                };
            default:
                throw new Error('Invalid sign mode');
        }
    }
}
exports.BaseCosmosWallet = BaseCosmosWallet;
}}),
"[project]/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosTxBuilderContext = void 0;
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
/**
 * Context for the transaction builder.
 */ class BaseCosmosTxBuilderContext extends types_1.BaseTxBuilderContext {
    signer;
    constructor(signer){
        super(signer);
        this.signer = signer;
    }
}
exports.BaseCosmosTxBuilderContext = BaseCosmosTxBuilderContext;
}}),
"[project]/node_modules/@interchainjs/cosmos/base/tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosTxBuilder = exports.BaseCosmosSigBuilder = exports.STAGING_AUTH_INFO = void 0;
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
exports.STAGING_AUTH_INFO = 'staging_auth_info';
/**
 * BaseCosmosSigBuilder is a helper class to build the signature from the document
 */ class BaseCosmosSigBuilder {
    ctx;
    constructor(ctx){
        this.ctx = ctx;
    }
    /**
     * build signature from the document
     * @param doc - The document to be signed.
     */ async buildSignature(doc) {
        // get doc bytes
        const docBytes = await this.buildDocBytes(doc);
        // sign signature to the doc bytes
        return this.ctx.signer.signArbitrary(docBytes);
    }
}
exports.BaseCosmosSigBuilder = BaseCosmosSigBuilder;
/**
 * BaseCosmosTxBuilder is a helper class to build the Tx and signDoc
 */ class BaseCosmosTxBuilder extends BaseCosmosSigBuilder {
    signMode;
    ctx;
    constructor(signMode, ctx){
        super(ctx);
        this.signMode = signMode;
        this.ctx = ctx;
    }
    async buildTxRaw({ messages, fee, memo, options }) {
        const { txBody, encode: txBodyEncode } = await this.buildTxBody({
            messages,
            memo,
            options
        });
        const { signerInfo } = await this.buildSignerInfo(this.ctx.signer.encodedPublicKey, options?.sequence ?? await this.ctx.signer.queryClient.getSequence(await this.ctx.signer.getAddress()), this.signMode);
        const stdFee = await this.getFee(fee, txBody, [
            signerInfo
        ], options);
        const { authInfo, encode: authEncode } = await this.buildAuthInfo([
            signerInfo
        ], (0, utils_1.toFee)(stdFee));
        this.ctx.setStagingData(exports.STAGING_AUTH_INFO, authInfo);
        return {
            bodyBytes: txBodyEncode(),
            authInfoBytes: authEncode(),
            fee: stdFee
        };
    }
    async buildTxBody({ messages, memo, options }) {
        if (options?.timeoutHeight?.type === 'relative') {
            throw new Error("timeoutHeight type in function `constructTxBody` shouldn't be `relative`. Please update it to `absolute` value before calling this function.");
        }
        const encoded = messages.map(({ typeUrl, value })=>{
            return {
                typeUrl,
                value: this.ctx.signer.getEncoder(typeUrl).encode(value)
            };
        });
        const txBody = tx_1.TxBody.fromPartial({
            messages: encoded,
            memo,
            timeoutHeight: options?.timeoutHeight?.value,
            extensionOptions: options?.extensionOptions,
            nonCriticalExtensionOptions: options?.nonCriticalExtensionOptions
        });
        return {
            txBody,
            encode: ()=>tx_1.TxBody.encode(txBody).finish()
        };
    }
    async buildSignerInfo(publicKey, sequence, signMode) {
        const signerInfo = tx_1.SignerInfo.fromPartial({
            publicKey,
            sequence,
            modeInfo: {
                single: {
                    mode: signMode
                }
            }
        });
        return {
            signerInfo,
            encode: ()=>tx_1.SignerInfo.encode(signerInfo).finish()
        };
    }
    async buildAuthInfo(signerInfos, fee) {
        const authInfo = tx_1.AuthInfo.fromPartial({
            signerInfos,
            fee
        });
        return {
            authInfo,
            encode: ()=>tx_1.AuthInfo.encode(authInfo).finish()
        };
    }
    async getFee(fee, txBody, signerInfos, options) {
        if (fee) {
            return fee;
        }
        const { gasInfo } = await this.ctx.signer.simulateByTxBody(txBody, signerInfos);
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, utils_1.calculateFee)(gasInfo, options, async ()=>{
            return this.ctx.signer.queryClient.getChainId();
        });
    }
    async buildSignedTxDoc({ messages, fee, memo, options }) {
        // create partial TxRaw
        const txRaw = await this.buildTxRaw({
            messages,
            fee,
            memo,
            options
        });
        // buildDoc
        const doc = await this.buildDoc({
            messages,
            fee: fee ?? txRaw.fee,
            memo,
            options
        }, txRaw);
        // sign signature to the doc bytes
        const signResp = await this.ctx.signer.signDoc(doc);
        // build TxRaw and sync with signed doc
        const signedTxRaw = await this.syncSignedDoc(tx_1.TxRaw.fromPartial(txRaw), signResp);
        return {
            tx: signedTxRaw,
            doc: doc
        };
    }
}
exports.BaseCosmosTxBuilder = BaseCosmosTxBuilder;
}}),
"[project]/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/base-signer.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/base-wallet.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/tx-builder.js [app-client] (ecmascript)"), exports);
}}),
"[project]/node_modules/@interchainjs/cosmos/builder/amino-tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AminoTxBuilder = exports.AminoSigBuilder = void 0;
const signing_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const base_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * Amino signature builder
 */ class AminoSigBuilder extends base_1.BaseCosmosSigBuilder {
    async buildDocBytes(doc) {
        return (0, utils_1.encodeStdSignDoc)(doc);
    }
}
exports.AminoSigBuilder = AminoSigBuilder;
/**
 * Amino transaction builder
 */ class AminoTxBuilder extends base_1.BaseCosmosTxBuilder {
    ctx;
    constructor(ctx){
        super(signing_1.SignMode.SIGN_MODE_LEGACY_AMINO_JSON, ctx);
        this.ctx = ctx;
    }
    async buildDoc({ messages, fee, memo, options }) {
        const signDoc = {
            chain_id: options?.chainId ?? await this.ctx.signer.queryClient.getChainId(),
            account_number: (options?.accountNumber ?? await this.ctx.signer.queryClient.getAccountNumber(await this.ctx.signer.getAddress())).toString(),
            sequence: (options?.sequence ?? await this.ctx.signer.queryClient.getSequence(await this.ctx.signer.getAddress())).toString(),
            fee,
            msgs: (0, utils_1.toAminoMsgs)(messages, this.ctx.signer.getConverterFromTypeUrl),
            memo: memo ?? ''
        };
        return signDoc;
    }
    async buildDocBytes(doc) {
        return (0, utils_1.encodeStdSignDoc)(doc);
    }
    async syncSignedDoc(txRaw, signResp) {
        const authFee = (0, utils_1.toFee)(signResp.signDoc.fee);
        const authInfo = this.ctx.getStagingData(base_1.STAGING_AUTH_INFO);
        const { encode: authEncode } = await this.buildAuthInfo(authInfo.signerInfos, authFee);
        const authInfoBytes = authEncode();
        return {
            bodyBytes: txRaw.bodyBytes,
            authInfoBytes: authInfoBytes,
            signatures: [
                signResp.signature.value
            ]
        };
    }
}
exports.AminoTxBuilder = AminoTxBuilder;
}}),
"[project]/node_modules/@interchainjs/cosmos/signers/amino.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AminoSigner = exports.AminoSignerBase = exports.AminoDocSigner = void 0;
const base_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const builder_context_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)");
const amino_tx_builder_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/builder/amino-tx-builder.js [app-client] (ecmascript)");
const docAuth_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * AminoDocSigner is a signer for Amino document.
 */ class AminoDocSigner extends base_1.CosmosDocSigner {
    getTxBuilder() {
        return new amino_tx_builder_1.AminoSigBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.AminoDocSigner = AminoDocSigner;
/**
 * AminoSignerBase is a base signer for Amino document.
 */ class AminoSignerBase extends base_1.CosmosBaseSigner {
    converters;
    constructor(auth, encoders, converters, endpoint, options, broadcastOptions){
        super(auth, encoders.map(utils_1.toEncoder), endpoint, options, broadcastOptions);
        this.converters = converters.map(utils_1.toConverter);
    }
    /**
     * register converters
     */ addConverters = (converters)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.converters.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newConverters = converters.filter((converter)=>!existingTypeUrls.has(converter.typeUrl));
        // Add only the unique converters
        this.converters.push(...newConverters.map(utils_1.toConverter));
    };
    /**
     * get converter by aminoType
     */ getConverter = (aminoType)=>{
        const converter = this.converters.find((converter)=>converter.aminoType === aminoType);
        if (!converter) {
            throw new Error(`No such Converter for type ${aminoType}, please add corresponding Converter with method \`addConverters\``);
        }
        return (0, utils_1.toConverter)(converter);
    };
    /**
     * get converter by typeUrl
     */ getConverterFromTypeUrl = (typeUrl)=>{
        const converter = this.converters.find((converter)=>converter.typeUrl === typeUrl);
        if (!converter) {
            throw new Error(`No such Converter for typeUrl ${typeUrl}, please add corresponding Converter with method \`addConverter\``);
        }
        return (0, utils_1.toConverter)(converter);
    };
}
exports.AminoSignerBase = AminoSignerBase;
/**
 * signer for Amino document.
 * one signer for one account.
 */ class AminoSigner extends AminoSignerBase {
    constructor(auth, encoders, converters, endpoint, options, broadcastOptions){
        super(auth, encoders, converters, endpoint, options, broadcastOptions);
    }
    getTxBuilder() {
        return new amino_tx_builder_1.AminoTxBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
    /**
     * create AminoSigner from wallet.
     * if there're multiple accounts in the wallet, it will return the first one by default.
     */ static async fromWallet(signer, encoders, converters, endpoint, options, broadcastOptions) {
        let auth;
        if ((0, wallet_1.isOfflineAminoSigner)(signer)) {
            [auth] = await docAuth_1.AminoDocAuth.fromOfflineSigner(signer);
        } else {
            [auth] = await docAuth_1.AminoDocAuth.fromGenericOfflineSigner(signer);
        }
        return new AminoSigner(auth, encoders, converters, endpoint, options, broadcastOptions);
    }
    /**
     * create AminoSigners from wallet.
     * if there're multiple accounts in the wallet, it will return all of the signers.
     */ static async fromWalletToSigners(signer, encoders, converters, endpoint, options, broadcastOptions) {
        let auths;
        if ((0, wallet_1.isOfflineAminoSigner)(signer)) {
            auths = await docAuth_1.AminoDocAuth.fromOfflineSigner(signer);
        } else {
            auths = await docAuth_1.AminoDocAuth.fromGenericOfflineSigner(signer);
        }
        return auths.map((auth)=>{
            return new AminoSigner(auth, encoders, converters, endpoint, options, broadcastOptions);
        });
    }
}
exports.AminoSigner = AminoSigner;
}}),
"[project]/node_modules/@interchainjs/cosmos/builder/direct-tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectTxBuilder = exports.DirectSigBuilder = void 0;
const signing_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const base_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
/**
 * Direct signature builder
 */ class DirectSigBuilder extends base_1.BaseCosmosSigBuilder {
    async buildDocBytes(doc) {
        return tx_1.SignDoc.encode(doc).finish();
    }
}
exports.DirectSigBuilder = DirectSigBuilder;
/**
 * Direct transaction builder
 */ class DirectTxBuilder extends base_1.BaseCosmosTxBuilder {
    ctx;
    constructor(ctx){
        super(signing_1.SignMode.SIGN_MODE_DIRECT, ctx);
        this.ctx = ctx;
    }
    async buildDoc({ options }, txRaw) {
        const signDoc = tx_1.SignDoc.fromPartial({
            bodyBytes: txRaw.bodyBytes,
            authInfoBytes: txRaw.authInfoBytes,
            chainId: options?.chainId ?? await this.ctx.signer.queryClient.getChainId(),
            accountNumber: options?.accountNumber ?? await this.ctx.signer.queryClient.getAccountNumber(await this.ctx.signer.getAddress())
        });
        return signDoc;
    }
    async buildDocBytes(doc) {
        return tx_1.SignDoc.encode(doc).finish();
    }
    async syncSignedDoc(txRaw, signResp) {
        return {
            bodyBytes: signResp.signDoc.bodyBytes,
            authInfoBytes: signResp.signDoc.authInfoBytes,
            signatures: [
                signResp.signature.value
            ]
        };
    }
}
exports.DirectTxBuilder = DirectTxBuilder;
}}),
"[project]/node_modules/@interchainjs/cosmos/signers/direct.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectSigner = exports.DirectSignerBase = exports.DirectDocSigner = void 0;
const base_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const builder_context_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)");
const direct_tx_builder_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/builder/direct-tx-builder.js [app-client] (ecmascript)");
const docAuth_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * DirectDocSigner is a signer for Direct document.
 */ class DirectDocSigner extends base_1.CosmosDocSigner {
    getTxBuilder() {
        return new direct_tx_builder_1.DirectSigBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.DirectDocSigner = DirectDocSigner;
/**
 * DirectSignerBase is a base signer for Direct document.
 */ class DirectSignerBase extends base_1.CosmosBaseSigner {
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, encoders.map(utils_1.toEncoder), endpoint, options, broadcastOptions);
    }
    getTxBuilder() {
        return new direct_tx_builder_1.DirectTxBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.DirectSignerBase = DirectSignerBase;
/**
 * DirectSigner is a signer for Direct document.
 */ class DirectSigner extends DirectSignerBase {
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, encoders, endpoint, options, broadcastOptions);
    }
    /**
     * Create DirectSigner from wallet.
     * If there're multiple accounts in the wallet, it will return the first one by default.
     */ static async fromWallet(signer, encoders, endpoint, options, broadcastOptions) {
        let auth;
        if ((0, wallet_1.isOfflineDirectSigner)(signer)) {
            [auth] = await docAuth_1.DirectDocAuth.fromOfflineSigner(signer);
        } else {
            [auth] = await docAuth_1.DirectDocAuth.fromGenericOfflineSigner(signer);
        }
        return new DirectSigner(auth, encoders, endpoint, options, broadcastOptions);
    }
    /**
     * Create DirectSigners from wallet.
     * If there're multiple accounts in the wallet, it will return all of the signers.
     */ static async fromWalletToSigners(signer, encoders, endpoint, options, broadcastOptions) {
        let auths;
        if ((0, wallet_1.isOfflineDirectSigner)(signer)) {
            auths = await docAuth_1.DirectDocAuth.fromOfflineSigner(signer);
        } else {
            auths = await docAuth_1.DirectDocAuth.fromGenericOfflineSigner(signer);
        }
        return auths.map((auth)=>{
            return new DirectSigner(auth, encoders, endpoint, options, broadcastOptions);
        });
    }
}
exports.DirectSigner = DirectSigner;
}}),
"[project]/node_modules/@interchainjs/cosmos/signing-client.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.SigningClient = void 0;
const amino_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/signers/amino.js [app-client] (ecmascript)");
const direct_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/signers/direct.js [app-client] (ecmascript)");
const rpc_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/query/rpc.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const query_1 = __turbopack_context__.r("[project]/node_modules/@interchainjs/cosmos/types/query.js [app-client] (ecmascript)");
/**
 * SigningClient is a client that can sign and broadcast transactions.
 */ class SigningClient {
    client;
    offlineSigner;
    options;
    signers = {};
    addresses = [];
    encoders = [];
    converters = [];
    txRpc;
    constructor(client, offlineSigner, options = {}){
        this.client = client;
        this.offlineSigner = offlineSigner;
        this.encoders = options.registry?.map((type)=>{
            if (Array.isArray(type)) {
                return (0, utils_1.toEncoder)(type[1]);
            }
            return (0, utils_1.toEncoder)(type);
        }) || [];
        this.converters = options.registry?.map((type)=>{
            if (Array.isArray(type)) {
                return (0, utils_1.toConverter)(type[1]);
            }
            return (0, utils_1.toConverter)(type);
        }) || [];
        this.options = options;
        this.txRpc = {
            request () {
                throw new Error('Not implemented yet');
            },
            signAndBroadcast: this.signAndBroadcast
        };
    }
    static async connectWithSigner(endpoint, signer, options = {}) {
        const signingClient = new SigningClient(new rpc_1.RpcClient(endpoint, options.signerOptions?.prefix), signer, options);
        await signingClient.connect();
        return signingClient;
    }
    async connect() {
        let signers;
        switch(this.offlineSigner.signMode){
            case types_1.SIGN_MODE.DIRECT:
                signers = await direct_1.DirectSigner.fromWalletToSigners(this.offlineSigner, this.encoders, this.endpoint, this.options.signerOptions);
                break;
            case types_1.SIGN_MODE.AMINO:
                signers = await amino_1.AminoSigner.fromWalletToSigners(this.offlineSigner, this.encoders, this.converters, this.endpoint, this.options.signerOptions);
                break;
            default:
                break;
        }
        for (const signer of signers){
            this.signers[await signer.getAddress()] = signer;
        }
    }
    /**
     * register converters
     */ addConverters = (converters)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.converters.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newConverters = converters.filter((converter)=>!existingTypeUrls.has(converter.typeUrl));
        // Add only the unique converters
        this.converters.push(...newConverters.map(utils_1.toConverter));
        Object.values(this.signers).forEach((signer)=>{
            if (signer instanceof amino_1.AminoSigner) {
                signer.addEncoders(this.encoders);
                signer.addConverters(newConverters);
            }
        });
    };
    /**
     * register encoders
     */ addEncoders = (encoders)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.encoders.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newEncoders = encoders.filter((encoder)=>!existingTypeUrls.has(encoder.typeUrl));
        // Add only the unique converters
        this.encoders.push(...newEncoders.map(utils_1.toEncoder));
        Object.values(this.signers).forEach((signer)=>{
            if (signer instanceof direct_1.DirectSigner) {
                signer.addEncoders(newEncoders);
            }
        });
    };
    get queryClient() {
        return this.client;
    }
    async getChainId() {
        return await this.queryClient.getChainId();
    }
    async getAccountNumber(address) {
        return await this.queryClient.getAccountNumber(address);
    }
    async getSequence(address) {
        return await this.queryClient.getSequence(address);
    }
    getSinger(signerAddress) {
        const signer = this.signers[signerAddress];
        if (!signer) {
            throw new Error(`No signer found for address ${signerAddress}`);
        }
        return signer;
    }
    async sign(signerAddress, messages, fee, memo) {
        const signer = this.getSinger(signerAddress);
        const resp = await signer.sign({
            messages,
            fee,
            memo
        });
        return resp.tx;
    }
    signWithAutoFee = async (signerAddress, messages, fee, memo = '')=>{
        const usedFee = fee === 'auto' ? undefined : fee;
        return await this.sign(signerAddress, messages, usedFee, memo);
    };
    async simulate(signerAddress, messages, memo) {
        const signer = this.getSinger(signerAddress);
        const resp = await signer.estimateFee({
            messages,
            memo,
            options: this.options
        });
        return BigInt(resp.gas);
    }
    async broadcastTxSync(tx) {
        const broadcasted = await this.queryClient.broadcast(tx, {
            checkTx: true,
            deliverTx: false
        });
        return broadcasted;
    }
    async signAndBroadcastSync(signerAddress, messages, fee, memo = '') {
        const txRaw = await this.signWithAutoFee(signerAddress, messages, fee, memo);
        const txBytes = tx_1.TxRaw.encode(txRaw).finish();
        return this.broadcastTxSync(txBytes);
    }
    async broadcastTx(tx, broadcast) {
        const resp = await this.queryClient.broadcast(tx, broadcast);
        return resp;
    }
    signAndBroadcast = async (signerAddress, messages, fee, memo = '')=>{
        const txRaw = await this.signWithAutoFee(signerAddress, messages, fee, memo);
        const txBytes = tx_1.TxRaw.encode(txRaw).finish();
        return this.broadcastTx(txBytes, this.options.broadcast);
    };
    get endpoint() {
        return typeof this.queryClient.endpoint === 'string' ? {
            url: this.queryClient.endpoint,
            headers: {}
        } : this.queryClient.endpoint;
    }
    async getStatus() {
        const data = await fetch(`${this.endpoint.url}/status`);
        const json = await data.json();
        return json['result'];
    }
    async getTx(id) {
        const data = await fetch(`${this.endpoint.url}/tx?hash=0x${id}`);
        const json = await data.json();
        const tx = json['result'];
        if (!tx) return null;
        const txRaw = tx_1.TxRaw.decode((0, utils_2.fromBase64)(tx.tx));
        const txBody = tx_1.TxBody.decode(txRaw.bodyBytes);
        return {
            height: tx.height,
            txIndex: tx.index,
            hash: tx.hash,
            code: tx.tx_result.code,
            events: tx.tx_result.events,
            rawLog: tx.tx_result.log,
            tx: (0, utils_2.fromBase64)(tx.tx),
            msgResponses: txBody.messages,
            gasUsed: tx?.tx_result?.gas_used ? BigInt(tx?.tx_result?.gas_used) : 0n,
            gasWanted: tx?.tx_result?.gas_wanted ? BigInt(tx?.tx_result?.gas_wanted) : 0n
        };
    }
    async searchTx(query) {
        let rawQuery;
        let prove = false;
        let page = 1;
        let perPage = 100;
        let orderBy = 'asc';
        if (typeof query === 'string') {
            rawQuery = query;
        } else if (Array.isArray(query)) {
            rawQuery = query.map((t)=>`${t.key}=${t.value}`).join(' AND ');
        } else if ((0, query_1.isSearchTxQueryObj)(query)) {
            if (typeof query.query === 'string') {
                rawQuery = query.query;
            } else if (Array.isArray(query.query)) {
                rawQuery = query.query.map((t)=>`${t.key}=${t.value}`).join(' AND ');
            } else {
                throw new Error('Need to provide a valid query.');
            }
            prove = query.prove ?? false;
            page = query.page ?? 1;
            perPage = query.perPage ?? 100;
            orderBy = query.orderBy ?? 'asc';
        } else {
            throw new Error('Got unsupported query type.');
        }
        const params = new URLSearchParams({
            query: `"${rawQuery}"`,
            prove: prove.toString(),
            page: page.toString(),
            per_page: perPage.toString(),
            order_by: `"${orderBy}"`
        });
        const data = await fetch(`${this.endpoint.url}/tx_search?${params.toString()}`);
        const json = await data.json();
        return (0, utils_2.camelCaseRecursive)(json['result']);
    }
    async searchBlock(query) {
        let rawQuery;
        let page = 1;
        let perPage = 100;
        let orderBy = 'asc';
        if (typeof query === 'string') {
            rawQuery = query;
        } else if (Array.isArray(query)) {
            rawQuery = query.map((t)=>`${t.key}=${t.value}`).join(' AND ');
        } else if ((0, query_1.isSearchBlockQueryObj)(query)) {
            if (typeof query.query === 'string') {
                rawQuery = query.query;
            } else if (Array.isArray(query.query)) {
                rawQuery = query.query.map((t)=>`${t.key}=${t.value}`).join(' AND ');
            } else {
                throw new Error('Need to provide a valid query.');
            }
            page = query.page ?? 1;
            perPage = query.perPage ?? 100;
            orderBy = query.orderBy ?? 'asc';
        } else {
            throw new Error('Got unsupported query type.');
        }
        const params = new URLSearchParams({
            query: `"${rawQuery}"`,
            page: page.toString(),
            per_page: perPage.toString(),
            order_by: `"${orderBy}"`
        });
        const data = await fetch(`${this.endpoint.url}/block_search?${params.toString()}`);
        const json = await data.json();
        return (0, utils_2.camelCaseRecursive)(json['result']);
    }
    async getBlock(height) {
        const data = await fetch(height == void 0 ? `${this.endpoint.url}/block?height=${height}` : `${this.endpoint.url}/block`);
        const json = await data.json();
        const { block_id, block } = json['result'];
        return {
            id: block_id.hash.toUpperCase(),
            header: {
                version: {
                    block: block.header.version.block,
                    app: block.header.version.app
                },
                height: Number(block.header.height),
                chainId: block.header.chain_id,
                time: block.header.time
            },
            txs: block.data.txs.map((tx)=>(0, utils_2.fromBase64)(tx))
        };
    }
}
exports.SigningClient = SigningClient;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectGenericOfflineSigner = exports.AminoGenericOfflineSigner = void 0;
exports.isOfflineAminoSigner = isOfflineAminoSigner;
exports.isOfflineDirectSigner = isOfflineDirectSigner;
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
/**
 * Check if signer is offline amino signer
 */ function isOfflineAminoSigner(signer) {
    return 'signAmino' in signer;
}
/**
 * Check if signer is offline direct signer
 */ function isOfflineDirectSigner(signer) {
    return 'signDirect' in signer;
}
/**
 * Amino general offline signer.
 * This is a wrapper for offline amino signer.
 */ class AminoGenericOfflineSigner {
    offlineSigner;
    constructor(offlineSigner){
        this.offlineSigner = offlineSigner;
    }
    signMode = types_1.SIGN_MODE.AMINO;
    getAccounts() {
        return this.offlineSigner.getAccounts();
    }
    sign({ signerAddress, signDoc }) {
        return this.offlineSigner.signAmino(signerAddress, signDoc);
    }
}
exports.AminoGenericOfflineSigner = AminoGenericOfflineSigner;
/**
 * Direct general offline signer.
 * This is a wrapper for offline direct signer.
 */ class DirectGenericOfflineSigner {
    offlineSigner;
    constructor(offlineSigner){
        this.offlineSigner = offlineSigner;
    }
    signMode = types_1.SIGN_MODE.DIRECT;
    getAccounts() {
        return this.offlineSigner.getAccounts();
    }
    sign({ signerAddress, signDoc }) {
        return this.offlineSigner.signDirect(signerAddress, signDoc);
    }
}
exports.DirectGenericOfflineSigner = DirectGenericOfflineSigner;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectDocAuth = exports.AminoDocAuth = void 0;
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
/**
 * a helper class to sign the StdSignDoc with Amino encoding using offline signer.
 */ class AminoDocAuth extends types_1.BaseDocAuth {
    getPublicKey() {
        return utils_1.Key.from(this.pubkey);
    }
    async signDoc(doc) {
        let resp;
        if ((0, wallet_1.isOfflineAminoSigner)(this.offlineSigner)) {
            resp = await this.offlineSigner.signAmino(this.address, doc);
        } else {
            resp = await this.offlineSigner.sign({
                signerAddress: this.address,
                signDoc: doc
            });
        }
        return {
            signature: utils_1.Key.fromBase64(resp.signature.signature),
            signDoc: resp.signed
        };
    }
    static async fromOfflineSigner(offlineSigner) {
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new AminoDocAuth(offlineSigner, account.address, account.algo, account.pubkey);
        });
    }
    static async fromGenericOfflineSigner(offlineSigner) {
        if (offlineSigner.signMode !== types_1.SIGN_MODE.AMINO) {
            throw new Error('not an amino general offline signer');
        }
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new AminoDocAuth({
                getAccounts: offlineSigner.getAccounts,
                signAmino (signerAddress, signDoc) {
                    return offlineSigner.sign({
                        signerAddress,
                        signDoc
                    });
                }
            }, account.address, account.algo, account.pubkey);
        });
    }
}
exports.AminoDocAuth = AminoDocAuth;
/**
 * a helper class to sign the SignDoc with Direct encoding using offline signer.
 */ class DirectDocAuth extends types_1.BaseDocAuth {
    getPublicKey() {
        return utils_1.Key.from(this.pubkey);
    }
    async signDoc(doc) {
        // let resp = await this.offlineSigner.signDirect(this.address, doc);
        let resp;
        if ((0, wallet_1.isOfflineDirectSigner)(this.offlineSigner)) {
            resp = await this.offlineSigner.signDirect(this.address, doc);
        } else {
            resp = await this.offlineSigner.sign({
                signerAddress: this.address,
                signDoc: doc
            });
        }
        return {
            signature: utils_1.Key.fromBase64(resp.signature.signature),
            signDoc: resp.signed
        };
    }
    static async fromOfflineSigner(offlineSigner) {
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new DirectDocAuth(offlineSigner, account.address, account.algo, account.pubkey);
        });
    }
    static async fromGenericOfflineSigner(offlineSigner) {
        if (offlineSigner.signMode !== types_1.SIGN_MODE.DIRECT) {
            throw new Error('not a direct general offline signer');
        }
        const accounts = await offlineSigner.getAccounts();
        return accounts.map((account)=>{
            return new DirectDocAuth({
                getAccounts: offlineSigner.getAccounts,
                signDirect (signerAddress, signDoc) {
                    return offlineSigner.sign({
                        signerAddress,
                        signDoc
                    });
                }
            }, account.address, account.algo, account.pubkey);
        });
    }
}
exports.DirectDocAuth = DirectDocAuth;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/query.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isSearchTxQueryObj = isSearchTxQueryObj;
exports.isSearchBlockQueryObj = isSearchBlockQueryObj;
function isSearchTxQueryObj(query) {
    return typeof query === 'object' && 'query' in query;
}
function isSearchBlockQueryObj(query) {
    return typeof query === 'object' && 'query' in query;
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TimeoutError = void 0;
class TimeoutError extends Error {
    txId;
    constructor(message, txId){
        super(message);
        this.txId = txId;
    }
}
exports.TimeoutError = TimeoutError;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/signer.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CosmosAccount = void 0;
exports.isICosmosAccount = isICosmosAccount;
const account_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/account.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const ripemd160_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/ripemd160.js [app-client] (ecmascript)");
const sha256_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/sha256.js [app-client] (ecmascript)");
/**
 * Check if instance is cosmos account
 */ function isICosmosAccount(instance) {
    return instance.toAccountData !== undefined;
}
/**
 * Cosmos account implementation
 */ class CosmosAccount extends account_1.AccountBase {
    getAddressByPubKey() {
        return utils_1.Key.from((0, ripemd160_1.ripemd160)((0, sha256_1.sha256)(this.publicKey.value))).toBech32(this.prefix);
    }
}
exports.CosmosAccount = CosmosAccount;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/signing-client.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isISigningClient = isISigningClient;
function isISigningClient(client) {
    return client !== null && client !== undefined && typeof client.signAndBroadcast === 'function' && (!client.addConverters || typeof client.addConverters === 'function') && (!client.addEncoders || typeof client.addEncoders === 'function');
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/query.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/signer.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/signing-client.js [app-client] (ecmascript)"), exports);
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/accounts.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isBaseAccount = isBaseAccount;
const auth_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/auth.js [app-client] (ecmascript)");
function isBaseAccount(o) {
    return o && (o.$typeUrl === auth_1.BaseAccount.typeUrl || typeof o.address === "string" && typeof o.accountNumber === "bigint" && typeof o.sequence === "bigint");
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/amino.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.encodeStdSignDoc = encodeStdSignDoc;
exports.toMessages = toMessages;
exports.toAminoMsgs = toAminoMsgs;
exports.toFee = toFee;
exports.toStdFee = toStdFee;
exports.toConverter = toConverter;
exports.toConverters = toConverters;
const coin_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/base/v1beta1/coin.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
function sortKey(target) {
    if (target === null || typeof target !== 'object') {
        return target;
    }
    if (Array.isArray(target)) {
        return target.map(sortKey);
    }
    const sortedObj = {};
    Object.keys(target).sort().forEach((key)=>{
        sortedObj[key] = sortKey(target[key]);
    });
    return sortedObj;
}
/**
 * Encode the StdSignDoc to bytes for amino signing
 */ function encodeStdSignDoc(doc) {
    const sorted = sortKey(doc);
    const str = JSON.stringify(sorted);
    const serialized = str.replaceAll('&', '\\u0026').replaceAll('<', '\\u003c').replaceAll('>', '\\u003e');
    return (0, utils_1.fromUtf8)(serialized);
}
/**
 * from Amino messages to protobuf messages
 */ function toMessages(aminoMsgs, getConverter) {
    return aminoMsgs.map(({ type, value })=>{
        const { fromAmino, typeUrl } = getConverter(type);
        return {
            typeUrl,
            value: fromAmino(value)
        };
    });
}
/**
 * from protobuf messages to Amino messages
 */ function toAminoMsgs(messages, getConverter) {
    return messages.map(({ typeUrl, value })=>{
        const { toAmino, aminoType } = getConverter(typeUrl);
        return {
            type: aminoType,
            value: toAmino(value)
        };
    });
}
/**
 * Convert StdFee to Fee
 */ function toFee(fee) {
    return tx_1.Fee.fromPartial({
        amount: fee.amount.map((coin)=>coin_1.Coin.fromPartial(coin)),
        gasLimit: BigInt(fee.gas),
        payer: fee.payer,
        granter: fee.granter
    });
}
/**
 * Convert Fee to StdFee
 */ function toStdFee(fee) {
    return {
        amount: fee.amount,
        gas: fee.gasLimit.toString(),
        granter: fee.granter === '' ? void 0 : fee.granter,
        payer: fee.payer === '' ? void 0 : fee.payer
    };
}
/**
 * from telescope generated codec to AminoConverter
 */ function toConverter(generated) {
    (0, utils_1.assertEmpty)(generated.aminoType);
    return {
        aminoType: generated.aminoType,
        typeUrl: generated.typeUrl,
        fromAmino: (data)=>{
            (0, utils_1.assertEmpty)(generated.fromAmino);
            return generated.fromAmino(data);
        },
        toAmino: (data)=>{
            (0, utils_1.assertEmpty)(generated.toAmino);
            return generated.toAmino(data);
        }
    };
}
/**
 * from telescope generated codecs to AminoConverters
 */ function toConverters(...generatedArray) {
    return generatedArray.map((generated)=>toConverter(generated));
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/asserts.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.isDeliverTxFailure = isDeliverTxFailure;
exports.isDeliverTxSuccess = isDeliverTxSuccess;
exports.assertIsDeliverTxSuccess = assertIsDeliverTxSuccess;
exports.assertIsDeliverTxFailure = assertIsDeliverTxFailure;
function isDeliverTxFailure(resp) {
    return resp.code !== 0;
}
function isDeliverTxSuccess(resp) {
    return !isDeliverTxFailure(resp);
}
function assertIsDeliverTxSuccess(resp) {
    if (isDeliverTxFailure(resp)) {
        throw new Error(`Error when broadcasting tx ${resp.transactionHash} at height ${resp.height}. Code: ${resp.code}; Raw log: ${resp.rawLog}`);
    }
}
function assertIsDeliverTxFailure(resp) {
    if (isDeliverTxSuccess(resp)) {
        throw new Error(`Transaction ${resp.transactionHash} did not fail at height ${resp.height}. Code: ${resp.code}; Raw log: ${resp.rawLog}`);
    }
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __importDefault = this && this.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getAvgGasPrice = getAvgGasPrice;
exports.getHighGasPrice = getHighGasPrice;
exports.getLowGasPrice = getLowGasPrice;
exports.calculateFee = calculateFee;
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const decimal_js_1 = __importDefault(__turbopack_context__.r("[project]/node_modules/decimal.js/decimal.js [app-client] (ecmascript)"));
const defaults_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
/**
 * get the average gas price of the chain
 */ function getAvgGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.averageGasPrice === 'undefined') {
        throw new Error(`No averageGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.averageGasPrice),
        denom: feeToken.denom
    };
}
function getHighGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.highGasPrice === 'undefined') {
        throw new Error(`No highGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.highGasPrice),
        denom: feeToken.denom
    };
}
function getLowGasPrice(chainId) {
    const feeToken = (0, utils_1.getChainById)(chainId)?.fees?.feeTokens?.[0];
    if (typeof feeToken?.lowGasPrice === 'undefined') {
        throw new Error(`No lowGasPrice found for chain ${chainId}`);
    }
    return {
        amount: new decimal_js_1.default(feeToken.lowGasPrice),
        denom: feeToken.denom
    };
}
/**
 * calculate fee based on gas info
 */ async function calculateFee(gasInfo, options, getChainId) {
    const gasLimit = new decimal_js_1.default(gasInfo.gasUsed.toString()).mul(options?.multiplier || defaults_1.defaultFeeOptions.multiplier).ceil();
    let price;
    switch(options?.gasPrice ?? defaults_1.defaultFeeOptions.gasPrice){
        case 'average':
            price = getAvgGasPrice(await getChainId());
            break;
        case 'high':
            price = getHighGasPrice(await getChainId());
            break;
        case 'low':
            price = getLowGasPrice(await getChainId());
            break;
        default:
            price = (0, utils_1.toPrice)(options?.gasPrice);
            break;
    }
    if (price.denom.length < 3 || price.denom.length > 128) {
        throw new Error('Denom must be between 3 and 128 characters');
    }
    return {
        amount: [
            {
                amount: gasLimit.mul(price.amount).ceil().toString(),
                denom: price.denom
            }
        ],
        gas: gasLimit.toString()
    };
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.constructAuthInfo = constructAuthInfo;
exports.toEncoder = toEncoder;
exports.toEncoders = toEncoders;
exports.toDecoder = toDecoder;
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
function constructAuthInfo(signerInfos, fee) {
    const authInfo = tx_1.AuthInfo.fromPartial({
        signerInfos,
        fee
    });
    return {
        authInfo,
        encode: ()=>tx_1.AuthInfo.encode(authInfo).finish()
    };
}
/**
 * from telescope generated codec to encoder
 */ function toEncoder(generated) {
    return {
        typeUrl: generated.typeUrl,
        fromPartial: generated.fromPartial,
        encode: (data)=>{
            (0, utils_1.assertEmpty)(generated.encode);
            const encoded = generated.encode(generated.fromPartial(data));
            return encoded.finish ? encoded.finish() : encoded;
        }
    };
}
/**
 * from telescope generated codecs to encoders
 */ function toEncoders(...generatedArray) {
    return generatedArray.map((generated)=>toEncoder(generated));
}
/**
 * from telescope generated codec to decoder
 */ function toDecoder(generated) {
    return {
        typeUrl: generated.typeUrl,
        fromPartial: generated.fromPartial,
        decode: (data)=>{
            (0, utils_1.assertEmpty)(generated.decode);
            return generated.decode(data);
        }
    };
}
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/accounts.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/amino.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/asserts.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)"), exports);
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.defaultWalletOptions = exports.defaultSignerOptions = exports.defaultAccountParser = exports.defaultPublicKeyEncoder = exports.defaultSignerConfig = exports.defaultFeeOptions = exports.defaultBroadcastOptions = void 0;
const auth_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/auth.js [app-client] (ecmascript)");
const keys_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/crypto/secp256k1/keys.js [app-client] (ecmascript)");
const vesting_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/vesting/v1beta1/vesting.js [app-client] (ecmascript)");
const account_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/injective/types/v1beta1/account.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/utils.js [app-client] (ecmascript)");
const ripemd160_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/ripemd160.js [app-client] (ecmascript)");
const sha256_1 = __turbopack_context__.r("[project]/node_modules/@noble/hashes/sha256.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)");
const utils_3 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
const secp256k1_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/auth/secp256k1.js [app-client] (ecmascript)");
exports.defaultBroadcastOptions = {
    checkTx: true,
    deliverTx: false,
    timeoutMs: 60_000,
    pollIntervalMs: 3_000
};
exports.defaultFeeOptions = {
    multiplier: 1.6,
    gasPrice: 'average'
};
/**
 * Default signer configuration for Cosmos chains.
 */ exports.defaultSignerConfig = {
    publicKey: {
        isCompressed: true,
        hash: (publicKey)=>utils_1.Key.from((0, ripemd160_1.ripemd160)((0, sha256_1.sha256)(publicKey.value)))
    },
    message: {
        hash: (message)=>{
            const hashed = (0, sha256_1.sha256)(message);
            (0, utils_2.bytesToHex)(hashed);
            return hashed;
        }
    }
};
const defaultPublicKeyEncoder = (key)=>{
    return {
        typeUrl: keys_1.PubKey.typeUrl,
        value: keys_1.PubKey.encode(keys_1.PubKey.fromPartial({
            key: key.value
        })).finish()
    };
};
exports.defaultPublicKeyEncoder = defaultPublicKeyEncoder;
const accountCodecs = [
    auth_1.BaseAccount,
    auth_1.ModuleAccount,
    vesting_1.BaseVestingAccount,
    vesting_1.ContinuousVestingAccount,
    vesting_1.DelayedVestingAccount,
    vesting_1.PeriodicVestingAccount,
    account_1.EthAccount
];
const defaultAccountParser = (encodedAccount)=>{
    const codec = accountCodecs.find((codec)=>codec.typeUrl === encodedAccount.typeUrl);
    if (!codec) {
        throw new Error(`No corresponding account found for account type ${encodedAccount.typeUrl}.`);
    }
    const decoder = (0, utils_3.toDecoder)(codec);
    const account = decoder.fromPartial(decoder.decode(encodedAccount.value));
    const baseAccount = account.baseVestingAccount?.baseAccount || account.baseAccount || account;
    return baseAccount;
};
exports.defaultAccountParser = defaultAccountParser;
exports.defaultSignerOptions = {
    ...exports.defaultSignerConfig,
    parseAccount: exports.defaultAccountParser,
    createAccount: types_1.CosmosAccount,
    encodePublicKey: exports.defaultPublicKeyEncoder,
    prefix: undefined
};
exports.defaultWalletOptions = {
    bip39Password: undefined,
    createAuthsFromMnemonic: secp256k1_1.Secp256k1Auth.fromMnemonic,
    signerConfig: exports.defaultSignerOptions
};
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/query/rpc.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RpcClient = void 0;
const signing_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const query_rpc_func_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/auth/v1beta1/query.rpc.func.js [app-client] (ecmascript)");
const service_rpc_func_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/service.rpc.func.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
const rpc_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/rpc.js [app-client] (ecmascript)");
const direct_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/direct.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const utils_3 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
const abci_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/base/abci/v1beta1/abci.js [app-client] (ecmascript)");
/**
 * client for cosmos rpc
 */ class RpcClient {
    endpoint;
    chainId;
    accountNumber;
    getAccount;
    getSimulate;
    parseAccount = defaults_1.defaultAccountParser;
    _prefix;
    txRpc;
    constructor(endpoint, prefix){
        this.endpoint = (0, utils_1.toHttpEndpoint)(endpoint);
        this.txRpc = (0, utils_2.createQueryRpc)(this.endpoint);
        this._prefix = prefix;
    }
    setAccountParser(parseBaseAccount) {
        this.parseAccount = parseBaseAccount;
    }
    async getPrefix() {
        return this._prefix ?? (0, utils_2.getPrefix)(await this.getChainId());
    }
    /**
     * get basic account info by address
     */ async getBaseAccount(address) {
        const accountResp = await (0, query_rpc_func_1.getAccount)(this.txRpc, {
            address
        });
        if (!accountResp || !accountResp.account) {
            throw new Error(`Account is undefined.`);
        }
        // if the account is a BaseAccount, return it
        if ((0, utils_3.isBaseAccount)(accountResp.account)) {
            return accountResp.account;
        }
        // if there's a baseAccount in the account, and it's a BaseAccount, return it
        if ('baseAccount' in accountResp.account && accountResp.account.baseAccount && (0, utils_3.isBaseAccount)(accountResp.account.baseAccount)) {
            return accountResp.account.baseAccount;
        }
        // otherwise, parse the account from Any type.
        return this.parseAccount(accountResp.account);
    }
    /**
     * get status of the chain
     */ async getStatus() {
        const data = await fetch(`${this.endpoint.url}/status`);
        const json = await data.json();
        return json['result'] ?? json;
    }
    /**
     * get chain id
     */ getChainId = async ()=>{
        if ((0, utils_1.isEmpty)(this.chainId)) {
            const status = await this.getStatus();
            this.chainId = status.node_info.network;
        }
        return this.chainId;
    };
    /**
     * get the latest block height
     */ async getLatestBlockHeight() {
        const status = await this.getStatus();
        return BigInt(status.sync_info.latest_block_height);
    }
    /**
     * get account number by address
     */ async getAccountNumber(address) {
        if ((0, utils_1.isEmpty)(this.accountNumber)) {
            const account = await this.getBaseAccount(address);
            this.accountNumber = account.accountNumber;
        }
        return this.accountNumber;
    }
    /**
     * get sequence by address
     */ async getSequence(address) {
        const account = await this.getBaseAccount(address);
        return account.sequence;
    }
    /**
     * get the account of the current signer
     */ async simulate(txBody, signerInfos) {
        const tx = tx_1.Tx.fromPartial({
            body: txBody,
            authInfo: (0, direct_1.constructAuthInfo)(signerInfos.map((signerInfo)=>{
                return {
                    ...signerInfo,
                    modeInfo: {
                        single: {
                            mode: signing_1.SignMode.SIGN_MODE_UNSPECIFIED
                        }
                    }
                };
            }), tx_1.Fee.fromPartial({})).authInfo,
            signatures: [
                new Uint8Array()
            ]
        });
        return await (0, service_rpc_func_1.getSimulate)(this.txRpc, {
            tx: void 0,
            txBytes: tx_1.Tx.encode(tx).finish()
        });
    }
    /**
     * Decode TxMsgData from base64-encoded data
     */ decodeTxMsgData(data) {
        return abci_1.TxMsgData.decode(data ? (0, utils_1.fromBase64)(data) : new Uint8Array());
    }
    /**
     * get the transaction by hash(id)
     */ async getTx(id) {
        const data = await fetch(`${this.endpoint.url}/tx?hash=0x${id}`);
        const json = await data.json();
        const tx = json['result'];
        if (!tx) return null;
        const txMsgData = this.decodeTxMsgData(tx.tx_result.data);
        return {
            height: tx.height,
            txIndex: tx.index,
            hash: tx.hash,
            code: tx.tx_result.code,
            events: tx.tx_result.events,
            rawLog: tx.tx_result.log,
            tx: (0, utils_1.fromBase64)(tx.tx),
            msgResponses: txMsgData.msgResponses,
            gasUsed: BigInt(tx.tx_result.gas_used),
            gasWanted: BigInt(tx.tx_result.gas_wanted),
            data: tx.tx_result.data,
            log: tx.tx_result.log,
            info: tx.tx_result.info
        };
    }
    /**
     * broadcast a transaction.
     * there're three modes:
     * - 'broadcast_tx_async': broadcast the transaction and return immediately.
     * - 'broadcast_tx_sync': broadcast the transaction and wait for the response.
     * - 'broadcast_tx_commit': broadcast the transaction and wait for the response and the transaction to be included in a block.
     */ async broadcast(txBytes, options) {
        const { checkTx, deliverTx, timeoutMs, pollIntervalMs, useLegacyBroadcastTxCommit } = {
            ...defaults_1.defaultBroadcastOptions,
            ...options
        };
        const mode = checkTx && deliverTx ? 'broadcast_tx_commit' : checkTx ? 'broadcast_tx_sync' : 'broadcast_tx_async';
        const resp = await (0, utils_2.broadcast)(this.endpoint, mode === 'broadcast_tx_commit' && !useLegacyBroadcastTxCommit ? 'broadcast_tx_async' : mode, txBytes);
        switch(mode){
            case 'broadcast_tx_async':
                return {
                    transactionHash: resp.hash,
                    hash: resp.hash,
                    code: resp.code,
                    height: 0,
                    txIndex: 0,
                    events: [],
                    msgResponses: [],
                    gasUsed: 0n,
                    gasWanted: 0n,
                    rawLog: resp.log || "",
                    data: [],
                    origin: resp
                };
            case 'broadcast_tx_sync':
                return {
                    transactionHash: resp.hash,
                    hash: resp.hash,
                    code: resp.code,
                    height: 0,
                    txIndex: 0,
                    events: [],
                    msgResponses: [],
                    gasUsed: 0n,
                    gasWanted: 0n,
                    rawLog: resp.log || "",
                    data: [],
                    origin: resp
                };
            case 'broadcast_tx_commit':
                if (useLegacyBroadcastTxCommit) {
                    const msgResponses = this.decodeTxMsgData(resp.deliver_tx.data).msgResponses;
                    const data = msgResponses.map((res)=>{
                        return {
                            msgType: res.typeUrl,
                            data: res.value
                        };
                    });
                    return {
                        transactionHash: resp.hash,
                        hash: resp.hash,
                        code: resp.deliver_tx.code,
                        height: resp.height,
                        txIndex: 0,
                        events: resp.deliver_tx.events,
                        msgResponses,
                        data,
                        gasUsed: BigInt(resp.deliver_tx.gas_used),
                        gasWanted: BigInt(resp.deliver_tx.gas_wanted),
                        rawLog: resp.deliver_tx.log || "",
                        origin: resp
                    };
                } else {
                    let timedOut = false;
                    const txPollTimeout = setTimeout(()=>{
                        timedOut = true;
                    }, timeoutMs);
                    const pollForTx = async (txId)=>{
                        if (timedOut) {
                            throw new rpc_1.TimeoutError(`Transaction with ID ${txId} was submitted but was not yet found on the chain. You might want to check later. There was a wait of ${timeoutMs / 1000} seconds.`, txId);
                        }
                        await (0, utils_2.sleep)(pollIntervalMs);
                        const result = await this.getTx(txId);
                        return result ? {
                            transactionHash: result.hash,
                            hash: result.hash,
                            code: result.code,
                            height: result.height,
                            txIndex: result.txIndex,
                            events: result.events,
                            msgResponses: result.msgResponses,
                            gasUsed: result.gasUsed,
                            gasWanted: result.gasWanted,
                            rawLog: result.rawLog,
                            data: result.msgResponses.map((res)=>{
                                return {
                                    msgType: res.typeUrl,
                                    data: res.value
                                };
                            }),
                            origin: result
                        } : pollForTx(txId);
                    };
                    const transactionId = resp.hash.toUpperCase();
                    return new Promise((resolve, reject)=>pollForTx(transactionId).then((value)=>{
                            clearTimeout(txPollTimeout);
                            resolve(value);
                        }, (error)=>{
                            clearTimeout(txPollTimeout);
                            reject(error);
                        }));
                }
            default:
                throw new Error(`Wrong method: ${mode}`);
        }
    }
}
exports.RpcClient = RpcClient;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/base-signer.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CosmosBaseSigner = exports.CosmosDocSigner = void 0;
const signing_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/utils/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
const rpc_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/query/rpc.js [app-client] (ecmascript)");
const chain_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/chain.js [app-client] (ecmascript)");
const utils_2 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * Base class for Cosmos Doc Signer.
 * It provides the basic methods for signing a document.
 * @template TDoc - The type of the document to be signed.
 *  * @template TArgs The type of the args.
 */ class CosmosDocSigner extends types_1.BaseSigner {
    constructor(auth, config){
        super(auth, config);
        this.txBuilder = this.getTxBuilder();
    }
    /**
     * signature builder
     */ txBuilder;
    /**
     * Sign a document.
     */ async signDoc(doc) {
        if ((0, types_1.isDocAuth)(this.auth)) {
            return await this.auth.signDoc(doc);
        } else {
            const sig = await this.txBuilder.buildSignature(doc);
            return {
                signature: sig,
                signDoc: doc
            };
        }
    }
}
exports.CosmosDocSigner = CosmosDocSigner;
/**
 * Base class for Cosmos Signer.
 */ class CosmosBaseSigner extends CosmosDocSigner {
    /**
     * QueryClient for querying chain data.
     */ _queryClient;
    /**
     * registered encoders
     */ encoders;
    /**
     * encode public key to EncodedMessage
     * the method is provided by the config
     */ _encodePublicKey;
    /**
     * parse account from EncodedMessage
     * the method is provided by the config
     */ parseAccount;
    /**
     * prefix of the chain.
     * will get from queryClient if not set.
     */ prefix;
    /**
     * account info of the current signer.
     */ account;
    /**
     * broadcast options
     */ broadcastOptions;
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, {
            ...defaults_1.defaultSignerOptions,
            ...options
        });
        this.encoders = encoders;
        this.parseAccount = options?.parseAccount ?? defaults_1.defaultSignerOptions.parseAccount;
        this._encodePublicKey = options?.encodePublicKey ?? defaults_1.defaultSignerOptions.encodePublicKey;
        this.prefix = options?.prefix;
        this.broadcastOptions = broadcastOptions;
        if (!(0, utils_1.isEmpty)(endpoint)) {
            this.setEndpoint(endpoint);
        }
        this.txBuilder = this.getTxBuilder();
    }
    get encodedPublicKey() {
        return this._encodePublicKey(this.publicKey);
    }
    /**
     * register encoders
     */ addEncoders = (encoders)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.encoders.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newEncoders = encoders.filter((encoder)=>!existingTypeUrls.has(encoder.typeUrl));
        // Add only the unique converters
        this.encoders.push(...newEncoders.map(utils_2.toEncoder));
    };
    /**
     * get prefix of the chain
     * @returns prefix of the chain
     */ getPrefix = async ()=>{
        if (this.prefix) {
            return this.prefix;
        }
        if (this.queryClient) {
            return this.queryClient.getPrefix();
        }
        throw new Error("Can't get prefix because no queryClient is set");
    };
    /**
     * get encoder by typeUrl
     */ getEncoder = (typeUrl)=>{
        const encoder = this.encoders.find((encoder)=>encoder.typeUrl === typeUrl);
        if (!encoder) {
            throw new Error(`No such Encoder for typeUrl ${typeUrl}, please add corresponding Encoder with method \`addEncoder\``);
        }
        return encoder;
    };
    /**
     * get the address of the current signer
     * @returns the address of the current signer
     */ async getAddress() {
        if (!this.account) {
            this.account = await this.getAccount();
        }
        return this.account.address;
    }
    /**
     * get account by account creator
     */ async getAccount() {
        const opts = this.config;
        if (opts.createAccount) {
            return new opts.createAccount(await this.getPrefix(), this.auth, this.config.publicKey.isCompressed);
        } else {
            throw new Error('No account creator is provided, or you can try to override the method `getAccount`');
        }
    }
    /**
     * set the endpoint of the queryClient
     */ setEndpoint(endpoint) {
        this._queryClient = new rpc_1.RpcClient(endpoint, this.prefix);
        this._queryClient.setAccountParser(this.parseAccount);
    }
    /**
     * get the queryClient
     */ get queryClient() {
        (0, utils_1.assertEmpty)(this._queryClient);
        return this._queryClient;
    }
    /**
     * convert relative timeoutHeight to absolute timeoutHeight
     */ async toAbsoluteTimeoutHeight(timeoutHeight) {
        return (0, utils_1.isEmpty)(timeoutHeight) ? void 0 : {
            type: 'absolute',
            value: timeoutHeight.type === 'absolute' ? timeoutHeight.value : await this.queryClient.getLatestBlockHeight() + timeoutHeight.value
        };
    }
    /**
     * sign tx messages with fee, memo, etc.
     * @param args - arguments for signing, e.g. messages, fee, memo, etc.
     * @returns a response object with the signed document and a broadcast method
     */ async sign(args) {
        const signed = await this.txBuilder.buildSignedTxDoc(args);
        return {
            ...signed,
            broadcast: async (options)=>{
                return this.broadcast(signed.tx, options);
            }
        };
    }
    /**
     * broadcast a signed document
     * @param txRaw - the signed document
     * @param options - options for broadcasting
     * @returns a broadcast response
     */ async broadcast(txRaw, options) {
        return this.broadcastArbitrary(tx_1.TxRaw.encode(tx_1.TxRaw.fromPartial(txRaw)).finish(), options);
    }
    /**
     * broadcast an arbitrary message in bytes
     */ async broadcastArbitrary(message, options) {
        const result = await this.queryClient.broadcast(message, options);
        return result;
    }
    /**
     * sign and broadcast tx messages
     */ async signAndBroadcast(args, messageOrOptions, fee, memo, options) {
        if (typeof args === 'string') {
            if (args !== await this.getAddress()) {
                throw new Error('signerAddress is not match');
            }
            return this._signAndBroadcast({
                messages: messageOrOptions,
                fee: fee === 'auto' ? undefined : fee,
                memo: memo,
                options: options
            }, this.broadcastOptions);
        }
        return this._signAndBroadcast(args, messageOrOptions ? messageOrOptions : this.broadcastOptions);
    }
    /**
     * sign and broadcast tx messages
     */ async _signAndBroadcast({ messages, fee, memo, options: signOptions }, options) {
        const { broadcast } = await this.sign({
            messages,
            fee,
            memo,
            options: signOptions
        });
        return await broadcast(options);
    }
    /**
     * simulate broadcasting tx messages.
     */ async simulate({ messages, memo, options }) {
        const { txBody } = await this.txBuilder.buildTxBody({
            messages,
            memo,
            options
        });
        const { signerInfo } = await this.txBuilder.buildSignerInfo(this.encodedPublicKey, options?.sequence ?? await this.queryClient.getSequence(await this.getAddress()), options?.signMode ?? signing_1.SignMode.SIGN_MODE_DIRECT);
        return await this.simulateByTxBody(txBody, [
            signerInfo
        ]);
    }
    /**
     * simulate broadcasting txBody.
     */ async simulateByTxBody(txBody, signerInfos) {
        return await this.queryClient.simulate(txBody, signerInfos);
    }
    /**
     * estimate fee for tx messages.
     */ async estimateFee({ messages, memo, options }) {
        const { gasInfo } = await this.simulate({
            messages,
            memo,
            options
        });
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, chain_1.calculateFee)(gasInfo, options, this.queryClient.getChainId);
    }
    /**
     * estimate fee by txBody.
     */ async estimateFeeByTxBody(txBody, signerInfos, options) {
        const { gasInfo } = await this.simulateByTxBody(txBody, signerInfos);
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, chain_1.calculateFee)(gasInfo, options, this.queryClient.getChainId);
    }
}
exports.CosmosBaseSigner = CosmosBaseSigner;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/base-wallet.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosWallet = void 0;
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
/**
 * Cosmos HD Wallet for secp256k1
 */ class BaseCosmosWallet {
    accounts;
    options;
    constructor(accounts, options){
        this.options = {
            ...defaults_1.defaultSignerConfig,
            ...options
        };
        this.accounts = accounts;
    }
    /**
     * Get account data
     * @returns account data
     */ async getAccounts() {
        return this.accounts.map((acct)=>{
            return acct.toAccountData();
        });
    }
    /**
     * Get one of the accounts using the address.
     * @param address
     * @returns
     */ getAcctFromBech32Addr(address) {
        const id = this.accounts.findIndex((acct)=>acct.address === address);
        if (id === -1) {
            throw new Error('No such signerAddress been authed.');
        }
        return this.accounts[id];
    }
    /**
     * Sign direct doc for signerAddress
     */ async signDirect(signerAddress, signDoc) {
        const account = this.getAcctFromBech32Addr(signerAddress);
        const docSigner = this.getDirectDocSigner(account.auth, this.options);
        const resp = await docSigner.signDoc(signDoc);
        return {
            signed: resp.signDoc,
            signature: {
                pub_key: {
                    type: 'tendermint/PubKeySecp256k1',
                    value: {
                        key: account.publicKey.toBase64()
                    }
                },
                signature: resp.signature.toBase64()
            }
        };
    }
    /**
     * sign amino doc for signerAddress
     */ async signAmino(signerAddress, signDoc) {
        const account = this.getAcctFromBech32Addr(signerAddress);
        const docSigner = this.getAminoDocSigner(account.auth, this.options);
        const resp = await docSigner.signDoc(signDoc);
        return {
            signed: resp.signDoc,
            signature: {
                pub_key: {
                    type: 'tendermint/PubKeySecp256k1',
                    value: {
                        key: account.publicKey.toBase64()
                    }
                },
                signature: resp.signature.toBase64()
            }
        };
    }
    /**
     * Convert this to offline direct signer for hiding the private key.
     */ toOfflineDirectSigner() {
        return {
            getAccounts: async ()=>this.getAccounts(),
            signDirect: async (signerAddress, signDoc)=>this.signDirect(signerAddress, signDoc)
        };
    }
    /**
     * Convert this to offline amino signer for hiding the private key.
     */ toOfflineAminoSigner() {
        return {
            getAccounts: async ()=>this.getAccounts(),
            signAmino: async (signerAddress, signDoc)=>this.signAmino(signerAddress, signDoc)
        };
    }
    /**
     * Convert this to general offline signer for hiding the private key.
     * @param signMode sign mode. (direct or amino)
     * @returns general offline signer for direct or amino
     */ toGenericOfflineSigner(signMode) {
        switch(signMode){
            case types_1.SIGN_MODE.DIRECT:
                return {
                    signMode: signMode,
                    getAccounts: async ()=>this.getAccounts(),
                    sign: async ({ signerAddress, signDoc })=>this.signDirect(signerAddress, signDoc)
                };
            case types_1.SIGN_MODE.AMINO:
                return {
                    signMode: signMode,
                    getAccounts: async ()=>this.getAccounts(),
                    sign: async ({ signerAddress, signDoc })=>this.signAmino(signerAddress, signDoc)
                };
            default:
                throw new Error('Invalid sign mode');
        }
    }
}
exports.BaseCosmosWallet = BaseCosmosWallet;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosTxBuilderContext = void 0;
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/types/esm/index.js [app-client] (ecmascript)");
/**
 * Context for the transaction builder.
 */ class BaseCosmosTxBuilderContext extends types_1.BaseTxBuilderContext {
    signer;
    constructor(signer){
        super(signer);
        this.signer = signer;
    }
}
exports.BaseCosmosTxBuilderContext = BaseCosmosTxBuilderContext;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.BaseCosmosTxBuilder = exports.BaseCosmosSigBuilder = exports.STAGING_AUTH_INFO = void 0;
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
exports.STAGING_AUTH_INFO = 'staging_auth_info';
/**
 * BaseCosmosSigBuilder is a helper class to build the signature from the document
 */ class BaseCosmosSigBuilder {
    ctx;
    constructor(ctx){
        this.ctx = ctx;
    }
    /**
     * build signature from the document
     * @param doc - The document to be signed.
     */ async buildSignature(doc) {
        // get doc bytes
        const docBytes = await this.buildDocBytes(doc);
        // sign signature to the doc bytes
        return this.ctx.signer.signArbitrary(docBytes);
    }
}
exports.BaseCosmosSigBuilder = BaseCosmosSigBuilder;
/**
 * BaseCosmosTxBuilder is a helper class to build the Tx and signDoc
 */ class BaseCosmosTxBuilder extends BaseCosmosSigBuilder {
    signMode;
    ctx;
    constructor(signMode, ctx){
        super(ctx);
        this.signMode = signMode;
        this.ctx = ctx;
    }
    async buildTxRaw({ messages, fee, memo, options }) {
        const { txBody, encode: txBodyEncode } = await this.buildTxBody({
            messages,
            memo,
            options
        });
        const { signerInfo } = await this.buildSignerInfo(this.ctx.signer.encodedPublicKey, options?.sequence ?? await this.ctx.signer.queryClient.getSequence(await this.ctx.signer.getAddress()), this.signMode);
        const stdFee = await this.getFee(fee, txBody, [
            signerInfo
        ], options);
        const { authInfo, encode: authEncode } = await this.buildAuthInfo([
            signerInfo
        ], (0, utils_1.toFee)(stdFee));
        this.ctx.setStagingData(exports.STAGING_AUTH_INFO, authInfo);
        return {
            bodyBytes: txBodyEncode(),
            authInfoBytes: authEncode(),
            fee: stdFee
        };
    }
    async buildTxBody({ messages, memo, options }) {
        if (options?.timeoutHeight?.type === 'relative') {
            throw new Error("timeoutHeight type in function `constructTxBody` shouldn't be `relative`. Please update it to `absolute` value before calling this function.");
        }
        const encoded = messages.map(({ typeUrl, value })=>{
            return {
                typeUrl,
                value: this.ctx.signer.getEncoder(typeUrl).encode(value)
            };
        });
        const txBody = tx_1.TxBody.fromPartial({
            messages: encoded,
            memo,
            timeoutHeight: options?.timeoutHeight?.value,
            extensionOptions: options?.extensionOptions,
            nonCriticalExtensionOptions: options?.nonCriticalExtensionOptions
        });
        return {
            txBody,
            encode: ()=>tx_1.TxBody.encode(txBody).finish()
        };
    }
    async buildSignerInfo(publicKey, sequence, signMode) {
        const signerInfo = tx_1.SignerInfo.fromPartial({
            publicKey,
            sequence,
            modeInfo: {
                single: {
                    mode: signMode
                }
            }
        });
        return {
            signerInfo,
            encode: ()=>tx_1.SignerInfo.encode(signerInfo).finish()
        };
    }
    async buildAuthInfo(signerInfos, fee) {
        const authInfo = tx_1.AuthInfo.fromPartial({
            signerInfos,
            fee
        });
        return {
            authInfo,
            encode: ()=>tx_1.AuthInfo.encode(authInfo).finish()
        };
    }
    async getFee(fee, txBody, signerInfos, options) {
        if (fee) {
            return fee;
        }
        const { gasInfo } = await this.ctx.signer.simulateByTxBody(txBody, signerInfos);
        if (typeof gasInfo === 'undefined') {
            throw new Error('Fail to estimate gas by simulate tx.');
        }
        return await (0, utils_1.calculateFee)(gasInfo, options, async ()=>{
            return this.ctx.signer.queryClient.getChainId();
        });
    }
    async buildSignedTxDoc({ messages, fee, memo, options }) {
        // create partial TxRaw
        const txRaw = await this.buildTxRaw({
            messages,
            fee,
            memo,
            options
        });
        // buildDoc
        const doc = await this.buildDoc({
            messages,
            fee: fee ?? txRaw.fee,
            memo,
            options
        }, txRaw);
        // sign signature to the doc bytes
        const signResp = await this.ctx.signer.signDoc(doc);
        // build TxRaw and sync with signed doc
        const signedTxRaw = await this.syncSignedDoc(tx_1.TxRaw.fromPartial(txRaw), signResp);
        return {
            tx: signedTxRaw,
            doc: doc
        };
    }
}
exports.BaseCosmosTxBuilder = BaseCosmosTxBuilder;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
var __createBinding = this && this.__createBinding || (Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});
var __exportStar = this && this.__exportStar || function(m, exports1) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports1, p)) __createBinding(exports1, m, p);
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/base-signer.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/base-wallet.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)"), exports);
__exportStar(__turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/tx-builder.js [app-client] (ecmascript)"), exports);
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/builder/amino-tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AminoTxBuilder = exports.AminoSigBuilder = void 0;
const signing_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const base_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * Amino signature builder
 */ class AminoSigBuilder extends base_1.BaseCosmosSigBuilder {
    async buildDocBytes(doc) {
        return (0, utils_1.encodeStdSignDoc)(doc);
    }
}
exports.AminoSigBuilder = AminoSigBuilder;
/**
 * Amino transaction builder
 */ class AminoTxBuilder extends base_1.BaseCosmosTxBuilder {
    ctx;
    constructor(ctx){
        super(signing_1.SignMode.SIGN_MODE_LEGACY_AMINO_JSON, ctx);
        this.ctx = ctx;
    }
    async buildDoc({ messages, fee, memo, options }) {
        const signDoc = {
            chain_id: options?.chainId ?? await this.ctx.signer.queryClient.getChainId(),
            account_number: (options?.accountNumber ?? await this.ctx.signer.queryClient.getAccountNumber(await this.ctx.signer.getAddress())).toString(),
            sequence: (options?.sequence ?? await this.ctx.signer.queryClient.getSequence(await this.ctx.signer.getAddress())).toString(),
            fee,
            msgs: (0, utils_1.toAminoMsgs)(messages, this.ctx.signer.getConverterFromTypeUrl),
            memo: memo ?? ''
        };
        return signDoc;
    }
    async buildDocBytes(doc) {
        return (0, utils_1.encodeStdSignDoc)(doc);
    }
    async syncSignedDoc(txRaw, signResp) {
        const authFee = (0, utils_1.toFee)(signResp.signDoc.fee);
        const authInfo = this.ctx.getStagingData(base_1.STAGING_AUTH_INFO);
        const { encode: authEncode } = await this.buildAuthInfo(authInfo.signerInfos, authFee);
        const authInfoBytes = authEncode();
        return {
            bodyBytes: txRaw.bodyBytes,
            authInfoBytes: authInfoBytes,
            signatures: [
                signResp.signature.value
            ]
        };
    }
}
exports.AminoTxBuilder = AminoTxBuilder;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/signers/amino.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.AminoSigner = exports.AminoSignerBase = exports.AminoDocSigner = void 0;
const base_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const builder_context_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)");
const amino_tx_builder_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/builder/amino-tx-builder.js [app-client] (ecmascript)");
const docAuth_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * AminoDocSigner is a signer for Amino document.
 */ class AminoDocSigner extends base_1.CosmosDocSigner {
    getTxBuilder() {
        return new amino_tx_builder_1.AminoSigBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.AminoDocSigner = AminoDocSigner;
/**
 * AminoSignerBase is a base signer for Amino document.
 */ class AminoSignerBase extends base_1.CosmosBaseSigner {
    converters;
    constructor(auth, encoders, converters, endpoint, options, broadcastOptions){
        super(auth, encoders.map(utils_1.toEncoder), endpoint, options, broadcastOptions);
        this.converters = converters.map(utils_1.toConverter);
    }
    /**
     * register converters
     */ addConverters = (converters)=>{
        // Create a Set of existing typeUrls for quick lookup
        const existingTypeUrls = new Set(this.converters.map((c)=>c.typeUrl));
        // Filter out converters with duplicate typeUrls
        const newConverters = converters.filter((converter)=>!existingTypeUrls.has(converter.typeUrl));
        // Add only the unique converters
        this.converters.push(...newConverters.map(utils_1.toConverter));
    };
    /**
     * get converter by aminoType
     */ getConverter = (aminoType)=>{
        const converter = this.converters.find((converter)=>converter.aminoType === aminoType);
        if (!converter) {
            throw new Error(`No such Converter for type ${aminoType}, please add corresponding Converter with method \`addConverters\``);
        }
        return (0, utils_1.toConverter)(converter);
    };
    /**
     * get converter by typeUrl
     */ getConverterFromTypeUrl = (typeUrl)=>{
        const converter = this.converters.find((converter)=>converter.typeUrl === typeUrl);
        if (!converter) {
            throw new Error(`No such Converter for typeUrl ${typeUrl}, please add corresponding Converter with method \`addConverter\``);
        }
        return (0, utils_1.toConverter)(converter);
    };
}
exports.AminoSignerBase = AminoSignerBase;
/**
 * signer for Amino document.
 * one signer for one account.
 */ class AminoSigner extends AminoSignerBase {
    constructor(auth, encoders, converters, endpoint, options, broadcastOptions){
        super(auth, encoders, converters, endpoint, options, broadcastOptions);
    }
    getTxBuilder() {
        return new amino_tx_builder_1.AminoTxBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
    /**
     * create AminoSigner from wallet.
     * if there're multiple accounts in the wallet, it will return the first one by default.
     */ static async fromWallet(signer, encoders, converters, endpoint, options, broadcastOptions) {
        let auth;
        if ((0, wallet_1.isOfflineAminoSigner)(signer)) {
            [auth] = await docAuth_1.AminoDocAuth.fromOfflineSigner(signer);
        } else {
            [auth] = await docAuth_1.AminoDocAuth.fromGenericOfflineSigner(signer);
        }
        return new AminoSigner(auth, encoders, converters, endpoint, options, broadcastOptions);
    }
    /**
     * create AminoSigners from wallet.
     * if there're multiple accounts in the wallet, it will return all of the signers.
     */ static async fromWalletToSigners(signer, encoders, converters, endpoint, options, broadcastOptions) {
        let auths;
        if ((0, wallet_1.isOfflineAminoSigner)(signer)) {
            auths = await docAuth_1.AminoDocAuth.fromOfflineSigner(signer);
        } else {
            auths = await docAuth_1.AminoDocAuth.fromGenericOfflineSigner(signer);
        }
        return auths.map((auth)=>{
            return new AminoSigner(auth, encoders, converters, endpoint, options, broadcastOptions);
        });
    }
}
exports.AminoSigner = AminoSigner;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/builder/direct-tx-builder.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectTxBuilder = exports.DirectSigBuilder = void 0;
const signing_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/signing/v1beta1/signing.js [app-client] (ecmascript)");
const tx_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos-types/cosmos/tx/v1beta1/tx.js [app-client] (ecmascript)");
const base_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
/**
 * Direct signature builder
 */ class DirectSigBuilder extends base_1.BaseCosmosSigBuilder {
    async buildDocBytes(doc) {
        return tx_1.SignDoc.encode(doc).finish();
    }
}
exports.DirectSigBuilder = DirectSigBuilder;
/**
 * Direct transaction builder
 */ class DirectTxBuilder extends base_1.BaseCosmosTxBuilder {
    ctx;
    constructor(ctx){
        super(signing_1.SignMode.SIGN_MODE_DIRECT, ctx);
        this.ctx = ctx;
    }
    async buildDoc({ options }, txRaw) {
        const signDoc = tx_1.SignDoc.fromPartial({
            bodyBytes: txRaw.bodyBytes,
            authInfoBytes: txRaw.authInfoBytes,
            chainId: options?.chainId ?? await this.ctx.signer.queryClient.getChainId(),
            accountNumber: options?.accountNumber ?? await this.ctx.signer.queryClient.getAccountNumber(await this.ctx.signer.getAddress())
        });
        return signDoc;
    }
    async buildDocBytes(doc) {
        return tx_1.SignDoc.encode(doc).finish();
    }
    async syncSignedDoc(txRaw, signResp) {
        return {
            bodyBytes: signResp.signDoc.bodyBytes,
            authInfoBytes: signResp.signDoc.authInfoBytes,
            signatures: [
                signResp.signature.value
            ]
        };
    }
}
exports.DirectTxBuilder = DirectTxBuilder;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/signers/direct.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.DirectSigner = exports.DirectSignerBase = exports.DirectDocSigner = void 0;
const base_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/index.js [app-client] (ecmascript)");
const builder_context_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/builder-context.js [app-client] (ecmascript)");
const direct_tx_builder_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/builder/direct-tx-builder.js [app-client] (ecmascript)");
const docAuth_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/docAuth.js [app-client] (ecmascript)");
const wallet_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/wallet.js [app-client] (ecmascript)");
const utils_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/utils/index.js [app-client] (ecmascript)");
/**
 * DirectDocSigner is a signer for Direct document.
 */ class DirectDocSigner extends base_1.CosmosDocSigner {
    getTxBuilder() {
        return new direct_tx_builder_1.DirectSigBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.DirectDocSigner = DirectDocSigner;
/**
 * DirectSignerBase is a base signer for Direct document.
 */ class DirectSignerBase extends base_1.CosmosBaseSigner {
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, encoders.map(utils_1.toEncoder), endpoint, options, broadcastOptions);
    }
    getTxBuilder() {
        return new direct_tx_builder_1.DirectTxBuilder(new builder_context_1.BaseCosmosTxBuilderContext(this));
    }
}
exports.DirectSignerBase = DirectSignerBase;
/**
 * DirectSigner is a signer for Direct document.
 */ class DirectSigner extends DirectSignerBase {
    constructor(auth, encoders, endpoint, options, broadcastOptions){
        super(auth, encoders, endpoint, options, broadcastOptions);
    }
    /**
     * Create DirectSigner from wallet.
     * If there're multiple accounts in the wallet, it will return the first one by default.
     */ static async fromWallet(signer, encoders, endpoint, options, broadcastOptions) {
        let auth;
        if ((0, wallet_1.isOfflineDirectSigner)(signer)) {
            [auth] = await docAuth_1.DirectDocAuth.fromOfflineSigner(signer);
        } else {
            [auth] = await docAuth_1.DirectDocAuth.fromGenericOfflineSigner(signer);
        }
        return new DirectSigner(auth, encoders, endpoint, options, broadcastOptions);
    }
    /**
     * Create DirectSigners from wallet.
     * If there're multiple accounts in the wallet, it will return all of the signers.
     */ static async fromWalletToSigners(signer, encoders, endpoint, options, broadcastOptions) {
        let auths;
        if ((0, wallet_1.isOfflineDirectSigner)(signer)) {
            auths = await docAuth_1.DirectDocAuth.fromOfflineSigner(signer);
        } else {
            auths = await docAuth_1.DirectDocAuth.fromGenericOfflineSigner(signer);
        }
        return auths.map((auth)=>{
            return new DirectSigner(auth, encoders, endpoint, options, broadcastOptions);
        });
    }
}
exports.DirectSigner = DirectSigner;
}}),
"[project]/examples/e2e/node_modules/@interchainjs/cosmos/wallets/secp256k1hd.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Secp256k1HDWallet = exports.HDWallet = void 0;
const secp256k1_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/auth/secp256k1.js [app-client] (ecmascript)");
const amino_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/signers/amino.js [app-client] (ecmascript)");
const defaults_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/defaults.js [app-client] (ecmascript)");
const direct_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/signers/direct.js [app-client] (ecmascript)");
const types_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/types/index.js [app-client] (ecmascript)");
const base_wallet_1 = __turbopack_context__.r("[project]/examples/e2e/node_modules/@interchainjs/cosmos/base/base-wallet.js [app-client] (ecmascript)");
class HDWallet extends base_wallet_1.BaseCosmosWallet {
    constructor(accounts, options){
        const opts = {
            ...defaults_1.defaultSignerConfig,
            ...options
        };
        super(accounts, opts);
    }
    getDirectDocSigner(auth, config) {
        return new direct_1.DirectDocSigner(auth, config);
    }
    getAminoDocSigner(auth, config) {
        return new amino_1.AminoDocSigner(auth, config);
    }
    /**
   * Create a new HD wallet from mnemonic
   * @param mnemonic
   * @param derivations infos for derivate addresses
   * @param options wallet options
   * @returns HD wallet
   */ static fromMnemonic(mnemonic, derivations, options) {
        const walletOpts = {
            ...defaults_1.defaultWalletOptions,
            ...options
        };
        const hdPaths = derivations.map((derivation)=>derivation.hdPath);
        let auths;
        if (walletOpts?.createAuthsFromMnemonic) {
            auths = walletOpts.createAuthsFromMnemonic(mnemonic, hdPaths, {
                bip39Password: walletOpts?.bip39Password
            });
        } else {
            auths = secp256k1_1.Secp256k1Auth.fromMnemonic(mnemonic, hdPaths, {
                bip39Password: walletOpts?.bip39Password
            });
        }
        const accounts = auths.map((auth, i)=>{
            const derivation = derivations[i];
            const opts = walletOpts.signerConfig;
            if (opts?.createAccount) {
                return new opts.createAccount(derivation.prefix, auth, opts.publicKey.isCompressed);
            } else {
                return new types_1.CosmosAccount(derivation.prefix, auth);
            }
        });
        return new HDWallet(accounts, walletOpts?.signerConfig);
    }
}
exports.HDWallet = HDWallet;
/**
 * Cosmos HD Wallet for secp256k1
 */ class Secp256k1HDWallet extends HDWallet {
}
exports.Secp256k1HDWallet = Secp256k1HDWallet;
}}),
}]);

//# sourceMappingURL=_35a9c1af._.js.map