(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@walletconnect/utils/dist/index.es.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "BASE10": (()=>Mn),
    "BASE16": (()=>et),
    "BASE64": (()=>te),
    "BASE64URL": (()=>qe),
    "COLON": (()=>zs),
    "DEFAULT_DEPTH": (()=>Je),
    "EMPTY_SPACE": (()=>Oe),
    "ENV_MAP": (()=>Q),
    "INTERNAL_ERRORS": (()=>is),
    "MemoryStore": (()=>Va),
    "ONE_THOUSAND": (()=>Gs),
    "REACT_NATIVE_PRODUCT": (()=>ur),
    "RELAYER_DEFAULT_PROTOCOL": (()=>Zo),
    "SDK_ERRORS": (()=>ss),
    "SDK_TYPE": (()=>dr),
    "SLASH": (()=>lr),
    "TYPE_0": (()=>Vn),
    "TYPE_1": (()=>ne),
    "TYPE_2": (()=>xe),
    "UTF8": (()=>ee),
    "addResourceToRecap": (()=>ro),
    "addSignatureToExtrinsic": (()=>As),
    "appendToQueryString": (()=>hr),
    "assertType": (()=>ei),
    "assignAbilityToActions": (()=>pn),
    "base64Decode": (()=>eo),
    "base64Encode": (()=>to),
    "buildApprovedNamespaces": (()=>ya),
    "buildAuthObject": (()=>Bc),
    "buildNamespacesFromAuth": (()=>ma),
    "buildRecapStatement": (()=>so),
    "buildSignedExtrinsicHash": (()=>Ga),
    "calcExpiry": (()=>hi),
    "capitalize": (()=>ci),
    "capitalizeWord": (()=>xr),
    "createDelayedPromise": (()=>fi),
    "createEncodedRecap": (()=>Nc),
    "createExpiringPromise": (()=>ai),
    "createRecap": (()=>no),
    "decodeRecap": (()=>jt),
    "decodeTypeByte": (()=>Kt),
    "decodeTypeTwoEnvelope": (()=>Qf),
    "decrypt": (()=>Xf),
    "deriveExtrinsicHash": (()=>Bs),
    "deriveSymKey": (()=>Gf),
    "deserialize": (()=>Ke),
    "encodeRecap": (()=>Re),
    "encodeTypeByte": (()=>Kn),
    "encodeTypeTwoEnvelope": (()=>Jf),
    "encrypt": (()=>Yf),
    "engineEvent": (()=>gi),
    "enumify": (()=>ii),
    "extractSolanaTransactionId": (()=>dc),
    "formatAccountId": (()=>rr),
    "formatAccountWithChain": (()=>Cs),
    "formatChainId": (()=>nr),
    "formatDeeplinkUrl": (()=>vr),
    "formatExpirerTarget": (()=>tn),
    "formatIdTarget": (()=>li),
    "formatMessage": (()=>Yr),
    "formatMessageContext": (()=>ni),
    "formatRelayParams": (()=>Xo),
    "formatRelayRpcUrl": (()=>Qs),
    "formatStatementFromRecap": (()=>bn),
    "formatTopicTarget": (()=>ui),
    "formatUA": (()=>yr),
    "formatUri": (()=>ca),
    "fromBase64": (()=>nn),
    "generateKeyPair": (()=>Ff),
    "generateRandomBytes32": (()=>zf),
    "getAccountsChains": (()=>Ft),
    "getAccountsFromNamespaces": (()=>ks),
    "getAddressFromAccount": (()=>or),
    "getAddressesFromAccounts": (()=>js),
    "getAlgorandTransactionId": (()=>gc),
    "getAppId": (()=>Ys),
    "getAppMetadata": (()=>pr),
    "getBrowserOnlineStatus": (()=>ys),
    "getChainFromAccount": (()=>sr),
    "getChainsFromAccounts": (()=>ir),
    "getChainsFromNamespace": (()=>Se),
    "getChainsFromNamespaces": (()=>Ps),
    "getChainsFromRecap": (()=>Tc),
    "getChainsFromRequiredNamespaces": (()=>Hs),
    "getCommonValuesInArrays": (()=>en),
    "getCryptoKeyFromKeyData": (()=>Go),
    "getDecodedRecapFromResources": (()=>Xr),
    "getDeepLink": (()=>yi),
    "getDidAddress": (()=>hn),
    "getDidAddressSegments": (()=>Te),
    "getDidChainId": (()=>Zr),
    "getEnvironment": (()=>Mt),
    "getHttpUrl": (()=>ti),
    "getInternalError": (()=>Et),
    "getJavascriptID": (()=>br),
    "getJavascriptOS": (()=>gr),
    "getLastItems": (()=>wr),
    "getLinkModeURL": (()=>fa),
    "getMethodsFromRecap": (()=>_c),
    "getNamespacedDidChainId": (()=>Wr),
    "getNamespacesChains": (()=>ts),
    "getNamespacesEventsForChainId": (()=>ns),
    "getNamespacesFromAccounts": (()=>os),
    "getNamespacesMethodsForChainId": (()=>es),
    "getNearTransactionIdFromSignedTransaction": (()=>pc),
    "getNearUint8ArrayFromBytes": (()=>Kr),
    "getNodeOnlineStatus": (()=>ws),
    "getReCapActions": (()=>Qr),
    "getReactNativeOnlineStatus": (()=>ms),
    "getRecapAbilitiesFromResource": (()=>Oc),
    "getRecapFromResources": (()=>$e),
    "getRecapResource": (()=>Jr),
    "getRelayClientMetadata": (()=>Js),
    "getRelayProtocolApi": (()=>sa),
    "getRelayProtocolName": (()=>oa),
    "getRequiredNamespacesFromNamespaces": (()=>ba),
    "getSdkError": (()=>zt),
    "getSearchParamFromURL": (()=>mi),
    "getSignDirectHash": (()=>bc),
    "getSuiDigest": (()=>hc),
    "getUniqueValues": (()=>Xe),
    "handleDeeplinkRedirect": (()=>bi),
    "hasOverlap": (()=>Bt),
    "hashEthereumMessage": (()=>un),
    "hashKey": (()=>Zf),
    "hashMessage": (()=>Wf),
    "isAndroid": (()=>Zs),
    "isAppVisible": (()=>Ma),
    "isBrowser": (()=>Wt),
    "isCaipNamespace": (()=>zn),
    "isConformingNamespaces": (()=>gs),
    "isExpired": (()=>pi),
    "isIframe": (()=>Br),
    "isIos": (()=>Ws),
    "isNode": (()=>Qe),
    "isOnline": (()=>Ha),
    "isProposalStruct": (()=>Ea),
    "isReactNative": (()=>At),
    "isRecap": (()=>gn),
    "isSessionCompatible": (()=>xa),
    "isSessionStruct": (()=>Aa),
    "isTelegram": (()=>Ar),
    "isTestRun": (()=>xi),
    "isTypeOneEnvelope": (()=>ea),
    "isTypeTwoEnvelope": (()=>na),
    "isUndefined": (()=>Ht),
    "isValidAccountId": (()=>cs),
    "isValidAccounts": (()=>us),
    "isValidActions": (()=>ds),
    "isValidArray": (()=>Ae),
    "isValidChainId": (()=>Be),
    "isValidChains": (()=>fs),
    "isValidController": (()=>Ba),
    "isValidEip1271Signature": (()=>qr),
    "isValidEip191Signature": (()=>Vr),
    "isValidErrorReason": (()=>Ua),
    "isValidEvent": (()=>Ra),
    "isValidId": (()=>Oa),
    "isValidNamespaceAccounts": (()=>ls),
    "isValidNamespaceActions": (()=>Zn),
    "isValidNamespaceChains": (()=>as),
    "isValidNamespaceMethodsOrEvents": (()=>Gn),
    "isValidNamespaces": (()=>hs),
    "isValidNamespacesChainId": (()=>$a),
    "isValidNamespacesEvent": (()=>Ca),
    "isValidNamespacesRequest": (()=>La),
    "isValidNumber": (()=>ze),
    "isValidObject": (()=>Fe),
    "isValidParams": (()=>Na),
    "isValidRecap": (()=>bt),
    "isValidRelay": (()=>ps),
    "isValidRelays": (()=>Sa),
    "isValidRequest": (()=>_a),
    "isValidRequestExpiry": (()=>Pa),
    "isValidRequiredNamespaces": (()=>Ia),
    "isValidResponse": (()=>Ta),
    "isValidString": (()=>ft),
    "isValidUrl": (()=>va),
    "mapEntries": (()=>si),
    "mapToObj": (()=>ri),
    "mergeArrays": (()=>ut),
    "mergeEncodedRecaps": (()=>Uc),
    "mergeRecaps": (()=>oo),
    "mergeRequiredAndOptionalNamespaces": (()=>wa),
    "normalizeNamespaces": (()=>Ee),
    "objToMap": (()=>oi),
    "openDeeplink": (()=>Er),
    "parseAccountId": (()=>Ye),
    "parseChainId": (()=>We),
    "parseContextNames": (()=>mr),
    "parseExpirerTarget": (()=>di),
    "parseNamespaceKey": (()=>rs),
    "parseRelayParams": (()=>Wo),
    "parseTopic": (()=>Yo),
    "parseUri": (()=>ia),
    "populateAppMetadata": (()=>Xs),
    "populateAuthPayload": (()=>Ic),
    "recapHasResource": (()=>Sc),
    "serialize": (()=>Fn),
    "sleep": (()=>vi),
    "ss58AddressToPublicKey": (()=>Es),
    "subscribeToBrowserNetworkChange": (()=>xs),
    "subscribeToNetworkChange": (()=>Da),
    "subscribeToReactNativeNetworkChange": (()=>vs),
    "toBase64": (()=>Ir),
    "uuidv4": (()=>wi),
    "validateDecoding": (()=>ta),
    "validateEncoding": (()=>zo),
    "validateSignedCacao": (()=>Ac),
    "verifyP256Jwt": (()=>ra),
    "verifySignature": (()=>Mr)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$detect$2d$browser$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/detect-browser/es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/time/dist/cjs/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/window-getters/dist/cjs/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$metadata$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/window-metadata/dist/cjs/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$signature$2f$recoverAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/signature/recoverAddress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bs58/src/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$msgpack$2f$msgpack$2f$dist$2e$esm$2f$decode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@msgpack/msgpack/dist.esm/decode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$msgpack$2f$msgpack$2f$dist$2e$esm$2f$encode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@msgpack/msgpack/dist.esm/encode.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@scure/base/lib/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$relay$2d$auth$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/relay-auth/dist/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/uint8arrays/esm/src/index.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/uint8arrays/esm/src/to-string.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/uint8arrays/esm/src/from-string.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/uint8arrays/esm/src/concat.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$relay$2d$api$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@walletconnect/relay-api/dist/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blakejs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/blakejs/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
const Ie = ":";
function We(t) {
    const [e, n] = t.split(Ie);
    return {
        namespace: e,
        reference: n
    };
}
function nr(t) {
    const { namespace: e, reference: n } = t;
    return [
        e,
        n
    ].join(Ie);
}
function Ye(t) {
    const [e, n, r] = t.split(Ie);
    return {
        namespace: e,
        reference: n,
        address: r
    };
}
function rr(t) {
    const { namespace: e, reference: n, address: r } = t;
    return [
        e,
        n,
        r
    ].join(Ie);
}
function Xe(t, e) {
    const n = [];
    return t.forEach((r)=>{
        const o = e(r);
        n.includes(o) || n.push(o);
    }), n;
}
function or(t) {
    const { address: e } = Ye(t);
    return e;
}
function sr(t) {
    const { namespace: e, reference: n } = Ye(t);
    return nr({
        namespace: e,
        reference: n
    });
}
function Cs(t, e) {
    const { namespace: n, reference: r } = We(e);
    return rr({
        namespace: n,
        reference: r,
        address: t
    });
}
function js(t) {
    return Xe(t, or);
}
function ir(t) {
    return Xe(t, sr);
}
function ks(t, e = []) {
    const n = [];
    return Object.keys(t).forEach((r)=>{
        if (e.length && !e.includes(r)) return;
        const o = t[r];
        n.push(...o.accounts);
    }), n;
}
function Ps(t, e = []) {
    const n = [];
    return Object.keys(t).forEach((r)=>{
        if (e.length && !e.includes(r)) return;
        const o = t[r];
        n.push(...ir(o.accounts));
    }), n;
}
function Hs(t, e = []) {
    const n = [];
    return Object.keys(t).forEach((r)=>{
        if (e.length && !e.includes(r)) return;
        const o = t[r];
        n.push(...Se(r, o));
    }), n;
}
function Se(t, e) {
    return t.includes(":") ? [
        t
    ] : e.chains || [];
}
var Ds = Object.defineProperty, Ms = Object.defineProperties, Vs = Object.getOwnPropertyDescriptors, cr = Object.getOwnPropertySymbols, qs = Object.prototype.hasOwnProperty, Ks = Object.prototype.propertyIsEnumerable, fr = (t, e, n)=>e in t ? Ds(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n, ar = (t, e)=>{
    for(var n in e || (e = {}))qs.call(e, n) && fr(t, n, e[n]);
    if (cr) for (var n of cr(e))Ks.call(e, n) && fr(t, n, e[n]);
    return t;
}, Fs = (t, e)=>Ms(t, Vs(e));
const ur = "ReactNative", Q = {
    reactNative: "react-native",
    node: "node",
    browser: "browser",
    unknown: "unknown"
}, Oe = " ", zs = ":", lr = "/", Je = 2, Gs = 1e3, dr = "js";
function Qe() {
    return typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] < "u" && typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].versions < "u" && typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].versions.node < "u";
}
function At() {
    return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])() && !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() && navigator.product === ur;
}
function Zs() {
    return At() && typeof global < "u" && typeof (global == null ? void 0 : global.Platform) < "u" && (global == null ? void 0 : global.Platform.OS) === "android";
}
function Ws() {
    return At() && typeof global < "u" && typeof (global == null ? void 0 : global.Platform) < "u" && (global == null ? void 0 : global.Platform.OS) === "ios";
}
function Wt() {
    return !Qe() && !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNavigator"])() && !!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])();
}
function Mt() {
    return At() ? Q.reactNative : Qe() ? Q.node : Wt() ? Q.browser : Q.unknown;
}
function Ys() {
    var t;
    try {
        return At() && typeof global < "u" && typeof (global == null ? void 0 : global.Application) < "u" ? (t = global.Application) == null ? void 0 : t.applicationId : void 0;
    } catch  {
        return;
    }
}
function hr(t, e) {
    const n = new URLSearchParams(t);
    for (const r of Object.keys(e).sort())if (e.hasOwnProperty(r)) {
        const o = e[r];
        o !== void 0 && n.set(r, o);
    }
    return n.toString();
}
function Xs(t) {
    var e, n;
    const r = pr();
    try {
        return t != null && t.url && r.url && new URL(t.url).host !== new URL(r.url).host && (console.warn(`The configured WalletConnect 'metadata.url':${t.url} differs from the actual page url:${r.url}. This is probably unintended and can lead to issues.`), t.url = r.url), (e = t?.icons) != null && e.length && t.icons.length > 0 && (t.icons = t.icons.filter((o)=>o !== "")), Fs(ar(ar({}, r), t), {
            url: t?.url || r.url,
            name: t?.name || r.name,
            description: t?.description || r.description,
            icons: (n = t?.icons) != null && n.length && t.icons.length > 0 ? t.icons : r.icons
        });
    } catch (o) {
        return console.warn("Error populating app metadata", o), t || r;
    }
}
function pr() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$metadata$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getWindowMetadata"])() || {
        name: "",
        description: "",
        url: "",
        icons: [
            ""
        ]
    };
}
function Js(t, e) {
    var n;
    const r = Mt(), o = {
        protocol: t,
        version: e,
        env: r
    };
    return r === "browser" && (o.host = ((n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])()) == null ? void 0 : n.host) || "unknown"), o;
}
function gr() {
    if (Mt() === Q.reactNative && typeof global < "u" && typeof (global == null ? void 0 : global.Platform) < "u") {
        const { OS: n, Version: r } = global.Platform;
        return [
            n,
            r
        ].join("-");
    }
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$detect$2d$browser$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detect"])();
    if (t === null) return "unknown";
    const e = t.os ? t.os.replace(" ", "").toLowerCase() : "unknown";
    return t.type === "browser" ? [
        e,
        t.name,
        t.version
    ].join("-") : [
        e,
        t.version
    ].join("-");
}
function br() {
    var t;
    const e = Mt();
    return e === Q.browser ? [
        e,
        ((t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLocation"])()) == null ? void 0 : t.host) || "unknown"
    ].join(":") : e;
}
function yr(t, e, n) {
    const r = gr(), o = br();
    return [
        [
            t,
            e
        ].join("-"),
        [
            dr,
            n
        ].join("-"),
        r,
        o
    ].join("/");
}
function Qs({ protocol: t, version: e, relayUrl: n, sdkVersion: r, auth: o, projectId: s, useOnCloseEvent: i, bundleId: c, packageName: f }) {
    const a = n.split("?"), l = yr(t, e, r), u = {
        auth: o,
        ua: l,
        projectId: s,
        useOnCloseEvent: i || void 0,
        packageName: f || void 0,
        bundleId: c || void 0
    }, h = hr(a[1] || "", u);
    return a[0] + "?" + h;
}
function ti(t) {
    let e = (t.match(/^[^:]+(?=:\/\/)/gi) || [])[0];
    const n = typeof e < "u" ? t.split("://")[1] : t;
    return e = e === "wss" ? "https" : "http", [
        e,
        n
    ].join("://");
}
function ei(t, e, n) {
    if (!t[e] || typeof t[e] !== n) throw new Error(`Missing or invalid "${e}" param`);
}
function mr(t, e = Je) {
    return wr(t.split(lr), e);
}
function ni(t) {
    return mr(t).join(Oe);
}
function Bt(t, e) {
    return t.filter((n)=>e.includes(n)).length === t.length;
}
function wr(t, e = Je) {
    return t.slice(Math.max(t.length - e, 0));
}
function ri(t) {
    return Object.fromEntries(t.entries());
}
function oi(t) {
    return new Map(Object.entries(t));
}
function si(t, e) {
    const n = {};
    return Object.keys(t).forEach((r)=>{
        n[r] = e(t[r]);
    }), n;
}
const ii = (t)=>t;
function xr(t) {
    return t.trim().replace(/^\w/, (e)=>e.toUpperCase());
}
function ci(t) {
    return t.split(Oe).map((e)=>xr(e)).join(Oe);
}
function fi(t = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FIVE_MINUTES"], e) {
    const n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toMiliseconds"])(t || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FIVE_MINUTES"]);
    let r, o, s, i;
    return {
        resolve: (c)=>{
            s && r && (clearTimeout(s), r(c), i = Promise.resolve(c));
        },
        reject: (c)=>{
            s && o && (clearTimeout(s), o(c));
        },
        done: ()=>new Promise((c, f)=>{
                if (i) return c(i);
                s = setTimeout(()=>{
                    const a = new Error(e);
                    i = Promise.reject(a), f(a);
                }, n), r = c, o = f;
            })
    };
}
function ai(t, e, n) {
    return new Promise(async (r, o)=>{
        const s = setTimeout(()=>o(new Error(n)), e);
        try {
            const i = await t;
            r(i);
        } catch (i) {
            o(i);
        }
        clearTimeout(s);
    });
}
function tn(t, e) {
    if (typeof e == "string" && e.startsWith(`${t}:`)) return e;
    if (t.toLowerCase() === "topic") {
        if (typeof e != "string") throw new Error('Value must be "string" for expirer target type: topic');
        return `topic:${e}`;
    } else if (t.toLowerCase() === "id") {
        if (typeof e != "number") throw new Error('Value must be "number" for expirer target type: id');
        return `id:${e}`;
    }
    throw new Error(`Unknown expirer target type: ${t}`);
}
function ui(t) {
    return tn("topic", t);
}
function li(t) {
    return tn("id", t);
}
function di(t) {
    const [e, n] = t.split(":"), r = {
        id: void 0,
        topic: void 0
    };
    if (e === "topic" && typeof n == "string") r.topic = n;
    else if (e === "id" && Number.isInteger(Number(n))) r.id = Number(n);
    else throw new Error(`Invalid target, expected id:number or topic:string, got ${e}:${n}`);
    return r;
}
function hi(t, e) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromMiliseconds"])((e || Date.now()) + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toMiliseconds"])(t));
}
function pi(t) {
    return Date.now() >= (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$time$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toMiliseconds"])(t);
}
function gi(t, e) {
    return `${t}${e ? `:${e}` : ""}`;
}
function ut(t = [], e = []) {
    return [
        ...new Set([
            ...t,
            ...e
        ])
    ];
}
async function bi({ id: t, topic: e, wcDeepLink: n }) {
    var r;
    try {
        if (!n) return;
        const o = typeof n == "string" ? JSON.parse(n) : n, s = o?.href;
        if (typeof s != "string") return;
        const i = vr(s, t, e), c = Mt();
        if (c === Q.browser) {
            if (!((r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])()) != null && r.hasFocus())) {
                console.warn("Document does not have focus, skipping deeplink.");
                return;
            }
            Er(i);
        } else c === Q.reactNative && typeof (global == null ? void 0 : global.Linking) < "u" && await global.Linking.openURL(i);
    } catch (o) {
        console.error(o);
    }
}
function vr(t, e, n) {
    const r = `requestId=${e}&sessionTopic=${n}`;
    t.endsWith("/") && (t = t.slice(0, -1));
    let o = `${t}`;
    if (t.startsWith("https://t.me")) {
        const s = t.includes("?") ? "&startapp=" : "?startapp=";
        o = `${o}${s}${Ir(r, !0)}`;
    } else o = `${o}/wc?${r}`;
    return o;
}
function Er(t) {
    let e = "_self";
    Br() ? e = "_top" : (Ar() || t.startsWith("https://") || t.startsWith("http://")) && (e = "_blank"), window.open(t, e, "noreferrer noopener");
}
async function yi(t, e) {
    let n = "";
    try {
        if (Wt() && (n = localStorage.getItem(e), n)) return n;
        n = await t.getItem(e);
    } catch (r) {
        console.error(r);
    }
    return n;
}
function en(t, e) {
    return t.filter((n)=>e.includes(n));
}
function mi(t, e) {
    if (!t.includes(e)) return null;
    const n = t.split(/([&,?,=])/), r = n.indexOf(e);
    return n[r + 2];
}
function wi() {
    return typeof crypto < "u" && crypto != null && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/gu, (t)=>{
        const e = Math.random() * 16 | 0;
        return (t === "x" ? e : e & 3 | 8).toString(16);
    });
}
function xi() {
    return typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"] < "u" && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.IS_VITEST === "true";
}
function Ar() {
    return typeof window < "u" && (!!window.TelegramWebviewProxy || !!window.Telegram || !!window.TelegramWebviewProxyProto);
}
function Br() {
    try {
        return window.self !== window.top;
    } catch  {
        return !1;
    }
}
function Ir(t, e = !1) {
    const n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t).toString("base64");
    return e ? n.replace(/[=]/g, "") : n;
}
function nn(t) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t, "base64").toString("utf-8");
}
function vi(t) {
    return new Promise((e)=>setTimeout(e, t));
}
const Ne = BigInt(2 ** 32 - 1), Sr = BigInt(32);
function Or(t, e = !1) {
    return e ? {
        h: Number(t & Ne),
        l: Number(t >> Sr & Ne)
    } : {
        h: Number(t >> Sr & Ne) | 0,
        l: Number(t & Ne) | 0
    };
}
function Nr(t, e = !1) {
    const n = t.length;
    let r = new Uint32Array(n), o = new Uint32Array(n);
    for(let s = 0; s < n; s++){
        const { h: i, l: c } = Or(t[s], e);
        [r[s], o[s]] = [
            i,
            c
        ];
    }
    return [
        r,
        o
    ];
}
const Ur = (t, e, n)=>t >>> n, _r = (t, e, n)=>t << 32 - n | e >>> n, It = (t, e, n)=>t >>> n | e << 32 - n, St = (t, e, n)=>t << 32 - n | e >>> n, fe = (t, e, n)=>t << 64 - n | e >>> n - 32, ae = (t, e, n)=>t >>> n - 32 | e << 64 - n, Ei = (t, e)=>e, Ai = (t, e)=>t, Bi = (t, e, n)=>t << n | e >>> 32 - n, Ii = (t, e, n)=>e << n | t >>> 32 - n, Si = (t, e, n)=>e << n - 32 | t >>> 64 - n, Oi = (t, e, n)=>t << n - 32 | e >>> 64 - n;
function dt(t, e, n, r) {
    const o = (e >>> 0) + (r >>> 0);
    return {
        h: t + n + (o / 2 ** 32 | 0) | 0,
        l: o | 0
    };
}
const rn = (t, e, n)=>(t >>> 0) + (e >>> 0) + (n >>> 0), on = (t, e, n, r)=>e + n + r + (t / 2 ** 32 | 0) | 0, Ni = (t, e, n, r)=>(t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0), Ui = (t, e, n, r, o)=>e + n + r + o + (t / 2 ** 32 | 0) | 0, _i = (t, e, n, r, o)=>(t >>> 0) + (e >>> 0) + (n >>> 0) + (r >>> 0) + (o >>> 0), Ti = (t, e, n, r, o, s)=>e + n + r + o + s + (t / 2 ** 32 | 0) | 0, Yt = typeof globalThis == "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
function Ri(t) {
    return t instanceof Uint8Array || ArrayBuffer.isView(t) && t.constructor.name === "Uint8Array";
}
function yt(t) {
    if (!Number.isSafeInteger(t) || t < 0) throw new Error("positive integer expected, got " + t);
}
function Ot(t, ...e) {
    if (!Ri(t)) throw new Error("Uint8Array expected");
    if (e.length > 0 && !e.includes(t.length)) throw new Error("Uint8Array expected of length " + e + ", got length=" + t.length);
}
function sn(t) {
    if (typeof t != "function" || typeof t.create != "function") throw new Error("Hash should be wrapped by utils.createHasher");
    yt(t.outputLen), yt(t.blockLen);
}
function Nt(t, e = !0) {
    if (t.destroyed) throw new Error("Hash instance has been destroyed");
    if (e && t.finished) throw new Error("Hash#digest() has already been called");
}
function cn(t, e) {
    Ot(t);
    const n = e.outputLen;
    if (t.length < n) throw new Error("digestInto() expects output buffer of length at least " + n);
}
function ue(t) {
    return new Uint32Array(t.buffer, t.byteOffset, Math.floor(t.byteLength / 4));
}
function lt(...t) {
    for(let e = 0; e < t.length; e++)t[e].fill(0);
}
function fn(t) {
    return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
function gt(t, e) {
    return t << 32 - e | t >>> e;
}
const Tr = new Uint8Array(new Uint32Array([
    287454020
]).buffer)[0] === 68;
function Rr(t) {
    return t << 24 & 4278190080 | t << 8 & 16711680 | t >>> 8 & 65280 | t >>> 24 & 255;
}
const mt = Tr ? (t)=>t : (t)=>Rr(t);
function $i(t) {
    for(let e = 0; e < t.length; e++)t[e] = Rr(t[e]);
    return t;
}
const Ut = Tr ? (t)=>t : $i;
function Li(t) {
    if (typeof t != "string") throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(t));
}
function ht(t) {
    return typeof t == "string" && (t = Li(t)), Ot(t), t;
}
function Ci(...t) {
    let e = 0;
    for(let r = 0; r < t.length; r++){
        const o = t[r];
        Ot(o), e += o.length;
    }
    const n = new Uint8Array(e);
    for(let r = 0, o = 0; r < t.length; r++){
        const s = t[r];
        n.set(s, o), o += s.length;
    }
    return n;
}
class Ue {
}
function le(t) {
    const e = (r)=>t().update(ht(r)).digest(), n = t();
    return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = ()=>t(), e;
}
function ji(t) {
    const e = (r, o)=>t(o).update(ht(r)).digest(), n = t({});
    return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = (r)=>t(r), e;
}
function Xt(t = 32) {
    if (Yt && typeof Yt.getRandomValues == "function") return Yt.getRandomValues(new Uint8Array(t));
    if (Yt && typeof Yt.randomBytes == "function") return Uint8Array.from(Yt.randomBytes(t));
    throw new Error("crypto.getRandomValues must be defined");
}
const ki = BigInt(0), de = BigInt(1), Pi = BigInt(2), Hi = BigInt(7), Di = BigInt(256), Mi = BigInt(113), $r = [], Lr = [], Cr = [];
for(let t = 0, e = de, n = 1, r = 0; t < 24; t++){
    [n, r] = [
        r,
        (2 * n + 3 * r) % 5
    ], $r.push(2 * (5 * r + n)), Lr.push((t + 1) * (t + 2) / 2 % 64);
    let o = ki;
    for(let s = 0; s < 7; s++)e = (e << de ^ (e >> Hi) * Mi) % Di, e & Pi && (o ^= de << (de << BigInt(s)) - de);
    Cr.push(o);
}
const jr = Nr(Cr, !0), Vi = jr[0], qi = jr[1], kr = (t, e, n)=>n > 32 ? Si(t, e, n) : Bi(t, e, n), Pr = (t, e, n)=>n > 32 ? Oi(t, e, n) : Ii(t, e, n);
function Ki(t, e = 24) {
    const n = new Uint32Array(10);
    for(let r = 24 - e; r < 24; r++){
        for(let i = 0; i < 10; i++)n[i] = t[i] ^ t[i + 10] ^ t[i + 20] ^ t[i + 30] ^ t[i + 40];
        for(let i = 0; i < 10; i += 2){
            const c = (i + 8) % 10, f = (i + 2) % 10, a = n[f], l = n[f + 1], u = kr(a, l, 1) ^ n[c], h = Pr(a, l, 1) ^ n[c + 1];
            for(let m = 0; m < 50; m += 10)t[i + m] ^= u, t[i + m + 1] ^= h;
        }
        let o = t[2], s = t[3];
        for(let i = 0; i < 24; i++){
            const c = Lr[i], f = kr(o, s, c), a = Pr(o, s, c), l = $r[i];
            o = t[l], s = t[l + 1], t[l] = f, t[l + 1] = a;
        }
        for(let i = 0; i < 50; i += 10){
            for(let c = 0; c < 10; c++)n[c] = t[i + c];
            for(let c = 0; c < 10; c++)t[i + c] ^= ~n[(c + 2) % 10] & n[(c + 4) % 10];
        }
        t[0] ^= Vi[r], t[1] ^= qi[r];
    }
    lt(n);
}
class Xn extends Ue {
    constructor(e, n, r, o = !1, s = 24){
        if (super(), this.pos = 0, this.posOut = 0, this.finished = !1, this.destroyed = !1, this.enableXOF = !1, this.blockLen = e, this.suffix = n, this.outputLen = r, this.enableXOF = o, this.rounds = s, yt(r), !(0 < e && e < 200)) throw new Error("only keccak-f1600 function is supported");
        this.state = new Uint8Array(200), this.state32 = ue(this.state);
    }
    clone() {
        return this._cloneInto();
    }
    keccak() {
        Ut(this.state32), Ki(this.state32, this.rounds), Ut(this.state32), this.posOut = 0, this.pos = 0;
    }
    update(e) {
        Nt(this), e = ht(e), Ot(e);
        const { blockLen: n, state: r } = this, o = e.length;
        for(let s = 0; s < o;){
            const i = Math.min(n - this.pos, o - s);
            for(let c = 0; c < i; c++)r[this.pos++] ^= e[s++];
            this.pos === n && this.keccak();
        }
        return this;
    }
    finish() {
        if (this.finished) return;
        this.finished = !0;
        const { state: e, suffix: n, pos: r, blockLen: o } = this;
        e[r] ^= n, (n & 128) !== 0 && r === o - 1 && this.keccak(), e[o - 1] ^= 128, this.keccak();
    }
    writeInto(e) {
        Nt(this, !1), Ot(e), this.finish();
        const n = this.state, { blockLen: r } = this;
        for(let o = 0, s = e.length; o < s;){
            this.posOut >= r && this.keccak();
            const i = Math.min(r - this.posOut, s - o);
            e.set(n.subarray(this.posOut, this.posOut + i), o), this.posOut += i, o += i;
        }
        return e;
    }
    xofInto(e) {
        if (!this.enableXOF) throw new Error("XOF is not possible for this instance");
        return this.writeInto(e);
    }
    xof(e) {
        return yt(e), this.xofInto(new Uint8Array(e));
    }
    digestInto(e) {
        if (cn(e, this), this.finished) throw new Error("digest() was already called");
        return this.writeInto(e), this.destroy(), e;
    }
    digest() {
        return this.digestInto(new Uint8Array(this.outputLen));
    }
    destroy() {
        this.destroyed = !0, lt(this.state);
    }
    _cloneInto(e) {
        const { blockLen: n, suffix: r, outputLen: o, rounds: s, enableXOF: i } = this;
        return e || (e = new Xn(n, r, o, i, s)), e.state32.set(this.state32), e.pos = this.pos, e.posOut = this.posOut, e.finished = this.finished, e.rounds = s, e.suffix = r, e.outputLen = o, e.enableXOF = i, e.destroyed = this.destroyed, e;
    }
}
const Fi = (t, e, n)=>le(()=>new Xn(e, t, n)), zi = Fi(1, 136, 256 / 8);
function Gi(t, e, n, r) {
    if (typeof t.setBigUint64 == "function") return t.setBigUint64(e, n, r);
    const o = BigInt(32), s = BigInt(4294967295), i = Number(n >> o & s), c = Number(n & s), f = r ? 4 : 0, a = r ? 0 : 4;
    t.setUint32(e + f, i, r), t.setUint32(e + a, c, r);
}
function Zi(t, e, n) {
    return t & e ^ ~t & n;
}
function Wi(t, e, n) {
    return t & e ^ t & n ^ e & n;
}
class Hr extends Ue {
    constructor(e, n, r, o){
        super(), this.finished = !1, this.length = 0, this.pos = 0, this.destroyed = !1, this.blockLen = e, this.outputLen = n, this.padOffset = r, this.isLE = o, this.buffer = new Uint8Array(e), this.view = fn(this.buffer);
    }
    update(e) {
        Nt(this), e = ht(e), Ot(e);
        const { view: n, buffer: r, blockLen: o } = this, s = e.length;
        for(let i = 0; i < s;){
            const c = Math.min(o - this.pos, s - i);
            if (c === o) {
                const f = fn(e);
                for(; o <= s - i; i += o)this.process(f, i);
                continue;
            }
            r.set(e.subarray(i, i + c), this.pos), this.pos += c, i += c, this.pos === o && (this.process(n, 0), this.pos = 0);
        }
        return this.length += e.length, this.roundClean(), this;
    }
    digestInto(e) {
        Nt(this), cn(e, this), this.finished = !0;
        const { buffer: n, view: r, blockLen: o, isLE: s } = this;
        let { pos: i } = this;
        n[i++] = 128, lt(this.buffer.subarray(i)), this.padOffset > o - i && (this.process(r, 0), i = 0);
        for(let u = i; u < o; u++)n[u] = 0;
        Gi(r, o - 8, BigInt(this.length * 8), s), this.process(r, 0);
        const c = fn(e), f = this.outputLen;
        if (f % 4) throw new Error("_sha2: outputLen should be aligned to 32bit");
        const a = f / 4, l = this.get();
        if (a > l.length) throw new Error("_sha2: outputLen bigger than state");
        for(let u = 0; u < a; u++)c.setUint32(4 * u, l[u], s);
    }
    digest() {
        const { buffer: e, outputLen: n } = this;
        this.digestInto(e);
        const r = e.slice(0, n);
        return this.destroy(), r;
    }
    _cloneInto(e) {
        e || (e = new this.constructor), e.set(...this.get());
        const { blockLen: n, buffer: r, length: o, finished: s, destroyed: i, pos: c } = this;
        return e.destroyed = i, e.finished = s, e.length = o, e.pos = c, o % n && e.buffer.set(r), e;
    }
    clone() {
        return this._cloneInto();
    }
}
const _t = Uint32Array.from([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
]), Y = Uint32Array.from([
    3418070365,
    3238371032,
    1654270250,
    914150663,
    2438529370,
    812702999,
    355462360,
    4144912697,
    1731405415,
    4290775857,
    2394180231,
    1750603025,
    3675008525,
    1694076839,
    1203062813,
    3204075428
]), X = Uint32Array.from([
    1779033703,
    4089235720,
    3144134277,
    2227873595,
    1013904242,
    4271175723,
    2773480762,
    1595750129,
    1359893119,
    2917565137,
    2600822924,
    725511199,
    528734635,
    4215389547,
    1541459225,
    327033209
]), Yi = Uint32Array.from([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
]), Tt = new Uint32Array(64);
class Xi extends Hr {
    constructor(e = 32){
        super(64, e, 8, !1), this.A = _t[0] | 0, this.B = _t[1] | 0, this.C = _t[2] | 0, this.D = _t[3] | 0, this.E = _t[4] | 0, this.F = _t[5] | 0, this.G = _t[6] | 0, this.H = _t[7] | 0;
    }
    get() {
        const { A: e, B: n, C: r, D: o, E: s, F: i, G: c, H: f } = this;
        return [
            e,
            n,
            r,
            o,
            s,
            i,
            c,
            f
        ];
    }
    set(e, n, r, o, s, i, c, f) {
        this.A = e | 0, this.B = n | 0, this.C = r | 0, this.D = o | 0, this.E = s | 0, this.F = i | 0, this.G = c | 0, this.H = f | 0;
    }
    process(e, n) {
        for(let u = 0; u < 16; u++, n += 4)Tt[u] = e.getUint32(n, !1);
        for(let u = 16; u < 64; u++){
            const h = Tt[u - 15], m = Tt[u - 2], p = gt(h, 7) ^ gt(h, 18) ^ h >>> 3, d = gt(m, 17) ^ gt(m, 19) ^ m >>> 10;
            Tt[u] = d + Tt[u - 7] + p + Tt[u - 16] | 0;
        }
        let { A: r, B: o, C: s, D: i, E: c, F: f, G: a, H: l } = this;
        for(let u = 0; u < 64; u++){
            const h = gt(c, 6) ^ gt(c, 11) ^ gt(c, 25), m = l + h + Zi(c, f, a) + Yi[u] + Tt[u] | 0, d = (gt(r, 2) ^ gt(r, 13) ^ gt(r, 22)) + Wi(r, o, s) | 0;
            l = a, a = f, f = c, c = i + m | 0, i = s, s = o, o = r, r = m + d | 0;
        }
        r = r + this.A | 0, o = o + this.B | 0, s = s + this.C | 0, i = i + this.D | 0, c = c + this.E | 0, f = f + this.F | 0, a = a + this.G | 0, l = l + this.H | 0, this.set(r, o, s, i, c, f, a, l);
    }
    roundClean() {
        lt(Tt);
    }
    destroy() {
        this.set(0, 0, 0, 0, 0, 0, 0, 0), lt(this.buffer);
    }
}
const Dr = Nr([
    "0x428a2f98d728ae22",
    "0x7137449123ef65cd",
    "0xb5c0fbcfec4d3b2f",
    "0xe9b5dba58189dbbc",
    "0x3956c25bf348b538",
    "0x59f111f1b605d019",
    "0x923f82a4af194f9b",
    "0xab1c5ed5da6d8118",
    "0xd807aa98a3030242",
    "0x12835b0145706fbe",
    "0x243185be4ee4b28c",
    "0x550c7dc3d5ffb4e2",
    "0x72be5d74f27b896f",
    "0x80deb1fe3b1696b1",
    "0x9bdc06a725c71235",
    "0xc19bf174cf692694",
    "0xe49b69c19ef14ad2",
    "0xefbe4786384f25e3",
    "0x0fc19dc68b8cd5b5",
    "0x240ca1cc77ac9c65",
    "0x2de92c6f592b0275",
    "0x4a7484aa6ea6e483",
    "0x5cb0a9dcbd41fbd4",
    "0x76f988da831153b5",
    "0x983e5152ee66dfab",
    "0xa831c66d2db43210",
    "0xb00327c898fb213f",
    "0xbf597fc7beef0ee4",
    "0xc6e00bf33da88fc2",
    "0xd5a79147930aa725",
    "0x06ca6351e003826f",
    "0x142929670a0e6e70",
    "0x27b70a8546d22ffc",
    "0x2e1b21385c26c926",
    "0x4d2c6dfc5ac42aed",
    "0x53380d139d95b3df",
    "0x650a73548baf63de",
    "0x766a0abb3c77b2a8",
    "0x81c2c92e47edaee6",
    "0x92722c851482353b",
    "0xa2bfe8a14cf10364",
    "0xa81a664bbc423001",
    "0xc24b8b70d0f89791",
    "0xc76c51a30654be30",
    "0xd192e819d6ef5218",
    "0xd69906245565a910",
    "0xf40e35855771202a",
    "0x106aa07032bbd1b8",
    "0x19a4c116b8d2d0c8",
    "0x1e376c085141ab53",
    "0x2748774cdf8eeb99",
    "0x34b0bcb5e19b48a8",
    "0x391c0cb3c5c95a63",
    "0x4ed8aa4ae3418acb",
    "0x5b9cca4f7763e373",
    "0x682e6ff3d6b2b8a3",
    "0x748f82ee5defb2fc",
    "0x78a5636f43172f60",
    "0x84c87814a1f0ab72",
    "0x8cc702081a6439ec",
    "0x90befffa23631e28",
    "0xa4506cebde82bde9",
    "0xbef9a3f7b2c67915",
    "0xc67178f2e372532b",
    "0xca273eceea26619c",
    "0xd186b8c721c0c207",
    "0xeada7dd6cde0eb1e",
    "0xf57d4f7fee6ed178",
    "0x06f067aa72176fba",
    "0x0a637dc5a2c898a6",
    "0x113f9804bef90dae",
    "0x1b710b35131c471b",
    "0x28db77f523047d84",
    "0x32caab7b40c72493",
    "0x3c9ebe0a15c9bebc",
    "0x431d67c49c100d4c",
    "0x4cc5d4becb3e42b6",
    "0x597f299cfc657e2a",
    "0x5fcb6fab3ad6faec",
    "0x6c44198c4a475817"
].map((t)=>BigInt(t))), Ji = Dr[0], Qi = Dr[1], Rt = new Uint32Array(80), $t = new Uint32Array(80);
class an extends Hr {
    constructor(e = 64){
        super(128, e, 16, !1), this.Ah = X[0] | 0, this.Al = X[1] | 0, this.Bh = X[2] | 0, this.Bl = X[3] | 0, this.Ch = X[4] | 0, this.Cl = X[5] | 0, this.Dh = X[6] | 0, this.Dl = X[7] | 0, this.Eh = X[8] | 0, this.El = X[9] | 0, this.Fh = X[10] | 0, this.Fl = X[11] | 0, this.Gh = X[12] | 0, this.Gl = X[13] | 0, this.Hh = X[14] | 0, this.Hl = X[15] | 0;
    }
    get() {
        const { Ah: e, Al: n, Bh: r, Bl: o, Ch: s, Cl: i, Dh: c, Dl: f, Eh: a, El: l, Fh: u, Fl: h, Gh: m, Gl: p, Hh: d, Hl: I } = this;
        return [
            e,
            n,
            r,
            o,
            s,
            i,
            c,
            f,
            a,
            l,
            u,
            h,
            m,
            p,
            d,
            I
        ];
    }
    set(e, n, r, o, s, i, c, f, a, l, u, h, m, p, d, I) {
        this.Ah = e | 0, this.Al = n | 0, this.Bh = r | 0, this.Bl = o | 0, this.Ch = s | 0, this.Cl = i | 0, this.Dh = c | 0, this.Dl = f | 0, this.Eh = a | 0, this.El = l | 0, this.Fh = u | 0, this.Fl = h | 0, this.Gh = m | 0, this.Gl = p | 0, this.Hh = d | 0, this.Hl = I | 0;
    }
    process(e, n) {
        for(let S = 0; S < 16; S++, n += 4)Rt[S] = e.getUint32(n), $t[S] = e.getUint32(n += 4);
        for(let S = 16; S < 80; S++){
            const g = Rt[S - 15] | 0, x = $t[S - 15] | 0, _ = It(g, x, 1) ^ It(g, x, 8) ^ Ur(g, x, 7), v = St(g, x, 1) ^ St(g, x, 8) ^ _r(g, x, 7), O = Rt[S - 2] | 0, T = $t[S - 2] | 0, R = It(O, T, 19) ^ fe(O, T, 61) ^ Ur(O, T, 6), E = St(O, T, 19) ^ ae(O, T, 61) ^ _r(O, T, 6), N = Ni(v, E, $t[S - 7], $t[S - 16]), B = Ui(N, _, R, Rt[S - 7], Rt[S - 16]);
            Rt[S] = B | 0, $t[S] = N | 0;
        }
        let { Ah: r, Al: o, Bh: s, Bl: i, Ch: c, Cl: f, Dh: a, Dl: l, Eh: u, El: h, Fh: m, Fl: p, Gh: d, Gl: I, Hh: k, Hl: H } = this;
        for(let S = 0; S < 80; S++){
            const g = It(u, h, 14) ^ It(u, h, 18) ^ fe(u, h, 41), x = St(u, h, 14) ^ St(u, h, 18) ^ ae(u, h, 41), _ = u & m ^ ~u & d, v = h & p ^ ~h & I, O = _i(H, x, v, Qi[S], $t[S]), T = Ti(O, k, g, _, Ji[S], Rt[S]), R = O | 0, E = It(r, o, 28) ^ fe(r, o, 34) ^ fe(r, o, 39), N = St(r, o, 28) ^ ae(r, o, 34) ^ ae(r, o, 39), B = r & s ^ r & c ^ s & c, C = o & i ^ o & f ^ i & f;
            k = d | 0, H = I | 0, d = m | 0, I = p | 0, m = u | 0, p = h | 0, ({ h: u, l: h } = dt(a | 0, l | 0, T | 0, R | 0)), a = c | 0, l = f | 0, c = s | 0, f = i | 0, s = r | 0, i = o | 0;
            const b = rn(R, N, C);
            r = on(b, T, E, B), o = b | 0;
        }
        ({ h: r, l: o } = dt(this.Ah | 0, this.Al | 0, r | 0, o | 0)), ({ h: s, l: i } = dt(this.Bh | 0, this.Bl | 0, s | 0, i | 0)), ({ h: c, l: f } = dt(this.Ch | 0, this.Cl | 0, c | 0, f | 0)), ({ h: a, l } = dt(this.Dh | 0, this.Dl | 0, a | 0, l | 0)), ({ h: u, l: h } = dt(this.Eh | 0, this.El | 0, u | 0, h | 0)), ({ h: m, l: p } = dt(this.Fh | 0, this.Fl | 0, m | 0, p | 0)), ({ h: d, l: I } = dt(this.Gh | 0, this.Gl | 0, d | 0, I | 0)), ({ h: k, l: H } = dt(this.Hh | 0, this.Hl | 0, k | 0, H | 0)), this.set(r, o, s, i, c, f, a, l, u, h, m, p, d, I, k, H);
    }
    roundClean() {
        lt(Rt, $t);
    }
    destroy() {
        lt(this.buffer), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
}
class tc extends an {
    constructor(){
        super(48), this.Ah = Y[0] | 0, this.Al = Y[1] | 0, this.Bh = Y[2] | 0, this.Bl = Y[3] | 0, this.Ch = Y[4] | 0, this.Cl = Y[5] | 0, this.Dh = Y[6] | 0, this.Dl = Y[7] | 0, this.Eh = Y[8] | 0, this.El = Y[9] | 0, this.Fh = Y[10] | 0, this.Fl = Y[11] | 0, this.Gh = Y[12] | 0, this.Gl = Y[13] | 0, this.Hh = Y[14] | 0, this.Hl = Y[15] | 0;
    }
}
const J = Uint32Array.from([
    573645204,
    4230739756,
    2673172387,
    3360449730,
    596883563,
    1867755857,
    2520282905,
    1497426621,
    2519219938,
    2827943907,
    3193839141,
    1401305490,
    721525244,
    746961066,
    246885852,
    2177182882
]);
class ec extends an {
    constructor(){
        super(32), this.Ah = J[0] | 0, this.Al = J[1] | 0, this.Bh = J[2] | 0, this.Bl = J[3] | 0, this.Ch = J[4] | 0, this.Cl = J[5] | 0, this.Dh = J[6] | 0, this.Dl = J[7] | 0, this.Eh = J[8] | 0, this.El = J[9] | 0, this.Fh = J[10] | 0, this.Fl = J[11] | 0, this.Gh = J[12] | 0, this.Gl = J[13] | 0, this.Hh = J[14] | 0, this.Hl = J[15] | 0;
    }
}
const _e = le(()=>new Xi), nc = le(()=>new an), rc = le(()=>new tc), oc = le(()=>new ec), sc = Uint8Array.from([
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9,
    12,
    5,
    1,
    15,
    14,
    13,
    4,
    10,
    0,
    7,
    6,
    3,
    9,
    2,
    8,
    11,
    13,
    11,
    7,
    14,
    12,
    1,
    3,
    9,
    5,
    0,
    15,
    4,
    8,
    6,
    2,
    10,
    6,
    15,
    14,
    9,
    11,
    3,
    0,
    8,
    12,
    2,
    13,
    7,
    1,
    4,
    10,
    5,
    10,
    2,
    8,
    4,
    7,
    6,
    1,
    5,
    15,
    11,
    9,
    14,
    3,
    12,
    13,
    0,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    14,
    10,
    4,
    8,
    9,
    15,
    13,
    6,
    1,
    12,
    0,
    2,
    11,
    7,
    5,
    3,
    11,
    8,
    12,
    0,
    5,
    2,
    15,
    13,
    10,
    14,
    3,
    6,
    7,
    1,
    9,
    4,
    7,
    9,
    3,
    1,
    13,
    12,
    11,
    14,
    2,
    6,
    5,
    10,
    4,
    0,
    15,
    8,
    9,
    0,
    5,
    7,
    2,
    4,
    10,
    15,
    14,
    1,
    11,
    12,
    6,
    8,
    3,
    13,
    2,
    12,
    6,
    10,
    0,
    11,
    8,
    3,
    4,
    13,
    7,
    5,
    15,
    14,
    1,
    9
]), K = Uint32Array.from([
    4089235720,
    1779033703,
    2227873595,
    3144134277,
    4271175723,
    1013904242,
    1595750129,
    2773480762,
    2917565137,
    1359893119,
    725511199,
    2600822924,
    4215389547,
    528734635,
    327033209,
    1541459225
]), U = new Uint32Array(32);
function Lt(t, e, n, r, o, s) {
    const i = o[s], c = o[s + 1];
    let f = U[2 * t], a = U[2 * t + 1], l = U[2 * e], u = U[2 * e + 1], h = U[2 * n], m = U[2 * n + 1], p = U[2 * r], d = U[2 * r + 1], I = rn(f, l, i);
    a = on(I, a, u, c), f = I | 0, ({ Dh: d, Dl: p } = {
        Dh: d ^ a,
        Dl: p ^ f
    }), ({ Dh: d, Dl: p } = {
        Dh: Ei(d, p),
        Dl: Ai(d)
    }), ({ h: m, l: h } = dt(m, h, d, p)), ({ Bh: u, Bl: l } = {
        Bh: u ^ m,
        Bl: l ^ h
    }), ({ Bh: u, Bl: l } = {
        Bh: It(u, l, 24),
        Bl: St(u, l, 24)
    }), U[2 * t] = f, U[2 * t + 1] = a, U[2 * e] = l, U[2 * e + 1] = u, U[2 * n] = h, U[2 * n + 1] = m, U[2 * r] = p, U[2 * r + 1] = d;
}
function Ct(t, e, n, r, o, s) {
    const i = o[s], c = o[s + 1];
    let f = U[2 * t], a = U[2 * t + 1], l = U[2 * e], u = U[2 * e + 1], h = U[2 * n], m = U[2 * n + 1], p = U[2 * r], d = U[2 * r + 1], I = rn(f, l, i);
    a = on(I, a, u, c), f = I | 0, ({ Dh: d, Dl: p } = {
        Dh: d ^ a,
        Dl: p ^ f
    }), ({ Dh: d, Dl: p } = {
        Dh: It(d, p, 16),
        Dl: St(d, p, 16)
    }), ({ h: m, l: h } = dt(m, h, d, p)), ({ Bh: u, Bl: l } = {
        Bh: u ^ m,
        Bl: l ^ h
    }), ({ Bh: u, Bl: l } = {
        Bh: fe(u, l, 63),
        Bl: ae(u, l, 63)
    }), U[2 * t] = f, U[2 * t + 1] = a, U[2 * e] = l, U[2 * e + 1] = u, U[2 * n] = h, U[2 * n + 1] = m, U[2 * r] = p, U[2 * r + 1] = d;
}
function ic(t, e = {}, n, r, o) {
    if (yt(n), t < 0 || t > n) throw new Error("outputLen bigger than keyLen");
    const { key: s, salt: i, personalization: c } = e;
    if (s !== void 0 && (s.length < 1 || s.length > n)) throw new Error("key length must be undefined or 1.." + n);
    if (i !== void 0 && i.length !== r) throw new Error("salt must be undefined or " + r);
    if (c !== void 0 && c.length !== o) throw new Error("personalization must be undefined or " + o);
}
class cc extends Ue {
    constructor(e, n){
        super(), this.finished = !1, this.destroyed = !1, this.length = 0, this.pos = 0, yt(e), yt(n), this.blockLen = e, this.outputLen = n, this.buffer = new Uint8Array(e), this.buffer32 = ue(this.buffer);
    }
    update(e) {
        Nt(this), e = ht(e), Ot(e);
        const { blockLen: n, buffer: r, buffer32: o } = this, s = e.length, i = e.byteOffset, c = e.buffer;
        for(let f = 0; f < s;){
            this.pos === n && (Ut(o), this.compress(o, 0, !1), Ut(o), this.pos = 0);
            const a = Math.min(n - this.pos, s - f), l = i + f;
            if (a === n && !(l % 4) && f + a < s) {
                const u = new Uint32Array(c, l, Math.floor((s - f) / 4));
                Ut(u);
                for(let h = 0; f + n < s; h += o.length, f += n)this.length += n, this.compress(u, h, !1);
                Ut(u);
                continue;
            }
            r.set(e.subarray(f, f + a), this.pos), this.pos += a, this.length += a, f += a;
        }
        return this;
    }
    digestInto(e) {
        Nt(this), cn(e, this);
        const { pos: n, buffer32: r } = this;
        this.finished = !0, lt(this.buffer.subarray(n)), Ut(r), this.compress(r, 0, !0), Ut(r);
        const o = ue(e);
        this.get().forEach((s, i)=>o[i] = mt(s));
    }
    digest() {
        const { buffer: e, outputLen: n } = this;
        this.digestInto(e);
        const r = e.slice(0, n);
        return this.destroy(), r;
    }
    _cloneInto(e) {
        const { buffer: n, length: r, finished: o, destroyed: s, outputLen: i, pos: c } = this;
        return e || (e = new this.constructor({
            dkLen: i
        })), e.set(...this.get()), e.buffer.set(n), e.destroyed = s, e.finished = o, e.length = r, e.pos = c, e.outputLen = i, e;
    }
    clone() {
        return this._cloneInto();
    }
}
class fc extends cc {
    constructor(e = {}){
        const n = e.dkLen === void 0 ? 64 : e.dkLen;
        super(128, n), this.v0l = K[0] | 0, this.v0h = K[1] | 0, this.v1l = K[2] | 0, this.v1h = K[3] | 0, this.v2l = K[4] | 0, this.v2h = K[5] | 0, this.v3l = K[6] | 0, this.v3h = K[7] | 0, this.v4l = K[8] | 0, this.v4h = K[9] | 0, this.v5l = K[10] | 0, this.v5h = K[11] | 0, this.v6l = K[12] | 0, this.v6h = K[13] | 0, this.v7l = K[14] | 0, this.v7h = K[15] | 0, ic(n, e, 64, 16, 16);
        let { key: r, personalization: o, salt: s } = e, i = 0;
        if (r !== void 0 && (r = ht(r), i = r.length), this.v0l ^= this.outputLen | i << 8 | 65536 | 1 << 24, s !== void 0) {
            s = ht(s);
            const c = ue(s);
            this.v4l ^= mt(c[0]), this.v4h ^= mt(c[1]), this.v5l ^= mt(c[2]), this.v5h ^= mt(c[3]);
        }
        if (o !== void 0) {
            o = ht(o);
            const c = ue(o);
            this.v6l ^= mt(c[0]), this.v6h ^= mt(c[1]), this.v7l ^= mt(c[2]), this.v7h ^= mt(c[3]);
        }
        if (r !== void 0) {
            const c = new Uint8Array(this.blockLen);
            c.set(r), this.update(c);
        }
    }
    get() {
        let { v0l: e, v0h: n, v1l: r, v1h: o, v2l: s, v2h: i, v3l: c, v3h: f, v4l: a, v4h: l, v5l: u, v5h: h, v6l: m, v6h: p, v7l: d, v7h: I } = this;
        return [
            e,
            n,
            r,
            o,
            s,
            i,
            c,
            f,
            a,
            l,
            u,
            h,
            m,
            p,
            d,
            I
        ];
    }
    set(e, n, r, o, s, i, c, f, a, l, u, h, m, p, d, I) {
        this.v0l = e | 0, this.v0h = n | 0, this.v1l = r | 0, this.v1h = o | 0, this.v2l = s | 0, this.v2h = i | 0, this.v3l = c | 0, this.v3h = f | 0, this.v4l = a | 0, this.v4h = l | 0, this.v5l = u | 0, this.v5h = h | 0, this.v6l = m | 0, this.v6h = p | 0, this.v7l = d | 0, this.v7h = I | 0;
    }
    compress(e, n, r) {
        this.get().forEach((f, a)=>U[a] = f), U.set(K, 16);
        let { h: o, l: s } = Or(BigInt(this.length));
        U[24] = K[8] ^ s, U[25] = K[9] ^ o, r && (U[28] = ~U[28], U[29] = ~U[29]);
        let i = 0;
        const c = sc;
        for(let f = 0; f < 12; f++)Lt(0, 4, 8, 12, e, n + 2 * c[i++]), Ct(0, 4, 8, 12, e, n + 2 * c[i++]), Lt(1, 5, 9, 13, e, n + 2 * c[i++]), Ct(1, 5, 9, 13, e, n + 2 * c[i++]), Lt(2, 6, 10, 14, e, n + 2 * c[i++]), Ct(2, 6, 10, 14, e, n + 2 * c[i++]), Lt(3, 7, 11, 15, e, n + 2 * c[i++]), Ct(3, 7, 11, 15, e, n + 2 * c[i++]), Lt(0, 5, 10, 15, e, n + 2 * c[i++]), Ct(0, 5, 10, 15, e, n + 2 * c[i++]), Lt(1, 6, 11, 12, e, n + 2 * c[i++]), Ct(1, 6, 11, 12, e, n + 2 * c[i++]), Lt(2, 7, 8, 13, e, n + 2 * c[i++]), Ct(2, 7, 8, 13, e, n + 2 * c[i++]), Lt(3, 4, 9, 14, e, n + 2 * c[i++]), Ct(3, 4, 9, 14, e, n + 2 * c[i++]);
        this.v0l ^= U[0] ^ U[16], this.v0h ^= U[1] ^ U[17], this.v1l ^= U[2] ^ U[18], this.v1h ^= U[3] ^ U[19], this.v2l ^= U[4] ^ U[20], this.v2h ^= U[5] ^ U[21], this.v3l ^= U[6] ^ U[22], this.v3h ^= U[7] ^ U[23], this.v4l ^= U[8] ^ U[24], this.v4h ^= U[9] ^ U[25], this.v5l ^= U[10] ^ U[26], this.v5h ^= U[11] ^ U[27], this.v6l ^= U[12] ^ U[28], this.v6h ^= U[13] ^ U[29], this.v7l ^= U[14] ^ U[30], this.v7h ^= U[15] ^ U[31], lt(U);
    }
    destroy() {
        this.destroyed = !0, lt(this.buffer32), this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
}
const ac = ji((t)=>new fc(t)), uc = "https://rpc.walletconnect.org/v1";
function un(t) {
    const e = `Ethereum Signed Message:
${t.length}`, n = new TextEncoder().encode(e + t);
    return "0x" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(zi(n)).toString("hex");
}
async function Mr(t, e, n, r, o, s) {
    switch(n.t){
        case "eip191":
            return await Vr(t, e, n.s);
        case "eip1271":
            return await qr(t, e, n.s, r, o, s);
        default:
            throw new Error(`verifySignature failed: Attempted to verify CacaoSignature with unknown type: ${n.t}`);
    }
}
async function Vr(t, e, n) {
    return (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$signature$2f$recoverAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["recoverAddress"])({
        hash: un(e),
        signature: n
    })).toLowerCase() === t.toLowerCase();
}
async function qr(t, e, n, r, o, s) {
    const i = We(r);
    if (!i.namespace || !i.reference) throw new Error(`isValidEip1271Signature failed: chainId must be in CAIP-2 format, received: ${r}`);
    try {
        const c = "0x1626ba7e", f = "0000000000000000000000000000000000000000000000000000000000000040", a = "0000000000000000000000000000000000000000000000000000000000000041", l = n.substring(2), u = un(e).substring(2), h = c + u + f + a + l, m = await fetch(`${s || uc}/?chainId=${r}&projectId=${o}`, {
            method: "POST",
            body: JSON.stringify({
                id: lc(),
                jsonrpc: "2.0",
                method: "eth_call",
                params: [
                    {
                        to: t,
                        data: h
                    },
                    "latest"
                ]
            })
        }), { result: p } = await m.json();
        return p ? p.slice(0, c.length).toLowerCase() === c.toLowerCase() : !1;
    } catch (c) {
        return console.error("isValidEip1271Signature: ", c), !1;
    }
}
function lc() {
    return Date.now() + Math.floor(Math.random() * 1e3);
}
function dc(t) {
    const e = atob(t), n = new Uint8Array(e.length);
    for(let i = 0; i < e.length; i++)n[i] = e.charCodeAt(i);
    const r = n[0];
    if (r === 0) throw new Error("No signatures found");
    const o = 1 + r * 64;
    if (n.length < o) throw new Error("Transaction data too short for claimed signature count");
    if (n.length < 100) throw new Error("Transaction too short");
    const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t, "base64").slice(1, 65);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].encode(s);
}
function hc(t) {
    const e = new Uint8Array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t, "base64")), n = Array.from("TransactionData::").map((s)=>s.charCodeAt(0)), r = new Uint8Array(n.length + e.length);
    r.set(n), r.set(e, n.length);
    const o = ac(r, {
        dkLen: 32
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].encode(o);
}
function pc(t) {
    const e = new Uint8Array(_e(Kr(t)));
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].encode(e);
}
function Kr(t) {
    if (t instanceof Uint8Array) return t;
    if (Array.isArray(t)) return new Uint8Array(t);
    if (typeof t == "object" && t != null && t.data) return new Uint8Array(Object.values(t.data));
    if (typeof t == "object" && t) return new Uint8Array(Object.values(t));
    throw new Error("getNearUint8ArrayFromBytes: Unexpected result type from bytes array");
}
function gc(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t, "base64"), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$msgpack$2f$msgpack$2f$dist$2e$esm$2f$decode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decode"])(e).txn;
    if (!n) throw new Error("Invalid signed transaction: missing 'txn' field");
    const r = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$msgpack$2f$msgpack$2f$dist$2e$esm$2f$encode$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encode"])(n), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from("TX"), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].concat([
        o,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(r)
    ]), i = oc(s);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$scure$2f$base$2f$lib$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base32"].encode(i).replace(/=+$/, "");
}
function ln(t) {
    const e = [];
    let n = BigInt(t);
    for(; n >= BigInt(128);)e.push(Number(n & BigInt(127) | BigInt(128))), n >>= BigInt(7);
    return e.push(Number(n)), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(e);
}
function bc(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.signed.bodyBytes, "base64"), n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.signed.authInfoBytes, "base64"), r = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.signature.signature, "base64"), o = [];
    o.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from([
        10
    ])), o.push(ln(e.length)), o.push(e), o.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from([
        18
    ])), o.push(ln(n.length)), o.push(n), o.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from([
        26
    ])), o.push(ln(r.length)), o.push(r);
    const s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].concat(o), i = _e(s);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(i).toString("hex").toUpperCase();
}
var yc = Object.defineProperty, mc = Object.defineProperties, wc = Object.getOwnPropertyDescriptors, Fr = Object.getOwnPropertySymbols, xc = Object.prototype.hasOwnProperty, vc = Object.prototype.propertyIsEnumerable, zr = (t, e, n)=>e in t ? yc(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n, dn = (t, e)=>{
    for(var n in e || (e = {}))xc.call(e, n) && zr(t, n, e[n]);
    if (Fr) for (var n of Fr(e))vc.call(e, n) && zr(t, n, e[n]);
    return t;
}, Gr = (t, e)=>mc(t, wc(e));
const Ec = "did:pkh:", Te = (t)=>t?.split(":"), Zr = (t)=>{
    const e = t && Te(t);
    if (e) return t.includes(Ec) ? e[3] : e[1];
}, Wr = (t)=>{
    const e = t && Te(t);
    if (e) return e[2] + ":" + e[3];
}, hn = (t)=>{
    const e = t && Te(t);
    if (e) return e.pop();
};
async function Ac(t) {
    const { cacao: e, projectId: n } = t, { s: r, p: o } = e, s = Yr(o, o.iss), i = hn(o.iss);
    return await Mr(i, s, r, Wr(o.iss), n);
}
const Yr = (t, e)=>{
    const n = `${t.domain} wants you to sign in with your Ethereum account:`, r = hn(e);
    if (!t.aud && !t.uri) throw new Error("Either `aud` or `uri` is required to construct the message");
    let o = t.statement || void 0;
    const s = `URI: ${t.aud || t.uri}`, i = `Version: ${t.version}`, c = `Chain ID: ${Zr(e)}`, f = `Nonce: ${t.nonce}`, a = `Issued At: ${t.iat}`, l = t.exp ? `Expiration Time: ${t.exp}` : void 0, u = t.nbf ? `Not Before: ${t.nbf}` : void 0, h = t.requestId ? `Request ID: ${t.requestId}` : void 0, m = t.resources ? `Resources:${t.resources.map((d)=>`
- ${d}`).join("")}` : void 0, p = $e(t.resources);
    if (p) {
        const d = jt(p);
        o = bn(o, d);
    }
    return [
        n,
        r,
        "",
        o,
        "",
        s,
        i,
        c,
        f,
        a,
        l,
        u,
        h,
        m
    ].filter((d)=>d != null).join(`
`);
};
function Bc(t, e, n) {
    return n.includes("did:pkh:") || (n = `did:pkh:${n}`), {
        h: {
            t: "caip122"
        },
        p: {
            iss: n,
            domain: t.domain,
            aud: t.aud,
            version: t.version,
            nonce: t.nonce,
            iat: t.iat,
            statement: t.statement,
            requestId: t.requestId,
            resources: t.resources,
            nbf: t.nbf,
            exp: t.exp
        },
        s: e
    };
}
function Ic(t) {
    var e;
    const { authPayload: n, chains: r, methods: o } = t, s = n.statement || "";
    if (!(r != null && r.length)) return n;
    const i = n.chains, c = en(i, r);
    if (!(c != null && c.length)) throw new Error("No supported chains");
    const f = Xr(n.resources);
    if (!f) return n;
    bt(f);
    const a = Jr(f, "eip155");
    let l = n?.resources || [];
    if (a != null && a.length) {
        const u = Qr(a), h = en(u, o);
        if (!(h != null && h.length)) throw new Error(`Supported methods don't satisfy the requested: ${JSON.stringify(u)}, supported: ${JSON.stringify(o)}`);
        const m = pn("request", h, {
            chains: c
        }), p = ro(f, "eip155", m);
        l = ((e = n?.resources) == null ? void 0 : e.slice(0, -1)) || [], l.push(Re(p));
    }
    return Gr(dn({}, n), {
        statement: so(s, $e(l)),
        chains: c,
        resources: n != null && n.resources || l.length > 0 ? l : void 0
    });
}
function Xr(t) {
    const e = $e(t);
    if (e && gn(e)) return jt(e);
}
function Sc(t, e) {
    var n;
    return (n = t?.att) == null ? void 0 : n.hasOwnProperty(e);
}
function Jr(t, e) {
    var n, r;
    return (n = t?.att) != null && n[e] ? Object.keys((r = t?.att) == null ? void 0 : r[e]) : [];
}
function Oc(t) {
    return t?.map((e)=>Object.keys(e)) || [];
}
function Qr(t) {
    return t?.map((e)=>{
        var n;
        return (n = e.split("/")) == null ? void 0 : n[1];
    }) || [];
}
function to(t) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(JSON.stringify(t)).toString("base64");
}
function eo(t) {
    return JSON.parse(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t, "base64").toString("utf-8"));
}
function bt(t) {
    if (!t) throw new Error("No recap provided, value is undefined");
    if (!t.att) throw new Error("No `att` property found");
    const e = Object.keys(t.att);
    if (!(e != null && e.length)) throw new Error("No resources found in `att` property");
    e.forEach((n)=>{
        const r = t.att[n];
        if (Array.isArray(r)) throw new Error(`Resource must be an object: ${n}`);
        if (typeof r != "object") throw new Error(`Resource must be an object: ${n}`);
        if (!Object.keys(r).length) throw new Error(`Resource object is empty: ${n}`);
        Object.keys(r).forEach((o)=>{
            const s = r[o];
            if (!Array.isArray(s)) throw new Error(`Ability limits ${o} must be an array of objects, found: ${s}`);
            if (!s.length) throw new Error(`Value of ${o} is empty array, must be an array with objects`);
            s.forEach((i)=>{
                if (typeof i != "object") throw new Error(`Ability limits (${o}) must be an array of objects, found: ${i}`);
            });
        });
    });
}
function no(t, e, n, r = {}) {
    return n?.sort((o, s)=>o.localeCompare(s)), {
        att: {
            [t]: pn(e, n, r)
        }
    };
}
function ro(t, e, n) {
    var r;
    t.att[e] = dn({}, n);
    const o = (r = Object.keys(t.att)) == null ? void 0 : r.sort((i, c)=>i.localeCompare(c)), s = {
        att: {}
    };
    return o.reduce((i, c)=>(i.att[c] = t.att[c], i), s);
}
function pn(t, e, n = {}) {
    e = e?.sort((o, s)=>o.localeCompare(s));
    const r = e.map((o)=>({
            [`${t}/${o}`]: [
                n
            ]
        }));
    return Object.assign({}, ...r);
}
function Re(t) {
    return bt(t), `urn:recap:${to(t).replace(/=/g, "")}`;
}
function jt(t) {
    const e = eo(t.replace("urn:recap:", ""));
    return bt(e), e;
}
function Nc(t, e, n) {
    const r = no(t, e, n);
    return Re(r);
}
function gn(t) {
    return t && t.includes("urn:recap:");
}
function Uc(t, e) {
    const n = jt(t), r = jt(e), o = oo(n, r);
    return Re(o);
}
function oo(t, e) {
    bt(t), bt(e);
    const n = Object.keys(t.att).concat(Object.keys(e.att)).sort((o, s)=>o.localeCompare(s)), r = {
        att: {}
    };
    return n.forEach((o)=>{
        var s, i;
        Object.keys(((s = t.att) == null ? void 0 : s[o]) || {}).concat(Object.keys(((i = e.att) == null ? void 0 : i[o]) || {})).sort((c, f)=>c.localeCompare(f)).forEach((c)=>{
            var f, a;
            r.att[o] = Gr(dn({}, r.att[o]), {
                [c]: ((f = t.att[o]) == null ? void 0 : f[c]) || ((a = e.att[o]) == null ? void 0 : a[c])
            });
        });
    }), r;
}
function bn(t = "", e) {
    bt(e);
    const n = "I further authorize the stated URI to perform the following actions on my behalf: ";
    if (t.includes(n)) return t;
    const r = [];
    let o = 0;
    Object.keys(e.att).forEach((c)=>{
        const f = Object.keys(e.att[c]).map((u)=>({
                ability: u.split("/")[0],
                action: u.split("/")[1]
            }));
        f.sort((u, h)=>u.action.localeCompare(h.action));
        const a = {};
        f.forEach((u)=>{
            a[u.ability] || (a[u.ability] = []), a[u.ability].push(u.action);
        });
        const l = Object.keys(a).map((u)=>(o++, `(${o}) '${u}': '${a[u].join("', '")}' for '${c}'.`));
        r.push(l.join(", ").replace(".,", "."));
    });
    const s = r.join(" "), i = `${n}${s}`;
    return `${t ? t + " " : ""}${i}`;
}
function _c(t) {
    var e;
    const n = jt(t);
    bt(n);
    const r = (e = n.att) == null ? void 0 : e.eip155;
    return r ? Object.keys(r).map((o)=>o.split("/")[1]) : [];
}
function Tc(t) {
    const e = jt(t);
    bt(e);
    const n = [];
    return Object.values(e.att).forEach((r)=>{
        Object.values(r).forEach((o)=>{
            var s;
            (s = o?.[0]) != null && s.chains && n.push(o[0].chains);
        });
    }), [
        ...new Set(n.flat())
    ];
}
function so(t, e) {
    if (!e) return t;
    const n = jt(e);
    return bt(n), bn(t, n);
}
function $e(t) {
    if (!t) return;
    const e = t?.[t.length - 1];
    return gn(e) ? e : void 0;
} /*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */ 
function io(t) {
    return t instanceof Uint8Array || ArrayBuffer.isView(t) && t.constructor.name === "Uint8Array";
}
function yn(t) {
    if (typeof t != "boolean") throw new Error(`boolean expected, not ${t}`);
}
function mn(t) {
    if (!Number.isSafeInteger(t) || t < 0) throw new Error("positive integer expected, got " + t);
}
function nt(t, ...e) {
    if (!io(t)) throw new Error("Uint8Array expected");
    if (e.length > 0 && !e.includes(t.length)) throw new Error("Uint8Array expected of length " + e + ", got length=" + t.length);
}
function co(t, e = !0) {
    if (t.destroyed) throw new Error("Hash instance has been destroyed");
    if (e && t.finished) throw new Error("Hash#digest() has already been called");
}
function Rc(t, e) {
    nt(t);
    const n = e.outputLen;
    if (t.length < n) throw new Error("digestInto() expects output buffer of length at least " + n);
}
function kt(t) {
    return new Uint32Array(t.buffer, t.byteOffset, Math.floor(t.byteLength / 4));
}
function Jt(...t) {
    for(let e = 0; e < t.length; e++)t[e].fill(0);
}
function $c(t) {
    return new DataView(t.buffer, t.byteOffset, t.byteLength);
}
const Lc = new Uint8Array(new Uint32Array([
    287454020
]).buffer)[0] === 68;
function Cc(t) {
    if (typeof t != "string") throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(t));
}
function wn(t) {
    if (typeof t == "string") t = Cc(t);
    else if (io(t)) t = xn(t);
    else throw new Error("Uint8Array expected, got " + typeof t);
    return t;
}
function jc(t, e) {
    if (e == null || typeof e != "object") throw new Error("options must be defined");
    return Object.assign(t, e);
}
function kc(t, e) {
    if (t.length !== e.length) return !1;
    let n = 0;
    for(let r = 0; r < t.length; r++)n |= t[r] ^ e[r];
    return n === 0;
}
const Pc = (t, e)=>{
    function n(r, ...o) {
        if (nt(r), !Lc) throw new Error("Non little-endian hardware is not yet supported");
        if (t.nonceLength !== void 0) {
            const l = o[0];
            if (!l) throw new Error("nonce / iv required");
            t.varSizeNonce ? nt(l) : nt(l, t.nonceLength);
        }
        const s = t.tagLength;
        s && o[1] !== void 0 && nt(o[1]);
        const i = e(r, ...o), c = (l, u)=>{
            if (u !== void 0) {
                if (l !== 2) throw new Error("cipher output not supported");
                nt(u);
            }
        };
        let f = !1;
        return {
            encrypt (l, u) {
                if (f) throw new Error("cannot encrypt() twice with same key + nonce");
                return f = !0, nt(l), c(i.encrypt.length, u), i.encrypt(l, u);
            },
            decrypt (l, u) {
                if (nt(l), s && l.length < s) throw new Error("invalid ciphertext length: smaller than tagLength=" + s);
                return c(i.decrypt.length, u), i.decrypt(l, u);
            }
        };
    }
    return Object.assign(n, t), n;
};
function fo(t, e, n = !0) {
    if (e === void 0) return new Uint8Array(t);
    if (e.length !== t) throw new Error("invalid output length, expected " + t + ", got: " + e.length);
    if (n && !Dc(e)) throw new Error("invalid output, must be aligned");
    return e;
}
function ao(t, e, n, r) {
    if (typeof t.setBigUint64 == "function") return t.setBigUint64(e, n, r);
    const o = BigInt(32), s = BigInt(4294967295), i = Number(n >> o & s), c = Number(n & s), f = r ? 4 : 0, a = r ? 0 : 4;
    t.setUint32(e + f, i, r), t.setUint32(e + a, c, r);
}
function Hc(t, e, n) {
    yn(n);
    const r = new Uint8Array(16), o = $c(r);
    return ao(o, 0, BigInt(e), n), ao(o, 8, BigInt(t), n), r;
}
function Dc(t) {
    return t.byteOffset % 4 === 0;
}
function xn(t) {
    return Uint8Array.from(t);
}
const uo = (t)=>Uint8Array.from(t.split("").map((e)=>e.charCodeAt(0))), Mc = uo("expand 16-byte k"), Vc = uo("expand 32-byte k"), qc = kt(Mc), Kc = kt(Vc);
function D(t, e) {
    return t << e | t >>> 32 - e;
}
function vn(t) {
    return t.byteOffset % 4 === 0;
}
const Le = 64, Fc = 16, lo = 2 ** 32 - 1, ho = new Uint32Array;
function zc(t, e, n, r, o, s, i, c) {
    const f = o.length, a = new Uint8Array(Le), l = kt(a), u = vn(o) && vn(s), h = u ? kt(o) : ho, m = u ? kt(s) : ho;
    for(let p = 0; p < f; i++){
        if (t(e, n, r, l, i, c), i >= lo) throw new Error("arx: counter overflow");
        const d = Math.min(Le, f - p);
        if (u && d === Le) {
            const I = p / 4;
            if (p % 4 !== 0) throw new Error("arx: invalid block position");
            for(let k = 0, H; k < Fc; k++)H = I + k, m[H] = h[H] ^ l[k];
            p += Le;
            continue;
        }
        for(let I = 0, k; I < d; I++)k = p + I, s[k] = o[k] ^ a[I];
        p += d;
    }
}
function Gc(t, e) {
    const { allowShortKeys: n, extendNonceFn: r, counterLength: o, counterRight: s, rounds: i } = jc({
        allowShortKeys: !1,
        counterLength: 8,
        counterRight: !1,
        rounds: 20
    }, e);
    if (typeof t != "function") throw new Error("core must be a function");
    return mn(o), mn(i), yn(s), yn(n), (c, f, a, l, u = 0)=>{
        nt(c), nt(f), nt(a);
        const h = a.length;
        if (l === void 0 && (l = new Uint8Array(h)), nt(l), mn(u), u < 0 || u >= lo) throw new Error("arx: counter overflow");
        if (l.length < h) throw new Error(`arx: output (${l.length}) is shorter than data (${h})`);
        const m = [];
        let p = c.length, d, I;
        if (p === 32) m.push(d = xn(c)), I = Kc;
        else if (p === 16 && n) d = new Uint8Array(32), d.set(c), d.set(c, 16), I = qc, m.push(d);
        else throw new Error(`arx: invalid 32-byte key, got length=${p}`);
        vn(f) || m.push(f = xn(f));
        const k = kt(d);
        if (r) {
            if (f.length !== 24) throw new Error("arx: extended nonce must be 24 bytes");
            r(I, k, kt(f.subarray(0, 16)), k), f = f.subarray(16);
        }
        const H = 16 - o;
        if (H !== f.length) throw new Error(`arx: nonce must be ${H} or 16 bytes`);
        if (H !== 12) {
            const g = new Uint8Array(12);
            g.set(f, s ? 0 : 12 - f.length), f = g, m.push(f);
        }
        const S = kt(f);
        return zc(t, I, k, S, a, l, u, i), Jt(...m), l;
    };
}
const Z = (t, e)=>t[e++] & 255 | (t[e++] & 255) << 8;
class Zc {
    constructor(e){
        this.blockLen = 16, this.outputLen = 16, this.buffer = new Uint8Array(16), this.r = new Uint16Array(10), this.h = new Uint16Array(10), this.pad = new Uint16Array(8), this.pos = 0, this.finished = !1, e = wn(e), nt(e, 32);
        const n = Z(e, 0), r = Z(e, 2), o = Z(e, 4), s = Z(e, 6), i = Z(e, 8), c = Z(e, 10), f = Z(e, 12), a = Z(e, 14);
        this.r[0] = n & 8191, this.r[1] = (n >>> 13 | r << 3) & 8191, this.r[2] = (r >>> 10 | o << 6) & 7939, this.r[3] = (o >>> 7 | s << 9) & 8191, this.r[4] = (s >>> 4 | i << 12) & 255, this.r[5] = i >>> 1 & 8190, this.r[6] = (i >>> 14 | c << 2) & 8191, this.r[7] = (c >>> 11 | f << 5) & 8065, this.r[8] = (f >>> 8 | a << 8) & 8191, this.r[9] = a >>> 5 & 127;
        for(let l = 0; l < 8; l++)this.pad[l] = Z(e, 16 + 2 * l);
    }
    process(e, n, r = !1) {
        const o = r ? 0 : 2048, { h: s, r: i } = this, c = i[0], f = i[1], a = i[2], l = i[3], u = i[4], h = i[5], m = i[6], p = i[7], d = i[8], I = i[9], k = Z(e, n + 0), H = Z(e, n + 2), S = Z(e, n + 4), g = Z(e, n + 6), x = Z(e, n + 8), _ = Z(e, n + 10), v = Z(e, n + 12), O = Z(e, n + 14);
        let T = s[0] + (k & 8191), R = s[1] + ((k >>> 13 | H << 3) & 8191), E = s[2] + ((H >>> 10 | S << 6) & 8191), N = s[3] + ((S >>> 7 | g << 9) & 8191), B = s[4] + ((g >>> 4 | x << 12) & 8191), C = s[5] + (x >>> 1 & 8191), b = s[6] + ((x >>> 14 | _ << 2) & 8191), y = s[7] + ((_ >>> 11 | v << 5) & 8191), A = s[8] + ((v >>> 8 | O << 8) & 8191), $ = s[9] + (O >>> 5 | o), w = 0, L = w + T * c + R * (5 * I) + E * (5 * d) + N * (5 * p) + B * (5 * m);
        w = L >>> 13, L &= 8191, L += C * (5 * h) + b * (5 * u) + y * (5 * l) + A * (5 * a) + $ * (5 * f), w += L >>> 13, L &= 8191;
        let j = w + T * f + R * c + E * (5 * I) + N * (5 * d) + B * (5 * p);
        w = j >>> 13, j &= 8191, j += C * (5 * m) + b * (5 * h) + y * (5 * u) + A * (5 * l) + $ * (5 * a), w += j >>> 13, j &= 8191;
        let P = w + T * a + R * f + E * c + N * (5 * I) + B * (5 * d);
        w = P >>> 13, P &= 8191, P += C * (5 * p) + b * (5 * m) + y * (5 * h) + A * (5 * u) + $ * (5 * l), w += P >>> 13, P &= 8191;
        let V = w + T * l + R * a + E * f + N * c + B * (5 * I);
        w = V >>> 13, V &= 8191, V += C * (5 * d) + b * (5 * p) + y * (5 * m) + A * (5 * h) + $ * (5 * u), w += V >>> 13, V &= 8191;
        let q = w + T * u + R * l + E * a + N * f + B * c;
        w = q >>> 13, q &= 8191, q += C * (5 * I) + b * (5 * d) + y * (5 * p) + A * (5 * m) + $ * (5 * h), w += q >>> 13, q &= 8191;
        let M = w + T * h + R * u + E * l + N * a + B * f;
        w = M >>> 13, M &= 8191, M += C * c + b * (5 * I) + y * (5 * d) + A * (5 * p) + $ * (5 * m), w += M >>> 13, M &= 8191;
        let W = w + T * m + R * h + E * u + N * l + B * a;
        w = W >>> 13, W &= 8191, W += C * f + b * c + y * (5 * I) + A * (5 * d) + $ * (5 * p), w += W >>> 13, W &= 8191;
        let F = w + T * p + R * m + E * h + N * u + B * l;
        w = F >>> 13, F &= 8191, F += C * a + b * f + y * c + A * (5 * I) + $ * (5 * d), w += F >>> 13, F &= 8191;
        let it = w + T * d + R * p + E * m + N * h + B * u;
        w = it >>> 13, it &= 8191, it += C * l + b * a + y * f + A * c + $ * (5 * I), w += it >>> 13, it &= 8191;
        let G = w + T * I + R * d + E * p + N * m + B * h;
        w = G >>> 13, G &= 8191, G += C * u + b * l + y * a + A * f + $ * c, w += G >>> 13, G &= 8191, w = (w << 2) + w | 0, w = w + L | 0, L = w & 8191, w = w >>> 13, j += w, s[0] = L, s[1] = j, s[2] = P, s[3] = V, s[4] = q, s[5] = M, s[6] = W, s[7] = F, s[8] = it, s[9] = G;
    }
    finalize() {
        const { h: e, pad: n } = this, r = new Uint16Array(10);
        let o = e[1] >>> 13;
        e[1] &= 8191;
        for(let c = 2; c < 10; c++)e[c] += o, o = e[c] >>> 13, e[c] &= 8191;
        e[0] += o * 5, o = e[0] >>> 13, e[0] &= 8191, e[1] += o, o = e[1] >>> 13, e[1] &= 8191, e[2] += o, r[0] = e[0] + 5, o = r[0] >>> 13, r[0] &= 8191;
        for(let c = 1; c < 10; c++)r[c] = e[c] + o, o = r[c] >>> 13, r[c] &= 8191;
        r[9] -= 8192;
        let s = (o ^ 1) - 1;
        for(let c = 0; c < 10; c++)r[c] &= s;
        s = ~s;
        for(let c = 0; c < 10; c++)e[c] = e[c] & s | r[c];
        e[0] = (e[0] | e[1] << 13) & 65535, e[1] = (e[1] >>> 3 | e[2] << 10) & 65535, e[2] = (e[2] >>> 6 | e[3] << 7) & 65535, e[3] = (e[3] >>> 9 | e[4] << 4) & 65535, e[4] = (e[4] >>> 12 | e[5] << 1 | e[6] << 14) & 65535, e[5] = (e[6] >>> 2 | e[7] << 11) & 65535, e[6] = (e[7] >>> 5 | e[8] << 8) & 65535, e[7] = (e[8] >>> 8 | e[9] << 5) & 65535;
        let i = e[0] + n[0];
        e[0] = i & 65535;
        for(let c = 1; c < 8; c++)i = (e[c] + n[c] | 0) + (i >>> 16) | 0, e[c] = i & 65535;
        Jt(r);
    }
    update(e) {
        co(this), e = wn(e), nt(e);
        const { buffer: n, blockLen: r } = this, o = e.length;
        for(let s = 0; s < o;){
            const i = Math.min(r - this.pos, o - s);
            if (i === r) {
                for(; r <= o - s; s += r)this.process(e, s);
                continue;
            }
            n.set(e.subarray(s, s + i), this.pos), this.pos += i, s += i, this.pos === r && (this.process(n, 0, !1), this.pos = 0);
        }
        return this;
    }
    destroy() {
        Jt(this.h, this.r, this.buffer, this.pad);
    }
    digestInto(e) {
        co(this), Rc(e, this), this.finished = !0;
        const { buffer: n, h: r } = this;
        let { pos: o } = this;
        if (o) {
            for(n[o++] = 1; o < 16; o++)n[o] = 0;
            this.process(n, 0, !0);
        }
        this.finalize();
        let s = 0;
        for(let i = 0; i < 8; i++)e[s++] = r[i] >>> 0, e[s++] = r[i] >>> 8;
        return e;
    }
    digest() {
        const { buffer: e, outputLen: n } = this;
        this.digestInto(e);
        const r = e.slice(0, n);
        return this.destroy(), r;
    }
}
function Wc(t) {
    const e = (r, o)=>t(o).update(wn(r)).digest(), n = t(new Uint8Array(32));
    return e.outputLen = n.outputLen, e.blockLen = n.blockLen, e.create = (r)=>t(r), e;
}
const Yc = Wc((t)=>new Zc(t));
function Xc(t, e, n, r, o, s = 20) {
    let i = t[0], c = t[1], f = t[2], a = t[3], l = e[0], u = e[1], h = e[2], m = e[3], p = e[4], d = e[5], I = e[6], k = e[7], H = o, S = n[0], g = n[1], x = n[2], _ = i, v = c, O = f, T = a, R = l, E = u, N = h, B = m, C = p, b = d, y = I, A = k, $ = H, w = S, L = g, j = x;
    for(let V = 0; V < s; V += 2)_ = _ + R | 0, $ = D($ ^ _, 16), C = C + $ | 0, R = D(R ^ C, 12), _ = _ + R | 0, $ = D($ ^ _, 8), C = C + $ | 0, R = D(R ^ C, 7), v = v + E | 0, w = D(w ^ v, 16), b = b + w | 0, E = D(E ^ b, 12), v = v + E | 0, w = D(w ^ v, 8), b = b + w | 0, E = D(E ^ b, 7), O = O + N | 0, L = D(L ^ O, 16), y = y + L | 0, N = D(N ^ y, 12), O = O + N | 0, L = D(L ^ O, 8), y = y + L | 0, N = D(N ^ y, 7), T = T + B | 0, j = D(j ^ T, 16), A = A + j | 0, B = D(B ^ A, 12), T = T + B | 0, j = D(j ^ T, 8), A = A + j | 0, B = D(B ^ A, 7), _ = _ + E | 0, j = D(j ^ _, 16), y = y + j | 0, E = D(E ^ y, 12), _ = _ + E | 0, j = D(j ^ _, 8), y = y + j | 0, E = D(E ^ y, 7), v = v + N | 0, $ = D($ ^ v, 16), A = A + $ | 0, N = D(N ^ A, 12), v = v + N | 0, $ = D($ ^ v, 8), A = A + $ | 0, N = D(N ^ A, 7), O = O + B | 0, w = D(w ^ O, 16), C = C + w | 0, B = D(B ^ C, 12), O = O + B | 0, w = D(w ^ O, 8), C = C + w | 0, B = D(B ^ C, 7), T = T + R | 0, L = D(L ^ T, 16), b = b + L | 0, R = D(R ^ b, 12), T = T + R | 0, L = D(L ^ T, 8), b = b + L | 0, R = D(R ^ b, 7);
    let P = 0;
    r[P++] = i + _ | 0, r[P++] = c + v | 0, r[P++] = f + O | 0, r[P++] = a + T | 0, r[P++] = l + R | 0, r[P++] = u + E | 0, r[P++] = h + N | 0, r[P++] = m + B | 0, r[P++] = p + C | 0, r[P++] = d + b | 0, r[P++] = I + y | 0, r[P++] = k + A | 0, r[P++] = H + $ | 0, r[P++] = S + w | 0, r[P++] = g + L | 0, r[P++] = x + j | 0;
}
const Jc = Gc(Xc, {
    counterRight: !1,
    counterLength: 4,
    allowShortKeys: !1
}), Qc = new Uint8Array(16), po = (t, e)=>{
    t.update(e);
    const n = e.length % 16;
    n && t.update(Qc.subarray(n));
}, tf = new Uint8Array(32);
function go(t, e, n, r, o) {
    const s = t(e, n, tf), i = Yc.create(s);
    o && po(i, o), po(i, r);
    const c = Hc(r.length, o ? o.length : 0, !0);
    i.update(c);
    const f = i.digest();
    return Jt(s, c), f;
}
const ef = (t)=>(e, n, r)=>({
            encrypt (s, i) {
                const c = s.length;
                i = fo(c + 16, i, !1), i.set(s);
                const f = i.subarray(0, -16);
                t(e, n, f, f, 1);
                const a = go(t, e, n, f, r);
                return i.set(a, c), Jt(a), i;
            },
            decrypt (s, i) {
                i = fo(s.length - 16, i, !1);
                const c = s.subarray(0, -16), f = s.subarray(-16), a = go(t, e, n, c, r);
                if (!kc(f, a)) throw new Error("invalid tag");
                return i.set(s.subarray(0, -16)), t(e, n, i, i, 1), Jt(a), i;
            }
        }), bo = Pc({
    blockSize: 64,
    nonceLength: 12,
    tagLength: 16
}, ef(Jc));
class yo extends Ue {
    constructor(e, n){
        super(), this.finished = !1, this.destroyed = !1, sn(e);
        const r = ht(n);
        if (this.iHash = e.create(), typeof this.iHash.update != "function") throw new Error("Expected instance of class which extends utils.Hash");
        this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
        const o = this.blockLen, s = new Uint8Array(o);
        s.set(r.length > o ? e.create().update(r).digest() : r);
        for(let i = 0; i < s.length; i++)s[i] ^= 54;
        this.iHash.update(s), this.oHash = e.create();
        for(let i = 0; i < s.length; i++)s[i] ^= 106;
        this.oHash.update(s), lt(s);
    }
    update(e) {
        return Nt(this), this.iHash.update(e), this;
    }
    digestInto(e) {
        Nt(this), Ot(e, this.outputLen), this.finished = !0, this.iHash.digestInto(e), this.oHash.update(e), this.oHash.digestInto(e), this.destroy();
    }
    digest() {
        const e = new Uint8Array(this.oHash.outputLen);
        return this.digestInto(e), e;
    }
    _cloneInto(e) {
        e || (e = Object.create(Object.getPrototypeOf(this), {}));
        const { oHash: n, iHash: r, finished: o, destroyed: s, blockLen: i, outputLen: c } = this;
        return e = e, e.finished = o, e.destroyed = s, e.blockLen = i, e.outputLen = c, e.oHash = n._cloneInto(e.oHash), e.iHash = r._cloneInto(e.iHash), e;
    }
    clone() {
        return this._cloneInto();
    }
    destroy() {
        this.destroyed = !0, this.oHash.destroy(), this.iHash.destroy();
    }
}
const Ce = (t, e, n)=>new yo(t, e).update(n).digest();
Ce.create = (t, e)=>new yo(t, e);
function nf(t, e, n) {
    return sn(t), n === void 0 && (n = new Uint8Array(t.outputLen)), Ce(t, ht(n), ht(e));
}
const En = Uint8Array.from([
    0
]), mo = Uint8Array.of();
function rf(t, e, n, r = 32) {
    sn(t), yt(r);
    const o = t.outputLen;
    if (r > 255 * o) throw new Error("Length should be <= 255*HashLen");
    const s = Math.ceil(r / o);
    n === void 0 && (n = mo);
    const i = new Uint8Array(s * o), c = Ce.create(t, e), f = c._cloneInto(), a = new Uint8Array(c.outputLen);
    for(let l = 0; l < s; l++)En[0] = l + 1, f.update(l === 0 ? mo : a).update(n).update(En).digestInto(a), i.set(a, o * l), c._cloneInto(f);
    return c.destroy(), f.destroy(), lt(a, En), i.slice(0, r);
}
const of = (t, e, n, r, o)=>rf(t, nf(t, e, n), r, o), je = _e; /*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */ 
const An = BigInt(0), Bn = BigInt(1);
function he(t) {
    return t instanceof Uint8Array || ArrayBuffer.isView(t) && t.constructor.name === "Uint8Array";
}
function In(t) {
    if (!he(t)) throw new Error("Uint8Array expected");
}
function pe(t, e) {
    if (typeof e != "boolean") throw new Error(t + " boolean expected, got " + e);
}
function ke(t) {
    const e = t.toString(16);
    return e.length & 1 ? "0" + e : e;
}
function wo(t) {
    if (typeof t != "string") throw new Error("hex string expected, got " + typeof t);
    return t === "" ? An : BigInt("0x" + t);
}
const xo = typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", sf = Array.from({
    length: 256
}, (t, e)=>e.toString(16).padStart(2, "0"));
function ge(t) {
    if (In(t), xo) return t.toHex();
    let e = "";
    for(let n = 0; n < t.length; n++)e += sf[t[n]];
    return e;
}
const wt = {
    _0: 48,
    _9: 57,
    A: 65,
    F: 70,
    a: 97,
    f: 102
};
function vo(t) {
    if (t >= wt._0 && t <= wt._9) return t - wt._0;
    if (t >= wt.A && t <= wt.F) return t - (wt.A - 10);
    if (t >= wt.a && t <= wt.f) return t - (wt.a - 10);
}
function Pe(t) {
    if (typeof t != "string") throw new Error("hex string expected, got " + typeof t);
    if (xo) return Uint8Array.fromHex(t);
    const e = t.length, n = e / 2;
    if (e % 2) throw new Error("hex string expected, got unpadded hex of length " + e);
    const r = new Uint8Array(n);
    for(let o = 0, s = 0; o < n; o++, s += 2){
        const i = vo(t.charCodeAt(s)), c = vo(t.charCodeAt(s + 1));
        if (i === void 0 || c === void 0) {
            const f = t[s] + t[s + 1];
            throw new Error('hex string expected, got non-hex character "' + f + '" at index ' + s);
        }
        r[o] = i * 16 + c;
    }
    return r;
}
function Vt(t) {
    return wo(ge(t));
}
function He(t) {
    return In(t), wo(ge(Uint8Array.from(t).reverse()));
}
function be(t, e) {
    return Pe(t.toString(16).padStart(e * 2, "0"));
}
function Sn(t, e) {
    return be(t, e).reverse();
}
function rt(t, e, n) {
    let r;
    if (typeof e == "string") try {
        r = Pe(e);
    } catch (s) {
        throw new Error(t + " must be hex string or Uint8Array, cause: " + s);
    }
    else if (he(e)) r = Uint8Array.from(e);
    else throw new Error(t + " must be hex string or Uint8Array");
    const o = r.length;
    if (typeof n == "number" && o !== n) throw new Error(t + " of length " + n + " expected, got " + o);
    return r;
}
function De(...t) {
    let e = 0;
    for(let r = 0; r < t.length; r++){
        const o = t[r];
        In(o), e += o.length;
    }
    const n = new Uint8Array(e);
    for(let r = 0, o = 0; r < t.length; r++){
        const s = t[r];
        n.set(s, o), o += s.length;
    }
    return n;
}
const On = (t)=>typeof t == "bigint" && An <= t;
function Nn(t, e, n) {
    return On(t) && On(e) && On(n) && e <= t && t < n;
}
function Pt(t, e, n, r) {
    if (!Nn(e, n, r)) throw new Error("expected valid " + t + ": " + n + " <= n < " + r + ", got " + e);
}
function cf(t) {
    let e;
    for(e = 0; t > An; t >>= Bn, e += 1);
    return e;
}
const Me = (t)=>(Bn << BigInt(t)) - Bn, Un = (t)=>new Uint8Array(t), Eo = (t)=>Uint8Array.from(t);
function ff(t, e, n) {
    if (typeof t != "number" || t < 2) throw new Error("hashLen must be a number");
    if (typeof e != "number" || e < 2) throw new Error("qByteLen must be a number");
    if (typeof n != "function") throw new Error("hmacFn must be a function");
    let r = Un(t), o = Un(t), s = 0;
    const i = ()=>{
        r.fill(1), o.fill(0), s = 0;
    }, c = (...u)=>n(o, r, ...u), f = (u = Un(0))=>{
        o = c(Eo([
            0
        ]), u), r = c(), u.length !== 0 && (o = c(Eo([
            1
        ]), u), r = c());
    }, a = ()=>{
        if (s++ >= 1e3) throw new Error("drbg: tried 1000 values");
        let u = 0;
        const h = [];
        for(; u < e;){
            r = c();
            const m = r.slice();
            h.push(m), u += r.length;
        }
        return De(...h);
    };
    return (u, h)=>{
        i(), f(u);
        let m;
        for(; !(m = h(a()));)f();
        return i(), m;
    };
}
const af = {
    bigint: (t)=>typeof t == "bigint",
    function: (t)=>typeof t == "function",
    boolean: (t)=>typeof t == "boolean",
    string: (t)=>typeof t == "string",
    stringOrUint8Array: (t)=>typeof t == "string" || he(t),
    isSafeInteger: (t)=>Number.isSafeInteger(t),
    array: (t)=>Array.isArray(t),
    field: (t, e)=>e.Fp.isValid(t),
    hash: (t)=>typeof t == "function" && Number.isSafeInteger(t.outputLen)
};
function ye(t, e, n = {}) {
    const r = (o, s, i)=>{
        const c = af[s];
        if (typeof c != "function") throw new Error("invalid validator function");
        const f = t[o];
        if (!(i && f === void 0) && !c(f, t)) throw new Error("param " + String(o) + " is invalid. Expected " + s + ", got " + f);
    };
    for (const [o, s] of Object.entries(e))r(o, s, !1);
    for (const [o, s] of Object.entries(n))r(o, s, !0);
    return t;
}
function Ao(t) {
    const e = new WeakMap;
    return (n, ...r)=>{
        const o = e.get(n);
        if (o !== void 0) return o;
        const s = t(n, ...r);
        return e.set(n, s), s;
    };
}
const ot = BigInt(0), tt = BigInt(1), qt = BigInt(2), uf = BigInt(3), Bo = BigInt(4), Io = BigInt(5), So = BigInt(8);
function st(t, e) {
    const n = t % e;
    return n >= ot ? n : e + n;
}
function pt(t, e, n) {
    let r = t;
    for(; e-- > ot;)r *= r, r %= n;
    return r;
}
function _n(t, e) {
    if (t === ot) throw new Error("invert: expected non-zero number");
    if (e <= ot) throw new Error("invert: expected positive modulus, got " + e);
    let n = st(t, e), r = e, o = ot, s = tt;
    for(; n !== ot;){
        const c = r / n, f = r % n, a = o - s * c;
        r = n, n = f, o = s, s = a;
    }
    if (r !== tt) throw new Error("invert: does not exist");
    return st(o, e);
}
function Oo(t, e) {
    const n = (t.ORDER + tt) / Bo, r = t.pow(e, n);
    if (!t.eql(t.sqr(r), e)) throw new Error("Cannot find square root");
    return r;
}
function lf(t, e) {
    const n = (t.ORDER - Io) / So, r = t.mul(e, qt), o = t.pow(r, n), s = t.mul(e, o), i = t.mul(t.mul(s, qt), o), c = t.mul(s, t.sub(i, t.ONE));
    if (!t.eql(t.sqr(c), e)) throw new Error("Cannot find square root");
    return c;
}
function df(t) {
    if (t < BigInt(3)) throw new Error("sqrt is not defined for small field");
    let e = t - tt, n = 0;
    for(; e % qt === ot;)e /= qt, n++;
    let r = qt;
    const o = me(t);
    for(; Uo(o, r) === 1;)if (r++ > 1e3) throw new Error("Cannot find square root: probably non-prime P");
    if (n === 1) return Oo;
    let s = o.pow(r, e);
    const i = (e + tt) / qt;
    return function(f, a) {
        if (f.is0(a)) return a;
        if (Uo(f, a) !== 1) throw new Error("Cannot find square root");
        let l = n, u = f.mul(f.ONE, s), h = f.pow(a, e), m = f.pow(a, i);
        for(; !f.eql(h, f.ONE);){
            if (f.is0(h)) return f.ZERO;
            let p = 1, d = f.sqr(h);
            for(; !f.eql(d, f.ONE);)if (p++, d = f.sqr(d), p === l) throw new Error("Cannot find square root");
            const I = tt << BigInt(l - p - 1), k = f.pow(u, I);
            l = p, u = f.sqr(k), h = f.mul(h, u), m = f.mul(m, k);
        }
        return m;
    };
}
function hf(t) {
    return t % Bo === uf ? Oo : t % So === Io ? lf : df(t);
}
const pf = [
    "create",
    "isValid",
    "is0",
    "neg",
    "inv",
    "sqrt",
    "sqr",
    "eql",
    "add",
    "sub",
    "mul",
    "pow",
    "div",
    "addN",
    "subN",
    "mulN",
    "sqrN"
];
function gf(t) {
    const e = {
        ORDER: "bigint",
        MASK: "bigint",
        BYTES: "isSafeInteger",
        BITS: "isSafeInteger"
    }, n = pf.reduce((r, o)=>(r[o] = "function", r), e);
    return ye(t, n);
}
function bf(t, e, n) {
    if (n < ot) throw new Error("invalid exponent, negatives unsupported");
    if (n === ot) return t.ONE;
    if (n === tt) return e;
    let r = t.ONE, o = e;
    for(; n > ot;)n & tt && (r = t.mul(r, o)), o = t.sqr(o), n >>= tt;
    return r;
}
function No(t, e, n = !1) {
    const r = new Array(e.length).fill(n ? t.ZERO : void 0), o = e.reduce((i, c, f)=>t.is0(c) ? i : (r[f] = i, t.mul(i, c)), t.ONE), s = t.inv(o);
    return e.reduceRight((i, c, f)=>t.is0(c) ? i : (r[f] = t.mul(i, r[f]), t.mul(i, c)), s), r;
}
function Uo(t, e) {
    const n = (t.ORDER - tt) / qt, r = t.pow(e, n), o = t.eql(r, t.ONE), s = t.eql(r, t.ZERO), i = t.eql(r, t.neg(t.ONE));
    if (!o && !s && !i) throw new Error("invalid Legendre symbol result");
    return o ? 1 : s ? 0 : -1;
}
function _o(t, e) {
    e !== void 0 && yt(e);
    const n = e !== void 0 ? e : t.toString(2).length, r = Math.ceil(n / 8);
    return {
        nBitLength: n,
        nByteLength: r
    };
}
function me(t, e, n = !1, r = {}) {
    if (t <= ot) throw new Error("invalid field: expected ORDER > 0, got " + t);
    const { nBitLength: o, nByteLength: s } = _o(t, e);
    if (s > 2048) throw new Error("invalid field: expected ORDER of <= 2048 bytes");
    let i;
    const c = Object.freeze({
        ORDER: t,
        isLE: n,
        BITS: o,
        BYTES: s,
        MASK: Me(o),
        ZERO: ot,
        ONE: tt,
        create: (f)=>st(f, t),
        isValid: (f)=>{
            if (typeof f != "bigint") throw new Error("invalid field element: expected bigint, got " + typeof f);
            return ot <= f && f < t;
        },
        is0: (f)=>f === ot,
        isOdd: (f)=>(f & tt) === tt,
        neg: (f)=>st(-f, t),
        eql: (f, a)=>f === a,
        sqr: (f)=>st(f * f, t),
        add: (f, a)=>st(f + a, t),
        sub: (f, a)=>st(f - a, t),
        mul: (f, a)=>st(f * a, t),
        pow: (f, a)=>bf(c, f, a),
        div: (f, a)=>st(f * _n(a, t), t),
        sqrN: (f)=>f * f,
        addN: (f, a)=>f + a,
        subN: (f, a)=>f - a,
        mulN: (f, a)=>f * a,
        inv: (f)=>_n(f, t),
        sqrt: r.sqrt || ((f)=>(i || (i = hf(t)), i(c, f))),
        toBytes: (f)=>n ? Sn(f, s) : be(f, s),
        fromBytes: (f)=>{
            if (f.length !== s) throw new Error("Field.fromBytes: expected " + s + " bytes, got " + f.length);
            return n ? He(f) : Vt(f);
        },
        invertBatch: (f)=>No(c, f),
        cmov: (f, a, l)=>l ? a : f
    });
    return Object.freeze(c);
}
function To(t) {
    if (typeof t != "bigint") throw new Error("field order must be bigint");
    const e = t.toString(2).length;
    return Math.ceil(e / 8);
}
function Ro(t) {
    const e = To(t);
    return e + Math.ceil(e / 2);
}
function yf(t, e, n = !1) {
    const r = t.length, o = To(e), s = Ro(e);
    if (r < 16 || r < s || r > 1024) throw new Error("expected " + s + "-1024 bytes of input, got " + r);
    const i = n ? He(t) : Vt(t), c = st(i, e - tt) + tt;
    return n ? Sn(c, o) : be(c, o);
}
const $o = BigInt(0), Tn = BigInt(1);
function Rn(t, e) {
    const n = e.negate();
    return t ? n : e;
}
function Lo(t, e) {
    if (!Number.isSafeInteger(t) || t <= 0 || t > e) throw new Error("invalid window size, expected [1.." + e + "], got W=" + t);
}
function $n(t, e) {
    Lo(t, e);
    const n = Math.ceil(e / t) + 1, r = 2 ** (t - 1), o = 2 ** t, s = Me(t), i = BigInt(t);
    return {
        windows: n,
        windowSize: r,
        mask: s,
        maxNumber: o,
        shiftBy: i
    };
}
function Co(t, e, n) {
    const { windowSize: r, mask: o, maxNumber: s, shiftBy: i } = n;
    let c = Number(t & o), f = t >> i;
    c > r && (c -= s, f += Tn);
    const a = e * r, l = a + Math.abs(c) - 1, u = c === 0, h = c < 0, m = e % 2 !== 0;
    return {
        nextN: f,
        offset: l,
        isZero: u,
        isNeg: h,
        isNegF: m,
        offsetF: a
    };
}
function mf(t, e) {
    if (!Array.isArray(t)) throw new Error("array expected");
    t.forEach((n, r)=>{
        if (!(n instanceof e)) throw new Error("invalid point at index " + r);
    });
}
function wf(t, e) {
    if (!Array.isArray(t)) throw new Error("array of scalars expected");
    t.forEach((n, r)=>{
        if (!e.isValid(n)) throw new Error("invalid scalar at index " + r);
    });
}
const Ln = new WeakMap, jo = new WeakMap;
function Cn(t) {
    return jo.get(t) || 1;
}
function xf(t, e) {
    return {
        constTimeNegate: Rn,
        hasPrecomputes (n) {
            return Cn(n) !== 1;
        },
        unsafeLadder (n, r, o = t.ZERO) {
            let s = n;
            for(; r > $o;)r & Tn && (o = o.add(s)), s = s.double(), r >>= Tn;
            return o;
        },
        precomputeWindow (n, r) {
            const { windows: o, windowSize: s } = $n(r, e), i = [];
            let c = n, f = c;
            for(let a = 0; a < o; a++){
                f = c, i.push(f);
                for(let l = 1; l < s; l++)f = f.add(c), i.push(f);
                c = f.double();
            }
            return i;
        },
        wNAF (n, r, o) {
            let s = t.ZERO, i = t.BASE;
            const c = $n(n, e);
            for(let f = 0; f < c.windows; f++){
                const { nextN: a, offset: l, isZero: u, isNeg: h, isNegF: m, offsetF: p } = Co(o, f, c);
                o = a, u ? i = i.add(Rn(m, r[p])) : s = s.add(Rn(h, r[l]));
            }
            return {
                p: s,
                f: i
            };
        },
        wNAFUnsafe (n, r, o, s = t.ZERO) {
            const i = $n(n, e);
            for(let c = 0; c < i.windows && o !== $o; c++){
                const { nextN: f, offset: a, isZero: l, isNeg: u } = Co(o, c, i);
                if (o = f, !l) {
                    const h = r[a];
                    s = s.add(u ? h.negate() : h);
                }
            }
            return s;
        },
        getPrecomputes (n, r, o) {
            let s = Ln.get(r);
            return s || (s = this.precomputeWindow(r, n), n !== 1 && Ln.set(r, o(s))), s;
        },
        wNAFCached (n, r, o) {
            const s = Cn(n);
            return this.wNAF(s, this.getPrecomputes(s, n, o), r);
        },
        wNAFCachedUnsafe (n, r, o, s) {
            const i = Cn(n);
            return i === 1 ? this.unsafeLadder(n, r, s) : this.wNAFUnsafe(i, this.getPrecomputes(i, n, o), r, s);
        },
        setWindowSize (n, r) {
            Lo(r, e), jo.set(n, r), Ln.delete(n);
        }
    };
}
function vf(t, e, n, r) {
    mf(n, t), wf(r, e);
    const o = n.length, s = r.length;
    if (o !== s) throw new Error("arrays of points and scalars must have equal length");
    const i = t.ZERO, c = cf(BigInt(o));
    let f = 1;
    c > 12 ? f = c - 3 : c > 4 ? f = c - 2 : c > 0 && (f = 2);
    const a = Me(f), l = new Array(Number(a) + 1).fill(i), u = Math.floor((e.BITS - 1) / f) * f;
    let h = i;
    for(let m = u; m >= 0; m -= f){
        l.fill(i);
        for(let d = 0; d < s; d++){
            const I = r[d], k = Number(I >> BigInt(m) & a);
            l[k] = l[k].add(n[d]);
        }
        let p = i;
        for(let d = l.length - 1, I = i; d > 0; d--)I = I.add(l[d]), p = p.add(I);
        if (h = h.add(p), m !== 0) for(let d = 0; d < f; d++)h = h.double();
    }
    return h;
}
function ko(t) {
    return gf(t.Fp), ye(t, {
        n: "bigint",
        h: "bigint",
        Gx: "field",
        Gy: "field"
    }, {
        nBitLength: "isSafeInteger",
        nByteLength: "isSafeInteger"
    }), Object.freeze({
        ..._o(t.n, t.nBitLength),
        ...t,
        p: t.Fp.ORDER
    });
}
BigInt(0), BigInt(1), BigInt(2), BigInt(8);
const we = BigInt(0), Qt = BigInt(1), Ve = BigInt(2);
function Ef(t) {
    return ye(t, {
        adjustScalarBytes: "function",
        powPminus2: "function"
    }), Object.freeze({
        ...t
    });
}
function Af(t) {
    const e = Ef(t), { P: n, type: r, adjustScalarBytes: o, powPminus2: s } = e, i = r === "x25519";
    if (!i && r !== "x448") throw new Error("invalid type");
    const c = i ? 255 : 448, f = i ? 32 : 56, a = BigInt(i ? 9 : 5), l = BigInt(i ? 121665 : 39081), u = i ? Ve ** BigInt(254) : Ve ** BigInt(447), h = i ? BigInt(8) * Ve ** BigInt(251) - Qt : BigInt(4) * Ve ** BigInt(445) - Qt, m = u + h + Qt, p = (v)=>st(v, n), d = I(a);
    function I(v) {
        return Sn(p(v), f);
    }
    function k(v) {
        const O = rt("u coordinate", v, f);
        return i && (O[31] &= 127), p(He(O));
    }
    function H(v) {
        return He(o(rt("scalar", v, f)));
    }
    function S(v, O) {
        const T = _(k(O), H(v));
        if (T === we) throw new Error("invalid private or public key received");
        return I(T);
    }
    function g(v) {
        return S(v, d);
    }
    function x(v, O, T) {
        const R = p(v * (O - T));
        return O = p(O - R), T = p(T + R), {
            x_2: O,
            x_3: T
        };
    }
    function _(v, O) {
        Pt("u", v, we, n), Pt("scalar", O, u, m);
        const T = O, R = v;
        let E = Qt, N = we, B = v, C = Qt, b = we;
        for(let A = BigInt(c - 1); A >= we; A--){
            const $ = T >> A & Qt;
            b ^= $, ({ x_2: E, x_3: B } = x(b, E, B)), ({ x_2: N, x_3: C } = x(b, N, C)), b = $;
            const w = E + N, L = p(w * w), j = E - N, P = p(j * j), V = L - P, q = B + C, M = B - C, W = p(M * w), F = p(q * j), it = W + F, G = W - F;
            B = p(it * it), C = p(R * p(G * G)), E = p(L * P), N = p(V * (L + p(l * V)));
        }
        ({ x_2: E, x_3: B } = x(b, E, B)), { x_2: N, x_3: C } = x(b, N, C);
        const y = s(N);
        return p(E * y);
    }
    return {
        scalarMult: S,
        scalarMultBase: g,
        getSharedSecret: (v, O)=>S(v, O),
        getPublicKey: (v)=>g(v),
        utils: {
            randomPrivateKey: ()=>e.randomBytes(f)
        },
        GuBytes: d.slice()
    };
}
const jn = BigInt("57896044618658097711785492504343953926634992332820282019728792003956564819949");
BigInt(0);
const Bf = BigInt(1), Po = BigInt(2), If = BigInt(3), Sf = BigInt(5);
BigInt(8);
function Of(t) {
    const e = BigInt(10), n = BigInt(20), r = BigInt(40), o = BigInt(80), s = jn, c = t * t % s * t % s, f = pt(c, Po, s) * c % s, a = pt(f, Bf, s) * t % s, l = pt(a, Sf, s) * a % s, u = pt(l, e, s) * l % s, h = pt(u, n, s) * u % s, m = pt(h, r, s) * h % s, p = pt(m, o, s) * m % s, d = pt(p, o, s) * m % s, I = pt(d, e, s) * l % s;
    return {
        pow_p_5_8: pt(I, Po, s) * t % s,
        b2: c
    };
}
function Nf(t) {
    return t[0] &= 248, t[31] &= 127, t[31] |= 64, t;
}
const kn = Af({
    P: jn,
    type: "x25519",
    powPminus2: (t)=>{
        const e = jn, { pow_p_5_8: n, b2: r } = Of(t);
        return st(pt(n, If, e) * r, e);
    },
    adjustScalarBytes: Nf,
    randomBytes: Xt
});
function Ho(t) {
    t.lowS !== void 0 && pe("lowS", t.lowS), t.prehash !== void 0 && pe("prehash", t.prehash);
}
function Uf(t) {
    const e = ko(t);
    ye(e, {
        a: "field",
        b: "field"
    }, {
        allowInfinityPoint: "boolean",
        allowedPrivateKeyLengths: "array",
        clearCofactor: "function",
        fromBytes: "function",
        isTorsionFree: "function",
        toBytes: "function",
        wrapPrivateKey: "boolean"
    });
    const { endo: n, Fp: r, a: o } = e;
    if (n) {
        if (!r.eql(o, r.ZERO)) throw new Error("invalid endo: CURVE.a must be 0");
        if (typeof n != "object" || typeof n.beta != "bigint" || typeof n.splitScalar != "function") throw new Error('invalid endo: expected "beta": bigint and "splitScalar": function');
    }
    return Object.freeze({
        ...e
    });
}
class _f extends Error {
    constructor(e = ""){
        super(e);
    }
}
const xt = {
    Err: _f,
    _tlv: {
        encode: (t, e)=>{
            const { Err: n } = xt;
            if (t < 0 || t > 256) throw new n("tlv.encode: wrong tag");
            if (e.length & 1) throw new n("tlv.encode: unpadded data");
            const r = e.length / 2, o = ke(r);
            if (o.length / 2 & 128) throw new n("tlv.encode: long form length too big");
            const s = r > 127 ? ke(o.length / 2 | 128) : "";
            return ke(t) + s + o + e;
        },
        decode (t, e) {
            const { Err: n } = xt;
            let r = 0;
            if (t < 0 || t > 256) throw new n("tlv.encode: wrong tag");
            if (e.length < 2 || e[r++] !== t) throw new n("tlv.decode: wrong tlv");
            const o = e[r++], s = !!(o & 128);
            let i = 0;
            if (!s) i = o;
            else {
                const f = o & 127;
                if (!f) throw new n("tlv.decode(long): indefinite length not supported");
                if (f > 4) throw new n("tlv.decode(long): byte length is too big");
                const a = e.subarray(r, r + f);
                if (a.length !== f) throw new n("tlv.decode: length bytes not complete");
                if (a[0] === 0) throw new n("tlv.decode(long): zero leftmost byte");
                for (const l of a)i = i << 8 | l;
                if (r += f, i < 128) throw new n("tlv.decode(long): not minimal encoding");
            }
            const c = e.subarray(r, r + i);
            if (c.length !== i) throw new n("tlv.decode: wrong value length");
            return {
                v: c,
                l: e.subarray(r + i)
            };
        }
    },
    _int: {
        encode (t) {
            const { Err: e } = xt;
            if (t < vt) throw new e("integer: negative integers are not allowed");
            let n = ke(t);
            if (Number.parseInt(n[0], 16) & 8 && (n = "00" + n), n.length & 1) throw new e("unexpected DER parsing assertion: unpadded hex");
            return n;
        },
        decode (t) {
            const { Err: e } = xt;
            if (t[0] & 128) throw new e("invalid signature integer: negative");
            if (t[0] === 0 && !(t[1] & 128)) throw new e("invalid signature integer: unnecessary leading zero");
            return Vt(t);
        }
    },
    toSig (t) {
        const { Err: e, _int: n, _tlv: r } = xt, o = rt("signature", t), { v: s, l: i } = r.decode(48, o);
        if (i.length) throw new e("invalid signature: left bytes after parsing");
        const { v: c, l: f } = r.decode(2, s), { v: a, l } = r.decode(2, f);
        if (l.length) throw new e("invalid signature: left bytes after parsing");
        return {
            r: n.decode(c),
            s: n.decode(a)
        };
    },
    hexFromSig (t) {
        const { _tlv: e, _int: n } = xt, r = e.encode(2, n.encode(t.r)), o = e.encode(2, n.encode(t.s)), s = r + o;
        return e.encode(48, s);
    }
};
function Pn(t, e) {
    return ge(be(t, e));
}
const vt = BigInt(0), z = BigInt(1);
BigInt(2);
const Hn = BigInt(3), Tf = BigInt(4);
function Rf(t) {
    const e = Uf(t), { Fp: n } = e, r = me(e.n, e.nBitLength), o = e.toBytes || ((S, g, x)=>{
        const _ = g.toAffine();
        return De(Uint8Array.from([
            4
        ]), n.toBytes(_.x), n.toBytes(_.y));
    }), s = e.fromBytes || ((S)=>{
        const g = S.subarray(1), x = n.fromBytes(g.subarray(0, n.BYTES)), _ = n.fromBytes(g.subarray(n.BYTES, 2 * n.BYTES));
        return {
            x,
            y: _
        };
    });
    function i(S) {
        const { a: g, b: x } = e, _ = n.sqr(S), v = n.mul(_, S);
        return n.add(n.add(v, n.mul(S, g)), x);
    }
    function c(S, g) {
        const x = n.sqr(g), _ = i(S);
        return n.eql(x, _);
    }
    if (!c(e.Gx, e.Gy)) throw new Error("bad curve params: generator point");
    const f = n.mul(n.pow(e.a, Hn), Tf), a = n.mul(n.sqr(e.b), BigInt(27));
    if (n.is0(n.add(f, a))) throw new Error("bad curve params: a or b");
    function l(S) {
        return Nn(S, z, e.n);
    }
    function u(S) {
        const { allowedPrivateKeyLengths: g, nByteLength: x, wrapPrivateKey: _, n: v } = e;
        if (g && typeof S != "bigint") {
            if (he(S) && (S = ge(S)), typeof S != "string" || !g.includes(S.length)) throw new Error("invalid private key");
            S = S.padStart(x * 2, "0");
        }
        let O;
        try {
            O = typeof S == "bigint" ? S : Vt(rt("private key", S, x));
        } catch  {
            throw new Error("invalid private key, expected hex or " + x + " bytes, got " + typeof S);
        }
        return _ && (O = st(O, v)), Pt("private key", O, z, v), O;
    }
    function h(S) {
        if (!(S instanceof d)) throw new Error("ProjectivePoint expected");
    }
    const m = Ao((S, g)=>{
        const { px: x, py: _, pz: v } = S;
        if (n.eql(v, n.ONE)) return {
            x,
            y: _
        };
        const O = S.is0();
        g == null && (g = O ? n.ONE : n.inv(v));
        const T = n.mul(x, g), R = n.mul(_, g), E = n.mul(v, g);
        if (O) return {
            x: n.ZERO,
            y: n.ZERO
        };
        if (!n.eql(E, n.ONE)) throw new Error("invZ was invalid");
        return {
            x: T,
            y: R
        };
    }), p = Ao((S)=>{
        if (S.is0()) {
            if (e.allowInfinityPoint && !n.is0(S.py)) return;
            throw new Error("bad point: ZERO");
        }
        const { x: g, y: x } = S.toAffine();
        if (!n.isValid(g) || !n.isValid(x)) throw new Error("bad point: x or y not FE");
        if (!c(g, x)) throw new Error("bad point: equation left != right");
        if (!S.isTorsionFree()) throw new Error("bad point: not in prime-order subgroup");
        return !0;
    });
    class d {
        constructor(g, x, _){
            if (g == null || !n.isValid(g)) throw new Error("x required");
            if (x == null || !n.isValid(x) || n.is0(x)) throw new Error("y required");
            if (_ == null || !n.isValid(_)) throw new Error("z required");
            this.px = g, this.py = x, this.pz = _, Object.freeze(this);
        }
        static fromAffine(g) {
            const { x, y: _ } = g || {};
            if (!g || !n.isValid(x) || !n.isValid(_)) throw new Error("invalid affine point");
            if (g instanceof d) throw new Error("projective point not allowed");
            const v = (O)=>n.eql(O, n.ZERO);
            return v(x) && v(_) ? d.ZERO : new d(x, _, n.ONE);
        }
        get x() {
            return this.toAffine().x;
        }
        get y() {
            return this.toAffine().y;
        }
        static normalizeZ(g) {
            const x = No(n, g.map((_)=>_.pz));
            return g.map((_, v)=>_.toAffine(x[v])).map(d.fromAffine);
        }
        static fromHex(g) {
            const x = d.fromAffine(s(rt("pointHex", g)));
            return x.assertValidity(), x;
        }
        static fromPrivateKey(g) {
            return d.BASE.multiply(u(g));
        }
        static msm(g, x) {
            return vf(d, r, g, x);
        }
        _setWindowSize(g) {
            H.setWindowSize(this, g);
        }
        assertValidity() {
            p(this);
        }
        hasEvenY() {
            const { y: g } = this.toAffine();
            if (n.isOdd) return !n.isOdd(g);
            throw new Error("Field doesn't support isOdd");
        }
        equals(g) {
            h(g);
            const { px: x, py: _, pz: v } = this, { px: O, py: T, pz: R } = g, E = n.eql(n.mul(x, R), n.mul(O, v)), N = n.eql(n.mul(_, R), n.mul(T, v));
            return E && N;
        }
        negate() {
            return new d(this.px, n.neg(this.py), this.pz);
        }
        double() {
            const { a: g, b: x } = e, _ = n.mul(x, Hn), { px: v, py: O, pz: T } = this;
            let R = n.ZERO, E = n.ZERO, N = n.ZERO, B = n.mul(v, v), C = n.mul(O, O), b = n.mul(T, T), y = n.mul(v, O);
            return y = n.add(y, y), N = n.mul(v, T), N = n.add(N, N), R = n.mul(g, N), E = n.mul(_, b), E = n.add(R, E), R = n.sub(C, E), E = n.add(C, E), E = n.mul(R, E), R = n.mul(y, R), N = n.mul(_, N), b = n.mul(g, b), y = n.sub(B, b), y = n.mul(g, y), y = n.add(y, N), N = n.add(B, B), B = n.add(N, B), B = n.add(B, b), B = n.mul(B, y), E = n.add(E, B), b = n.mul(O, T), b = n.add(b, b), B = n.mul(b, y), R = n.sub(R, B), N = n.mul(b, C), N = n.add(N, N), N = n.add(N, N), new d(R, E, N);
        }
        add(g) {
            h(g);
            const { px: x, py: _, pz: v } = this, { px: O, py: T, pz: R } = g;
            let E = n.ZERO, N = n.ZERO, B = n.ZERO;
            const C = e.a, b = n.mul(e.b, Hn);
            let y = n.mul(x, O), A = n.mul(_, T), $ = n.mul(v, R), w = n.add(x, _), L = n.add(O, T);
            w = n.mul(w, L), L = n.add(y, A), w = n.sub(w, L), L = n.add(x, v);
            let j = n.add(O, R);
            return L = n.mul(L, j), j = n.add(y, $), L = n.sub(L, j), j = n.add(_, v), E = n.add(T, R), j = n.mul(j, E), E = n.add(A, $), j = n.sub(j, E), B = n.mul(C, L), E = n.mul(b, $), B = n.add(E, B), E = n.sub(A, B), B = n.add(A, B), N = n.mul(E, B), A = n.add(y, y), A = n.add(A, y), $ = n.mul(C, $), L = n.mul(b, L), A = n.add(A, $), $ = n.sub(y, $), $ = n.mul(C, $), L = n.add(L, $), y = n.mul(A, L), N = n.add(N, y), y = n.mul(j, L), E = n.mul(w, E), E = n.sub(E, y), y = n.mul(w, A), B = n.mul(j, B), B = n.add(B, y), new d(E, N, B);
        }
        subtract(g) {
            return this.add(g.negate());
        }
        is0() {
            return this.equals(d.ZERO);
        }
        wNAF(g) {
            return H.wNAFCached(this, g, d.normalizeZ);
        }
        multiplyUnsafe(g) {
            const { endo: x, n: _ } = e;
            Pt("scalar", g, vt, _);
            const v = d.ZERO;
            if (g === vt) return v;
            if (this.is0() || g === z) return this;
            if (!x || H.hasPrecomputes(this)) return H.wNAFCachedUnsafe(this, g, d.normalizeZ);
            let { k1neg: O, k1: T, k2neg: R, k2: E } = x.splitScalar(g), N = v, B = v, C = this;
            for(; T > vt || E > vt;)T & z && (N = N.add(C)), E & z && (B = B.add(C)), C = C.double(), T >>= z, E >>= z;
            return O && (N = N.negate()), R && (B = B.negate()), B = new d(n.mul(B.px, x.beta), B.py, B.pz), N.add(B);
        }
        multiply(g) {
            const { endo: x, n: _ } = e;
            Pt("scalar", g, z, _);
            let v, O;
            if (x) {
                const { k1neg: T, k1: R, k2neg: E, k2: N } = x.splitScalar(g);
                let { p: B, f: C } = this.wNAF(R), { p: b, f: y } = this.wNAF(N);
                B = H.constTimeNegate(T, B), b = H.constTimeNegate(E, b), b = new d(n.mul(b.px, x.beta), b.py, b.pz), v = B.add(b), O = C.add(y);
            } else {
                const { p: T, f: R } = this.wNAF(g);
                v = T, O = R;
            }
            return d.normalizeZ([
                v,
                O
            ])[0];
        }
        multiplyAndAddUnsafe(g, x, _) {
            const v = d.BASE, O = (R, E)=>E === vt || E === z || !R.equals(v) ? R.multiplyUnsafe(E) : R.multiply(E), T = O(this, x).add(O(g, _));
            return T.is0() ? void 0 : T;
        }
        toAffine(g) {
            return m(this, g);
        }
        isTorsionFree() {
            const { h: g, isTorsionFree: x } = e;
            if (g === z) return !0;
            if (x) return x(d, this);
            throw new Error("isTorsionFree() has not been declared for the elliptic curve");
        }
        clearCofactor() {
            const { h: g, clearCofactor: x } = e;
            return g === z ? this : x ? x(d, this) : this.multiplyUnsafe(e.h);
        }
        toRawBytes(g = !0) {
            return pe("isCompressed", g), this.assertValidity(), o(d, this, g);
        }
        toHex(g = !0) {
            return pe("isCompressed", g), ge(this.toRawBytes(g));
        }
    }
    d.BASE = new d(e.Gx, e.Gy, n.ONE), d.ZERO = new d(n.ZERO, n.ONE, n.ZERO);
    const { endo: I, nBitLength: k } = e, H = xf(d, I ? Math.ceil(k / 2) : k);
    return {
        CURVE: e,
        ProjectivePoint: d,
        normPrivateKeyToScalar: u,
        weierstrassEquation: i,
        isWithinCurveOrder: l
    };
}
function $f(t) {
    const e = ko(t);
    return ye(e, {
        hash: "hash",
        hmac: "function",
        randomBytes: "function"
    }, {
        bits2int: "function",
        bits2int_modN: "function",
        lowS: "boolean"
    }), Object.freeze({
        lowS: !0,
        ...e
    });
}
function Lf(t) {
    const e = $f(t), { Fp: n, n: r, nByteLength: o, nBitLength: s } = e, i = n.BYTES + 1, c = 2 * n.BYTES + 1;
    function f(b) {
        return st(b, r);
    }
    function a(b) {
        return _n(b, r);
    }
    const { ProjectivePoint: l, normPrivateKeyToScalar: u, weierstrassEquation: h, isWithinCurveOrder: m } = Rf({
        ...e,
        toBytes (b, y, A) {
            const $ = y.toAffine(), w = n.toBytes($.x), L = De;
            return pe("isCompressed", A), A ? L(Uint8Array.from([
                y.hasEvenY() ? 2 : 3
            ]), w) : L(Uint8Array.from([
                4
            ]), w, n.toBytes($.y));
        },
        fromBytes (b) {
            const y = b.length, A = b[0], $ = b.subarray(1);
            if (y === i && (A === 2 || A === 3)) {
                const w = Vt($);
                if (!Nn(w, z, n.ORDER)) throw new Error("Point is not on curve");
                const L = h(w);
                let j;
                try {
                    j = n.sqrt(L);
                } catch (q) {
                    const M = q instanceof Error ? ": " + q.message : "";
                    throw new Error("Point is not on curve" + M);
                }
                const P = (j & z) === z;
                return (A & 1) === 1 !== P && (j = n.neg(j)), {
                    x: w,
                    y: j
                };
            } else if (y === c && A === 4) {
                const w = n.fromBytes($.subarray(0, n.BYTES)), L = n.fromBytes($.subarray(n.BYTES, 2 * n.BYTES));
                return {
                    x: w,
                    y: L
                };
            } else {
                const w = i, L = c;
                throw new Error("invalid Point, expected length of " + w + ", or uncompressed " + L + ", got " + y);
            }
        }
    });
    function p(b) {
        const y = r >> z;
        return b > y;
    }
    function d(b) {
        return p(b) ? f(-b) : b;
    }
    const I = (b, y, A)=>Vt(b.slice(y, A));
    class k {
        constructor(y, A, $){
            Pt("r", y, z, r), Pt("s", A, z, r), this.r = y, this.s = A, $ != null && (this.recovery = $), Object.freeze(this);
        }
        static fromCompact(y) {
            const A = o;
            return y = rt("compactSignature", y, A * 2), new k(I(y, 0, A), I(y, A, 2 * A));
        }
        static fromDER(y) {
            const { r: A, s: $ } = xt.toSig(rt("DER", y));
            return new k(A, $);
        }
        assertValidity() {}
        addRecoveryBit(y) {
            return new k(this.r, this.s, y);
        }
        recoverPublicKey(y) {
            const { r: A, s: $, recovery: w } = this, L = v(rt("msgHash", y));
            if (w == null || ![
                0,
                1,
                2,
                3
            ].includes(w)) throw new Error("recovery id invalid");
            const j = w === 2 || w === 3 ? A + e.n : A;
            if (j >= n.ORDER) throw new Error("recovery id 2 or 3 invalid");
            const P = (w & 1) === 0 ? "02" : "03", V = l.fromHex(P + Pn(j, n.BYTES)), q = a(j), M = f(-L * q), W = f($ * q), F = l.BASE.multiplyAndAddUnsafe(V, M, W);
            if (!F) throw new Error("point at infinify");
            return F.assertValidity(), F;
        }
        hasHighS() {
            return p(this.s);
        }
        normalizeS() {
            return this.hasHighS() ? new k(this.r, f(-this.s), this.recovery) : this;
        }
        toDERRawBytes() {
            return Pe(this.toDERHex());
        }
        toDERHex() {
            return xt.hexFromSig(this);
        }
        toCompactRawBytes() {
            return Pe(this.toCompactHex());
        }
        toCompactHex() {
            const y = o;
            return Pn(this.r, y) + Pn(this.s, y);
        }
    }
    const H = {
        isValidPrivateKey (b) {
            try {
                return u(b), !0;
            } catch  {
                return !1;
            }
        },
        normPrivateKeyToScalar: u,
        randomPrivateKey: ()=>{
            const b = Ro(e.n);
            return yf(e.randomBytes(b), e.n);
        },
        precompute (b = 8, y = l.BASE) {
            return y._setWindowSize(b), y.multiply(BigInt(3)), y;
        }
    };
    function S(b, y = !0) {
        return l.fromPrivateKey(b).toRawBytes(y);
    }
    function g(b) {
        if (typeof b == "bigint") return !1;
        if (b instanceof l) return !0;
        const A = rt("key", b).length, $ = n.BYTES, w = $ + 1, L = 2 * $ + 1;
        if (!(e.allowedPrivateKeyLengths || o === w)) return A === w || A === L;
    }
    function x(b, y, A = !0) {
        if (g(b) === !0) throw new Error("first arg must be private key");
        if (g(y) === !1) throw new Error("second arg must be public key");
        return l.fromHex(y).multiply(u(b)).toRawBytes(A);
    }
    const _ = e.bits2int || function(b) {
        if (b.length > 8192) throw new Error("input is too large");
        const y = Vt(b), A = b.length * 8 - s;
        return A > 0 ? y >> BigInt(A) : y;
    }, v = e.bits2int_modN || function(b) {
        return f(_(b));
    }, O = Me(s);
    function T(b) {
        return Pt("num < 2^" + s, b, vt, O), be(b, o);
    }
    function R(b, y, A = E) {
        if ([
            "recovered",
            "canonical"
        ].some((G)=>G in A)) throw new Error("sign() legacy options not supported");
        const { hash: $, randomBytes: w } = e;
        let { lowS: L, prehash: j, extraEntropy: P } = A;
        L == null && (L = !0), b = rt("msgHash", b), Ho(A), j && (b = rt("prehashed msgHash", $(b)));
        const V = v(b), q = u(y), M = [
            T(q),
            T(V)
        ];
        if (P != null && P !== !1) {
            const G = P === !0 ? w(n.BYTES) : P;
            M.push(rt("extraEntropy", G));
        }
        const W = De(...M), F = V;
        function it(G) {
            const Gt = _(G);
            if (!m(Gt)) return;
            const Ge = a(Gt), re = l.BASE.multiply(Gt).toAffine(), Dt = f(re.x);
            if (Dt === vt) return;
            const oe = f(Ge * f(F + Dt * q));
            if (oe === vt) return;
            let Zt = (re.x === Dt ? 0 : 2) | Number(re.y & z), Jn = oe;
            return L && p(oe) && (Jn = d(oe), Zt ^= 1), new k(Dt, Jn, Zt);
        }
        return {
            seed: W,
            k2sig: it
        };
    }
    const E = {
        lowS: e.lowS,
        prehash: !1
    }, N = {
        lowS: e.lowS,
        prehash: !1
    };
    function B(b, y, A = E) {
        const { seed: $, k2sig: w } = R(b, y, A), L = e;
        return ff(L.hash.outputLen, L.nByteLength, L.hmac)($, w);
    }
    l.BASE._setWindowSize(8);
    function C(b, y, A, $ = N) {
        const w = b;
        y = rt("msgHash", y), A = rt("publicKey", A);
        const { lowS: L, prehash: j, format: P } = $;
        if (Ho($), "strict" in $) throw new Error("options.strict was renamed to lowS");
        if (P !== void 0 && P !== "compact" && P !== "der") throw new Error("format must be compact or der");
        const V = typeof w == "string" || he(w), q = !V && !P && typeof w == "object" && w !== null && typeof w.r == "bigint" && typeof w.s == "bigint";
        if (!V && !q) throw new Error("invalid signature, expected Uint8Array, hex string or Signature instance");
        let M, W;
        try {
            if (q && (M = new k(w.r, w.s)), V) {
                try {
                    P !== "compact" && (M = k.fromDER(w));
                } catch (Zt) {
                    if (!(Zt instanceof xt.Err)) throw Zt;
                }
                !M && P !== "der" && (M = k.fromCompact(w));
            }
            W = l.fromHex(A);
        } catch  {
            return !1;
        }
        if (!M || L && M.hasHighS()) return !1;
        j && (y = e.hash(y));
        const { r: F, s: it } = M, G = v(y), Gt = a(it), Ge = f(G * Gt), re = f(F * Gt), Dt = l.BASE.multiplyAndAddUnsafe(W, Ge, re)?.toAffine();
        return Dt ? f(Dt.x) === F : !1;
    }
    return {
        CURVE: e,
        getPublicKey: S,
        getSharedSecret: x,
        sign: B,
        verify: C,
        ProjectivePoint: l,
        Signature: k,
        utils: H
    };
}
function Cf(t) {
    return {
        hash: t,
        hmac: (e, ...n)=>Ce(t, e, Ci(...n)),
        randomBytes: Xt
    };
}
function Dn(t, e) {
    const n = (r)=>Lf({
            ...t,
            ...Cf(r)
        });
    return {
        ...n(e),
        create: n
    };
}
const Do = me(BigInt("0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff")), jf = Do.create(BigInt("-3")), kf = BigInt("0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b"), Pf = Dn({
    a: jf,
    b: kf,
    Fp: Do,
    n: BigInt("0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551"),
    Gx: BigInt("0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296"),
    Gy: BigInt("0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5"),
    h: BigInt(1),
    lowS: !1
}, _e), Mo = me(BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffeffffffff0000000000000000ffffffff")), Hf = Mo.create(BigInt("-3")), Df = BigInt("0xb3312fa7e23ee7e4988e056be3f82d19181d9c6efe8141120314088f5013875ac656398d8a2ed19d2a85c8edd3ec2aef");
Dn({
    a: Hf,
    b: Df,
    Fp: Mo,
    n: BigInt("0xffffffffffffffffffffffffffffffffffffffffffffffffc7634d81f4372ddf581a0db248b0a77aecec196accc52973"),
    Gx: BigInt("0xaa87ca22be8b05378eb1c71ef320ad746e1d3b628ba79b9859f741e082542a385502f25dbf55296c3a545e3872760ab7"),
    Gy: BigInt("0x3617de4a96262c6f5d9e98bf9292dc29f8f41dbd289a147ce9da3113b5f0b8c00a60b1ce1d7e819d7a431d7c90ea0e5f"),
    h: BigInt(1),
    lowS: !1
}, rc);
const Vo = me(BigInt("0x1ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff")), Mf = Vo.create(BigInt("-3")), Vf = BigInt("0x0051953eb9618e1c9a1f929a21a0b68540eea2da725b99b315f3b8b489918ef109e156193951ec7e937b1652c0bd3bb1bf073573df883d2c34f1ef451fd46b503f00");
Dn({
    a: Mf,
    b: Vf,
    Fp: Vo,
    n: BigInt("0x01fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffa51868783bf2f966b7fcc0148f709a5d03bb5c9b8899c47aebb6fb71e91386409"),
    Gx: BigInt("0x00c6858e06b70404e9cd9e3ecb662395b4429c648139053fb521f828af606b4d3dbaa14b5e77efe75928fe1dc127a2ffa8de3348b3c1856a429bf97e7e31c2e5bd66"),
    Gy: BigInt("0x011839296a789a3bc0045c8a5fb42c7d1bd998f54449579b446817afbd17273e662c97ee72995ef42640c550b9013fad0761353c7086a272c24088be94769fd16650"),
    h: BigInt(1),
    lowS: !1,
    allowedPrivateKeyLengths: [
        130,
        131,
        132
    ]
}, nc);
const qf = Pf, Mn = "base10", et = "base16", te = "base64pad", qe = "base64url", ee = "utf8", Vn = 0, ne = 1, xe = 2, Kf = 0, qo = 1, ve = 12, qn = 32;
function Ff() {
    const t = kn.utils.randomPrivateKey(), e = kn.getPublicKey(t);
    return {
        privateKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(t, et),
        publicKey: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(e, et)
    };
}
function zf() {
    const t = Xt(qn);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(t, et);
}
function Gf(t, e) {
    const n = kn.getSharedSecret((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t, et), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(e, et)), r = of(je, n, void 0, void 0, qn);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(r, et);
}
function Zf(t) {
    const e = je((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t, et));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(e, et);
}
function Wf(t) {
    const e = je((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t, ee));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(e, et);
}
function Kn(t) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(`${t}`, Mn);
}
function Kt(t) {
    return Number((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(t, Mn));
}
function Ko(t) {
    return t.replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
function Fo(t) {
    const e = t.replace(/-/g, "+").replace(/_/g, "/"), n = (4 - e.length % 4) % 4;
    return e + "=".repeat(n);
}
function Yf(t) {
    const e = Kn(typeof t.type < "u" ? t.type : Vn);
    if (Kt(e) === ne && typeof t.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
    const n = typeof t.senderPublicKey < "u" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t.senderPublicKey, et) : void 0, r = typeof t.iv < "u" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t.iv, et) : Xt(ve), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t.symKey, et), s = bo(o, r).encrypt((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t.message, ee)), i = Fn({
        type: e,
        sealed: s,
        iv: r,
        senderPublicKey: n
    });
    return t.encoding === qe ? Ko(i) : i;
}
function Xf(t) {
    const e = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t.symKey, et), { sealed: n, iv: r } = Ke({
        encoded: t.encoded,
        encoding: t.encoding
    }), o = bo(e, r).decrypt(n);
    if (o === null) throw new Error("Failed to decrypt");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(o, ee);
}
function Jf(t, e) {
    const n = Kn(xe), r = Xt(ve), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(t, ee), s = Fn({
        type: n,
        sealed: o,
        iv: r
    });
    return e === qe ? Ko(s) : s;
}
function Qf(t, e) {
    const { sealed: n } = Ke({
        encoded: t,
        encoding: e
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(n, ee);
}
function Fn(t) {
    if (Kt(t.type) === xe) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concat"])([
        t.type,
        t.sealed
    ]), te);
    if (Kt(t.type) === ne) {
        if (typeof t.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concat"])([
            t.type,
            t.senderPublicKey,
            t.iv,
            t.sealed
        ]), te);
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concat"])([
        t.type,
        t.iv,
        t.sealed
    ]), te);
}
function Ke(t) {
    const e = (t.encoding || te) === qe ? Fo(t.encoded) : t.encoded, n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$from$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromString"])(e, te), r = n.slice(Kf, qo), o = qo;
    if (Kt(r) === ne) {
        const f = o + qn, a = f + ve, l = n.slice(o, f), u = n.slice(f, a), h = n.slice(a);
        return {
            type: r,
            sealed: h,
            iv: u,
            senderPublicKey: l
        };
    }
    if (Kt(r) === xe) {
        const f = n.slice(o), a = Xt(ve);
        return {
            type: r,
            sealed: f,
            iv: a
        };
    }
    const s = o + ve, i = n.slice(o, s), c = n.slice(s);
    return {
        type: r,
        sealed: c,
        iv: i
    };
}
function ta(t, e) {
    const n = Ke({
        encoded: t,
        encoding: e?.encoding
    });
    return zo({
        type: Kt(n.type),
        senderPublicKey: typeof n.senderPublicKey < "u" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$to$2d$string$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toString"])(n.senderPublicKey, et) : void 0,
        receiverPublicKey: e?.receiverPublicKey
    });
}
function zo(t) {
    const e = t?.type || Vn;
    if (e === ne) {
        if (typeof t?.senderPublicKey > "u") throw new Error("missing sender public key");
        if (typeof t?.receiverPublicKey > "u") throw new Error("missing receiver public key");
    }
    return {
        type: e,
        senderPublicKey: t?.senderPublicKey,
        receiverPublicKey: t?.receiverPublicKey
    };
}
function ea(t) {
    return t.type === ne && typeof t.senderPublicKey == "string" && typeof t.receiverPublicKey == "string";
}
function na(t) {
    return t.type === xe;
}
function Go(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.x, "base64"), n = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.y, "base64");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concat"])([
        new Uint8Array([
            4
        ]),
        e,
        n
    ]);
}
function ra(t, e) {
    const [n, r, o] = t.split("."), s = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(Fo(o), "base64");
    if (s.length !== 64) throw new Error("Invalid signature length");
    const i = s.slice(0, 32), c = s.slice(32, 64), f = `${n}.${r}`, a = je(f), l = Go(e);
    if (!qf.verify((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$uint8arrays$2f$esm$2f$src$2f$concat$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concat"])([
        i,
        c
    ]), a, l)) throw new Error("Invalid signature");
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$relay$2d$auth$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["decodeJWT"])(t).payload;
}
const Zo = "irn";
function oa(t) {
    return t?.relay || {
        protocol: Zo
    };
}
function sa(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$relay$2d$api$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RELAY_JSONRPC"][t];
    if (typeof e > "u") throw new Error(`Relay Protocol not supported: ${t}`);
    return e;
}
function Wo(t, e = "-") {
    const n = {}, r = "relay" + e;
    return Object.keys(t).forEach((o)=>{
        if (o.startsWith(r)) {
            const s = o.replace(r, ""), i = t[o];
            n[s] = i;
        }
    }), n;
}
function ia(t) {
    if (!t.includes("wc:")) {
        const a = nn(t);
        a != null && a.includes("wc:") && (t = a);
    }
    t = t.includes("wc://") ? t.replace("wc://", "") : t, t = t.includes("wc:") ? t.replace("wc:", "") : t;
    const e = t.indexOf(":"), n = t.indexOf("?") !== -1 ? t.indexOf("?") : void 0, r = t.substring(0, e), o = t.substring(e + 1, n).split("@"), s = typeof n < "u" ? t.substring(n) : "", i = new URLSearchParams(s), c = {};
    i.forEach((a, l)=>{
        c[l] = a;
    });
    const f = typeof c.methods == "string" ? c.methods.split(",") : void 0;
    return {
        protocol: r,
        topic: Yo(o[0]),
        version: parseInt(o[1], 10),
        symKey: c.symKey,
        relay: Wo(c),
        methods: f,
        expiryTimestamp: c.expiryTimestamp ? parseInt(c.expiryTimestamp, 10) : void 0
    };
}
function Yo(t) {
    return t.startsWith("//") ? t.substring(2) : t;
}
function Xo(t, e = "-") {
    const n = "relay", r = {};
    return Object.keys(t).forEach((o)=>{
        const s = o, i = n + e + s;
        t[s] && (r[i] = t[s]);
    }), r;
}
function ca(t) {
    const e = new URLSearchParams, n = Xo(t.relay);
    Object.keys(n).sort().forEach((o)=>{
        e.set(o, n[o]);
    }), e.set("symKey", t.symKey), t.expiryTimestamp && e.set("expiryTimestamp", t.expiryTimestamp.toString()), t.methods && e.set("methods", t.methods.join(","));
    const r = e.toString();
    return `${t.protocol}:${t.topic}@${t.version}?${r}`;
}
function fa(t, e, n) {
    return `${t}?wc_ev=${n}&topic=${e}`;
}
var aa = Object.defineProperty, ua = Object.defineProperties, la = Object.getOwnPropertyDescriptors, Jo = Object.getOwnPropertySymbols, da = Object.prototype.hasOwnProperty, ha = Object.prototype.propertyIsEnumerable, Qo = (t, e, n)=>e in t ? aa(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : t[e] = n, pa = (t, e)=>{
    for(var n in e || (e = {}))da.call(e, n) && Qo(t, n, e[n]);
    if (Jo) for (var n of Jo(e))ha.call(e, n) && Qo(t, n, e[n]);
    return t;
}, ga = (t, e)=>ua(t, la(e));
function Ft(t) {
    const e = [];
    return t.forEach((n)=>{
        const [r, o] = n.split(":");
        e.push(`${r}:${o}`);
    }), e;
}
function ts(t) {
    const e = [];
    return Object.values(t).forEach((n)=>{
        e.push(...Ft(n.accounts));
    }), e;
}
function es(t, e) {
    const n = [];
    return Object.values(t).forEach((r)=>{
        Ft(r.accounts).includes(e) && n.push(...r.methods);
    }), n;
}
function ns(t, e) {
    const n = [];
    return Object.values(t).forEach((r)=>{
        Ft(r.accounts).includes(e) && n.push(...r.events);
    }), n;
}
function ba(t, e) {
    const n = hs(t, e);
    if (n) throw new Error(n.message);
    const r = {};
    for (const [o, s] of Object.entries(t))r[o] = {
        methods: s.methods,
        events: s.events,
        chains: s.accounts.map((i)=>`${i.split(":")[0]}:${i.split(":")[1]}`)
    };
    return r;
}
function ya(t) {
    const { proposal: { requiredNamespaces: e, optionalNamespaces: n = {} }, supportedNamespaces: r } = t, o = Ee(e), s = Ee(n), i = {};
    Object.keys(r).forEach((a)=>{
        const l = r[a].chains, u = r[a].methods, h = r[a].events, m = r[a].accounts;
        l.forEach((p)=>{
            if (!m.some((d)=>d.includes(p))) throw new Error(`No accounts provided for chain ${p} in namespace ${a}`);
        }), i[a] = {
            chains: l,
            methods: u,
            events: h,
            accounts: m
        };
    });
    const c = gs(e, i, "approve()");
    if (c) throw new Error(c.message);
    const f = {};
    return !Object.keys(e).length && !Object.keys(n).length ? i : (Object.keys(o).forEach((a)=>{
        const l = r[a].chains.filter((p)=>{
            var d, I;
            return (I = (d = o[a]) == null ? void 0 : d.chains) == null ? void 0 : I.includes(p);
        }), u = r[a].methods.filter((p)=>{
            var d, I;
            return (I = (d = o[a]) == null ? void 0 : d.methods) == null ? void 0 : I.includes(p);
        }), h = r[a].events.filter((p)=>{
            var d, I;
            return (I = (d = o[a]) == null ? void 0 : d.events) == null ? void 0 : I.includes(p);
        }), m = l.map((p)=>r[a].accounts.filter((d)=>d.includes(`${p}:`))).flat();
        f[a] = {
            chains: l,
            methods: u,
            events: h,
            accounts: m
        };
    }), Object.keys(s).forEach((a)=>{
        var l, u, h, m, p, d;
        if (!r[a]) return;
        const I = (u = (l = s[a]) == null ? void 0 : l.chains) == null ? void 0 : u.filter((g)=>r[a].chains.includes(g)), k = r[a].methods.filter((g)=>{
            var x, _;
            return (_ = (x = s[a]) == null ? void 0 : x.methods) == null ? void 0 : _.includes(g);
        }), H = r[a].events.filter((g)=>{
            var x, _;
            return (_ = (x = s[a]) == null ? void 0 : x.events) == null ? void 0 : _.includes(g);
        }), S = I?.map((g)=>r[a].accounts.filter((x)=>x.includes(`${g}:`))).flat();
        f[a] = {
            chains: ut((h = f[a]) == null ? void 0 : h.chains, I),
            methods: ut((m = f[a]) == null ? void 0 : m.methods, k),
            events: ut((p = f[a]) == null ? void 0 : p.events, H),
            accounts: ut((d = f[a]) == null ? void 0 : d.accounts, S)
        };
    }), f);
}
function zn(t) {
    return t.includes(":");
}
function rs(t) {
    return zn(t) ? t.split(":")[0] : t;
}
function Ee(t) {
    var e, n, r;
    const o = {};
    if (!Fe(t)) return o;
    for (const [s, i] of Object.entries(t)){
        const c = zn(s) ? [
            s
        ] : i.chains, f = i.methods || [], a = i.events || [], l = rs(s);
        o[l] = ga(pa({}, o[l]), {
            chains: ut(c, (e = o[l]) == null ? void 0 : e.chains),
            methods: ut(f, (n = o[l]) == null ? void 0 : n.methods),
            events: ut(a, (r = o[l]) == null ? void 0 : r.events)
        });
    }
    return o;
}
function os(t) {
    const e = {};
    return t?.forEach((n)=>{
        var r;
        const [o, s] = n.split(":");
        e[o] || (e[o] = {
            accounts: [],
            chains: [],
            events: [],
            methods: []
        }), e[o].accounts.push(n), (r = e[o].chains) == null || r.push(`${o}:${s}`);
    }), e;
}
function ma(t, e) {
    e = e.map((r)=>r.replace("did:pkh:", ""));
    const n = os(e);
    for (const [r, o] of Object.entries(n))o.methods ? o.methods = ut(o.methods, t) : o.methods = t, o.events = [
        "chainChanged",
        "accountsChanged"
    ];
    return n;
}
function wa(t, e) {
    var n, r, o, s, i, c;
    const f = Ee(t), a = Ee(e), l = {}, u = Object.keys(f).concat(Object.keys(a));
    for (const h of u)l[h] = {
        chains: ut((n = f[h]) == null ? void 0 : n.chains, (r = a[h]) == null ? void 0 : r.chains),
        methods: ut((o = f[h]) == null ? void 0 : o.methods, (s = a[h]) == null ? void 0 : s.methods),
        events: ut((i = f[h]) == null ? void 0 : i.events, (c = a[h]) == null ? void 0 : c.events)
    };
    return l;
}
const ss = {
    INVALID_METHOD: {
        message: "Invalid method.",
        code: 1001
    },
    INVALID_EVENT: {
        message: "Invalid event.",
        code: 1002
    },
    INVALID_UPDATE_REQUEST: {
        message: "Invalid update request.",
        code: 1003
    },
    INVALID_EXTEND_REQUEST: {
        message: "Invalid extend request.",
        code: 1004
    },
    INVALID_SESSION_SETTLE_REQUEST: {
        message: "Invalid session settle request.",
        code: 1005
    },
    UNAUTHORIZED_METHOD: {
        message: "Unauthorized method.",
        code: 3001
    },
    UNAUTHORIZED_EVENT: {
        message: "Unauthorized event.",
        code: 3002
    },
    UNAUTHORIZED_UPDATE_REQUEST: {
        message: "Unauthorized update request.",
        code: 3003
    },
    UNAUTHORIZED_EXTEND_REQUEST: {
        message: "Unauthorized extend request.",
        code: 3004
    },
    USER_REJECTED: {
        message: "User rejected.",
        code: 5e3
    },
    USER_REJECTED_CHAINS: {
        message: "User rejected chains.",
        code: 5001
    },
    USER_REJECTED_METHODS: {
        message: "User rejected methods.",
        code: 5002
    },
    USER_REJECTED_EVENTS: {
        message: "User rejected events.",
        code: 5003
    },
    UNSUPPORTED_CHAINS: {
        message: "Unsupported chains.",
        code: 5100
    },
    UNSUPPORTED_METHODS: {
        message: "Unsupported methods.",
        code: 5101
    },
    UNSUPPORTED_EVENTS: {
        message: "Unsupported events.",
        code: 5102
    },
    UNSUPPORTED_ACCOUNTS: {
        message: "Unsupported accounts.",
        code: 5103
    },
    UNSUPPORTED_NAMESPACE_KEY: {
        message: "Unsupported namespace key.",
        code: 5104
    },
    USER_DISCONNECTED: {
        message: "User disconnected.",
        code: 6e3
    },
    SESSION_SETTLEMENT_FAILED: {
        message: "Session settlement failed.",
        code: 7e3
    },
    WC_METHOD_UNSUPPORTED: {
        message: "Unsupported wc_ method.",
        code: 10001
    }
}, is = {
    NOT_INITIALIZED: {
        message: "Not initialized.",
        code: 1
    },
    NO_MATCHING_KEY: {
        message: "No matching key.",
        code: 2
    },
    RESTORE_WILL_OVERRIDE: {
        message: "Restore will override.",
        code: 3
    },
    RESUBSCRIBED: {
        message: "Resubscribed.",
        code: 4
    },
    MISSING_OR_INVALID: {
        message: "Missing or invalid.",
        code: 5
    },
    EXPIRED: {
        message: "Expired.",
        code: 6
    },
    UNKNOWN_TYPE: {
        message: "Unknown type.",
        code: 7
    },
    MISMATCHED_TOPIC: {
        message: "Mismatched topic.",
        code: 8
    },
    NON_CONFORMING_NAMESPACES: {
        message: "Non conforming namespaces.",
        code: 9
    }
};
function Et(t, e) {
    const { message: n, code: r } = is[t];
    return {
        message: e ? `${n} ${e}` : n,
        code: r
    };
}
function zt(t, e) {
    const { message: n, code: r } = ss[t];
    return {
        message: e ? `${n} ${e}` : n,
        code: r
    };
}
function Ae(t, e) {
    return Array.isArray(t) ? typeof e < "u" && t.length ? t.every(e) : !0 : !1;
}
function Fe(t) {
    return Object.getPrototypeOf(t) === Object.prototype && Object.keys(t).length;
}
function Ht(t) {
    return typeof t > "u";
}
function ft(t, e) {
    return e && Ht(t) ? !0 : typeof t == "string" && !!t.trim().length;
}
function ze(t, e) {
    return e && Ht(t) ? !0 : typeof t == "number" && !isNaN(t);
}
function xa(t, e) {
    const { requiredNamespaces: n } = e, r = Object.keys(t.namespaces), o = Object.keys(n);
    let s = !0;
    return Bt(o, r) ? (r.forEach((i)=>{
        const { accounts: c, methods: f, events: a } = t.namespaces[i], l = Ft(c), u = n[i];
        (!Bt(Se(i, u), l) || !Bt(u.methods, f) || !Bt(u.events, a)) && (s = !1);
    }), s) : !1;
}
function Be(t) {
    return ft(t, !1) && t.includes(":") ? t.split(":").length === 2 : !1;
}
function cs(t) {
    if (ft(t, !1) && t.includes(":")) {
        const e = t.split(":");
        if (e.length === 3) {
            const n = e[0] + ":" + e[1];
            return !!e[2] && Be(n);
        }
    }
    return !1;
}
function va(t) {
    function e(n) {
        try {
            return typeof new URL(n) < "u";
        } catch  {
            return !1;
        }
    }
    try {
        if (ft(t, !1)) {
            if (e(t)) return !0;
            const n = nn(t);
            return e(n);
        }
    } catch  {}
    return !1;
}
function Ea(t) {
    var e;
    return (e = t?.proposer) == null ? void 0 : e.publicKey;
}
function Aa(t) {
    return t?.topic;
}
function Ba(t, e) {
    let n = null;
    return ft(t?.publicKey, !1) || (n = Et("MISSING_OR_INVALID", `${e} controller public key should be a string`)), n;
}
function Gn(t) {
    let e = !0;
    return Ae(t) ? t.length && (e = t.every((n)=>ft(n, !1))) : e = !1, e;
}
function fs(t, e, n) {
    let r = null;
    return Ae(e) && e.length ? e.forEach((o)=>{
        r || Be(o) || (r = zt("UNSUPPORTED_CHAINS", `${n}, chain ${o} should be a string and conform to "namespace:chainId" format`));
    }) : Be(t) || (r = zt("UNSUPPORTED_CHAINS", `${n}, chains must be defined as "namespace:chainId" e.g. "eip155:1": {...} in the namespace key OR as an array of CAIP-2 chainIds e.g. eip155: { chains: ["eip155:1", "eip155:5"] }`)), r;
}
function as(t, e, n) {
    let r = null;
    return Object.entries(t).forEach(([o, s])=>{
        if (r) return;
        const i = fs(o, Se(o, s), `${e} ${n}`);
        i && (r = i);
    }), r;
}
function us(t, e) {
    let n = null;
    return Ae(t) ? t.forEach((r)=>{
        n || cs(r) || (n = zt("UNSUPPORTED_ACCOUNTS", `${e}, account ${r} should be a string and conform to "namespace:chainId:address" format`));
    }) : n = zt("UNSUPPORTED_ACCOUNTS", `${e}, accounts should be an array of strings conforming to "namespace:chainId:address" format`), n;
}
function ls(t, e) {
    let n = null;
    return Object.values(t).forEach((r)=>{
        if (n) return;
        const o = us(r?.accounts, `${e} namespace`);
        o && (n = o);
    }), n;
}
function ds(t, e) {
    let n = null;
    return Gn(t?.methods) ? Gn(t?.events) || (n = zt("UNSUPPORTED_EVENTS", `${e}, events should be an array of strings or empty array for no events`)) : n = zt("UNSUPPORTED_METHODS", `${e}, methods should be an array of strings or empty array for no methods`), n;
}
function Zn(t, e) {
    let n = null;
    return Object.values(t).forEach((r)=>{
        if (n) return;
        const o = ds(r, `${e}, namespace`);
        o && (n = o);
    }), n;
}
function Ia(t, e, n) {
    let r = null;
    if (t && Fe(t)) {
        const o = Zn(t, e);
        o && (r = o);
        const s = as(t, e, n);
        s && (r = s);
    } else r = Et("MISSING_OR_INVALID", `${e}, ${n} should be an object with data`);
    return r;
}
function hs(t, e) {
    let n = null;
    if (t && Fe(t)) {
        const r = Zn(t, e);
        r && (n = r);
        const o = ls(t, e);
        o && (n = o);
    } else n = Et("MISSING_OR_INVALID", `${e}, namespaces should be an object with data`);
    return n;
}
function ps(t) {
    return ft(t.protocol, !0);
}
function Sa(t, e) {
    let n = !1;
    return e && !t ? n = !0 : t && Ae(t) && t.length && t.forEach((r)=>{
        n = ps(r);
    }), n;
}
function Oa(t) {
    return typeof t == "number";
}
function Na(t) {
    return typeof t < "u" && typeof t !== null;
}
function Ua(t) {
    return !(!t || typeof t != "object" || !t.code || !ze(t.code, !1) || !t.message || !ft(t.message, !1));
}
function _a(t) {
    return !(Ht(t) || !ft(t.method, !1));
}
function Ta(t) {
    return !(Ht(t) || Ht(t.result) && Ht(t.error) || !ze(t.id, !1) || !ft(t.jsonrpc, !1));
}
function Ra(t) {
    return !(Ht(t) || !ft(t.name, !1));
}
function $a(t, e) {
    return !(!Be(e) || !ts(t).includes(e));
}
function La(t, e, n) {
    return ft(n, !1) ? es(t, e).includes(n) : !1;
}
function Ca(t, e, n) {
    return ft(n, !1) ? ns(t, e).includes(n) : !1;
}
function gs(t, e, n) {
    let r = null;
    const o = ja(t), s = ka(e), i = Object.keys(o), c = Object.keys(s), f = bs(Object.keys(t)), a = bs(Object.keys(e)), l = f.filter((u)=>!a.includes(u));
    return l.length && (r = Et("NON_CONFORMING_NAMESPACES", `${n} namespaces keys don't satisfy requiredNamespaces.
      Required: ${l.toString()}
      Received: ${Object.keys(e).toString()}`)), Bt(i, c) || (r = Et("NON_CONFORMING_NAMESPACES", `${n} namespaces chains don't satisfy required namespaces.
      Required: ${i.toString()}
      Approved: ${c.toString()}`)), Object.keys(e).forEach((u)=>{
        if (!u.includes(":") || r) return;
        const h = Ft(e[u].accounts);
        h.includes(u) || (r = Et("NON_CONFORMING_NAMESPACES", `${n} namespaces accounts don't satisfy namespace accounts for ${u}
        Required: ${u}
        Approved: ${h.toString()}`));
    }), i.forEach((u)=>{
        r || (Bt(o[u].methods, s[u].methods) ? Bt(o[u].events, s[u].events) || (r = Et("NON_CONFORMING_NAMESPACES", `${n} namespaces events don't satisfy namespace events for ${u}`)) : r = Et("NON_CONFORMING_NAMESPACES", `${n} namespaces methods don't satisfy namespace methods for ${u}`));
    }), r;
}
function ja(t) {
    const e = {};
    return Object.keys(t).forEach((n)=>{
        var r;
        n.includes(":") ? e[n] = t[n] : (r = t[n].chains) == null || r.forEach((o)=>{
            e[o] = {
                methods: t[n].methods,
                events: t[n].events
            };
        });
    }), e;
}
function bs(t) {
    return [
        ...new Set(t.map((e)=>e.includes(":") ? e.split(":")[0] : e))
    ];
}
function ka(t) {
    const e = {};
    return Object.keys(t).forEach((n)=>{
        if (n.includes(":")) e[n] = t[n];
        else {
            const r = Ft(t[n].accounts);
            r?.forEach((o)=>{
                e[o] = {
                    accounts: t[n].accounts.filter((s)=>s.includes(`${o}:`)),
                    methods: t[n].methods,
                    events: t[n].events
                };
            });
        }
    }), e;
}
function Pa(t, e) {
    return ze(t, !1) && t <= e.max && t >= e.min;
}
function Ha() {
    const t = Mt();
    return new Promise((e)=>{
        switch(t){
            case Q.browser:
                e(ys());
                break;
            case Q.reactNative:
                e(ms());
                break;
            case Q.node:
                e(ws());
                break;
            default:
                e(!0);
        }
    });
}
function ys() {
    return Wt() && navigator?.onLine;
}
async function ms() {
    if (At() && typeof global < "u" && global != null && global.NetInfo) {
        const t = await (global == null ? void 0 : global.NetInfo.fetch());
        return t?.isConnected;
    }
    return !0;
}
function ws() {
    return !0;
}
function Da(t) {
    switch(Mt()){
        case Q.browser:
            xs(t);
            break;
        case Q.reactNative:
            vs(t);
            break;
        case Q.node:
            break;
    }
}
function xs(t) {
    !At() && Wt() && (window.addEventListener("online", ()=>t(!0)), window.addEventListener("offline", ()=>t(!1)));
}
function vs(t) {
    At() && typeof global < "u" && global != null && global.NetInfo && global?.NetInfo.addEventListener((e)=>t(e?.isConnected));
}
function Ma() {
    var t;
    return Wt() && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])() ? ((t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$walletconnect$2f$window$2d$getters$2f$dist$2f$cjs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocument"])()) == null ? void 0 : t.visibilityState) === "visible" : !0;
}
const Wn = {};
class Va {
    static get(e) {
        return Wn[e];
    }
    static set(e, n) {
        Wn[e] = n;
    }
    static delete(e) {
        delete Wn[e];
    }
}
function Es(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].decode(t);
    if (e.length < 33) throw new Error("Too short to contain a public key");
    return e.slice(1, 33);
}
function As({ publicKey: t, signature: e, payload: n }) {
    var r;
    const o = Yn(n.method), s = 128 | parseInt(((r = n.version) == null ? void 0 : r.toString()) || "4"), i = Ka(n.address), c = n.era === "00" ? new Uint8Array([
        0
    ]) : Yn(n.era);
    if (c.length !== 1 && c.length !== 2) throw new Error("Invalid era length");
    const f = parseInt(n.nonce, 16), a = new Uint8Array([
        f & 255,
        f >> 8 & 255
    ]), l = BigInt(`0x${qa(n.tip)}`), u = za(l), h = new Uint8Array([
        0,
        ...t,
        i,
        ...e,
        ...c,
        ...a,
        ...u,
        ...o
    ]), m = Fa(h.length + 1);
    return new Uint8Array([
        ...m,
        s,
        ...h
    ]);
}
function Bs(t) {
    const e = Yn(t), n = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blakejs$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["blake2b"])(e, void 0, 32);
    return "0x" + __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(n).toString("hex");
}
function Yn(t) {
    return new Uint8Array(t.replace(/^0x/, "").match(/.{1,2}/g).map((e)=>parseInt(e, 16)));
}
function qa(t) {
    return t.startsWith("0x") ? t.slice(2) : t;
}
function Ka(t) {
    const e = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bs58$2f$src$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].decode(t)[0];
    return e === 42 ? 0 : e === 60 ? 2 : 1;
}
function Fa(t) {
    if (t < 64) return new Uint8Array([
        t << 2
    ]);
    if (t < 16384) {
        const e = t << 2 | 1;
        return new Uint8Array([
            e & 255,
            e >> 8 & 255
        ]);
    } else if (t < 1 << 30) {
        const e = t << 2 | 2;
        return new Uint8Array([
            e & 255,
            e >> 8 & 255,
            e >> 16 & 255,
            e >> 24 & 255
        ]);
    } else throw new Error("Compact encoding > 2^30 not supported");
}
function za(t) {
    if (t < BigInt(1) << BigInt(6)) return new Uint8Array([
        Number(t << BigInt(2))
    ]);
    if (t < BigInt(1) << BigInt(14)) {
        const e = t << BigInt(2) | BigInt(1);
        return new Uint8Array([
            Number(e & BigInt(255)),
            Number(e >> BigInt(8) & BigInt(255))
        ]);
    } else if (t < BigInt(1) << BigInt(30)) {
        const e = t << BigInt(2) | BigInt(2);
        return new Uint8Array([
            Number(e & BigInt(255)),
            Number(e >> BigInt(8) & BigInt(255)),
            Number(e >> BigInt(16) & BigInt(255)),
            Number(e >> BigInt(24) & BigInt(255))
        ]);
    } else throw new Error("BigInt compact encoding not supported > 2^30");
}
function Ga(t) {
    const e = Uint8Array.from(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(t.signature, "hex")), n = Es(t.transaction.address), r = As({
        publicKey: n,
        signature: e,
        payload: t.transaction
    }), o = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].from(r).toString("hex");
    return Bs(o);
}
;
 //# sourceMappingURL=index.es.js.map
}}),
}]);

//# sourceMappingURL=node_modules_%40walletconnect_utils_dist_index_es_a023e97a.js.map