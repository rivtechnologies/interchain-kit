(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'picasso',
    assets: [
        {
            description: 'The native staking and governance token of Picasso Kusama.',
            denomUnits: [
                {
                    denom: 'ppica',
                    exponent: 0
                },
                {
                    denom: 'pica',
                    exponent: 12
                }
            ],
            typeAsset: 'substrate',
            base: 'ppica',
            name: 'Pica',
            display: 'pica',
            symbol: 'PICA',
            coingeckoId: 'picasso',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/composable/images/pica.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/composable/images/pica.svg'
                }
            ]
        },
        {
            denomUnits: [
                {
                    denom: '4',
                    exponent: 0
                },
                {
                    denom: 'ksm',
                    exponent: 12
                }
            ],
            typeAsset: 'substrate',
            base: '4',
            name: 'Kusama',
            display: 'ksm',
            symbol: 'KSM',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'kusama',
                        baseDenom: 'Planck'
                    },
                    provider: 'Kusama Parachain'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'kusama',
                        baseDenom: 'Planck'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/kusama/images/ksm.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/kusama/images/ksm.svg'
            }
        },
        {
            denomUnits: [
                {
                    denom: '79228162514264337593543950342',
                    exponent: 0
                },
                {
                    denom: 'dot',
                    exponent: 10
                }
            ],
            typeAsset: 'substrate',
            base: '79228162514264337593543950342',
            name: 'Polkadot',
            display: 'dot',
            symbol: 'DOT',
            traces: [
                {
                    type: 'ibc-bridge',
                    counterparty: {
                        chainName: 'composablepolkadot',
                        baseDenom: '79228162514264337593543950342',
                        channelId: 'channel-15'
                    },
                    chain: {
                        channelId: 'channel-15',
                        path: 'transfer/channel-15/79228162514264337593543950342'
                    },
                    provider: 'Picasso'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'composablepolkadot',
                        baseDenom: '79228162514264337593543950342'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                    theme: {
                        primaryColorHex: '#e4047c'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
            }
        },
        {
            denomUnits: [
                {
                    denom: '130',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            typeAsset: 'substrate',
            base: '130',
            name: 'Statemine',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'statemine',
                        baseDenom: '130'
                    },
                    provider: 'Kusama Parachain'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'statemine',
                        baseDenom: '130'
                    }
                }
            ]
        },
        {
            denomUnits: [
                {
                    denom: '2125',
                    exponent: 0
                },
                {
                    denom: 'TNKR',
                    exponent: 12
                }
            ],
            typeAsset: 'substrate',
            base: '2125',
            name: 'Tinkernet',
            display: 'TNKR',
            symbol: 'TNKR',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'tinkernet',
                        baseDenom: 'Planck'
                    },
                    provider: 'Tinkernet Parachain'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'tinkernet',
                        baseDenom: 'Planck'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/tinkernet/images/tnkr.svg'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/tinkernet/images/tnkr.svg'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'composable',
            clientId: '08-wasm-5',
            connectionId: 'connection-5'
        },
        chain2: {
            chainName: 'picasso',
            clientId: '07-tendermint-32',
            connectionId: 'connection-26'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-17',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'composablepolkadot',
            clientId: '10-grandpa-28',
            connectionId: 'connection-23'
        },
        chain2: {
            chainName: 'picasso',
            clientId: '10-grandpa-28',
            connectionId: 'connection-23'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'passage',
            clientId: '07-tendermint-8',
            connectionId: 'connection-8'
        },
        chain2: {
            chainName: 'picasso',
            clientId: '07-tendermint-225',
            connectionId: 'connection-118'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-7',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-80',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/ibc-data.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'composablepolkadot',
    assets: [
        {
            denomUnits: [
                {
                    denom: '79228162514264337593543950342',
                    exponent: 0
                },
                {
                    denom: 'dot',
                    exponent: 10
                }
            ],
            typeAsset: 'substrate',
            base: '79228162514264337593543950342',
            name: 'Polkadot',
            display: 'dot',
            symbol: 'DOT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'polkadot',
                        baseDenom: 'Planck'
                    },
                    provider: 'Polkadot Parachain'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'polkadot',
                        baseDenom: 'Planck'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                    theme: {
                        primaryColorHex: '#e4047c'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'composablepolkadot',
            clientId: '10-grandpa-28',
            connectionId: 'connection-23'
        },
        chain2: {
            chainName: 'picasso',
            clientId: '10-grandpa-28',
            connectionId: 'connection-23'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-15',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/ibc-data.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'penumbra',
    assets: [
        {
            description: 'The native token of Penumbra.',
            extendedDescription: 'A fully private, cross-chain proof-of-stake network and decentralized exchange for the Cosmos and beyond.',
            denomUnits: [
                {
                    denom: 'upenumbra',
                    exponent: 0
                },
                {
                    denom: 'penumbra',
                    exponent: 6
                }
            ],
            typeAsset: 'unknown',
            base: 'upenumbra',
            display: 'penumbra',
            symbol: 'UM',
            name: 'Penumbra',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/penumbra/images/um.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/penumbra/images/um.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#c7b07f'
                    }
                }
            ],
            socials: {
                website: 'https://penumbra.zone/',
                twitter: 'https://twitter.com/penumbrazone'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'neutron',
            clientId: '07-tendermint-137',
            connectionId: 'connection-98'
        },
        chain2: {
            chainName: 'penumbra',
            clientId: '07-tendermint-9',
            connectionId: 'connection-7'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4886',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosis',
            clientId: '07-tendermint-3242',
            connectionId: 'connection-2730'
        },
        chain2: {
            chainName: 'penumbra',
            clientId: '07-tendermint-4',
            connectionId: 'connection-4'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-79703',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/ibc-data.js [app-client] (ecmascript)");
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/0l/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: '0l',
    assets: [
        {
            description: 'The native token of 0L Network',
            extendedDescription: 'Libra Coin is a fork from Facebook\'s Diem (Libra) blockchain that was announced in 2019. Libra Coin operates on its own high-performance Layer 1 blockchain, known as the 0L Network. In October 2021, Libra Coin began mining.\n\n Like Bitcoin, there were no pre-mined coins or dedicated token allocation to any parties; all coins were minted through a mining process. Unlike Bitcoin, which undergoes continuous issuance, Libra Coin has a fixed supply. By December 2023, all the Libra Coin had been issued, establishing a capped supply and making the coin permanently deflationary.\n\n Fiercely independent, the project has a long-term view because it is unburdened by venture capital funding, labs entities, a foundation, and the influence of other blockchain ecosystems. Carpe diem.',
            denomUnits: [
                {
                    denom: 'microlibra',
                    exponent: 0
                },
                {
                    denom: 'libra',
                    exponent: 6
                }
            ],
            typeAsset: 'unknown',
            base: 'microlibra',
            name: 'Libra Coin',
            display: 'libra',
            symbol: 'LIBRA',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/0l/images/libra.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/0l/images/libra.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/0l/images/libra.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/0l/images/libra.svg',
                    theme: {
                        primaryColorHex: '#e45c5c'
                    }
                }
            ],
            coingeckoId: 'libra-3',
            socials: {
                website: 'https://0l.network/',
                twitter: 'https://twitter.com/0LNetwork'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/0l/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$0l$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/0l/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$0l$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/aptos/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'aptos',
    assets: [
        {
            description: 'Aptos token (APT) is the Aptos blockchain native token used for paying network and transaction fees.',
            denomUnits: [
                {
                    denom: '0x1::aptos_coin::AptosCoin',
                    exponent: 0,
                    aliases: [
                        'Octa'
                    ]
                },
                {
                    denom: 'APT',
                    exponent: 8
                }
            ],
            typeAsset: 'unknown',
            base: '0x1::aptos_coin::AptosCoin',
            name: 'Aptos Coin',
            display: 'APT',
            symbol: 'APT',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/aptos/images/aptos.svg'
            },
            coingeckoId: 'aptos',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/aptos/images/aptos.svg'
                },
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/aptos/images/apt-dm.svg',
                    theme: {
                        darkMode: true
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/aptos/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$aptos$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/aptos/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$aptos$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/arbitrum/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'arbitrum',
    assets: [
        {
            description: 'The governance token of Arbitrum',
            extendedDescription: 'Arbitrum is a Layer 2 scaling solution for Ethereum, enhancing transaction speed and reducing costs. Built to support smart contracts and decentralized applications (dApps), Arbitrum aims to improve scalability while maintaining compatibility with Ethereum\'s ecosystem.',
            typeAsset: 'erc20',
            address: '0x912CE59144191C1204E64559FE8253a0e49E6548',
            denomUnits: [
                {
                    denom: '0x912CE59144191C1204E64559FE8253a0e49E6548',
                    exponent: 0,
                    aliases: [
                        'arb-wei'
                    ]
                },
                {
                    denom: 'arb',
                    exponent: 18
                }
            ],
            base: '0x912CE59144191C1204E64559FE8253a0e49E6548',
            name: 'Arbitrum',
            display: 'arb',
            symbol: 'ARB',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/arbitrum/images/arb.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/arbitrum/images/arb.svg'
            },
            coingeckoId: 'arbitrum',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/arbitrum/images/arb.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/arbitrum/images/arb.svg',
                    theme: {
                        primaryColorHex: '#253545'
                    }
                }
            ]
        },
        {
            description: 'Ether (ETH) is the native currency of Arbitrum.',
            typeAsset: 'evm-base',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'eth',
                    exponent: 18
                }
            ],
            base: 'wei',
            display: 'eth',
            name: 'Ether',
            symbol: 'ETH',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    provider: 'Arbitrum Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            description: 'wETH is \'wrapped ETH\'',
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
                    exponent: 0
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            address: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
            base: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
            display: 'weth',
            name: 'Wrapped Ether',
            symbol: 'WETH',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'arbitrum',
                        baseDenom: 'wei'
                    },
                    provider: 'Arbitrum'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                },
                {
                    imageSync: {
                        chainName: 'arbitrum',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0xab19bdaeb37242fa0f30486195f45b9cf5361b78',
                    exponent: 0
                }
            ],
            address: '0xab19bdaeb37242fa0f30486195f45b9cf5361b78',
            base: '0xab19bdaeb37242fa0f30486195f45b9cf5361b78',
            display: '0xab19bdaeb37242fa0f30486195f45b9cf5361b78',
            name: 'cGLP',
            symbol: 'cGLP'
        },
        {
            description: 'USDC issued on Arbitrum.',
            typeAsset: 'erc20',
            address: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
            denomUnits: [
                {
                    denom: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                }
            ],
            coingeckoId: 'usd-coin',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'This is a bridged USDC token deployed by Arbitrum Foundation.',
            typeAsset: 'erc20',
            address: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            denomUnits: [
                {
                    denom: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8',
            name: 'Bridged USDC',
            display: 'usdc',
            symbol: 'USDC.e',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Arbitrum Bridge'
                }
            ],
            coingeckoId: 'usd-coin-ethereum-bridged',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDT from Ethereum bridged to Arbitrum via Arbitrum Bridge.',
            typeAsset: 'erc20',
            address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
            denomUnits: [
                {
                    denom: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
            name: 'Arbitrum Bridged USDT',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Arbitrum Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/arbitrum/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$arbitrum$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/arbitrum/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$arbitrum$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avail/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'avail',
    assets: [
        {
            description: 'Avail is a web3 infrastructure layer that allows modular execution layers to scale and interoperate in a trust minimized way.',
            extendedDescription: 'Avail is a unification layer for Web3 that decouples the data availability layer, making it easier for developers to focus on execution and settlement. It\'s built to make applications fast, efficient, and scalable. Avail works with any execution environment designed to scale blockchains. ',
            typeAsset: 'unknown',
            denomUnits: [
                {
                    denom: 'avail',
                    exponent: 0
                },
                {
                    denom: 'AVAIL',
                    exponent: 18
                }
            ],
            base: 'avail',
            name: 'Avail',
            display: 'AVAIL',
            symbol: 'AVAIL',
            coingeckoId: 'avail',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avail/images/avail.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avail/images/avail.png',
                    theme: {
                        circle: false,
                        primaryColorHex: '#2B80D7'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avail/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avail$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avail/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avail$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanche/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'avalanche',
    assets: [
        {
            description: 'Avalanche is a high-performance blockchain platform known for its fast transaction speeds, low costs, and scalability, ideal for decentralized applications and custom blockchain networks.',
            extendedDescription: 'Avalanche is a blockchain platform developed by Ava Labs that aims to provide a highly scalable and efficient environment for decentralized applications (dApps) and custom blockchain networks. Launched in 2020, Avalanche uses a novel consensus protocol called Avalanche Consensus, which allows it to process thousands of transactions per second with near-instant finality. The platform\'s architecture includes three built-in blockchains: the Exchange Chain (X-Chain), the Contract Chain (C-Chain), and the Platform Chain (P-Chain), each serving different purposes such as asset creation, smart contracts, and coordination of validators and subnets. Avalanche supports interoperability with Ethereum and other blockchains through its Avalanche Bridge and other cross-chain bridges. The native token, AVAX, is used for transaction fees, staking, and governance, making it an integral part of the Avalanche ecosystem.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'avax',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Avalanche',
            display: 'avax',
            symbol: 'AVAX',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.svg'
            },
            coingeckoId: 'avalanche-2',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.svg',
                    theme: {
                        primaryColorHex: '#eb4444'
                    }
                }
            ]
        },
        {
            description: 'The wrapped ERC-20 representation of AVAX, the native token of Avalanche.',
            typeAsset: 'erc20',
            address: '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7',
            denomUnits: [
                {
                    denom: '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7',
                    exponent: 0,
                    aliases: [
                        'wavax-wei'
                    ]
                },
                {
                    denom: 'wavax',
                    exponent: 18
                }
            ],
            base: '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7',
            name: 'Wrapped AVAX',
            display: 'wavax',
            symbol: 'WAVAX',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'avalanche',
                        baseDenom: 'wei'
                    },
                    provider: 'Avalanche'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/wavax.svg'
            },
            coingeckoId: 'wrapped-avax',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/wavax.svg'
                }
            ]
        },
        {
            description: 'USDC issued on Avalanche.',
            typeAsset: 'erc20',
            address: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
            denomUnits: [
                {
                    denom: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            coingeckoId: 'usd-coin',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDC Bridged from Ethereum via Avalanche Bridge.',
            typeAsset: 'erc20',
            address: '0xa7d7079b0fead91f3e65f86e8915cb59c1a4c664',
            denomUnits: [
                {
                    denom: '0xa7d7079b0fead91f3e65f86e8915cb59c1a4c664',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0xa7d7079b0fead91f3e65f86e8915cb59c1a4c664',
            name: 'Bridged USDC',
            display: 'usdc',
            symbol: 'USDC.e',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Avalanche Bridge'
                }
            ],
            coingeckoId: 'usd-coin-avalanche-bridged-usdc-e',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'Multi-Collateral Dai, brings a lot of new and exciting features, such as support for new CDP collateral types and Dai Savings Rate.',
            typeAsset: 'erc20',
            address: '0xc5fa5669e326da8b2c35540257cd48811f40a36b',
            denomUnits: [
                {
                    denom: '0xc5fa5669e326da8b2c35540257cd48811f40a36b',
                    exponent: 0,
                    aliases: [
                        'dai-wei'
                    ]
                },
                {
                    denom: 'axldai',
                    exponent: 18
                }
            ],
            base: '0xc5fa5669e326da8b2c35540257cd48811f40a36b',
            name: 'Axelar Wrapped DAI',
            display: 'axldai',
            symbol: 'axlDAI',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'dai-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
                }
            ]
        },
        {
            description: 'Frax is a fractional-algorithmic stablecoin protocol. It aims to provide a highly scalable, decentralized, algorithmic money in place of fixed-supply assets like BTC. Additionally, FXS is the value accrual and governance token of the entire Frax ecosystem.',
            typeAsset: 'erc20',
            address: '0x4914886dbb8aad7a7456d471eaab10b06d42348d',
            denomUnits: [
                {
                    denom: '0x4914886dbb8aad7a7456d471eaab10b06d42348d',
                    exponent: 0,
                    aliases: [
                        'frax-wei'
                    ]
                },
                {
                    denom: 'axlfrax',
                    exponent: 18
                }
            ],
            base: '0x4914886dbb8aad7a7456d471eaab10b06d42348d',
            name: 'Axelar Wrapped Frax',
            display: 'axlfrax',
            symbol: 'axlFRAX',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0xfab550568C688d5d8a52c7d794cb93edc26ec0ec',
            denomUnits: [
                {
                    denom: '0xfab550568C688d5d8a52c7d794cb93edc26ec0ec',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0xfab550568C688d5d8a52c7d794cb93edc26ec0ec',
            name: 'Axelar Wrapped USDC',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'Tether gives you the joint benefits of open blockchain technology and traditional currency by converting your cash into a stable digital currency equivalent.',
            typeAsset: 'erc20',
            address: '0xf976ba91b6bb3468c91e4f02e68b37bc64a57e66',
            denomUnits: [
                {
                    denom: '0xf976ba91b6bb3468c91e4f02e68b37bc64a57e66',
                    exponent: 0,
                    aliases: [
                        'uusdt'
                    ]
                },
                {
                    denom: 'axlusdt',
                    exponent: 6
                }
            ],
            base: '0xf976ba91b6bb3468c91e4f02e68b37bc64a57e66',
            name: 'Axelar Wrapped USDT',
            display: 'axlusdt',
            symbol: 'axlUSDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        },
        {
            description: 'USDT issued on Avalanche.',
            typeAsset: 'erc20',
            address: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
            denomUnits: [
                {
                    denom: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
            name: 'Tether USD',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Tether'
                }
            ],
            coingeckoId: 'tether',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanche/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanche$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanche/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanche$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/base/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'base',
    assets: [
        {
            description: 'Ether (ETH) is the native currency of Base.',
            typeAsset: 'evm-base',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'eth',
                    exponent: 18
                }
            ],
            base: 'wei',
            display: 'eth',
            name: 'Ether',
            symbol: 'ETH',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    provider: 'Base Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            description: 'wETH is \'wrapped ETH\'',
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0x4200000000000000000000000000000000000006',
                    exponent: 0
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            address: '0x4200000000000000000000000000000000000006',
            base: '0x4200000000000000000000000000000000000006',
            display: 'weth',
            name: 'Wrapped Ether',
            symbol: 'WETH',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'base',
                        baseDenom: 'wei'
                    },
                    provider: 'Base'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                },
                {
                    imageSync: {
                        chainName: 'base',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            description: 'USDC issued on Base.',
            typeAsset: 'erc20',
            address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
            denomUnits: [
                {
                    denom: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            coingeckoId: 'usd-coin',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDC Bridged from Ethereum via Base Bridge.',
            typeAsset: 'erc20',
            address: '0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA',
            denomUnits: [
                {
                    denom: '0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0xd9aAEc86B65D86f6A7B5B1b0c42FFA531710b6CA',
            name: 'USD Base Coin',
            display: 'usdc',
            symbol: 'USDbC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Base Bridge'
                }
            ],
            coingeckoId: 'bridged-usd-coin-base',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'Coinbase Wrapped BTC (\'cbBTC\') is an ERC20 token that is backed 1:1 by Bitcoin (BTC) held by Coinbase. cbBTC is built to be seamlessly compatible with DeFi applications, giving customers the option to tap into DeFi and unlock financial utility.',
            typeAsset: 'erc20',
            address: '0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf',
            denomUnits: [
                {
                    denom: '0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf',
                    exponent: 0
                },
                {
                    denom: 'cbbtc',
                    exponent: 8
                }
            ],
            base: '0xcbB7C0000aB88B473b1f5aFd9ef808440eed33Bf',
            name: 'Coinbase Wrapped BTC',
            display: 'cbbtc',
            symbol: 'cbBTC',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    provider: 'Coinbase'
                }
            ],
            coingeckoId: 'coinbase-wrapped-btc',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/base/images/cbbtc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/base/images/cbbtc.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#0052FF'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/base/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$base$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/base/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$base$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchain/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'binancesmartchain',
    assets: [
        {
            description: 'BNB is the native cryptocurrency of the Binance exchange, used to pay for transaction fees and participate in various features and services within the Binance ecosystem.',
            extendedDescription: 'BNB, or Binance Coin, is the native cryptocurrency of the Binance exchange, one of the largest cryptocurrency exchanges in the world. Initially launched as an ERC-20 token on the Ethereum blockchain in 2017, BNB has since migrated to Binance\'s own blockchain, the Binance Chain. BNB was created to facilitate various operations on the Binance platform, such as reducing transaction fees for traders when paid with BNB, participating in token sales on Binance Launchpad, and more. Over time, the utility of BNB has expanded beyond the Binance platform, with it being used in a variety of applications including payment for goods and services, online and offline, and even for booking travel arrangements through partners.\n\nIn addition to its wide range of uses, BNB has a unique deflationary mechanism known as coin burns. Binance commits to using 20% of its profits each quarter to buy back and burn BNB, effectively reducing the total supply over time and increasing its scarcity. This mechanism is aimed at boosting the value of BNB by controlling its supply. The ongoing development of the Binance Smart Chain (BSC), a parallel blockchain that runs smart contracts and is compatible with the Ethereum Virtual Machine (EVM), further enhances BNB\'s utility by supporting decentralized finance (DeFi) applications and other blockchain-based projects. BNB\'s role in both the Binance ecosystem and the broader crypto market continues to grow, making it a significant asset in the cryptocurrency space.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'bnb',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Binance Coin',
            display: 'bnb',
            symbol: 'BNB',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.svg'
            },
            coingeckoId: 'binancecoin',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.svg',
                    theme: {
                        primaryColorHex: '#f3bb0c'
                    }
                }
            ]
        },
        {
            description: 'Wrapped BNB. As the native coin of Binance Chain, BNB has multiple use cases: fueling transactions on the Chain, paying for transaction fees on Binance Exchange, making in-store payments, and many more.',
            typeAsset: 'erc20',
            address: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
            denomUnits: [
                {
                    denom: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
                    exponent: 0
                },
                {
                    denom: 'wbnb',
                    exponent: 18
                }
            ],
            base: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
            name: 'Wrapped BNB',
            display: 'wbnb',
            symbol: 'WBNB',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'binancesmartchain',
                        baseDenom: 'wei'
                    },
                    chain: {
                        contract: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c'
                    },
                    provider: 'Binance'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.svg'
            },
            coingeckoId: 'wbnb',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.svg',
                    theme: {
                        primaryColorHex: '#f3bb0c'
                    }
                }
            ]
        },
        {
            description: 'BUSD is a 1:1 USD-backed stablecoin approved by NYDFS and issued by Paxos on Ethereum. Binance provides Binance-Peg BUSD on other chains by locking an equivalent amount of assets on Ethereum. Note that Binance-Peg BUSD is provided by Binance, which is not issued by Paxos nor regulated by the NYDFS.',
            denomUnits: [
                {
                    denom: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
                    exponent: 0
                },
                {
                    denom: 'busd',
                    exponent: 18
                }
            ],
            typeAsset: 'erc20',
            address: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
            base: '0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56',
            name: 'Binance-Peg BUSD Token',
            display: 'busd',
            symbol: 'BUSD',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Binance'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/busd.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/busd.png',
                    theme: {
                        primaryColorHex: '#f3bb0c'
                    }
                }
            ]
        },
        {
            description: 'USD Coin (known by its ticker USDC) is a stablecoin that is pegged to the U.S. dollar on a 1:1 basis.',
            denomUnits: [
                {
                    denom: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
                    exponent: 0
                },
                {
                    denom: 'usdc',
                    exponent: 18
                }
            ],
            typeAsset: 'erc20',
            address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
            base: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
            name: 'Binance-Peg USD Coin',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x4fabb145d64652a948d72533023f6e7a623c7c53'
                    },
                    provider: 'Binance'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'PURSE Token',
            denomUnits: [
                {
                    denom: '0x29a63F4B209C29B4DC47f06FFA896F32667DAD2C',
                    exponent: 0
                },
                {
                    denom: 'PURSE',
                    exponent: 18
                }
            ],
            typeAsset: 'erc20',
            address: '0x29a63F4B209C29B4DC47f06FFA896F32667DAD2C',
            base: '0x29a63F4B209C29B4DC47f06FFA896F32667DAD2C',
            name: 'PURSE Token',
            display: 'PURSE',
            symbol: 'PURSE',
            coingeckoId: 'pundi-x-purse',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/pundix/images/purse-token-logo.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/pundix/images/purse-token-logo.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/pundix/images/purse-token-logo.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/pundix/images/purse-token-logo.svg',
                    theme: {
                        primaryColorHex: '#1c1c1b'
                    }
                }
            ]
        },
        {
            description: 'The SRCX token of Source Protocol.',
            denomUnits: [
                {
                    denom: '0x454b90716a9435e7161a9aea5cf00e0acbe565ae',
                    exponent: 0
                },
                {
                    denom: 'srcx',
                    exponent: 9
                }
            ],
            typeAsset: 'erc20',
            address: '0x454b90716a9435e7161a9aea5cf00e0acbe565ae',
            base: '0x454b90716a9435e7161a9aea5cf00e0acbe565ae',
            name: 'Source Token',
            display: 'srcx',
            symbol: 'SRCX',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/srcx.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/srcx.png',
                    theme: {
                        primaryColorHex: '#7f22bc'
                    }
                }
            ]
        },
        {
            description: 'BUSD-T gives you the joint benefits of open blockchain technology and traditional currency by converting your cash into a stable digital currency equivalent.',
            typeAsset: 'erc20',
            address: '0x55d398326f99059fF775485246999027B3197955',
            denomUnits: [
                {
                    denom: '0x55d398326f99059fF775485246999027B3197955',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0x55d398326f99059fF775485246999027B3197955',
            name: 'Binance Bridged USDT',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Binance Bridge'
                }
            ],
            coingeckoId: 'binance-bridged-usdt-bnb-smart-chain',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchain/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchain$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchain/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchain$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoin/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'bitcoin',
    assets: [
        {
            description: 'Bitcoin, the first and most well-known cryptocurrency, allows decentralized peer-to-peer transactions on a secure blockchain network, serving as "digital gold."',
            extendedDescription: 'Bitcoin, often referred to as BTC, is the first and most well-known cryptocurrency, introduced in 2009 by an anonymous entity known as Satoshi Nakamoto. It was designed as a decentralized digital currency, allowing peer-to-peer transactions without the need for a central authority or intermediary. Bitcoin operates on a technology called blockchain, a distributed ledger that records all transactions across a network of computers. The security and integrity of the blockchain are maintained through a process called mining, where participants solve complex mathematical problems to validate and add new transactions to the blockchain. Bitcoin\'s decentralized nature and limited supply, capped at 21 million coins, have contributed to its status as "digital gold" and a store of value.\n\nBitcoin has significantly influenced the financial world, inspiring the development of thousands of other cryptocurrencies and blockchain technologies. Its adoption has grown over the years, with numerous merchants and service providers accepting it as a payment method. Additionally, Bitcoin has become a popular investment asset, attracting both individual and institutional investors. Despite its volatility and regulatory challenges, Bitcoin remains a dominant force in the crypto space, symbolizing the potential for a more open and inclusive financial system. Its impact extends beyond finance, as it continues to drive innovation in areas such as decentralized finance (DeFi), supply chain management, and digital identity verification.',
            denomUnits: [
                {
                    denom: 'sat',
                    exponent: 0
                },
                {
                    denom: 'btc',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'sat',
            name: 'Bitcoin',
            display: 'btc',
            symbol: 'BTC',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.svg'
            },
            coingeckoId: 'bitcoin',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.png',
                    theme: {
                        primaryColorHex: '#f4941c',
                        backgroundColorHex: '#f4941c',
                        circle: true
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoin/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoin/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincash/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'bitcoincash',
    assets: [
        {
            description: 'Bitcoin Cash (BCH) is a digital coin designed for quick and cost-effective transactions.',
            extendedDescription: 'Bitcoin Cash (BCH) is a peer-to-peer cryptocurrency that was created as a fork of Bitcoin (BTC) in 2017 to address scalability issues. It increases transaction throughput by allowing larger block sizes, enabling faster and cheaper transactions compared to Bitcoin. Bitcoin Cash aims to serve as a more practical digital cash for everyday use, prioritizing efficiency and low fees in financial transactions on a global scale.',
            denomUnits: [
                {
                    denom: 'sat',
                    exponent: 0
                },
                {
                    denom: 'bch',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'sat',
            name: 'Bitcoin Cash',
            display: 'bch',
            symbol: 'BCH',
            coingeckoId: 'bitcoin-cash',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoincash/images/bch.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoincash/images/bch.png',
                    theme: {
                        primaryColorHex: '#0AC18E',
                        circle: true
                    }
                }
            ],
            socials: {
                website: 'https://bitcoincash.org/',
                twitter: 'https://x.com/bitcoincashorg'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincash/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincash$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincash/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincash$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/comex/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'comex',
    assets: [
        {
            typeAsset: 'unknown',
            denomUnits: [
                {
                    denom: 'XAU',
                    exponent: 0
                }
            ],
            base: 'XAU',
            display: 'XAU',
            name: 'Gold',
            symbol: 'XAU'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/comex/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$comex$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/comex/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$comex$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecoin/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'dogecoin',
    assets: [
        {
            description: 'The native token of Dogecoin.',
            extendedDescription: 'Dogecoin (DOGE) is a cryptocurrency created as a playful homage, known for its friendly community, Shiba Inu meme origins, and accessible, fast transactions.',
            denomUnits: [
                {
                    denom: 'shibe',
                    exponent: 0
                },
                {
                    denom: 'doge',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'shibe',
            name: 'Dogecoin',
            display: 'doge',
            symbol: 'DOGE',
            coingeckoId: 'dogecoin',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/dogecoin/images/doge.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/dogecoin/images/doge.png',
                    theme: {
                        primaryColorHex: '#bda148'
                    }
                }
            ],
            socials: {
                website: 'https://dogecoin.com/',
                twitter: 'https://x.com/dogecoin'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecoin/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecoin/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantom/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'fantom',
    assets: [
        {
            description: 'Fantom\'s native utility token — FTM — powers the entire Fantom blockchain ecosystem. FTM tokens are used for staking, governance, payments, and fees on the network.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'ftm',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Fantom',
            display: 'ftm',
            symbol: 'FTM',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.svg'
            },
            coingeckoId: 'fantom',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.svg',
                    theme: {
                        primaryColorHex: '#1c6cfc'
                    }
                }
            ]
        },
        {
            description: 'ERC20 wrapped version of FTM',
            typeAsset: 'erc20',
            address: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83',
            denomUnits: [
                {
                    denom: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83',
                    exponent: 0
                },
                {
                    denom: 'wftm',
                    exponent: 18
                }
            ],
            base: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83',
            name: 'Wrapped Fantom',
            display: 'wftm',
            symbol: 'WFTM',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'fantom',
                        baseDenom: 'wei'
                    },
                    chain: {
                        contract: '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83'
                    },
                    provider: 'Fantom'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'fantom',
                        baseDenom: 'wei'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.svg',
                    theme: {
                        primaryColorHex: '#1c6cfc'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.svg'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantom/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantom$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantom/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantom$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/filecoin/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'filecoin',
    assets: [
        {
            description: 'Filecoin is a decentralized storage network designed to turn cloud storage into an algorithmic market. The network facilitates open markets for storing and retrieving data, where users pay to store their files on storage miners. Filecoin is built on top of the InterPlanetary File System (IPFS), a peer-to-peer storage network. Filecoin aims to store data in a decentralized manner, unlike traditional cloud storage providers.\n\nParticipants in the Filecoin network are incentivized to act honestly and store as much data as possible because they earn the Filecoin cryptocurrency (FIL) in exchange for their storage services. This setup ensures the integrity and accessibility of data stored. Filecoin\'s model allows for a variety of storage options, including long-term archival storage and more rapid retrieval services, making it a versatile solution for decentralized data storage. The project, developed by Protocol Labs, also focuses on ensuring that data is stored reliably and efficiently.',
            denomUnits: [
                {
                    denom: 'attoFIL',
                    exponent: 0,
                    aliases: [
                        'fil-wei'
                    ]
                },
                {
                    denom: 'fil',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'attoFIL',
            name: 'Filecoin',
            display: 'fil',
            symbol: 'FIL',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/fil.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/fil.svg'
            },
            coingeckoId: 'filecoin',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/fil.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/fil.svg',
                    theme: {
                        primaryColorHex: '#0493fc'
                    }
                }
            ]
        },
        {
            description: 'Wrapped Filecoin, ERC20 Wrapper over Filecoin',
            address: '0x60E1773636CF5E4A227d9AC24F20fEca034ee25A',
            denomUnits: [
                {
                    denom: '0x60E1773636CF5E4A227d9AC24F20fEca034ee25A',
                    exponent: 0,
                    aliases: [
                        'wfil-wei'
                    ]
                },
                {
                    denom: 'wfil',
                    exponent: 18
                }
            ],
            typeAsset: 'erc20',
            base: '0x60E1773636CF5E4A227d9AC24F20fEca034ee25A',
            name: 'Wrapped FIL',
            display: 'wfil',
            symbol: 'WFIL',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'filecoin',
                        baseDenom: 'attoFIL'
                    },
                    provider: 'Filecoin'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/wfil.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/wfil.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/wfil.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/filecoin/images/wfil.svg',
                    theme: {
                        primaryColorHex: '#0694fc'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/filecoin/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$filecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/filecoin/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$filecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/forex/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'forex',
    assets: [
        {
            typeAsset: 'unknown',
            denomUnits: [
                {
                    denom: 'USD',
                    exponent: 0
                }
            ],
            base: 'USD',
            display: 'USD',
            name: 'United States Dollar',
            symbol: 'USD'
        },
        {
            typeAsset: 'unknown',
            denomUnits: [
                {
                    denom: 'EUR',
                    exponent: 0
                }
            ],
            base: 'EUR',
            display: 'EUR',
            name: 'Euro',
            symbol: 'EUR'
        },
        {
            typeAsset: 'unknown',
            denomUnits: [
                {
                    denom: 'BRL',
                    exponent: 0
                }
            ],
            base: 'BRL',
            display: 'BRL',
            name: 'Brazilian Real',
            symbol: 'BRL'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/forex/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$forex$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/forex/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$forex$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/internetcomputer/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'internetcomputer',
    assets: [
        {
            description: 'The native token of Internet Computer',
            extendedDescription: 'The Internet Computer blockchain incorporates a radical rethink of blockchain design, powered by innovations in cryptography. It provides the first “World Computer” blockchain that can be used to build almost any Web 2.0 online system or service, and web3 services, including web3 social media services, without any need for centralized traditional IT such as cloud computing services. It also enables smart contracts it hosts to directly create transactions on other blockchains, which in turn enables the full end-to-end decentralization of online services and web3 for the first time.',
            denomUnits: [
                {
                    denom: 'e8s',
                    exponent: 0
                },
                {
                    denom: 'ICP',
                    exponent: 8
                }
            ],
            typeAsset: 'unknown',
            base: 'e8s',
            name: 'Internet Computer',
            display: 'ICP',
            symbol: 'ICP',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/internetcomputer/images/icp.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/internetcomputer/images/icp.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#29ABE2',
                        backgroundColorHex: '#E3E3E3'
                    }
                }
            ],
            coingeckoId: 'internet-computer',
            socials: {
                website: 'https://internetcomputer.org/',
                twitter: 'https://x.com/dfinity'
            }
        },
        {
            description: 'A multi-chain bitcoin twin, trustlessly created by chain-key cryptography and Internet Computer smart contracts that directly hold raw bitcoin.',
            extendedDescription: 'Chain-key Bitcoin (ckBTC) is an ICRC-2-compliant token that is backed 1:1 by BTC held 100% on the mainnet. ckBTC does not rely on a centralized bridge to facilitate the conversion between BTC and ckBTC, which makes it substantially more secure when compared to other traditional \'wrapped\' tokens.',
            denomUnits: [
                {
                    denom: 'uckBTC',
                    exponent: 0,
                    aliases: [
                        'sat'
                    ]
                },
                {
                    denom: 'ckBTC',
                    exponent: 8
                }
            ],
            typeAsset: 'unknown',
            base: 'uckBTC',
            name: 'Chain-key Bitcoin',
            display: 'ckBTC',
            symbol: 'ckBTC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    provider: 'Omnity Network'
                }
            ],
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/internetcomputer/images/ckbtc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/internetcomputer/images/ckbtc.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#3B00B9',
                        backgroundColorHex: '#3B00B9'
                    }
                }
            ],
            coingeckoId: 'chain-key-bitcoin',
            socials: {
                website: 'https://internetcomputer.org/ckbtc',
                twitter: 'https://x.com/dfinity'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/internetcomputer/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$internetcomputer$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/internetcomputer/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$internetcomputer$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/kusama/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'kusama',
    assets: [
        {
            description: 'The native fee, governance, staking, and bonding token of the Polkadot platform.',
            denomUnits: [
                {
                    denom: 'Planck',
                    exponent: 0
                },
                {
                    denom: 'Point',
                    exponent: 3
                },
                {
                    denom: 'uKSM',
                    exponent: 3,
                    aliases: [
                        'MicroKSM'
                    ]
                },
                {
                    denom: 'uKSM',
                    exponent: 3,
                    aliases: [
                        'MilliKSM'
                    ]
                },
                {
                    denom: 'KSM',
                    exponent: 12
                }
            ],
            typeAsset: 'substrate',
            base: 'Planck',
            name: 'Kusama',
            display: 'KSM',
            symbol: 'KSM',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/kusama/images/ksm.svg'
            },
            coingeckoId: 'kusama',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/kusama/images/ksm.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/kusama/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$kusama$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/kusama/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$kusama$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecoin/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'litecoin',
    assets: [
        {
            description: 'The currency of Litecoin.',
            extendedDescription: 'Litecoin (LTC) is a peer-to-peer cryptocurrency created in 2011 by Charlie Lee as a lighter alternative to Bitcoin. It features faster block generation times and a different hashing algorithm (Scrypt), allowing for quicker transaction processing and lower fees. Often referred to as the "silver to Bitcoin\'s gold," Litecoin is designed to provide a more efficient and accessible digital payment option.',
            denomUnits: [
                {
                    denom: 'litoshi',
                    exponent: 0
                },
                {
                    denom: 'ltc',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'litoshi',
            name: 'Litecoin',
            display: 'ltc',
            symbol: 'LTC',
            coingeckoId: 'litecoin',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/litecoin/images/ltc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/litecoin/images/ltc.png',
                    theme: {
                        primaryColorHex: '#345D9D',
                        circle: true
                    }
                }
            ],
            socials: {
                website: 'https://litecoin.org/',
                twitter: 'https://x.com/litecoin'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecoin/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecoin/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecoin$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/mantle/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'mantle',
    assets: [
        {
            description: 'Ignition introduces $FBTC, an omnichain Bitcoin asset pegged 1:1 to BTC, aimed at elevating Bitcoin�s accessibility and utility, paving the way for a low-friction and interoperable future.',
            extendedDescription: 'FBTC enhances Bitcoin utility beyond just a store of value, and elevates its power with an asset that commands ultimate liquidity across many chains and various yield enhancement options.\n\n\n\nFBTC uses reputable and trusted multisignature custody solutions, and employs Threshold Signature Scheme (TSS) Network to conduct minting and bridging.\n\nFBTC is seamlessly interoperable to enable a wide range of use cases on L1s and L2s.\n\nFBTC brings an impressive slate of prominent strategic partnerships with industry leading institutions, blockchain ecosystems and infrastructure providers. FBTC will also be supported by many DeFi applications, CEXs and wallets.',
            typeAsset: 'erc20',
            address: '0xC96dE26018A54D51c097160568752c4E3BD6C364',
            denomUnits: [
                {
                    denom: '0xC96dE26018A54D51c097160568752c4E3BD6C364',
                    exponent: 0
                },
                {
                    denom: 'fbtc',
                    exponent: 8
                }
            ],
            base: '0xC96dE26018A54D51c097160568752c4E3BD6C364',
            name: 'Fire Bitcoin',
            display: 'fbtc',
            symbol: 'FBTC',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    provider: 'Ignition'
                }
            ],
            coingeckoId: 'ignition-fbtc',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/mantle/images/fbtc.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/mantle/images/fbtc.svg',
                    theme: {
                        circle: false,
                        primaryColorHex: '#8F00FF',
                        backgroundColorHex: '#00000000'
                    }
                }
            ],
            socials: {
                website: 'https://fbtc.com/',
                twitter: 'https://twitter.com/fbtc_official'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/mantle/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$mantle$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/mantle/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$mantle$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeam/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'moonbeam',
    assets: [
        {
            description: 'Glimmer (GLMR) is the utility token of the Moonbeam Network, Moonbeam’s primary deployment on the Polkadot network that serves as a developer-friendly parachain.',
            denomUnits: [
                {
                    denom: 'Wei',
                    exponent: 0,
                    aliases: [
                        'wei'
                    ]
                },
                {
                    denom: 'GLMR',
                    exponent: 18,
                    aliases: [
                        'glmr'
                    ]
                }
            ],
            typeAsset: 'substrate',
            base: 'Wei',
            name: 'Glimmer',
            display: 'GLMR',
            symbol: 'GLMR',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
            },
            coingeckoId: 'moonbeam',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg',
                    theme: {
                        primaryColorHex: '#e4147c'
                    }
                }
            ]
        },
        {
            description: 'An ERC-20 representation of GLMR, the native token of Moonbeam.',
            typeAsset: 'erc20',
            address: '0xacc15dc74880c9944775448304b263d191c6077f',
            denomUnits: [
                {
                    denom: '0xacc15dc74880c9944775448304b263d191c6077f',
                    exponent: 0,
                    aliases: [
                        'wglmr-wei'
                    ]
                },
                {
                    denom: 'wglmr',
                    exponent: 18
                }
            ],
            base: '0xacc15dc74880c9944775448304b263d191c6077f',
            name: 'Wrapped Moonbeam',
            display: 'wglmr',
            symbol: 'WGLMR',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'moonbeam',
                        baseDenom: 'Wei'
                    },
                    provider: 'Moonbeam'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
            },
            coingeckoId: 'wrapped-moonbeam',
            images: [
                {
                    imageSync: {
                        chainName: 'moonbeam',
                        baseDenom: 'Wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.png',
                    theme: {
                        primaryColorHex: '#e4147c'
                    }
                }
            ]
        },
        {
            description: 'Polkadot is a blockchain network designed to support various interconnected, application-specific sub-chains. Each chain built within Polkadot uses Parity Technologies\' Substrate modular framework, which allows developers to select specific components that suit their application-specific chain best.',
            typeAsset: 'erc20',
            address: '0xffffffff1fcacbd218edc0eba20fc2308c778080',
            denomUnits: [
                {
                    denom: '0xffffffff1fcacbd218edc0eba20fc2308c778080',
                    exponent: 0,
                    aliases: [
                        'dot-planck'
                    ]
                },
                {
                    denom: 'xcdot',
                    exponent: 10
                }
            ],
            base: '0xffffffff1fcacbd218edc0eba20fc2308c778080',
            name: 'Wrapped Polkadot',
            display: 'xcdot',
            symbol: 'xcDOT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'polkadot',
                        baseDenom: 'Planck'
                    },
                    provider: 'Polkadot Parachain'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'polkadot',
                        baseDenom: 'Planck'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg',
                    theme: {
                        primaryColorHex: '#e4047c'
                    }
                }
            ]
        },
        {
            description: 'Multi-Collateral Dai, brings a lot of new and exciting features, such as support for new CDP collateral types and Dai Savings Rate.',
            typeAsset: 'erc20',
            address: '0x14df360966a1c4582d2b18edbdae432ea0a27575',
            denomUnits: [
                {
                    denom: '0x14df360966a1c4582d2b18edbdae432ea0a27575',
                    exponent: 0,
                    aliases: [
                        'dai-wei'
                    ]
                },
                {
                    denom: 'axldai',
                    exponent: 18
                }
            ],
            base: '0x14df360966a1c4582d2b18edbdae432ea0a27575',
            name: 'Axelar Wrapped Dai Stablecoin',
            display: 'axldai',
            symbol: 'axlDAI',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'dai-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
                }
            ]
        },
        {
            description: 'Frax is a fractional-algorithmic stablecoin protocol. It aims to provide a highly scalable, decentralized, algorithmic money in place of fixed-supply assets like BTC. Additionally, FXS is the value accrual and governance token of the entire Frax ecosystem.',
            typeAsset: 'erc20',
            address: '0x61C82805453a989E99B544DFB7031902e9bac448',
            denomUnits: [
                {
                    denom: '0x61C82805453a989E99B544DFB7031902e9bac448',
                    exponent: 0,
                    aliases: [
                        'frax-wei'
                    ]
                },
                {
                    denom: 'axlfrax',
                    exponent: 18
                }
            ],
            base: '0x61C82805453a989E99B544DFB7031902e9bac448',
            name: 'Axelar Wrapped Frax',
            display: 'axlfrax',
            symbol: 'axlFRAX',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0xca01a1d0993565291051daff390892518acfad3a',
            denomUnits: [
                {
                    denom: '0xca01a1d0993565291051daff390892518acfad3a',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0xca01a1d0993565291051daff390892518acfad3a',
            name: 'Axelar Wrapped USD Coin',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'Tether gives you the joint benefits of open blockchain technology and traditional currency by converting your cash into a stable digital currency equivalent.',
            typeAsset: 'erc20',
            address: '0xdfd74af792bc6d45d1803f425ce62dd16f8ae038',
            denomUnits: [
                {
                    denom: '0xdfd74af792bc6d45d1803f425ce62dd16f8ae038',
                    exponent: 0,
                    aliases: [
                        'uusdt'
                    ]
                },
                {
                    denom: 'axlusdt',
                    exponent: 6
                }
            ],
            base: '0xdfd74af792bc6d45d1803f425ce62dd16f8ae038',
            name: 'Axelar Wrapped Tether USD',
            display: 'axlusdt',
            symbol: 'axlUSDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeam/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeam$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeam/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeam$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/movement/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'movement',
    assets: [
        {
            description: 'The native currency of Movement Network',
            extendedDescription: 'Movement Network is an ecosystem of Modular Move-Based Blockchains that enables developers to build secure, performant, and interoperable blockchain applications, bridging the gap between Move and EVM ecosystems. Movement Network is the first Move-EVM L2 for Ethereum, alongside open-source tooling and protocols to facilitate the adoption of the Move programming language across blockchain ecosystems.',
            typeAsset: 'erc20',
            address: '0xa',
            denomUnits: [
                {
                    denom: '0xa',
                    exponent: 0,
                    aliases: [
                        'octa'
                    ]
                },
                {
                    denom: 'move',
                    exponent: 8
                }
            ],
            base: '0xa',
            name: 'Movement',
            display: 'move',
            symbol: 'MOVE',
            coingeckoId: 'movement',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/movement/images/move.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/movement/images/move.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#F1BB15'
                    }
                }
            ],
            socials: {
                website: 'https://www.movementnetwork.xyz/',
                twitter: 'https://twitter.com/movementfdn'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/movement/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$movement$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/movement/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$movement$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/neo/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'neo',
    assets: [
        {
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0x48c40d4666f93408be1bef038b6722404d9a4c2a',
                    exponent: 0
                }
            ],
            address: '0x48c40d4666f93408be1bef038b6722404d9a4c2a',
            base: '0x48c40d4666f93408be1bef038b6722404d9a4c2a',
            display: '0x48c40d4666f93408be1bef038b6722404d9a4c2a',
            name: 'NeoBurger',
            symbol: 'bNEO'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/neo/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$neo$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/neo/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$neo$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/optimism/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'optimism',
    assets: [
        {
            description: 'The governance token of Optimism',
            typeAsset: 'erc20',
            address: '0x4200000000000000000000000000000000000042',
            denomUnits: [
                {
                    denom: '0x4200000000000000000000000000000000000042',
                    exponent: 0
                },
                {
                    denom: 'op',
                    exponent: 18
                }
            ],
            base: '0x4200000000000000000000000000000000000042',
            name: 'Optimism',
            display: 'op',
            symbol: 'OP',
            coingeckoId: 'optimism',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/optimism/images/op.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/optimism/images/op.png',
                    theme: {
                        primaryColorHex: '#fc0424'
                    }
                }
            ]
        },
        {
            description: 'Ether (ETH) is the native currency of Optimism.',
            typeAsset: 'evm-base',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'eth',
                    exponent: 18
                }
            ],
            base: 'wei',
            display: 'eth',
            name: 'Ether',
            symbol: 'ETH',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    provider: 'Optimism Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            description: 'wETH is \'wrapped ETH\'',
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0x4200000000000000000000000000000000000006',
                    exponent: 0
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            address: '0x4200000000000000000000000000000000000006',
            base: '0x4200000000000000000000000000000000000006',
            display: 'weth',
            name: 'Wrapped Ether',
            symbol: 'WETH',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'optimism',
                        baseDenom: 'wei'
                    },
                    provider: 'Optimism'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                },
                {
                    imageSync: {
                        chainName: 'optimism',
                        baseDenom: 'wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth-white.png',
                    theme: {
                        primaryColorHex: '#303030'
                    }
                }
            ]
        },
        {
            description: 'USDC issued on Optimism.',
            typeAsset: 'erc20',
            address: '0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85',
            denomUnits: [
                {
                    denom: '0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                }
            ],
            coingeckoId: 'usd-coin',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDC Bridged from Ethereum via Optimism Bridge.',
            typeAsset: 'erc20',
            address: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607',
            denomUnits: [
                {
                    denom: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x7F5c764cBc14f9669B88837ca1490cCa17c31607',
            name: 'Bridged USDC',
            display: 'usdc',
            symbol: 'USDC.e',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Optimism Bridge'
                }
            ],
            coingeckoId: 'bridged-usd-coin-optimism',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDT Bridged from Ethereum via Optimism Bridge.',
            typeAsset: 'erc20',
            address: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
            denomUnits: [
                {
                    denom: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
                    exponent: 0,
                    aliases: [
                        'uusdt'
                    ]
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
            name: 'Tether USD',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Optimism Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                },
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt_logomark.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt_logomark.svg',
                    theme: {
                        circle: false,
                        primaryColorHex: '#50AF95',
                        backgroundColorHex: '#00000000'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/optimism/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$optimism$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/optimism/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$optimism$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadot/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'polkadot',
    assets: [
        {
            description: 'Polkadot is a multi-chain blockchain platform that enables interoperability between different blockchains, allowing them to share information and security.',
            extendedDescription: 'Polkadot is a next-generation blockchain platform that facilitates interoperability between multiple blockchains, allowing them to operate seamlessly together. Developed by the Web3 Foundation and led by Dr. Gavin Wood, Polkadot\'s architecture includes a central relay chain that coordinates consensus and communication among connected parachains. These parachains can be customized for various use cases, providing flexibility and scalability. The native token, DOT, is used for governance, staking, and bonding on the network. Polkadot\'s mission is to create a decentralized web where diverse blockchains can share information and security, enabling a new era of innovation and collaboration.',
            denomUnits: [
                {
                    denom: 'Planck',
                    exponent: 0,
                    aliases: [
                        'planck'
                    ]
                },
                {
                    denom: 'uDOT',
                    exponent: 4,
                    aliases: [
                        'udot',
                        'microdot',
                        'Microdot'
                    ]
                },
                {
                    denom: 'mDOT',
                    exponent: 7,
                    aliases: [
                        'millidot',
                        'Millidot'
                    ]
                },
                {
                    denom: 'DOT',
                    exponent: 10,
                    aliases: [
                        'dot',
                        'New DOT',
                        'new dot'
                    ]
                },
                {
                    denom: 'DOT (old)',
                    exponent: 12
                },
                {
                    denom: 'MDOT',
                    exponent: 16,
                    aliases: [
                        'million',
                        'Million'
                    ]
                }
            ],
            typeAsset: 'substrate',
            base: 'Planck',
            name: 'Polkadot',
            display: 'DOT',
            symbol: 'DOT',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
            },
            coingeckoId: 'polkadot',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg',
                    theme: {
                        primaryColorHex: '#e4047c'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadot/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadot$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadot/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadot$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygon/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'polygon',
    assets: [
        {
            description: 'Polygon combines the best of Ethereum and sovereign blockchains into a full-fledged multi-chain system.',
            extendedDescription: 'POL (ex-MATIC) is the native coin of the Polygon network, used to pay transaction fees and staking rewards. It\'s also an ERC-20 token and will power a vast ecosystem of zero-knowledge-based Layer 2 chains. POL will gradually replace the current MATIC token over 4 years as part of Polygon 2.0.',
            typeAsset: 'erc20',
            address: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
            denomUnits: [
                {
                    denom: '0x0000000000000000000000000000000000001010',
                    exponent: 0
                },
                {
                    denom: 'pol',
                    exponent: 18
                }
            ],
            base: '0x0000000000000000000000000000000000001010',
            name: 'Polygon (ex-MATIC)',
            display: 'pol',
            symbol: 'POL',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.svg'
            },
            coingeckoId: 'polygon-ecosystem-token',
            images: [
                {
                    imageSync: {
                        chainName: 'polygon',
                        baseDenom: 'wei'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.svg',
                    theme: {
                        primaryColorHex: '#8444e4'
                    }
                }
            ]
        },
        {
            deprecated: true,
            description: 'Polygon, previously known as Matic Network, is a Layer 2 scaling solution for Ethereum that aims to provide faster and cheaper transactions.',
            extendedDescription: 'Polygon is a Layer 2 scaling solution for Ethereum, designed to improve the scalability and usability of the Ethereum blockchain. It achieves this by using sidechains for off-chain computation while ensuring asset security using the Plasma framework and a decentralized network of Proof-of-Stake (PoS) validators. Polygon supports various DeFi and NFT projects by providing a faster, more efficient, and low-cost environment for transactions. Its native token, MATIC, is used for staking, governance, and paying transaction fees on the network. The platform aims to transform Ethereum into a multi-chain system, similar to Polkadot, but with the benefits of Ethereum\'s security and vibrant ecosystem.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'matic',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Polygon',
            display: 'matic',
            symbol: 'MATIC',
            traces: [
                {
                    type: 'legacy-mintage',
                    counterparty: {
                        chainName: 'polygon',
                        baseDenom: '0x0000000000000000000000000000000000001010'
                    },
                    provider: 'Polygon'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.svg'
            },
            coingeckoId: 'matic-network',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic-purple.svg',
                    theme: {
                        primaryColorHex: '#8444e4'
                    }
                }
            ]
        },
        {
            description: 'Polygon combines the best of Ethereum and sovereign blockchains into a full-fledged multi-chain system.',
            typeAsset: 'erc20',
            address: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
            denomUnits: [
                {
                    denom: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
                    exponent: 0,
                    aliases: [
                        'wmatic-wei'
                    ]
                },
                {
                    denom: 'wmatic',
                    exponent: 18
                }
            ],
            base: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
            name: 'Wrapped Matic',
            display: 'wmatic',
            symbol: 'WMATIC',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'polygon',
                        baseDenom: '0x0000000000000000000000000000000000001010'
                    },
                    provider: 'Polygon'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.svg'
            },
            coingeckoId: 'wmatic',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.svg',
                    theme: {
                        primaryColorHex: '#2b93fb'
                    }
                }
            ]
        },
        {
            description: 'USDC issued on Polygon.',
            typeAsset: 'erc20',
            address: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
            denomUnits: [
                {
                    denom: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                }
            ],
            coingeckoId: 'usd-coin',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'USDC Bridged from Ethereum via Polygon PoS Bridge.',
            typeAsset: 'erc20',
            address: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
            denomUnits: [
                {
                    denom: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174',
            name: 'Bridged USDC',
            display: 'usdc',
            symbol: 'USDC.e',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Polygon PoS Bridge'
                }
            ],
            coingeckoId: 'bridged-usdc-polygon-pos-bridge',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png'
                }
            ]
        },
        {
            description: 'Multi-Collateral Dai, brings a lot of new and exciting features, such as support for new CDP collateral types and Dai Savings Rate.',
            typeAsset: 'erc20',
            address: '0xddc9e2891fa11a4cc5c223145e8d14b44f3077c9',
            denomUnits: [
                {
                    denom: '0xddc9e2891fa11a4cc5c223145e8d14b44f3077c9',
                    exponent: 0,
                    aliases: [
                        'dai-wei'
                    ]
                },
                {
                    denom: 'axldai',
                    exponent: 18
                }
            ],
            base: '0xddc9e2891fa11a4cc5c223145e8d14b44f3077c9',
            name: 'Axelar Wrapped Dai Stablecoin',
            display: 'axldai',
            symbol: 'axlDAI',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'dai-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/dai.svg'
                }
            ]
        },
        {
            description: 'Frax is a fractional-algorithmic stablecoin protocol. It aims to provide a highly scalable, decentralized, algorithmic money in place of fixed-supply assets like BTC. Additionally, FXS is the value accrual and governance token of the entire Frax ecosystem.',
            typeAsset: 'erc20',
            address: '0x53adc464b488be8c5d7269b9abbce8ba74195c3a',
            denomUnits: [
                {
                    denom: '0x53adc464b488be8c5d7269b9abbce8ba74195c3a',
                    exponent: 0,
                    aliases: [
                        'frax-wei'
                    ]
                },
                {
                    denom: 'axlfrax',
                    exponent: 18
                }
            ],
            base: '0x53adc464b488be8c5d7269b9abbce8ba74195c3a',
            name: 'Axelar Wrapped Frax',
            display: 'axlfrax',
            symbol: 'axlFRAX',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'frax-wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/frax.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0x750e4c4984a9e0f12978ea6742bc1c5d248f40ed',
            denomUnits: [
                {
                    denom: '0x750e4c4984a9e0f12978ea6742bc1c5d248f40ed',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0x750e4c4984a9e0f12978ea6742bc1c5d248f40ed',
            name: 'Axelar Wrapped USD Coin',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'Tether gives you the joint benefits of open blockchain technology and traditional currency by converting your cash into a stable digital currency equivalent.',
            typeAsset: 'erc20',
            address: '0xceed2671d8634e3ee65000edbbee66139b132fbf',
            denomUnits: [
                {
                    denom: '0xceed2671d8634e3ee65000edbbee66139b132fbf',
                    exponent: 0,
                    aliases: [
                        'uusdt'
                    ]
                },
                {
                    denom: 'axlusdt',
                    exponent: 6
                }
            ],
            base: '0xceed2671d8634e3ee65000edbbee66139b132fbf',
            name: 'Axelar Wrapped Tether USD',
            display: 'axlusdt',
            symbol: 'axlUSDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelar',
                        baseDenom: 'uusdt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        },
        {
            description: 'The PAGE token is used for actions in the PageDAO NFT literary ecosystem and for DAO governance.',
            typeAsset: 'erc20',
            address: '0x9ceE70895726B0ea14E6019C961dAf32222a7C2f',
            denomUnits: [
                {
                    denom: '0x9ceE70895726B0ea14E6019C961dAf32222a7C2f',
                    exponent: 0,
                    aliases: []
                },
                {
                    denom: 'page',
                    exponent: 8
                }
            ],
            base: '0x9ceE70895726B0ea14E6019C961dAf32222a7C2f',
            name: 'Page',
            display: 'page',
            symbol: 'PAGE',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0x60e683C6514Edd5F758A55b6f393BeBBAfaA8d5e'
                    },
                    provider: 'PageDAO'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/page.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/page.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0x60e683C6514Edd5F758A55b6f393BeBBAfaA8d5e'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/page.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/page.svg',
                    theme: {
                        primaryColorHex: '#ebb324'
                    }
                }
            ],
            coingeckoId: 'page'
        },
        {
            description: 'wETH is \'wrapped ETH\'',
            typeAsset: 'erc20',
            denomUnits: [
                {
                    denom: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
                    exponent: 0
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            address: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
            base: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
            display: 'weth',
            name: 'Wrapped Ether',
            symbol: 'WETH',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    provider: 'Polygon PoS Bridge'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                }
            ]
        },
        {
            description: 'USDT from Ethereum bridged to Polygon via Polygon PoS Bridge.',
            typeAsset: 'erc20',
            address: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
            denomUnits: [
                {
                    denom: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
            name: 'Polygon Bridged USDT',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Polygon PoS Bridge'
                }
            ],
            coingeckoId: 'polygon-bridged-usdt-polygon',
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygon/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygon$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygon/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygon$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/statemine/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'statemine',
    assets: [
        {
            denomUnits: [
                {
                    denom: '130',
                    exponent: 0
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            typeAsset: 'substrate',
            base: '130',
            name: 'Statemine',
            display: 'usdt',
            symbol: 'USDT',
            coingeckoId: 'tether',
            traces: [
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Tether'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/statemine/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$statemine$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/statemine/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$statemine$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/stellar/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'stellar',
    assets: [
        {
            description: 'Native token of Stellar network',
            extendedDescription: 'The Stellar network is an open-sourced, public blockchain powered by the Stellar Consensus protocol (SCP), a proof-of-agreement (PoA) consensus mechanism. Thanks to PoA, the Stellar network is faster, cheaper, and far more energy-efficient than many other blockchains.\n\nIts core design makes it easy to create and issue digital assets that enable rapid payments at low-cost around the world. The Stellar network allows you to create your own currency or token within the network and distribute it digitally on a large scale. On the Stellar blockchain, you can create, send, and trade digital representations of almost any form of value such as – US dollars, Argentine pesos, gold, and real estate. Then, the network acts as a bridge that connects financial systems and makes global interoperability a reality.',
            denomUnits: [
                {
                    denom: 'stroop',
                    exponent: 0
                },
                {
                    denom: 'lumen',
                    exponent: 7
                }
            ],
            typeAsset: 'evm-base',
            base: 'stroop',
            name: 'Lumen',
            display: 'lumen',
            symbol: 'XLM',
            coingeckoId: 'stellar',
            socials: {
                website: 'https://stellar.org/',
                twitter: 'https://twitter.com/StellarOrg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/stellar/images/xlm.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/stellar/images/xlm.svg',
                    theme: {
                        primaryColorHex: '#040404'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/stellar/images/xlm.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/stellar/images/xlm.svg'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/stellar/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$stellar$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/stellar/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$stellar$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/sui/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'sui',
    assets: [
        {
            description: 'Sui’s native asset is called SUI.',
            denomUnits: [
                {
                    denom: '0x2::sui::SUI',
                    exponent: 0,
                    aliases: [
                        'MIST'
                    ]
                },
                {
                    denom: 'SUI',
                    exponent: 9
                }
            ],
            typeAsset: 'unknown',
            base: '0x2::sui::SUI',
            name: 'Sui',
            display: 'SUI',
            symbol: 'SUI',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/sui/images/sui.svg'
            },
            coingeckoId: 'sui',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/sui/images/sui.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/sui/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$sui$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/sui/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$sui$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/tinkernet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'tinkernet',
    assets: [
        {
            description: 'The native fee, governance and staking token of the Tinkernet Parachain.',
            extendedDescription: 'Tinkernet is a Kusama parachain and the sister-chain of the InvArch Network on Polkadot. Tinkernet is an experimental proving ground where omnichain account & DAO governance protocols are deployed and tested before deploying on the InvArch Network. Protocols on Tinkernet realize features such as multichain multisig accounts & DAO Staking. Unlike a testnet, Tinkernet features real value.',
            socials: {
                website: 'https://tinker.network',
                twitter: 'https://twitter.com/TinkerParachain'
            },
            denomUnits: [
                {
                    denom: 'Planck',
                    exponent: 0
                },
                {
                    denom: 'TNKR',
                    exponent: 12
                }
            ],
            typeAsset: 'substrate',
            base: 'Planck',
            name: 'Tinkernet',
            display: 'TNKR',
            symbol: 'TNKR',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/tinkernet/images/tnkr.svg'
            },
            coingeckoId: 'tinkernet',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/tinkernet/images/tnkr.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/tinkernet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tinkernet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/tinkernet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tinkernet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpl/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'xrpl',
    assets: [
        {
            description: 'Native token of Ripple XRP Ledger',
            extendedDescription: 'The XRP Ledger: The Blockchain Built for Business\n\nThe XRP Ledger (XRPL) is a decentralized, public blockchain led by a global community of businesses and developers looking to solve problems and create value.\n\nProven reliable over more than a decade of error-free functioning, the XRPL offers streamlined development, low transaction costs, high performance, and sustainability. So you can build with confidence–and move your most critical projects forward.',
            denomUnits: [
                {
                    denom: 'drop',
                    exponent: 0
                },
                {
                    denom: 'xrp',
                    exponent: 6
                }
            ],
            typeAsset: 'unknown',
            base: 'drop',
            name: 'Ripple',
            display: 'xrp',
            symbol: 'XRP',
            coingeckoId: 'ripple',
            socials: {
                website: 'https://xrpl.org/',
                twitter: 'https://twitter.com/Ripple'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.svg',
                    theme: {
                        primaryColorHex: '#040404'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.svg'
            }
        },
        {
            description: 'Sologenic is disrupting the asset trading industry: Tokenized Securities, Crypto Assets & NFTs.',
            denomUnits: [
                {
                    denom: 'xrpl11278ecf9e',
                    exponent: 0,
                    aliases: [
                        'xrpl11278ecf9e'
                    ]
                },
                {
                    denom: 'solo',
                    exponent: 15
                }
            ],
            base: 'xrpl11278ecf9e',
            name: 'Solo',
            display: 'solo',
            symbol: 'SOLO',
            typeAsset: 'unknown',
            coingeckoId: 'solo-coin',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/solo.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/solo.svg',
                    theme: {
                        primaryColorHex: '#ffffff'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/solo.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/solo.svg'
            }
        },
        {
            description: 'RLUSD, Ripple’s official USD-backed stablecoin, offers stability and liquidity for cross-border transactions on the XRP Ledger.',
            denomUnits: [
                {
                    denom: 'xrpl570c00a604',
                    exponent: 0,
                    aliases: [
                        'xrpl570c00a604'
                    ]
                },
                {
                    denom: 'rlusd',
                    exponent: 15
                }
            ],
            base: 'xrpl570c00a604',
            name: 'RLUSD',
            display: 'rlusd',
            symbol: 'RLUSD',
            coingeckoId: 'ripple-usd',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/rlusd.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/rlusd.svg',
                    theme: {
                        primaryColorHex: '#1b90f7'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/rlusd.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/rlusd.svg'
            },
            typeAsset: 'unknown'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpl/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpl$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpl/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpl$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/zilliqa/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'zilliqa',
    assets: [
        {
            typeAsset: 'evm-base',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                }
            ],
            base: 'wei',
            display: 'wei',
            name: 'Ether',
            symbol: 'ETH'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/zilliqa/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$zilliqa$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/zilliqa/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$zilliqa$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/berachain/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../assetlist.schema.json',
    chainName: 'berachain',
    assets: [
        {
            description: 'The native staking token of Berachain.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'bera',
                    exponent: 18
                }
            ],
            base: 'wei',
            display: 'bera',
            name: 'Berachain',
            symbol: 'BERA',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/berachain/images/bera.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#7c340c'
                    }
                }
            ],
            coingeckoId: 'berachain-bera',
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/berachain/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$berachain$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/berachain/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$berachain$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/hall/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../assetlist.schema.json',
    chainName: 'hall',
    assets: [
        {
            description: 'The native token of Coinhall',
            denomUnits: [
                {
                    denom: 'uhall',
                    exponent: 0
                },
                {
                    denom: 'hall',
                    exponent: 6
                }
            ],
            base: 'uhall',
            display: 'hall',
            name: 'Hall',
            symbol: 'HALL',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/hall/images/hall.svg',
                    theme: {
                        circle: false
                    }
                }
            ],
            socials: {
                website: 'https://coinhall.org/',
                twitter: 'https://twitter.com/coinhall_org'
            },
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/hall/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$hall$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/hall/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$hall$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/namada/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../assetlist.schema.json',
    chainName: 'namada',
    assets: [
        {
            description: 'The native token of Namada',
            denomUnits: [
                {
                    denom: 'unam',
                    exponent: 0
                },
                {
                    denom: 'nam',
                    exponent: 6
                }
            ],
            base: 'unam',
            display: 'nam',
            name: 'Namada',
            symbol: 'NAM',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/namada/images/nam.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#fbfb04'
                    }
                }
            ],
            socials: {
                website: 'https://namada.net/',
                twitter: 'https://twitter.com/namada'
            },
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/namada/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$namada$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/namada/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$namada$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanchetestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'avalanchetestnet',
    assets: [
        {
            description: 'AVAX is the native token of Avalanche. It is a hard-capped, scarce asset that is used to pay for fees, secure the platform through staking, and provide a basic unit of account between the multiple subnets created on Avalanche.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'avax',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Avalanche',
            display: 'avax',
            symbol: 'AVAX',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'avalanche',
                        baseDenom: 'wei'
                    },
                    provider: 'Avalanche'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.svg'
            },
            coingeckoId: 'avalanche-2',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/avax.svg'
                }
            ]
        },
        {
            description: 'The wrapped ERC-20 representation of AVAX, the native token of Avalanche.',
            typeAsset: 'erc20',
            address: '0xd00ae08403B9bbb9124bB305C09058E32C39A48c',
            denomUnits: [
                {
                    denom: '0xd00ae08403B9bbb9124bB305C09058E32C39A48c',
                    exponent: 0,
                    aliases: [
                        'wavax-wei'
                    ]
                },
                {
                    denom: 'wavax',
                    exponent: 18
                }
            ],
            base: '0xd00ae08403B9bbb9124bB305C09058E32C39A48c',
            name: 'Wrapped AVAX',
            display: 'wavax',
            symbol: 'WAVAX',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'avalanchetestnet',
                        baseDenom: 'wei'
                    },
                    provider: 'Avalanche'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/wavax.svg'
            },
            coingeckoId: 'wrapped-avax',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/avalanche/images/wavax.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0x57F1c63497AEe0bE305B8852b354CEc793da43bB',
            denomUnits: [
                {
                    denom: '0x57F1c63497AEe0bE305B8852b354CEc793da43bB',
                    exponent: 0,
                    aliases: [
                        'uausdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0x57F1c63497AEe0bE305B8852b354CEc793da43bB',
            name: 'Axelar Wrapped USDC',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0x5425890298aed601595a70ab815c96711a31bc65',
            denomUnits: [
                {
                    denom: '0x5425890298aed601595a70ab815c96711a31bc65',
                    exponent: 0,
                    aliases: [
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x5425890298aed601595a70ab815c96711a31bc65',
            name: 'USD Coin',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'avalanche',
                        baseDenom: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E'
                    },
                    provider: 'Circle'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'avalanche',
                        baseDenom: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    }
                }
            ],
            coingeckoId: 'usd-coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanchetestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanchetestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanchetestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanchetestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchaintestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'binancesmartchaintestnet',
    assets: [
        {
            description: 'BNB powers the BNB Chain ecosystem and is the native coin of the BNB Beacon Chain and BNB Smart Chain.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'bnb',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Binance Coin',
            display: 'bnb',
            symbol: 'BNB',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'binancesmartchain',
                        baseDenom: 'wei'
                    },
                    provider: 'Binance Smart Chain'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.svg'
            },
            coingeckoId: 'binancecoin',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/bnb.svg'
                }
            ]
        },
        {
            description: 'Wrapped BNB. As the native coin of Binance Chain, BNB has multiple use cases: fueling transactions on the Chain, paying for transaction fees on Binance Exchange, making in-store payments, and many more.',
            denomUnits: [
                {
                    denom: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
                    exponent: 0
                },
                {
                    denom: 'wbnb',
                    exponent: 18
                }
            ],
            typeAsset: 'erc20',
            address: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
            base: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd',
            name: 'Wrapped BNB',
            display: 'wbnb',
            symbol: 'WBNB',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'binancesmartchaintestnet',
                        baseDenom: 'wei'
                    },
                    chain: {
                        contract: '0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd'
                    },
                    provider: 'Binance'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.svg'
            },
            coingeckoId: 'wbnb',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/binancesmartchain/images/wbnb.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0xc2fA98faB811B785b81c64Ac875b31CC9E40F9D2',
            denomUnits: [
                {
                    denom: '0xc2fA98faB811B785b81c64Ac875b31CC9E40F9D2',
                    exponent: 0,
                    aliases: [
                        'uausdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0xc2fA98faB811B785b81c64Ac875b31CC9E40F9D2',
            name: 'Axelar Wrapped USDC',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchaintestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchaintestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchaintestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchaintestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincashtestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'bitcoincashtestnet',
    assets: [
        {
            description: 'The testnet version of Bitcoin Cash.',
            denomUnits: [
                {
                    denom: 'sat',
                    exponent: 0
                },
                {
                    denom: 'bch',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'sat',
            name: 'Bitcoin Cash',
            display: 'bch',
            symbol: 'BCH',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'bitcoincash',
                        baseDenom: 'sat'
                    },
                    provider: 'Bitcoin Cash'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'bitcoincash',
                        baseDenom: 'sat'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoincash/images/bch.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoincash/images/bch.png',
                    theme: {
                        primaryColorHex: '#f4941c',
                        backgroundColorHex: '#f4941c',
                        circle: true
                    }
                }
            ],
            coingeckoId: 'bitcoin-cash'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincashtestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincashtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincashtestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincashtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcointestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'bitcointestnet',
    assets: [
        {
            description: 'The testnet version of Bitcoin.',
            denomUnits: [
                {
                    denom: 'sat',
                    exponent: 0
                },
                {
                    denom: 'btc',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'sat',
            name: 'Bitcoin',
            display: 'btc',
            symbol: 'BTC',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    provider: 'Bitcoin'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'bitcoin',
                        baseDenom: 'sat'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/bitcoin/images/btc.png',
                    theme: {
                        primaryColorHex: '#f4941c',
                        backgroundColorHex: '#f4941c',
                        circle: true
                    }
                }
            ],
            coingeckoId: 'bitcoin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcointestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcointestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecointestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'dogecointestnet',
    assets: [
        {
            description: 'The testnet version of Dogecoin.',
            denomUnits: [
                {
                    denom: 'shibe',
                    exponent: 0
                },
                {
                    denom: 'doge',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'shibe',
            name: 'Dogecoin',
            display: 'doge',
            symbol: 'DOGE',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'dogecoin',
                        baseDenom: 'shibe'
                    },
                    provider: 'Dogecoin'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'dogecoin',
                        baseDenom: 'shibe'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/dogecoin/images/doge.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/dogecoin/images/doge.png',
                    theme: {
                        primaryColorHex: '#f4941c',
                        backgroundColorHex: '#f4941c',
                        circle: true
                    }
                }
            ],
            coingeckoId: 'dogecoin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecointestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecointestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ethereumtestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'ethereumtestnet',
    assets: [
        {
            description: 'Ether is the native fee token of the Ethereum network.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'gwei',
                    exponent: 9
                },
                {
                    denom: 'eth',
                    exponent: 18,
                    aliases: [
                        'ether'
                    ]
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Ether',
            display: 'eth',
            symbol: 'ETH',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: 'wei'
                    },
                    provider: 'Ethereum'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth.svg'
            },
            coingeckoId: 'ethereum',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/eth.svg'
                }
            ]
        },
        {
            description: 'wETH is \'wrapped ETH\'',
            typeAsset: 'erc20',
            address: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6',
            denomUnits: [
                {
                    denom: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6',
                    exponent: 0,
                    aliases: [
                        'weth-wei'
                    ]
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            base: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6',
            name: 'Wrapped Ether',
            display: 'weth',
            symbol: 'WETH',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'ethereumtestnet',
                        baseDenom: 'wei'
                    },
                    provider: 'Ethereum'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
            },
            coingeckoId: 'weth',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0x254d06f33bDc5b8ee05b2ea472107E300226659A',
            denomUnits: [
                {
                    denom: '0x254d06f33bDc5b8ee05b2ea472107E300226659A',
                    exponent: 0,
                    aliases: [
                        'uausdc'
                    ]
                },
                {
                    denom: 'ausdc',
                    exponent: 6
                }
            ],
            base: '0x254d06f33bDc5b8ee05b2ea472107E300226659A',
            name: 'Axelar Wrapped aUSDC',
            display: 'ausdc',
            symbol: 'aUSDC',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'ethereumtestnet',
                        baseDenom: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            typeAsset: 'erc20',
            address: '0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0',
            denomUnits: [
                {
                    denom: '0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0',
                    exponent: 0,
                    aliases: [
                        'uusdt'
                    ]
                },
                {
                    denom: 'usdt',
                    exponent: 6
                }
            ],
            base: '0xaA8E23Fb1079EA71e0a56F48a2aA51851D8433D0',
            name: 'Tether USD',
            display: 'usdt',
            symbol: 'USDT',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    provider: 'Tether'
                }
            ],
            coingeckoId: 'tether',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'ethereum',
                        baseDenom: '0xdac17f958d2ee523a2206206994597c13d831ec7'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#009393',
                        backgroundColorHex: '#009393'
                    }
                },
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt_logomark.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdt_logomark.svg',
                    theme: {
                        circle: false,
                        primaryColorHex: '#50AF95',
                        backgroundColorHex: '#00000000'
                    }
                }
            ]
        },
        {
            description: 'USDC (USD Coin) is a stablecoin fully backed by US dollars, providing a transparent and regulated digital dollar solution.',
            extendedDescription: 'USD Coin (USDC) was launched in 2018 as a joint effort between Coinbase and Circle. USDC is a fully reserved stablecoin, meaning each token is backed 1:1 by US dollars held in reserve. This structure is designed to provide transparency and trust, reinforced by regular audits from reputable third-party firms. Initially built on the Ethereum blockchain, USDC has expanded to support multiple blockchain networks, including Algorand, Solana, and more. It is widely used in DeFi protocols, as collateral, and for international transactions, offering a stable and compliant digital dollar solution.',
            typeAsset: 'erc20',
            address: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
            denomUnits: [
                {
                    denom: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
                    exponent: 0
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            base: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
            name: 'USDC',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Ethereum'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            coingeckoId: 'usd-coin',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ethereumtestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ethereumtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ethereumtestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ethereumtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantomtestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'fantomtestnet',
    assets: [
        {
            description: 'Fantom\'s native utility token — FTM — powers the entire Fantom blockchain ecosystem. FTM tokens are used for staking, governance, payments, and fees on the network.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'ftm',
                    exponent: 18
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Fantom',
            display: 'ftm',
            symbol: 'FTM',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png'
                }
            ]
        },
        {
            description: 'ERC20 wrapped version of FTM',
            typeAsset: 'erc20',
            address: '0x812666209b90344Ec8e528375298ab9045c2Bd08',
            denomUnits: [
                {
                    denom: '0x812666209b90344Ec8e528375298ab9045c2Bd08',
                    exponent: 0
                },
                {
                    denom: 'wftm',
                    exponent: 18
                }
            ],
            base: '0x812666209b90344Ec8e528375298ab9045c2Bd08',
            name: 'Wrapped Fantom',
            display: 'wftm',
            symbol: 'WFTM',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'fantomtestnet',
                        baseDenom: 'wei'
                    },
                    chain: {
                        contract: '0x812666209b90344Ec8e528375298ab9045c2Bd08'
                    },
                    provider: 'Fantom'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'fantomtestnet',
                        baseDenom: 'wei'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/fantom/images/ftm.png'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantomtestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantomtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantomtestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantomtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecointestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'litecointestnet',
    assets: [
        {
            description: 'The testnet version of Litecoin.',
            denomUnits: [
                {
                    denom: 'litoshi',
                    exponent: 0
                },
                {
                    denom: 'ltc',
                    exponent: 8
                }
            ],
            typeAsset: 'bitcoin-like',
            base: 'litoshi',
            name: 'Litecoin',
            display: 'ltc',
            symbol: 'LTC',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'litecoin',
                        baseDenom: 'litoshi'
                    },
                    provider: 'Litecoin'
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'litecoin',
                        baseDenom: 'litoshi'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/litecoin/images/ltc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/litecoin/images/ltc.png',
                    theme: {
                        primaryColorHex: '#f4941c',
                        backgroundColorHex: '#f4941c',
                        circle: true
                    }
                }
            ],
            coingeckoId: 'litecoin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecointestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecointestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecointestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeamtestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'moonbeamtestnet',
    assets: [
        {
            description: 'Glimmer (GLMR) is the utility token of the Moonbeam Network, Moonbeam’s primary deployment on the Polkadot network that serves as a developer-friendly parachain.',
            denomUnits: [
                {
                    denom: 'Wei',
                    exponent: 0,
                    aliases: [
                        'wei'
                    ]
                },
                {
                    denom: 'GLMR',
                    exponent: 18,
                    aliases: [
                        'glmr'
                    ]
                }
            ],
            typeAsset: 'substrate',
            base: 'Wei',
            name: 'Glimmer',
            display: 'GLMR',
            symbol: 'GLMR',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'moonbeam',
                        baseDenom: 'Wei'
                    },
                    provider: 'Moonbeam'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
            },
            coingeckoId: 'moonbeam',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
                }
            ]
        },
        {
            description: 'An ERC-20 representation of GLMR, the native token of Moonbeam.',
            typeAsset: 'erc20',
            address: '0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715',
            denomUnits: [
                {
                    denom: '0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715',
                    exponent: 0,
                    aliases: [
                        'wglmr-wei'
                    ]
                },
                {
                    denom: 'wglmr',
                    exponent: 18
                }
            ],
            base: '0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715',
            name: 'Wrapped Moonbeam',
            display: 'wglmr',
            symbol: 'WGLMR',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'moonbeamtestnet',
                        baseDenom: 'Wei'
                    },
                    provider: 'Moonbeam'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
            },
            coingeckoId: 'wrapped-moonbeam',
            images: [
                {
                    imageSync: {
                        chainName: 'moonbeamtestnet',
                        baseDenom: 'Wei'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/moonbeam/images/glmr.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0xD1633F7Fb3d716643125d6415d4177bC36b7186b',
            denomUnits: [
                {
                    denom: '0xD1633F7Fb3d716643125d6415d4177bC36b7186b',
                    exponent: 0,
                    aliases: [
                        'uausdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0xD1633F7Fb3d716643125d6415d4177bC36b7186b',
            name: 'Axelar Wrapped USD Coin',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeamtestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeamtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeamtestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeamtestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadottestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'polkadottestnet',
    assets: [
        {
            description: 'The native fee, governance, staking, and bonding token of the Polkadot platform.',
            denomUnits: [
                {
                    denom: 'Planck',
                    exponent: 0,
                    aliases: [
                        'planck'
                    ]
                },
                {
                    denom: 'uDOT',
                    exponent: 4,
                    aliases: [
                        'udot',
                        'microdot',
                        'Microdot'
                    ]
                },
                {
                    denom: 'mDOT',
                    exponent: 7,
                    aliases: [
                        'millidot',
                        'Millidot'
                    ]
                },
                {
                    denom: 'DOT',
                    exponent: 10,
                    aliases: [
                        'dot',
                        'New DOT',
                        'new dot'
                    ]
                },
                {
                    denom: 'DOT (old)',
                    exponent: 12
                },
                {
                    denom: 'MDOT',
                    exponent: 16,
                    aliases: [
                        'million',
                        'Million'
                    ]
                }
            ],
            typeAsset: 'substrate',
            base: 'Planck',
            name: 'Polkadot',
            display: 'DOT',
            symbol: 'DOT',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'polkadot',
                        baseDenom: 'Planck'
                    },
                    provider: 'Polkadot'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
            },
            coingeckoId: 'polkadot',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polkadot/images/dot.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadottestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadottestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadottestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadottestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygontestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'polygontestnet',
    assets: [
        {
            description: 'Polygon (formerly Matic) Network brings massive scale to Ethereum using an adapted version of Plasma with PoS based side chains. Polygon is a well-structured, easy-to-use platform for Ethereum scaling and infrastructure development.',
            denomUnits: [
                {
                    denom: 'wei',
                    exponent: 0
                },
                {
                    denom: 'matic',
                    exponent: 18,
                    aliases: [
                        'polygon'
                    ]
                }
            ],
            typeAsset: 'evm-base',
            base: 'wei',
            name: 'Matic',
            display: 'matic',
            symbol: 'MATIC',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'polygon',
                        baseDenom: 'wei'
                    },
                    provider: 'Polygon'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic.svg'
            },
            coingeckoId: 'matic-network',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/matic.svg'
                }
            ]
        },
        {
            description: 'Polygon combines the best of Ethereum and sovereign blockchains into a full-fledged multi-chain system.',
            typeAsset: 'erc20',
            address: '0x9c3C9283D3e44854697Cd22D3Faa240Cfb032889',
            denomUnits: [
                {
                    denom: '0x9c3C9283D3e44854697Cd22D3Faa240Cfb032889',
                    exponent: 0,
                    aliases: [
                        'wmatic-wei'
                    ]
                },
                {
                    denom: 'wmatic',
                    exponent: 18,
                    aliases: [
                        'polygon'
                    ]
                }
            ],
            base: '0x9c3C9283D3e44854697Cd22D3Faa240Cfb032889',
            name: 'Wrapped Matic',
            display: 'wmatic',
            symbol: 'WMATIC',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'polygontestnet',
                        baseDenom: 'wei'
                    },
                    provider: 'Polygon'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.svg'
            },
            coingeckoId: 'wmatic',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/polygon/images/wmatic.svg'
                }
            ]
        },
        {
            description: 'USDC is a fully collateralized US Dollar stablecoin developed by CENTRE, the open source project with Circle being the first of several forthcoming issuers.',
            typeAsset: 'erc20',
            address: '0x2c852e740B62308c46DD29B982FBb650D063Bd07',
            denomUnits: [
                {
                    denom: '0x2c852e740B62308c46DD29B982FBb650D063Bd07',
                    exponent: 0,
                    aliases: [
                        'uausdc'
                    ]
                },
                {
                    denom: 'axlusdc',
                    exponent: 6
                }
            ],
            base: '0x2c852e740B62308c46DD29B982FBb650D063Bd07',
            name: 'Axelar Wrapped USD Coin',
            display: 'axlusdc',
            symbol: 'axlUSDC',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    provider: 'Axelar'
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygontestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygontestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygontestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygontestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/solanatestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'solanatestnet',
    assets: [
        {
            description: 'The testnet version of Solana.',
            denomUnits: [
                {
                    denom: 'Lamport',
                    exponent: 0
                },
                {
                    denom: 'SOL',
                    exponent: 9
                }
            ],
            typeAsset: 'svm-base',
            base: 'Lamport',
            name: 'Solana',
            display: 'SOL',
            symbol: 'SOL',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'solana',
                        baseDenom: 'Lamport'
                    },
                    provider: 'Solana'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.svg'
            },
            coingeckoId: 'solana',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.png',
                    theme: {
                        circle: true,
                        backgroundColorHex: '#000000'
                    }
                },
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol.svg',
                    theme: {
                        circle: false,
                        backgroundColorHex: '#00000000'
                    }
                }
            ]
        },
        {
            typeAsset: 'erc20',
            address: 'So11111111111111111111111111111111111111112',
            denomUnits: [
                {
                    denom: 'So11111111111111111111111111111111111111112',
                    exponent: 0
                },
                {
                    denom: 'wsol',
                    exponent: 9
                }
            ],
            base: 'So11111111111111111111111111111111111111112',
            name: 'Wrapped SOL',
            display: 'wsol',
            symbol: 'WSOL',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'solanatestnet',
                        baseDenom: 'Lamport'
                    },
                    provider: 'Solana'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.svg'
            },
            coingeckoId: 'wrapped-solana',
            images: [
                {
                    imageSync: {
                        chainName: 'solanatestnet',
                        baseDenom: 'Lamport'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/sol_circle.png',
                    theme: {
                        circle: true,
                        backgroundColorHex: '#000000'
                    }
                }
            ]
        },
        {
            description: 'The Meow token',
            typeAsset: 'erc20',
            address: 'HYGEZGU5kRh9vjw723wuyjUQGe654ByRQzQRP7PWxgMa',
            denomUnits: [
                {
                    denom: 'HYGEZGU5kRh9vjw723wuyjUQGe654ByRQzQRP7PWxgMa',
                    exponent: 0
                },
                {
                    denom: 'meow',
                    exponent: 8
                }
            ],
            base: 'HYGEZGU5kRh9vjw723wuyjUQGe654ByRQzQRP7PWxgMa',
            name: 'MEOW',
            display: 'meow',
            symbol: 'MEOW',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'solana',
                        baseDenom: 'BUhS5coXEt9hcxN3JSpGYUWSKbNo96RsKu52LcMo12rf'
                    },
                    provider: 'Solana'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/meow.png'
            },
            coingeckoId: 'meow',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/meow.png'
                }
            ]
        },
        {
            description: 'The Oracler AI token',
            typeAsset: 'erc20',
            address: '3AoNjsp7M2k9tsaNpKjcBWC5JQi67BinysbVnrcPjKNt',
            denomUnits: [
                {
                    denom: '3AoNjsp7M2k9tsaNpKjcBWC5JQi67BinysbVnrcPjKNt',
                    exponent: 0
                },
                {
                    denom: 'oracler',
                    exponent: 6
                }
            ],
            base: '3AoNjsp7M2k9tsaNpKjcBWC5JQi67BinysbVnrcPjKNt',
            name: 'ORACLER',
            display: 'oracler',
            symbol: 'ORACLER',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/oracler.png'
            },
            coingeckoId: 'oracler-ai',
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/solana/images/oracler.png'
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/solanatestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$solanatestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/solanatestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$solanatestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/tontestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'tontestnet',
    assets: [
        {
            description: 'The testnet version of Toncoin.',
            denomUnits: [
                {
                    denom: 'nanoton',
                    exponent: 0,
                    aliases: [
                        'nanoTon'
                    ]
                },
                {
                    denom: 'ton',
                    exponent: 9
                }
            ],
            typeAsset: 'unknown',
            base: 'nanoton',
            name: 'Toncoin',
            display: 'ton',
            symbol: 'TON',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'ton',
                        baseDenom: 'nanoton'
                    },
                    provider: 'Toncoin'
                }
            ],
            coingeckoId: 'the-open-network',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ton/images/ton.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ton/images/ton.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#0088CC',
                        backgroundColorHex: '#0088CC'
                    }
                }
            ],
            socials: {
                website: 'https://ton.tg/',
                twitter: 'https://x.com/ton_blockchain'
            }
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/tontestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tontestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/tontestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tontestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpltestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../../assetlist.schema.json',
    chainName: 'xrpltestnet',
    assets: [
        {
            description: 'The testnet version of XRP.',
            denomUnits: [
                {
                    denom: 'drop',
                    exponent: 0
                },
                {
                    denom: 'xrp',
                    exponent: 6
                }
            ],
            typeAsset: 'unknown',
            base: 'drop',
            name: 'Ripple',
            display: 'xrp',
            symbol: 'XRP',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'xrpl',
                        baseDenom: 'drop'
                    },
                    provider: 'Ripple'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.svg'
            },
            coingeckoId: 'ripple',
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.png',
                    theme: {
                        circle: true,
                        backgroundColorHex: '#000000'
                    }
                },
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/xrpl/images/xrp.svg',
                    theme: {
                        circle: false,
                        backgroundColorHex: '#00000000'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpltestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpltestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpltestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpltestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ojotestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'ojotestnet',
    assets: [
        {
            description: 'The native token of Ojo Network',
            denomUnits: [
                {
                    denom: 'uojo',
                    exponent: 0
                },
                {
                    denom: 'ojo',
                    exponent: 6
                }
            ],
            base: 'uojo',
            name: 'ojo',
            display: 'ojo',
            symbol: 'OJO',
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/ojotestnet/images/ojo.svg'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/ojotestnet/images/ojo.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ojotestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ojotestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ojotestnet/asset-list.js [app-client] (ecmascript)");
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ojotestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$0l$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/0l/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$aptos$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/aptos/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$arbitrum$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/arbitrum/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avail$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avail/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanche$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanche/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$base$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/base/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchain$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchain/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoin/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincash$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincash/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$comex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/comex/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecoin/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$filecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/filecoin/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$forex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/forex/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$internetcomputer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/internetcomputer/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$kusama$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/kusama/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecoin/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$mantle$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/mantle/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeam$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeam/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$movement$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/movement/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$neo$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/neo/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$optimism$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/optimism/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadot/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygon$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygon/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$statemine$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/statemine/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$stellar$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/stellar/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$sui$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/sui/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tinkernet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/tinkernet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpl$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpl/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$zilliqa$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/zilliqa/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$berachain$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/berachain/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$hall$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/hall/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$namada$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/namada/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanchetestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/avalanchetestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchaintestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/binancesmartchaintestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincashtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcoincashtestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/bitcointestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/dogecointestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ethereumtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ethereumtestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantomtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/fantomtestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/litecointestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeamtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/moonbeamtestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadottestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polkadottestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygontestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/polygontestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$solanatestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/solanatestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tontestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/tontestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpltestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/xrpltestnet/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ojotestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ojotestnet/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const assetList = [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$0l$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$aptos$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$arbitrum$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avail$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanche$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$base$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchain$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincash$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$comex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$filecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$forex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$internetcomputer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$kusama$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecoin$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$mantle$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeam$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$movement$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$neo$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$optimism$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygon$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$statemine$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$stellar$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$sui$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tinkernet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpl$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$zilliqa$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$berachain$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$hall$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$namada$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$avalanchetestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$binancesmartchaintestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcoincashtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$bitcointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$dogecointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ethereumtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$fantomtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$litecointestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$moonbeamtestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polkadottestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$polygontestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$solanatestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$tontestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$xrpltestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"],
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ojotestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assetList"]
];
const __TURBOPACK__default__export__ = assetList;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/cosmoshubicstestnet/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'babylontestnet',
            clientId: '07-tendermint-12',
            connectionId: 'connection-11'
        },
        chain2: {
            chainName: 'cosmoshubicstestnet',
            clientId: '07-tendermint-248',
            connectionId: 'connection-179'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-347',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/cosmoshubicstestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$cosmoshubicstestnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/cosmoshubicstestnet/ibc-data.js [app-client] (ecmascript)");
;
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$cosmoshubicstestnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/picasso/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/composablepolkadot/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/penumbra/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$cosmoshubicstestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/cosmoshubicstestnet/index.js [app-client] (ecmascript)");
;
;
;
;
const ibcData = [
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$picasso$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$composablepolkadot$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$penumbra$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ibcData"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$cosmoshubicstestnet$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ibcData"]
];
const __TURBOPACK__default__export__ = ibcData;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript)");
;
;
const __TURBOPACK__default__export__ = {
    assetLists: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    ibcData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
;
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript) <export default as assetLists>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetLists": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$asset$2d$lists$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/asset-lists.js [app-client] (ecmascript)");
}}),
"[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript) <export default as ibcData>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ibcData": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$noncosmos$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/noncosmos/ibc-data.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=node_modules_%40chain-registry_v2_esm_noncosmos_2669719e._.js.map