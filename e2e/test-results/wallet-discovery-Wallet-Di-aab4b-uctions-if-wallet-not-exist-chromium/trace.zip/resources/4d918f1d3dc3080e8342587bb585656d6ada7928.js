(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/asset-list.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../assetlist.schema.json',
    chainName: 'osmosistestnet',
    assets: [
        {
            description: 'The native token of Osmosis',
            denomUnits: [
                {
                    denom: 'uosmo',
                    exponent: 0,
                    aliases: []
                },
                {
                    denom: 'osmo',
                    exponent: 6,
                    aliases: []
                }
            ],
            typeAsset: 'sdk.coin',
            base: 'uosmo',
            name: 'Osmosis Testnet',
            display: 'osmo',
            symbol: 'OSMO',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'osmosis',
                        baseDenom: 'uosmo'
                    },
                    provider: 'Osmosis'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmo.svg'
                }
            ],
            coingeckoId: 'osmosis',
            keywords: [
                'dex',
                'staking'
            ]
        },
        {
            denomUnits: [
                {
                    denom: 'uion',
                    exponent: 0
                },
                {
                    denom: 'ion',
                    exponent: 6
                }
            ],
            typeAsset: 'sdk.coin',
            base: 'uion',
            name: 'Ion',
            display: 'ion',
            symbol: 'ION',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'osmosis',
                        baseDenom: 'uion'
                    },
                    provider: 'Osmosis'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ion.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ion.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ion.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ion.svg'
                }
            ],
            coingeckoId: 'ion',
            keywords: [
                'memecoin'
            ]
        },
        {
            description: 'The native staking and governance token of the Theta testnet version of the Cosmos Hub.',
            denomUnits: [
                {
                    denom: 'ibc/9FF2B7A5F55038A7EE61F4FD6749D9A648B48E89830F2682B67B5DC158E2753C',
                    exponent: 0,
                    aliases: [
                        'uatom'
                    ]
                },
                {
                    denom: 'atom',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9FF2B7A5F55038A7EE61F4FD6749D9A648B48E89830F2682B67B5DC158E2753C',
            name: 'Cosmos Hub Public Testnet',
            display: 'atom',
            symbol: 'ATOM',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'cosmoshubtestnet',
                        baseDenom: 'uatom',
                        channelId: 'channel-3306'
                    },
                    chain: {
                        channelId: 'channel-4156',
                        path: 'transfer/channel-4156/uatom'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'cosmoshubtestnet',
                        baseDenom: 'uatom'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/cosmoshub/images/atom.svg'
                }
            ]
        },
        {
            description: 'Circle\'s stablecoin on Axelar',
            denomUnits: [
                {
                    denom: 'ibc/2164BDB48DE5501430E71286448D87C6D2240EC0E078CF113CAB85E21A352BB0',
                    exponent: 0
                },
                {
                    denom: 'ausdc',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/2164BDB48DE5501430E71286448D87C6D2240EC0E078CF113CAB85E21A352BB0',
            name: 'USD Coin (Axelar)',
            display: 'ausdc',
            symbol: 'aUSDC.axl',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'forex',
                        baseDenom: 'USD'
                    },
                    provider: 'Circle'
                },
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereumtestnet',
                        baseDenom: '0x254d06f33bDc5b8ee05b2ea472107E300226659A'
                    },
                    provider: 'Axelar'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'uausdc',
                        channelId: 'channel-339'
                    },
                    chain: {
                        channelId: 'channel-4170',
                        path: 'transfer/channel-4170/uausdc'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'ethereumtestnet',
                        baseDenom: '0x254d06f33bDc5b8ee05b2ea472107E300226659A'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
                }
            ]
        },
        {
            description: 'Wrapped Ether on Axelar',
            denomUnits: [
                {
                    denom: 'ibc/1F42AC9631DBE03009219ECCFE151786F53A038DE9F7A07C709158514F1D5942',
                    exponent: 0,
                    aliases: [
                        'eth-wei'
                    ]
                },
                {
                    denom: 'weth',
                    exponent: 18
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/1F42AC9631DBE03009219ECCFE151786F53A038DE9F7A07C709158514F1D5942',
            name: 'Wrapped Ether (Axelar)',
            display: 'weth',
            symbol: 'ETH',
            traces: [
                {
                    type: 'wrapped',
                    counterparty: {
                        chainName: 'ethereumtestnet',
                        baseDenom: 'wei'
                    },
                    provider: 'Ethereum'
                },
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'ethereumtestnet',
                        baseDenom: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6'
                    },
                    provider: 'Axelar'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'axelartestnet',
                        baseDenom: 'eth-wei',
                        channelId: 'channel-339'
                    },
                    chain: {
                        channelId: 'channel-4170',
                        path: 'transfer/channel-4170/eth-wei'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'ethereumtestnet',
                        baseDenom: '0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/weth.svg'
                }
            ]
        },
        {
            description: 'The native token of JUNO Chain',
            denomUnits: [
                {
                    denom: 'ibc/31D220286E6C224C0F72D890D0EB75A228D388089EF5C4D77212344F9EAF0183',
                    exponent: 0,
                    aliases: [
                        'ujunox'
                    ]
                },
                {
                    denom: 'junox',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/31D220286E6C224C0F72D890D0EB75A228D388089EF5C4D77212344F9EAF0183',
            name: 'Juno Testnet',
            display: 'junox',
            symbol: 'JUNOX',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'junotestnet6',
                        baseDenom: 'ujunox',
                        channelId: 'channel-889'
                    },
                    chain: {
                        channelId: 'channel-5498',
                        path: 'transfer/channel-5498/ujunox'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/junotestnet/images/juno.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/junotestnet/images/juno.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'junotestnet',
                        baseDenom: 'ujunox'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/junotestnet/images/juno.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/junotestnet/images/juno.svg'
                }
            ],
            coingeckoId: 'juno-network'
        },
        {
            description: 'The native token of Mars Protocol',
            denomUnits: [
                {
                    denom: 'ibc/66A7ADA623D33D0B66C6890FE3E1AF3D638D56CE2B56F8BDA210B2AA62016216',
                    exponent: 0,
                    aliases: [
                        'umars'
                    ]
                },
                {
                    denom: 'mars',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/66A7ADA623D33D0B66C6890FE3E1AF3D638D56CE2B56F8BDA210B2AA62016216',
            name: 'Mars Hub Testnet',
            display: 'mars',
            symbol: 'MARS',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'marstestnet',
                        baseDenom: 'umars',
                        channelId: 'channel-28'
                    },
                    chain: {
                        channelId: 'channel-5499',
                        path: 'transfer/channel-5499/umars'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'marstestnet',
                        baseDenom: 'umars'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/neutron/images/mars-token.svg'
                }
            ]
        },
        {
            description: 'USD Coin',
            denomUnits: [
                {
                    denom: 'ibc/DE6792CF9E521F6AD6E9A4BDF6225C9571A3B74ACC0A529F92BC5122A39D2E58',
                    exponent: 0,
                    aliases: [
                        'microusdc',
                        'uusdc'
                    ]
                },
                {
                    denom: 'usdc',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/DE6792CF9E521F6AD6E9A4BDF6225C9571A3B74ACC0A529F92BC5122A39D2E58',
            name: 'USD Coin',
            display: 'usdc',
            symbol: 'USDC',
            traces: [
                {
                    type: 'synthetic',
                    counterparty: {
                        chainName: 'forex',
                        baseDenom: 'USD'
                    },
                    provider: 'Circle'
                },
                {
                    type: 'additional-mintage',
                    counterparty: {
                        chainName: 'ethereum',
                        baseDenom: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
                    },
                    provider: 'Circle'
                },
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'noble',
                        baseDenom: 'uusdc'
                    },
                    provider: 'Circle'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'nobletestnet',
                        baseDenom: 'uusdc',
                        channelId: 'channel-22'
                    },
                    chain: {
                        channelId: 'channel-4280',
                        path: 'transfer/channel-4280/uusdc'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'nobletestnet',
                        baseDenom: 'uusdc'
                    },
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/_non-cosmos/ethereum/images/usdc.png',
                    theme: {
                        circle: true,
                        primaryColorHex: '#2775CA'
                    }
                }
            ],
            coingeckoId: 'usd-coin'
        },
        {
            description: 'Akash Token (AKT) is the Akash Network\'s native utility token, used as the primary means to govern, secure the blockchain, incentivize participants, and provide a default mechanism to store and exchange value.',
            denomUnits: [
                {
                    denom: 'ibc/AD59D59CFB0E628E73C798415F823AB5B6257C2FE4BF67DBB5D6A677B2686E82',
                    exponent: 0,
                    aliases: [
                        'uakt'
                    ]
                },
                {
                    denom: 'akt',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/AD59D59CFB0E628E73C798415F823AB5B6257C2FE4BF67DBB5D6A677B2686E82',
            name: 'Sandbox',
            display: 'akt',
            symbol: 'AKT',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'akashtestnet',
                        baseDenom: 'uakt',
                        channelId: 'channel-6'
                    },
                    chain: {
                        channelId: 'channel-4171',
                        path: 'transfer/channel-4171/uakt'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/akash/images/akt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/akash/images/akt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'akashtestnet',
                        baseDenom: 'uakt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/akash/images/akt.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/akash/images/akt.svg'
                }
            ]
        },
        {
            description: 'The native utility token of the Kaon testnet version of KYVE.',
            denomUnits: [
                {
                    denom: 'ibc/AB8AF05799E299FB5C5C80781DA35887F53E029745D20E5641233DB4E6B28515',
                    exponent: 0,
                    aliases: [
                        'tkyve'
                    ]
                },
                {
                    denom: 'kyve',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/AB8AF05799E299FB5C5C80781DA35887F53E029745D20E5641233DB4E6B28515',
            name: 'KYVE Kaon',
            display: 'kyve',
            symbol: 'KYVE',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'kyve',
                        baseDenom: 'ukyve'
                    },
                    provider: 'Kyve'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'kyvetestnet',
                        baseDenom: 'tkyve',
                        channelId: 'channel-2'
                    },
                    chain: {
                        channelId: 'channel-10',
                        path: 'transfer/channel-10/tkyve'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/kyve/images/kyve-token.svg',
                    imageSync: {
                        chainName: 'kyve',
                        baseDenom: 'ukyve'
                    },
                    theme: {
                        primaryColorHex: '#335350'
                    }
                }
            ],
            coingeckoId: 'kyve-network'
        },
        {
            description: 'QCK - native token of Quicksilver',
            denomUnits: [
                {
                    denom: 'ibc/F37CF69589DE12342758382F8770C0852CD8D2E4519F55166EBDAF472AD667C9',
                    exponent: 0,
                    aliases: [
                        'uqck'
                    ]
                },
                {
                    denom: 'qck',
                    exponent: 6,
                    aliases: []
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/F37CF69589DE12342758382F8770C0852CD8D2E4519F55166EBDAF472AD667C9',
            name: 'Quicksilver Testnet',
            display: 'qck',
            symbol: 'QCK',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'quicksilvertestnet2',
                        baseDenom: 'uqck',
                        channelId: 'channel-20'
                    },
                    chain: {
                        channelId: 'channel-13',
                        path: 'transfer/channel-13/uqck'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/quicksilver/images/qck.png'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'quicksilvertestnet2',
                        baseDenom: 'uqck'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/quicksilver/images/qck.png'
                }
            ],
            coingeckoId: 'quicksilver'
        },
        {
            description: 'The XPRT token is primarily a governance token for the Persistence chain.',
            denomUnits: [
                {
                    denom: 'ibc/754C8533F8A418B03AD5F2C6AA19D4703CF78BBAB9E2E4DDD6212AAC2E502CA6',
                    exponent: 0,
                    aliases: [
                        'uxprt'
                    ]
                },
                {
                    denom: 'xprt',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/754C8533F8A418B03AD5F2C6AA19D4703CF78BBAB9E2E4DDD6212AAC2E502CA6',
            name: 'Persistence Testnet',
            display: 'xprt',
            symbol: 'XPRT',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'persistencetestnet2',
                        baseDenom: 'uxprt',
                        channelId: 'channel-7'
                    },
                    chain: {
                        channelId: 'channel-1037',
                        path: 'transfer/channel-1037/uxprt'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/persistence/images/xprt.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/persistence/images/xprt.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'persistencetestnet2',
                        baseDenom: 'uxprt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/persistence/images/xprt.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/persistence/images/xprt.svg'
                }
            ],
            coingeckoId: 'persistence'
        },
        {
            description: 'The native token of Saga Testnet',
            denomUnits: [
                {
                    denom: 'ibc/48384130079A5987378F5776775F8C29A02505273E777BBB99361F2BB5B577C9',
                    exponent: 0,
                    aliases: [
                        'utsaga'
                    ]
                },
                {
                    denom: 'tsaga',
                    exponent: 6,
                    aliases: []
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/48384130079A5987378F5776775F8C29A02505273E777BBB99361F2BB5B577C9',
            name: 'Saga Testnet',
            display: 'tsaga',
            symbol: 'TSAGA',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'sagatestnet',
                        baseDenom: 'utsaga',
                        channelId: 'channel-20'
                    },
                    chain: {
                        channelId: 'channel-4946',
                        path: 'transfer/channel-4946/utsaga'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/saga/images/saga.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/saga/images/saga.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'sagatestnet',
                        baseDenom: 'utsaga'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/saga/images/saga.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/saga/images/saga.svg'
                }
            ]
        },
        {
            description: 'The native token of IXO Chain',
            denomUnits: [
                {
                    denom: 'ibc/88C815D69587CF0F05E96E5E2731EA56194D73C9A02A500095294D3A5DE68F16',
                    exponent: 0,
                    aliases: [
                        'uixo'
                    ]
                },
                {
                    denom: 'ixo',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/88C815D69587CF0F05E96E5E2731EA56194D73C9A02A500095294D3A5DE68F16',
            name: 'ixo',
            display: 'ixo',
            symbol: 'IXO',
            traces: [
                {
                    type: 'test-mintage',
                    counterparty: {
                        chainName: 'impacthub',
                        baseDenom: 'uixo'
                    },
                    provider: 'impacthub'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'impacthubtestnet',
                        baseDenom: 'uixo',
                        channelId: 'channel-10'
                    },
                    chain: {
                        channelId: 'channel-1637',
                        path: 'transfer/channel-1637/uixo'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/impacthub/images/ixo.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/impacthub/images/ixo.svg'
            },
            images: [
                {
                    imageSync: {
                        chainName: 'impacthub',
                        baseDenom: 'uixo'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/impacthub/images/ixo.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/impacthub/images/ixo.svg',
                    theme: {
                        primaryColorHex: '#2c4484'
                    }
                }
            ],
            coingeckoId: 'ixo'
        },
        {
            denomUnits: [
                {
                    denom: 'factory/osmo1zlkzu72774ynac53necz46u4ycqtp36wedrar0/willyz',
                    exponent: 0
                },
                {
                    denom: 'willyz',
                    exponent: 6
                }
            ],
            base: 'factory/osmo1zlkzu72774ynac53necz46u4ycqtp36wedrar0/willyz',
            name: 'Willyz',
            display: 'willyz',
            symbol: 'WILLYZ',
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/osmosistestnet/images/willyz.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/osmosistestnet/images/willyz.svg'
            },
            keywords: [
                'memecoin'
            ],
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/osmosistestnet/images/willyz.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/testnets/osmosistestnet/images/willyz.svg'
                }
            ],
            typeAsset: 'sdk.coin'
        },
        {
            description: 'TIMMY Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/1675C95A6F253E9FA7AFD2B4549A551F567FCB3FB7FF3978163E400FA0718D29',
                    exponent: 0
                },
                {
                    denom: 'timmy',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/1675C95A6F253E9FA7AFD2B4549A551F567FCB3FB7FF3978163E400FA0718D29',
            name: 'TIMMY',
            display: 'timmy',
            symbol: 'TIMMY',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1c799jddmlz7segvg6jrw6w2k6svwafganjdznard3tc74n7td7rqdqe6ks/utimmy',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1c799jddmlz7segvg6jrw6w2k6svwafganjdznard3tc74n7td7rqdqe6ks/utimmy'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1c799jddmlz7segvg6jrw6w2k6svwafganjdznard3tc74n7td7rqdqe6ks/utimmy'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'SIMPLE Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/1BAC7171193B1FED44024C08E460D4CA59DCDCEF76C56340AF8057C0D8C49634',
                    exponent: 0
                },
                {
                    denom: 'simple',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/1BAC7171193B1FED44024C08E460D4CA59DCDCEF76C56340AF8057C0D8C49634',
            name: 'SIMPLE',
            display: 'simple',
            symbol: 'SIMPLE',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/usimple',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/usimple'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/usimple'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'AGA Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/1DE9DEEEB9EF636EF8F6B54A3F12655911908DA0039921D671E3282BBDF36D23',
                    exponent: 0
                },
                {
                    denom: 'aga',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/1DE9DEEEB9EF636EF8F6B54A3F12655911908DA0039921D671E3282BBDF36D23',
            name: 'AGA',
            display: 'aga',
            symbol: 'AGA',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uaga',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uaga'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uaga'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'CUTE Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/3F779F3860A4794972D03865FE273EC81B24CF0CCAE223165776D8442B62A8B2',
                    exponent: 0
                },
                {
                    denom: 'cute',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/3F779F3860A4794972D03865FE273EC81B24CF0CCAE223165776D8442B62A8B2',
            name: 'CUTE',
            display: 'cute',
            symbol: 'CUTE',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ucute',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ucute'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ucute'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'FUNZIE Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/708B876DB3632A7490D6477F365EABF1414E6F60F60CAEC1FB6F06760451ACBE',
                    exponent: 0
                },
                {
                    denom: 'funzie',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/708B876DB3632A7490D6477F365EABF1414E6F60F60CAEC1FB6F06760451ACBE',
            name: 'FUNZIE',
            display: 'funzie',
            symbol: 'FUNZIE',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/ufunzie',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/ufunzie'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/ufunzie'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'GOZER Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/77DA06A20632C7AB6396B40989FCFB942CD2D56E107F402C595F010455B76BE1',
                    exponent: 0
                },
                {
                    denom: 'gozer',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/77DA06A20632C7AB6396B40989FCFB942CD2D56E107F402C595F010455B76BE1',
            name: 'GOZER',
            display: 'gozer',
            symbol: 'GOZER',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugozer',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugozer'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugozer'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'DANCINGPENGUIN Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/7A4DD8299304AA9D4D86B06584C56EE08C26F6F7338F2CADC5D3A8D6895A3859',
                    exponent: 0
                },
                {
                    denom: 'dancingpenguin',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/7A4DD8299304AA9D4D86B06584C56EE08C26F6F7338F2CADC5D3A8D6895A3859',
            name: 'DANCINGPENGUIN',
            display: 'dancingpenguin',
            symbol: 'DANCINGPENGUIN',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udancingpenguin',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udancingpenguin'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udancingpenguin'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'ADAM Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/A9B2FC600298D994291B87D6452663514C88AE078F56228B584862641B0E2D6C',
                    exponent: 0
                },
                {
                    denom: 'adam',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/A9B2FC600298D994291B87D6452663514C88AE078F56228B584862641B0E2D6C',
            name: 'ADAM',
            display: 'adam',
            symbol: 'ADAM',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uadam',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uadam'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uadam'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'DRIPPY Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/AB89909B308854835AD98DEF0DE18D1B324A12A443335398945E485A9B69AE34',
                    exponent: 0
                },
                {
                    denom: 'drippy',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/AB89909B308854835AD98DEF0DE18D1B324A12A443335398945E485A9B69AE34',
            name: 'DRIPPY',
            display: 'drippy',
            symbol: 'DRIPPY',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udrippy',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udrippy'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/udrippy'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'GAS Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/AF2EFBAABB4A14F6E50D83D550698FE33CC2565B7DB1CA480CAF07C7557D8277',
                    exponent: 0
                },
                {
                    denom: 'gas',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/AF2EFBAABB4A14F6E50D83D550698FE33CC2565B7DB1CA480CAF07C7557D8277',
            name: 'GAS',
            display: 'gas',
            symbol: 'GAS',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugas',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugas'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/ugas'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'MFX Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/71C8E0B309E2F2A4C66F85E7C34C4415A3D26E489DBDF3FFF4EDCBE15B229B14',
                    exponent: 0
                },
                {
                    denom: 'mfx',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/71C8E0B309E2F2A4C66F85E7C34C4415A3D26E489DBDF3FFF4EDCBE15B229B14',
            name: 'MFX',
            display: 'mfx',
            symbol: 'MFX',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'umfx',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/umfx'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'umfx'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'TACO Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/D926A833F572447AC30E189FD1629560E679CF73170C180681B9FE29FB3BA2B6',
                    exponent: 0
                },
                {
                    denom: 'taco',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/D926A833F572447AC30E189FD1629560E679CF73170C180681B9FE29FB3BA2B6',
            name: 'TACO',
            display: 'taco',
            symbol: 'TACO',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/utaco',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/utaco'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/utaco'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'UMEGA Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/E09C607844E95C9338079729100E026CA5FA357DD41AFEA17FA5889535299009',
                    exponent: 0
                },
                {
                    denom: 'umega',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/E09C607844E95C9338079729100E026CA5FA357DD41AFEA17FA5889535299009',
            name: 'UMEGA',
            display: 'umega',
            symbol: 'UMEGA',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1czvrq3ufn045q5k50tjl4qu8kcmagve9ghty3c/uumega',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1czvrq3ufn045q5k50tjl4qu8kcmagve9ghty3c/uumega'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1czvrq3ufn045q5k50tjl4qu8kcmagve9ghty3c/uumega'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'WMVT Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/E58506AA351C65F86C8DCD019C57682BA7489D2277C978D5977DFA8FE4B808E6',
                    exponent: 0
                },
                {
                    denom: 'wmvt',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/E58506AA351C65F86C8DCD019C57682BA7489D2277C978D5977DFA8FE4B808E6',
            name: 'WMVT',
            display: 'wmvt',
            symbol: 'WMVT',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uwmvt',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uwmvt'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uwmvt'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'SPOOF Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/E96950EBFD6690785604A4B835C8FCA238927E96C2ABCF6F51725DA872699E33',
                    exponent: 0
                },
                {
                    denom: 'spoof',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/E96950EBFD6690785604A4B835C8FCA238927E96C2ABCF6F51725DA872699E33',
            name: 'SPOOF',
            display: 'spoof',
            symbol: 'SPOOF',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uspoof',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uspoof'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uspoof'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'ASDASDASD Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/EAF2ADEA5251B1FC527B407FD36BE64B572ACE19BCC325544604C5E8DE8C605E',
                    exponent: 0
                },
                {
                    denom: 'asdasdasd',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/EAF2ADEA5251B1FC527B407FD36BE64B572ACE19BCC325544604C5E8DE8C605E',
            name: 'ASDASDASD',
            display: 'asdasdasd',
            symbol: 'ASDASDASD',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uasdasdasd',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uasdasdasd'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1hj5fveer5cjtn4wd6wstzugjfdxzl0xp8ws9ct/uasdasdasd'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'SNOOP Token on Manifest Ledger Testnet',
            denomUnits: [
                {
                    denom: 'ibc/F5C09D41BEA7D1E30AE6CB0D303E9DF5C4D0A16859329973FEAD94A1DA279643',
                    exponent: 0
                },
                {
                    denom: 'snoop',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/F5C09D41BEA7D1E30AE6CB0D303E9DF5C4D0A16859329973FEAD94A1DA279643',
            name: 'SNOOP',
            display: 'snoop',
            symbol: 'SNOOP',
            traces: [
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/usnoop',
                        channelId: 'channel-5'
                    },
                    chain: {
                        channelId: 'channel-10183',
                        path: 'transfer/channel-10183/factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/usnoop'
                    }
                }
            ],
            images: [
                {
                    imageSync: {
                        chainName: 'manifesttestnet',
                        baseDenom: 'factory/manifest1rme50egv6kwxq5skm60s0n7hd6ynuf33p5g87e/usnoop'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/manifest/images/manifest.svg'
            }
        },
        {
            description: 'Testnet DOGE from Dogecoin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/FCB9537564D517E821D0438AB6CA3BBE03B9E2B2C661B89311181329DFD331C4',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    ]
                },
                {
                    denom: 'doge',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/FCB9537564D517E821D0438AB6CA3BBE03B9E2B2C661B89311181329DFD331C4',
            name: 'Testnet Dogecoin (Int3)',
            display: 'doge',
            symbol: 'DOGE.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'dogecointestnet',
                        baseDenom: 'shibe'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/doge.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/doge.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/doge.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/doge.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/dogecoin-doge'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/doge.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet BTC from Bitcoin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/68157A7910F47A17C4BA8E06180FA4E5D6E3DF8A8F2B2FD4A74F23597BC1ABBF',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    ]
                },
                {
                    denom: 'btc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/68157A7910F47A17C4BA8E06180FA4E5D6E3DF8A8F2B2FD4A74F23597BC1ABBF',
            name: 'Testnet Bitcoin (Int3)',
            display: 'btc',
            symbol: 'BTC.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'bitcointestnet',
                        baseDenom: 'sat'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/btc.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/btc.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/btc.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/btc.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-btc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/btc.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet BCH from Bitcoin-Cash bridged via  Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/B746CC188C8315EE135101C7F77D361AF6A62A4740EEDBB99A8AC5A80246D719',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    ]
                },
                {
                    denom: 'bch',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/B746CC188C8315EE135101C7F77D361AF6A62A4740EEDBB99A8AC5A80246D719',
            name: 'Testnet Bitcoin Cash (Int3)',
            display: 'bch',
            symbol: 'BCH.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'bitcoincashtestnet',
                        baseDenom: 'sat'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/bch.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/bch.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/bch.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/bch.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/bitcoin-cash-bch'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/bch.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet LTC from Litecoin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/713D13C42B4EC1327AAD87602393D8870089B59005F552289E46141ABCF79F4C',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    ]
                },
                {
                    denom: 'ltc',
                    exponent: 8
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/713D13C42B4EC1327AAD87602393D8870089B59005F552289E46141ABCF79F4C',
            name: 'Testnet Litecoin (Int3)',
            display: 'ltc',
            symbol: 'LTC.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'litecointestnet',
                        baseDenom: 'litoshi'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ltc.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ltc.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ltc.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ltc.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/litecoin-ltc'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ltc.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet TON coin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/17993F75F724B0CB68D0C26642007CDD62286010974B843F86507F383E9F19F3',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/ton-ton'
                    ]
                },
                {
                    denom: 'ton',
                    exponent: 9
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/17993F75F724B0CB68D0C26642007CDD62286010974B843F86507F383E9F19F3',
            name: 'Testnet Toncoin (Int3)',
            display: 'ton',
            symbol: 'TON.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'tontestnet',
                        baseDenom: 'nanoton'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/ton-ton',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/ton-ton'
                    }
                }
            ],
            logoURIs: {
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ton.int3.svg',
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ton.int3.png'
            },
            images: [
                {
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ton.int3.svg',
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/ton.int3.png'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/ton-ton'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ton.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/ton.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet Solana (SOL) coin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/931C1E953C5312AB6856BDE136EFBD43FAC52398E484CA2C344F623746BAC4BE',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/solana-sol'
                    ]
                },
                {
                    denom: 'sol',
                    exponent: 9
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/931C1E953C5312AB6856BDE136EFBD43FAC52398E484CA2C344F623746BAC4BE',
            name: 'Testnet SOL (Int3)',
            display: 'sol',
            symbol: 'SOL.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'solanatestnet',
                        baseDenom: 'Lamport'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/solana-sol',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/solana-sol'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/sol.int3.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/sol.int3.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/sol.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/sol.int3.svg'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/solana-sol'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/sol.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/sol.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        },
        {
            description: 'Testnet XRPL (XRP) coin bridged via Int3face bridge',
            denomUnits: [
                {
                    denom: 'ibc/9D44B9A113D449A16FAB9F639FF5B074CAB6D33D049056AB6B4DCE6E3891DD55',
                    exponent: 0,
                    aliases: [
                        'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/xrpl-xrp'
                    ]
                },
                {
                    denom: 'xrp',
                    exponent: 6
                }
            ],
            typeAsset: 'ics20',
            base: 'ibc/9D44B9A113D449A16FAB9F639FF5B074CAB6D33D049056AB6B4DCE6E3891DD55',
            name: 'Testnet XRP (Int3)',
            display: 'xrp',
            symbol: 'XRP.int3',
            traces: [
                {
                    type: 'bridge',
                    counterparty: {
                        chainName: 'xrpltestnet',
                        baseDenom: 'drop'
                    },
                    provider: 'Int3face'
                },
                {
                    type: 'ibc',
                    counterparty: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/xrpl-xrp',
                        channelId: 'channel-1'
                    },
                    chain: {
                        channelId: 'channel-9755',
                        path: 'transfer/channel-9755/factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/xrpl-xrp'
                    }
                }
            ],
            logoURIs: {
                png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/xrp.int3.png',
                svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/xrp.int3.svg'
            },
            images: [
                {
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/xrp.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/xrp.int3.svg'
                },
                {
                    imageSync: {
                        chainName: 'int3facetestnet',
                        baseDenom: 'factory/int31zlefkpe3g0vvm9a4h0jf9000lmqutlh99h7fsd/xrpl-xrp'
                    },
                    png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/xrp.int3.png',
                    svg: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/int3face/images/xrp.int3.svg',
                    theme: {
                        primaryColorHex: '#3d3d3d'
                    }
                }
            ]
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/chain.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = {
    $schema: '../../chain.schema.json',
    chainName: 'osmosistestnet',
    status: 'live',
    networkType: 'testnet',
    prettyName: 'Osmosis Testnet',
    chainType: 'cosmos',
    chainId: 'osmo-test-5',
    bech32Prefix: 'osmo',
    daemonName: 'osmosisd',
    nodeHome: '$HOME/.osmosisd',
    keyAlgos: [
        'secp256k1'
    ],
    slip44: 118,
    fees: {
        feeTokens: [
            {
                denom: 'uosmo',
                fixedMinGasPrice: 0,
                lowGasPrice: 0.0025,
                averageGasPrice: 0.025,
                highGasPrice: 0.04
            }
        ]
    },
    staking: {
        stakingTokens: [
            {
                denom: 'uosmo'
            }
        ]
    },
    codebase: {
        gitRepo: 'https://github.com/osmosis-labs/osmosis',
        recommendedVersion: '29.0.0',
        compatibleVersions: [
            '29.0.0-rc1',
            '29.0.0'
        ]
    },
    apis: {
        rpc: [
            {
                address: 'https://rpc.osmotest5.osmosis.zone/',
                provider: 'Osmosis'
            },
            {
                address: 'https://osmosis-testnet-tendermint.reliableninjas.com',
                provider: 'Reliable Ninjas'
            }
        ],
        rest: [
            {
                address: 'https://lcd.osmotest5.osmosis.zone/',
                provider: 'Osmosis'
            },
            {
                address: 'https://osmosis-testnet-cosmos.reliableninjas.com',
                provider: 'Reliable Ninjas'
            }
        ],
        grpc: [
            {
                address: 'https://grpc.osmotest5.osmosis.zone/',
                provider: 'Osmosis'
            }
        ]
    },
    logoURIs: {
        png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmosis-chain-logo.png'
    },
    explorers: [
        {
            kind: 'mintscan',
            url: 'https://mintscan.io/osmosis-testnet',
            txPage: 'https://mintscan.io/osmosis-testnet/txs/${txHash}',
            accountPage: 'https://mintscan.io/osmosis-testnet/account/${accountAddress}'
        },
        {
            kind: 'ping.pub',
            url: 'https://explorer.osmotest5.osmosis.zone',
            txPage: 'https://explorer.osmotest5.osmosis.zone/osmo-test-5/tx/${txHash}',
            accountPage: 'https://explorer.osmotest5.osmosis.zone/osmo-test-5/account/${accountAddress}'
        }
    ],
    keywords: [
        'dex',
        'testnet'
    ],
    images: [
        {
            png: 'https://raw.githubusercontent.com/cosmos/chain-registry/master/osmosis/images/osmosis-chain-logo.png'
        }
    ]
};
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/ibc-data.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const info = [
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'agoricdevnet',
            clientId: '07-tendermint-6',
            connectionId: 'connection-6'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4596',
            connectionId: 'connection-3957'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10293',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'akashtestnet',
            clientId: '07-tendermint-6',
            connectionId: 'connection-6'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1271',
            connectionId: 'connection-1171'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-6',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4171',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'archwaytestnet',
            clientId: '07-tendermint-121',
            connectionId: 'connection-120'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3459',
            connectionId: 'connection-3027'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-225',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-7779',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live'
                }
            },
            {
                chain1: {
                    channelId: '*',
                    portId: 'wasm.*'
                },
                chain2: {
                    channelId: '*',
                    portId: 'icahost'
                },
                ordering: 'ordered',
                version: 'ics27-1',
                tags: {
                    status: 'live'
                }
            },
            {
                chain1: {
                    channelId: '*',
                    portId: 'wasm.*'
                },
                chain2: {
                    channelId: '*',
                    portId: 'icqhost'
                },
                ordering: 'unordered',
                version: 'icq-1',
                tags: {
                    status: 'live'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'axelartestnet',
            clientId: '07-tendermint-685',
            connectionId: 'connection-538'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1270',
            connectionId: 'connection-1169'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-339',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4170',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'babylontestnet',
            clientId: '07-tendermint-31',
            connectionId: 'connection-29'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4636',
            connectionId: 'connection-3994'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-21',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10366',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            },
            {
                chain1: {
                    channelId: 'channel-22',
                    portId: 'wasm.bbn17tu5q57xdf3u4m0u8j4mnjlcwe9kt4n87fmc4cdnrkf9zungn7wsjfhts0'
                },
                chain2: {
                    channelId: 'channel-10367',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    description: 'cw20-ics20'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'celestiatestnet3',
            clientId: '07-tendermint-118',
            connectionId: 'connection-98'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1445',
            connectionId: 'connection-1350'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-25',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4370',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'chain4energytestnet',
            clientId: '07-tendermint-18',
            connectionId: 'connection-5'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3393',
            connectionId: 'connection-2989'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-7735',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'composabletestnet',
            clientId: '07-tendermint-23',
            connectionId: 'connection-18'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-273',
            connectionId: 'connection-237'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-11',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-329',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'coreumtestnet',
            clientId: '07-tendermint-104',
            connectionId: 'connection-69'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3529',
            connectionId: 'connection-3094'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-47',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-7894',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'cosmoshubtestnet',
            clientId: '07-tendermint-2528',
            connectionId: 'connection-2886'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1262',
            connectionId: 'connection-1157'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-3306',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4156',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'doravotatestnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-3'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-611'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1260',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'empowertestnet',
            clientId: '07-tendermint-1',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-146',
            connectionId: 'connection-157'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-155',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'entrypointtestnet',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-930',
            connectionId: 'connection-840'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1543',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'impacthubtestnet',
            clientId: '07-tendermint-53',
            connectionId: 'connection-23'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1010',
            connectionId: 'connection-911'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1637',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'injectivetestnet',
            clientId: '07-tendermint-305',
            connectionId: 'connection-272'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4379',
            connectionId: 'connection-3814'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-77026',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10092',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'int3facetestnet',
            clientId: '07-tendermint-3',
            connectionId: 'connection-3'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4231',
            connectionId: 'connection-3694'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-9755',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'junotestnet6',
            clientId: '07-tendermint-743',
            connectionId: 'connection-827'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1932',
            connectionId: 'connection-1889'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-889',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5498',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'killed',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'kimanetworktestnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4135',
            connectionId: 'connection-3592'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-9247',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'kyvetestnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-11',
            connectionId: 'connection-11'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-10',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'lavatestnet',
            clientId: '07-tendermint-11',
            connectionId: 'connection-11'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-2554',
            connectionId: 'connection-2401'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-6092',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'likecointestnet',
            clientId: '07-tendermint-5',
            connectionId: 'connection-2'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1431',
            connectionId: 'connection-1336'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4357',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'manifesttestnet',
            clientId: '07-tendermint-8',
            connectionId: 'connection-9'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4456',
            connectionId: 'connection-3898'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer',
                    clientId: '07-tendermint-8',
                    connectionId: 'connection-9'
                },
                chain2: {
                    channelId: 'channel-10183',
                    portId: 'transfer',
                    clientId: '07-tendermint-4456',
                    connectionId: 'connection-3898'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'mantrachaintestnet',
            clientId: '07-tendermint-5',
            connectionId: 'connection-5'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3930',
            connectionId: 'connection-3411'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-8734',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'mantrachaintestnet2',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4086',
            connectionId: 'connection-3531'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-9126',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'marstestnet',
            clientId: '07-tendermint-33',
            connectionId: 'connection-30'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1933',
            connectionId: 'connection-1890'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-28',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5499',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'neutrontestnet',
            clientId: '07-tendermint-133',
            connectionId: 'connection-123'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1272',
            connectionId: 'connection-1172'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-196',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4172',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'nobletestnet',
            clientId: '07-tendermint-42',
            connectionId: 'connection-31'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1374',
            connectionId: 'connection-1275'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-22',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-4280',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'nolustestnet',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3711',
            connectionId: 'connection-3235'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-8272',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'nolustestnet1',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        chain2: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-102',
            connectionId: 'connection-120'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-110',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-595',
            connectionId: 'connection-529'
        },
        chain2: {
            chainName: 'persistencetestnet2',
            clientId: '07-tendermint-3',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1037',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-7',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-19',
            connectionId: 'connection-14'
        },
        chain2: {
            chainName: 'quicksilvertestnet2',
            clientId: '07-tendermint-6',
            connectionId: 'connection-4'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-13',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-20',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'killed',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1448',
            connectionId: 'connection-1552'
        },
        chain2: {
            chainName: 'sagatestnet',
            clientId: '07-tendermint-26',
            connectionId: 'connection-21'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4946',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-20',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-965',
            connectionId: 'connection-865'
        },
        chain2: {
            chainName: 'sgetestnet',
            clientId: '07-tendermint-1',
            connectionId: 'connection-1'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-1568',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-1274',
            connectionId: 'connection-1175'
        },
        chain2: {
            chainName: 'stargazetestnet',
            clientId: '07-tendermint-621',
            connectionId: 'connection-633'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-4175',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-638',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3714',
            connectionId: 'connection-3238'
        },
        chain2: {
            chainName: 'swisstroniktestnet',
            clientId: '07-tendermint-31',
            connectionId: 'connection-18'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8295',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4155',
            connectionId: 'connection-3614'
        },
        chain2: {
            chainName: 'symphonytestnet',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9540',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3946',
            connectionId: 'connection-3419'
        },
        chain2: {
            chainName: 'symphonytestnet3',
            clientId: '07-tendermint-0',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-8743',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4093',
            connectionId: 'connection-3540'
        },
        chain2: {
            chainName: 'synternettestnet',
            clientId: '07-tendermint-3',
            connectionId: 'connection-0'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9152',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-0',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: false,
                    dex: 'osmosis'
                }
            },
            {
                chain1: {
                    channelId: 'channel-85186',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-1',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4301',
            connectionId: 'connection-3765'
        },
        chain2: {
            chainName: 'titannettestnet',
            clientId: '07-tendermint-7',
            connectionId: 'connection-5'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-9941',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-5',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-2436',
            connectionId: 'connection-2267'
        },
        chain2: {
            chainName: 'titantestnet',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-5969',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'killed',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-3125',
            connectionId: 'connection-2826'
        },
        chain2: {
            chainName: 'xiontestnet',
            clientId: '07-tendermint-121',
            connectionId: 'connection-57'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-6668',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-490',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live'
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4492',
            connectionId: 'connection-3926'
        },
        chain2: {
            chainName: 'xiontestnet2',
            clientId: '07-tendermint-2',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-10231',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true
                }
            }
        ]
    },
    {
        $schema: '../../ibc_data.schema.json',
        chain1: {
            chainName: 'osmosistestnet',
            clientId: '07-tendermint-4629',
            connectionId: 'connection-3984'
        },
        chain2: {
            chainName: 'xrplevmtestnet',
            clientId: '07-tendermint-10',
            connectionId: 'connection-2'
        },
        channels: [
            {
                chain1: {
                    channelId: 'channel-10361',
                    portId: 'transfer'
                },
                chain2: {
                    channelId: 'channel-2',
                    portId: 'transfer'
                },
                ordering: 'unordered',
                version: 'ics20-1',
                tags: {
                    status: 'live',
                    preferred: true,
                    dex: 'osmosis'
                }
            }
        ]
    }
];
const __TURBOPACK__default__export__ = info;
}}),
"[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "assetList": (()=>assetList),
    "chain": (()=>chain),
    "ibcData": (()=>ibcData)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/asset-list.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/chain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@chain-registry/v2/esm/testnet/osmosistestnet/ibc-data.js [app-client] (ecmascript)");
;
;
;
const assetList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$asset$2d$list$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const chain = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$chain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
const ibcData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$chain$2d$registry$2f$v2$2f$esm$2f$testnet$2f$osmosistestnet$2f$ibc$2d$data$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
}}),
}]);

//# sourceMappingURL=node_modules_%40chain-registry_v2_esm_testnet_osmosistestnet_040a6c06._.js.map